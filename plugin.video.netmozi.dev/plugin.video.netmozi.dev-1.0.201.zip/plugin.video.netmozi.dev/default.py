# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
from urllib.parse import parse_qsl

# A hozzászólás-kérés fájlneve. Ugyanaz, mint comments.REQUEST_FILE -- azt
# NEM importáljuk, mert a modul a nehéz importláncot húzná be; a tesztsor
# ellenőrzi, hogy a kettő egyezik.
COMMENT_REQUEST_FILE = 'comments.request'


def quick_comment_request():
    """
    Jelzés a háttérszolgáltatásnak, hogy hozza vissza a hozzászólásokat.

    SZÁNDÉKOSAN a nehéz importok ELŐTT fut le, és csak azt tölti be, amire
    tényleg szükség van. A Kodi minden gombnyomásra új folyamatot indít, és
    a navigator importja (resolveurl, requests, tíz belső modul) több
    másodpercet vinne el egyetlen fájl írásához.
    """
    import os

    import xbmcaddon
    import xbmcvfs

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    try:
        if not os.path.exists(profile):
            os.makedirs(profile)
        with open(os.path.join(profile, COMMENT_REQUEST_FILE), 'w') as handle:
            handle.write('1')
    except OSError:
        pass


def route(params):
    '''A plugin:// URL query-jét a megfelelő navigator metódusra képezi.'''
    from resources.lib.indexers import navigator
    from resources.lib.modules import control

    action = params.get('action')
    nav = navigator.navigator()

    if action is None:
        return nav.root()
    if action == 'base':
        return nav.getOrderTypes(params.get('type'), params.get('year'))
    # A 'netflix*' nevek régebbi kedvencekben/widgetekben még élhetnek.
    if action in ('streams', 'netflix'):
        return nav.getStreams()
    if action == 'streamtop':
        return nav.getStreamTop(params.get('provider'))
    if action in ('playtitle', 'netflixplay'):
        return nav.playTitle(params.get('search'))
    if action == 'netflixtop':
        return nav.getNetflixTop10(params.get('category'))
    if action == 'years':
        return nav.getYears(params.get('type'))
    if action == 'movies':
        return nav.getMovies(params.get('type'), params.get('page'),
                             params.get('order'), params.get('search'),
                             params.get('year'))
    if action == 'movie':
        return nav.getMovie(params.get('url'))
    if action == 'playmovie':
        return nav.playmovie(params.get('url'), params.get('subtitled') == 'true')
    if action == 'search':
        return nav.getSearches()
    if action == 'series':
        return nav.getSeries(params.get('url'), params.get('auto') == '1')
    if action == 'episodes':
        return nav.getEpisodes(params.get('url'), params.get('serie'),
                               params.get('auto') == '1')
    if action == 'sources':
        return nav.showSources(params.get('url'))
    if action == 'playdirect':
        return nav.playDirect(params.get('url'))
    if action == 'playepisode':
        return nav.playEpisode(params.get('url'))
    if action == 'resolveepisode':
        return nav.resolveEpisode(params.get('url'), params.get('skip') == '1')
    if action == 'searchbuilder':
        return nav.getSearchBuilder(params)
    if action == 'searchpick':
        return nav.pickSearchField(params.get('field'), params)
    if action == 'searchrun':
        return nav.runSearch(params)
    if action == 'adultlist':
        return nav.adultList()
    if action == 'adultsearch':
        return nav.adultSearch()
    if action == 'adultresults':
        return nav.adultResults(params.get('query'), params.get('page'))
    if action == 'adultplay':
        return nav.adultPlay(params.get('url'))
    if action == 'newsearch':
        return nav.doSearch()
    if action == 'deletesearchhistory':
        return nav.deleteSearchHistory()
    if action == 'clearcache':
        return nav.clearCache()
    if action == 'recommended':
        return nav.getRecommended()
    if action == 'recommendedlist':
        return nav.getRecommendedList(params.get('type'))
    if action == 'watchlist':
        return nav.getWatchlist()
    if action == 'watchopen':
        return nav.watchOpen(params.get('url'))
    if action == 'watchadd':
        return nav.watchAdd(params.get('url'))
    if action == 'watchsearch':
        return nav.watchSearch(params.get('search'))
    if action == 'watchdub':
        return nav.watchDub(params.get('url'), params.get('mode') or 'dub')
    if action == 'listlanguage':
        return nav.pickListLanguage(params.get('type'), params.get('year'))
    if action == 'streamcheck':
        return nav.streamCheck(params.get('quiet') == '1')
    if action == 'ncoreplay':
        return nav.playNcore(params.get('url'))
    if action == 'ncoreplayimdb':
        return nav.playNcoreImdb(params.get('imdb'), params.get('title', ''), params.get('thumb', ''))
    if action == 'ncoretest':
        return nav.ncoreTest()
    if action == 'ncoresetup':
        return nav.ncoreSetup()
    if action == 'tonight':
        return nav.tonight()
    if action == 'introclear':
        return nav.introClear()
    if action == 'profiles':
        return nav.pickProfile()
    if action == 'exportlog':
        target = control.exportLog()
        return control.infoDialog(u'Napló mentve: %s' % target if target else u'A naplót nem sikerült kimásolni.')
    if action == 'watchremove':
        return nav.watchRemove(params.get('url'))
    if action == 'watchappear':
        return nav.watchAppear(params.get('imdb'), params.get('title', ''), params.get('thumb', ''))
    if action == 'watchcheck':
        return nav.watchCheck(params.get('quiet') == '1')
    if action == 'continueseries':
        return nav.continueSeries(params.get('url'))
    if action == 'continueremove':
        return nav.continueRemove(params.get('url'))
    if action == 'history':
        return nav.getHistory()
    if action == 'historyplay':
        return nav.playHistory(params.get('url'))
    if action == 'historyremove':
        return nav.removeHistory(params.get('url'))
    if action == 'historyclear':
        return nav.clearHistory()
    if action == 'comments':
        return nav.requestComments()
    if action == 'commentkey':
        return nav.installCommentKey()
    if action == 'commentlearn':
        return nav.learnCommentKey()
    if action == 'diagnostics':
        return nav.runDiagnostics()
    if action == 'updatecheck':
        return nav.forceUpdate()
    if action == 'upstreamcheck':
        return nav.checkUpstream()

    control.log_error('Ismeretlen action: %s' % action)
    return nav.root()


def home_view_enabled():
    import xbmcaddon
    try:
        return xbmcaddon.Addon().getSettingBool('homeview')
    except Exception:
        return True


def host_home(ask_profile=False):
    """
    A boritos kezdokepernyo -- EBBEN a folyamatban. A navigator (es a
    requests) nelkul indul; a halozati sorokat a hatterszal hozza.
    ask_profile: indulaskor a "Ki nez?" kepernyo (a szolgaltatas keri).
    """
    from resources.lib.modules import home, homewindow
    if home.guard_tripped():
        # Az elozo megnyitas kozben akadt el a Kodi: most kihagyjuk, szolunk.
        home.guard_clear()
        from resources.lib.modules import control
        control.log(u'Kezdőképernyő kihagyva: az előző megnyitás elakadt', control.LOGWARNING)
        control.infoDialog(u'A borítós kezdőképernyő most kimaradt (az előző megnyitás '
                           u'elakadt). Beállításokban kikapcsolható.', time=10000)
        return False
    return homewindow.host(ask_profile=ask_profile)


def quick_root():
    """
    A főmenü a navigator (és a requests) betöltése NÉLKÜL.

    A bekapcsolás utáni első képernyő ez; lassú Android-dobozon a navigator
    importlánca másodperceket visz el, pedig ehhez a 8 sorhoz csak egy
    JSON-olvasás kell. A sorok a menu.py-ból jönnek, ugyanonnan, ahonnan a
    navigator is rajzolja őket.
    """
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    from resources.lib.modules import menu, watchlist
    handle = int(sys.argv[1])
    base = sys.argv[0]
    fanart = xbmcaddon.Addon().getAddonInfo('fanart')
    for label, query in menu.root_items(watchlist.new_summary()):
        item = xbmcgui.ListItem(label=label)
        item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        item.setProperty('Fanart_Image', fanart)
        xbmcplugin.addDirectoryItem(handle=handle, url='%s?action=%s' % (base, query),
                                    listitem=item, isFolder=True)
    xbmcplugin.setContent(handle, 'addons')
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == '__main__':
    _params = dict(parse_qsl(sys.argv[2].replace('?', '', 1)))
    if _params.get('action') == 'comments':
        # Gyors ág: nincs mögötte menü, csak egy jelzés.
        quick_comment_request()
    elif _params.get('action') == 'trailerplay':
        # Az elozetes kesz videocime, plugin-utvonalon at feloldva. Azert
        # igy, mert a Kodi a lejatszas LEALLITASAKOR a fajl allapotat
        # menti, es ehhez kozvetlen http-cimnel HEAD-del lekeri a fajl
        # datumat -- ha a szerver nem valaszol, 30 mp-ig all az egesz Kodi.
        # plugin:// utvonalnal ezt kihagyja.
        import xbmcgui
        import xbmcplugin
        _url = _params.get('url', '')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), bool(_url), xbmcgui.ListItem(path=_url))
    elif not _params.get('action'):
        # Boritos kezdokepernyo (ha be van kapcsolva), kulonben a szoveges
        # fomenu -- mindketto a navigator nelkul. A lista-keresre eloszor
        # "nincs lista"-t mondunk a Kodinak, es utana nyitjuk az ablakot.
        if home_view_enabled():
            import xbmcplugin
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            if not host_home():
                quick_root()
        else:
            quick_root()
    elif _params.get('action') == 'home':
        # A szolgaltatas hivja indulaskor (RunPlugin): nincs lista-keres.
        host_home(ask_profile=_params.get('askprofile') == '1')
    elif _params.get('action') == 'classic':
        quick_root()
    else:
        from resources.lib.indexers import navigator
        from resources.lib.modules import control
        route(_params)
