# -*- coding: utf-8 -*-

'''
    NetMozi Addon
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
import locale
import os
import random
import re
import string
import sys
import time
from datetime import date
import urllib.parse as urlparse
from urllib.parse import quote_plus

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# A ResolveURL-t SZANDEKOSAN nem itt toltjuk be: importkor ~230 hoszter-
# modult szkennel, ami lassu Android-dobozon masodpercek -- es MINDEN
# menunyitasnal fizetnenk erte, pedig csak lejatszaskor kell. Lasd
# resolveStream(): ott importaljuk, elso hasznalatkor.

from resources.lib.modules import (adult, cache, client, comments, config,
                                   control, diagnostics, history, ncore, netflix,
                                   hosts, listing, menu, overlay, playprogress, profiles,
                                   progress, search, sourcecache, streamcheck,
                                   streams, tmdb, upnext, upstream, watchlist)
from resources.lib.modules.utils import (absolute_url, at, first, normalize_title,
                                         safeopen, to_int)

sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])
addonFanart = xbmcaddon.Addon().getAddonInfo('fanart')

# Visszafelé kompatibilitás: régebben a modul szintjén volt definiálva.
base_url = config.BASE_URL


class ScrapeError(Exception):
    '''Az oldal szerkezete nem az elvárt -- valószínűleg átdesignolták.'''


class navigator:

    def __init__(self):
        self.username = xbmcaddon.Addon().getSetting('username')
        self.password = xbmcaddon.Addon().getSetting('password')
        self.downloadsubtitles = xbmcaddon.Addon().getSettingBool('downloadsubtitles')
        self.autoplay = control.settingBool('autoplay')
        # A csúszkák szövegként is visszajöhetnek, ezért to_int-tel olvassuk.
        self.autoplaytimeout = to_int(control.setting('autoplaytimeout'),
                                      config.AUTOPLAY_START_TIMEOUT)
        self.autoplaymaxsources = to_int(control.setting('autoplaymaxsources'),
                                         config.AUTOPLAY_MAX_SOURCES)
        self.autoplaynext = control.settingBool('autoplaynext')
        self.skipdeadepisode = control.settingBool('skipdeadepisode')
        self.preferlanguage = control.setting('preferlanguage') or ''
        self.episodeskipmax = to_int(control.setting('episodeskipmax'),
                                     config.EPISODE_SKIP_MAX)
        self.base_path = control.transPath(control.addonInfo('profile'))
        self.searchFileName = os.path.join(self.base_path, 'search.history')

    # --- Segédfüggvények ---------------------------------------------------

    @staticmethod
    def generate_random_string(length):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    def generate_visitorId(self):
        return self.generate_random_string(18)

    def generate_fingerprint(self):
        return self.generate_random_string(65)

    @property
    def visitorId(self):
        # Lustán számoljuk: csak akkor kerül sqlite-lekérés, ha tényleg kell.
        return cache.get(self.generate_visitorId, config.CACHE_HOURS_VISITOR_ID)

    @property
    def fingerprint(self):
        return cache.get(self.generate_fingerprint, config.CACHE_HOURS_VISITOR_ID)

    def fetch(self, url, what, **kwargs):
        '''
        Oldal letöltése beszédes hibajelzéssel.

        None-t ad vissza, ha nem sikerült -- a hívó ilyenkor egyszerűen
        kilép, ahelyett hogy egy IndexError-ral szállna el mélyebben.
        '''
        content = client.request(url, **kwargs)
        if content is None:
            if client.blocked_recently():
                control.okDialog(
                    u'A netmozi most ellenőrzést kér (Cloudflare), és a '
                    u'bővítményt nem engedi be.\n\n'
                    u'Böngészőben megnyitva átmegy; itt csak várni lehet -- '
                    u'általában órák múlva magától elmúlik.')
            else:
                control.errorDialog(u'Nem sikerült betölteni: %s' % what)
        return content

    @staticmethod
    def require(value, what):
        '''Kötelező elem: ha hiányzik, ScrapeError -- így látszik, MI hiányzik.'''
        if value is None or value == []:
            raise ScrapeError(what)
        return value

    def handle_scrape_error(self, exc):
        control.log_error(u'Az oldal szerkezete megváltozott, hiányzik: %s' % exc)
        control.okDialog(
            u'Az oldal szerkezete megváltozott (%s).\n'
            u'A bővítmény frissítésére van szükség.' % exc)
        self.endDirectory()

    # --- Menük -------------------------------------------------------------

    def root(self):
        """
        Főmenü. A sorok a menu.py-ban vannak: ugyanazt rajzolja a default.py
        gyors ága is, a navigator betöltése nélkül.
        """
        for label, query in menu.root_items(watchlist.new_summary()):
            self.addDirectoryItem(label, query, '', 'DefaultFolder.png')
        self.endDirectory()

    # --- Profilok ("Ki nez?") -------------------------------------------------

    def pickProfile(self):
        """
        Profilvalasztas, majd a fomenu ujrarajzolasa ugyanebben a hivasban.

        A lista: Kozos + a nevvel letrehozottak + "Uj profil..." + torles.
        Idos nezonek ebbol csak a nevek latszanak; a tobbit az allitja be,
        aki a TV-t gondozza.
        """
        current = profiles.active()
        rows = [(profiles.SHARED, profiles.SHARED_LABEL)] + [(n, n) for n in profiles.names()]
        labels = [u'%s%s' % (label, u'  (ez)' if name == current else u'')
                  for name, label in rows]
        labels += [u'Új profil...', u'Profil törlése...']
        choice = xbmcgui.Dialog().select(u'Ki néz?', labels)
        if choice < 0:
            return self.root()
        if choice < len(rows):
            profiles.set_active(rows[choice][0])
            control.infoDialog(u'Profil: %s' % profiles.label())
        elif choice == len(rows):
            name = self.getSearchText(u'A profil neve')
            if name:
                if profiles.add(name):
                    profiles.set_active(name)
                    control.infoDialog(u'Új profil: %s' % name)
                else:
                    control.okDialog(u'Ezt a nevet nem tudom használni (vagy már túl sok a profil).')
        else:
            victims = profiles.names()
            if victims:
                which = xbmcgui.Dialog().select(u'Melyik profilt töröljem?', victims)
                if which >= 0 and control.yesnoDialog(
                        u'Profil törlése',
                        u'„%s" és minden adata (előzmény, folytatás, figyelt lista) törlődik. Biztos?'
                        % victims[which]):
                    profiles.remove(victims[which])
                    control.infoDialog(u'Profil törölve: %s' % victims[which])
        return self.root()

    def getOrderTypes(self, tipus, year=None):
        url_content = self.fetch(config.BASE_URL, u'rendezési lehetőségek',
                                 cookie=self.getSiteCookies())
        if url_content is None:
            return self.endDirectory()
        try:
            select = self.require(
                first(client.parseDOM(url_content, 'select',
                                      attrs={'id': config.ORDER_SELECT_ID})),
                u'rendezés választó (#%s)' % config.ORDER_SELECT_ID)
        except ScrapeError as exc:
            return self.handle_scrape_error(exc)

        # Az év-szűrő a lista tetején: megmutatja az aktuális állapotot, és
        # kattintásra az év-választóba visz.
        year = self.validYear(year)
        self.addDirectoryItem(
            u'[COLOR yellow]Év szűrő: %s[/COLOR]' % (year or u'mind'),
            'years&type=%s' % tipus, '', 'DefaultFolder.png')
        # A nyelv-szűrő RAGADÓS: beállításban él, minden listára érvényes,
        # amíg vissza nem állítod. Keresésre nem vonatkozik.
        _value, label = self.listLanguage()
        self.addDirectoryItem(
            u'[COLOR yellow]Nyelv szűrő: %s[/COLOR]' % (label or u'mind'),
            'listlanguage&type=%s&year=%s' % (tipus, year or config.YEAR_ALL),
            '', 'DefaultFolder.png')

        for match in re.findall(config.ORDER_OPTION_RE, select):
            label = match[2]
            if any(hidden in label for hidden in config.HIDDEN_ORDERS):
                continue
            self.addDirectoryItem(
                label,
                'movies&page=1&type=%s&order=%s&search=&year=%s' % (
                    tipus, match[0], year or config.YEAR_ALL),
                '', 'DefaultFolder.png')
        self.endDirectory()

    # --- Nyelv szerinti szűrés ---------------------------------------------

    @staticmethod
    def listLanguage():
        '''(érték, felirat) a beállításból; ('', '') = nincs szűrés.'''
        return (control.setting('listlanguage') or '',
                control.setting('listlanguagelabel') or '')

    def languageOptions(self):
        '''[(érték, felirat)] az oldal űrlapjából; ha nem elérhető, tartalék.'''
        options = (self.searchOptions() or {}).get('language') or []
        return list(options) or list(config.LANGUAGE_FALLBACK)

    def pickListLanguage(self, tipus, year=None):
        '''Nyelv választása, mentés, és a lista újrarajzolása ugyanebben a hívásban.'''
        options = [('', config.LANGUAGE_ANY)] + self.languageOptions()
        current, _label = self.listLanguage()
        preselect = next((i for i, (value, _l) in enumerate(options) if value == current), 0)
        choice = xbmcgui.Dialog().select(u'Nyelv szűrő', [label for _v, label in options],
                                         preselect=preselect)
        if choice >= 0:
            value, label = options[choice]
            control.setSetting('listlanguage', value)
            control.setSetting('listlanguagelabel', label if value else '')
            control.log(u'Nyelv szűrő: %s' % (label if value else u'nincs'))
        return self.getOrderTypes(tipus, year)

    # --- Év szerinti szűrés ------------------------------------------------

    @staticmethod
    def validYear(year):
        '''Ellenőrzött évszám, vagy None, ha nincs/érvénytelen a szűrés.'''
        value = to_int(year, 0)
        return value if config.YEAR_MIN <= value <= date.today().year + 5 else None

    def fetchMaxYear(self):
        '''A legnagyobb választható év az oldal keresőűrlapjából.'''
        content = client.request(config.BASE_URL, cookie=self.getSiteCookies())
        if not content:
            return None
        match = re.search(config.YEAR_MAX_RE, content)
        return to_int(match.group(1)) if match else None

    def maxYear(self):
        # Naponta egyszer elég lekérni; ha nem megy, az aktuális év a tartalék.
        return cache.get(self.fetchMaxYear, config.CACHE_HOURS_LOGIN_COOKIE) or date.today().year

    def getYears(self, tipus):
        '''
        Év-választó. A választás a rendezés menübe tér vissza, immár szűrve --
        így utána BÁRMELYIK kategória az adott évre szűkítve listáz.
        '''
        self.addDirectoryItem(u'[COLOR lightgreen]Mind (nincs szűrés)[/COLOR]',
                              'base&type=%s' % tipus, '', 'DefaultFolder.png')
        for year in range(self.maxYear(), config.YEAR_MIN - 1, -1):
            self.addDirectoryItem(str(year), 'base&type=%s&year=%s' % (tipus, year),
                                  '', 'DefaultFolder.png')
        self.endDirectory()

    # --- Netflix Top 10 ----------------------------------------------------

    def providerData(self, key):
        """Egy szolgáltató listája, gyorsítótárból."""
        if key == 'netflix':
            # A Netflixnél két forrás van (magyar + globális tartalék), ezért
            # KÜLÖN cache-bejegyzés: egy átmeneti magyar hiba ne zárja ki a
            # magyar listát egy napra.
            data = cache.get(netflix.fetch_hu, config.CACHE_HOURS_NETFLIX)
            if data:
                data['source'] = 'netflix'
                return data
            control.log(u'Netflix: a magyar lista nem érhető el, jön a globális tartalék',
                        control.LOGWARNING)
            return cache.get(netflix.fetch_global, config.CACHE_HOURS_NETFLIX)
        return cache.get(streams.fetch, config.CACHE_HOURS_NETFLIX, key)

    def getStreams(self):
        """
        Szolgáltató-választó.

        Szándékosan nem tölt le semmit: a listák csak akkor jönnek, amikor
        belépsz valamelyikbe, így a menü azonnal nyílik.
        """
        self.addDirectoryItem(
            u'[COLOR lightgreen]Mind egyben (%d lista)[/COLOR]' % len(streams.PROVIDERS),
            'streamtop&provider=%s' % streams.ALL_KEY, '', 'DefaultFolder.png',
            meta={'title': u'Mind egyben',
                  'plot': u'Mind a(z) %d szolgáltató top listája egyben, '
                          u'szolgáltatónként csoportosítva.' % len(streams.PROVIDERS)})
        for provider in streams.PROVIDERS:
            self.addDirectoryItem(
                provider['label'],
                'streamtop&provider=%s' % quote_plus(provider['key']),
                '', 'DefaultFolder.png',
                meta={'title': provider['label'],
                      'plot': u'A(z) %s jelenleg legnépszerűbb címei Magyarországon.\n\n'
                              u'Egy címre lépve rákeres a netmozi kínálatában.'
                              % provider['label']})
        self.endDirectory()

    def getStreamTop(self, key):
        """Egy szolgáltató top listája."""
        key = key or 'netflix'
        if key == streams.ALL_KEY:
            return self.getAllStreams()
        provider = streams.PROVIDER_BY_KEY.get(key)
        if not provider:
            control.log_error(u'Ismeretlen szolgáltató: %s' % key)
            return self.endDirectory()

        data = self.providerData(key)
        if not data:
            control.okDialog(u'A(z) %s listája jelenleg nem érhető el.' % provider['label'])
            return self.endDirectory()

        # A Netflix globális tartaléka angol nyelvű és kategóriákra bomlik.
        if data.get('source') == 'global':
            self.addDirectoryItem(
                u'[COLOR orange]A magyar lista most nem érhető el - angol nyelvű '
                u'tartaléklista. Újrapróbáláshoz nyisd meg ezt a sort.[/COLOR]',
                'streamtop&provider=netflix', '', 'DefaultFolder.png')
            note = (u'A %s kezdetű héten mért nézettség alapján, a Netflix '
                    u'hivatalos globális adatai szerint.' % data.get('week', ''))
            for cat_key, label in netflix.CATEGORIES:
                if not netflix.by_category(data, cat_key):
                    continue
                self.addDirectoryItem(
                    u'%s [COLOR gray](%s)[/COLOR]' % (label, data.get('week', '')),
                    'netflixtop&category=%s' % quote_plus(cat_key), '', 'DefaultFolder.png',
                    meta={'title': label, 'plot': note})
            return self.endDirectory()

        self.addStreamTitles(data['rows'], provider['label'])

    def getNetflixTop10(self, category):
        """Egy kategória 10 címe a Netflix globális tartaléklistájából."""
        data = self.providerData('netflix')
        rows = netflix.by_category(data, category)
        if not rows:
            control.okDialog(u'Ehhez a kategóriához nincs adat.')
            return self.endDirectory()
        self.addStreamTitles(rows, u'Netflix (globális)', english=True)

    def getAllStreams(self):
        """
        Mind a négy lista egyben, szolgáltatónként csoportosítva.

        Az első megnyitás több letöltést jelent, ezért háttér-folyamatjelző
        mutatja, hol tart; utána 24 óráig gyorsítótárból jön.
        """
        progress = xbmcgui.DialogProgressBG()
        progress.create(u'NetMozi', u'Top listák betöltése...')
        shown = 0
        missing = []
        try:
            total = len(streams.PROVIDERS)
            for position, provider in enumerate(streams.PROVIDERS, start=1):
                progress.update(int(100.0 * (position - 1) / total),
                                message=u'%s (%d/%d)' % (provider['label'], position, total))
                data = self.providerData(provider['key'])
                # A Netflix angol nyelvű tartaléka nem illik a magyar listák
                # közé, ezért a kombinált nézetből kimarad.
                if not data or data.get('source') == 'global':
                    missing.append(provider['label'])
                    control.log(u'Kombinált lista: %s kimarad' % provider['label'],
                                control.LOGWARNING)
                    continue
                self.addStreamItems(data['rows'], provider['label'], tag=provider['short'])
                shown += 1
        finally:
            progress.close()

        if not shown:
            control.okDialog(u'Egyik top lista sem érhető el.')
            return self.endDirectory()
        if missing:
            control.infoDialog(u'Nem érhető el: %s' % u', '.join(missing))
        self.endDirectory(type='movies')

    def addStreamTitles(self, rows, label, english=False):
        """Egy szolgáltató tételei önálló listaként."""
        self.addStreamItems(rows, label, english=english)
        self.endDirectory(type='movies')

    def addStreamItems(self, rows, label, english=False, tag=''):
        """
        Top lista tételei; megnyitva rákeresnek a címre a netmozi kínálatában.

        A `tag` a kombinált nézetben mutatja, melyik szolgáltatótól jön a sor.
        """
        if english:
            note = (u'%s -- %%s. hely.\n\nMegnyitva rákeres a netmozi kínálatában. '
                    u'Itt angol cím szerepel, ezért a magyar cím eltérhet -- a '
                    u'találati listából válaszd ki a megfelelőt.' % label)
        else:
            note = (u'%s -- jelenleg a legnépszerűbbek közt, %%s. hely.\n\n'
                    u'Megnyitva rákeres a netmozi kínálatában.' % label)
        prefix = u'[COLOR gray]%s[/COLOR]  ' % tag if tag else u''
        known = streamcheck.load()
        for row in rows:
            title = row['title']
            item_label = u'%s[COLOR yellow]%s.[/COLOR] %s' % (prefix, row['rank'], title)
            if row.get('season') and row['season'] != title:
                item_label += u' [COLOR gray](%s)[/COLOR]' % row['season']
            # Ha a napi ellenorzes mar megnezte: jeloles, es ha megvan, a
            # kattintas egybol oda visz -- nem kell ujra keresni.
            entry = streamcheck.status(title, known)
            item_label += streamcheck.marker(entry)
            if entry and (entry.get('quality') or entry.get('language')):
                item_label += u' [%s]' % u', '.join(
                    part for part in (entry.get('quality'), (entry.get('language') or '').lower())
                    if part)
            if entry and entry.get('url') and entry.get('status') == streamcheck.SERIES:
                query = 'series&url=%s&auto=1' % entry['url']
            elif entry and entry.get('url') and entry.get('status') == streamcheck.FILM:
                query = 'playdirect&url=%s' % entry['url']
            else:
                query = 'playtitle&search=%s' % quote_plus(title)
            self.addDirectoryItem(
                item_label,
                query,
                row.get('thumb', ''), 'DefaultVideo.png',
                # A mediatype alapján dönti el a skin, hogy poszter-nézetet
                # kínáljon-e; nélküle sok skin sima listaként rajzolja ki.
                meta={'title': title, 'plot': note % row['rank'],
                      'mediatype': 'movie'},
                poster=row.get('poster') or row.get('thumb', ''),
                # Itt még nem tudjuk, a netmozin sorozat-e: a figyelés
                # rákeres, és ha sorozat, felveszi.
                context=[(u'Figyelés, ha sorozat (új részek jelzése)',
                          'watchsearch&search=%s' % quote_plus(title))])

    # --- Stream Top: elérhetőség a netmozin ---------------------------------

    def streamTitles(self):
        """Az osszes szolgaltato cimei, gyorsitotarbol (halozat csak ha lejart)."""
        titles = []
        for provider in streams.PROVIDERS:
            data = self.providerData(provider['key'])
            for row in (data or {}).get('rows') or []:
                if row.get('title'):
                    titles.append(row['title'])
        return titles

    def streamCheck(self, quiet=False):
        """
        Napi futas: melyik top-listas cim van meg a netmozin. A hatter-
        szolgaltatas hivja (quiet); kezzel is inditható.
        """
        if quiet and not streamcheck.due():
            return
        titles = self.streamTitles()
        if not titles:
            if not quiet:
                control.okDialog(u'A top listák most nem érhetők el.')
            return
        progress_bar = None
        if not quiet:
            progress_bar = xbmcgui.DialogProgressBG()
            progress_bar.create(u'NetMozi', u'Stream Top: keresés a netmozin...')
        try:
            count = streamcheck.run(titles, self.searchMovies, self.pickBestMatch)
        finally:
            if progress_bar:
                progress_bar.close()
        if not quiet:
            control.okDialog(u'%d címet néztem meg; a listában látszik, mi van meg.' % count)
            xbmc.executebuiltin('Container.Refresh')

    # --- nCore -----------------------------------------------------------------

    def ncoreTest(self):
        """
        Belépés próbája + egy keresés, dialógusban. A nézőnek: ebből látszik,
        mi hiányzik (jelszó, Elementum), anélkül hogy a naplót kellene nézni.
        """
        lines = []
        user, password = ncore.credentials()
        if not user or not password:
            return control.okDialog(u'Előbb add meg az nCore felhasználónevet és jelszót.')
        ncore.forget()
        ok, message = ncore.login(user, password)
        lines.append(u'Belépés: %s' % (u'rendben' if ok else message))
        if ok:
            rows = ncore.search(config.NCORE_TEST_IMDB, 'film')
            if rows is None:
                lines.append(u'Keresés: nem sikerült (lásd a naplót)')
            else:
                lines.append(u'Keresés (%s): %d torrent' % (config.NCORE_TEST_IMDB, len(rows)))
                for row in rows[:3]:
                    lines.append(u'  %s  (%d seed)' % (row['title'][:50], row['seeders']))
        lines.append(u'Elementum: %s' % (u'telepítve' if ncore.elementum_installed()
                                         else u'NINCS telepítve vagy le van tiltva -- Bővítmények / Videó / Elementum'))
        control.okDialog(u'\n'.join(lines))

    def playNcore(self, url):
        """
        Kifejezetten az nCore-rol (a reszletezo "nCore" gombja): csak a
        torrentek, a beallitott mod ellenere is. Ha nincs: szol.
        """
        if not url:
            return self.endDirectory()
        if not ncore.enabled():
            return control.okDialog(u'Az nCore nincs beállítva (Beállítások / nCore).')
        details, sources = self.movieSources(url)
        torrents = [source for source in sources if source.get('ncore')]
        if not torrents:
            control.okDialog(u'Ehhez a filmhez nincs torrent az nCore-on.')
            return self.endDirectory()
        history.set_context(url, details, self.episodeLabel(url))
        resume = progress.film_resume(url)
        self.force_ncore = True
        try:
            started = self.autoplaySources(torrents, details, page=url, resume=resume)
        finally:
            self.force_ncore = False
        if not started:
            control.errorDialog(u'A torrent nem indult el.')
        return xbmcplugin.endOfDirectory(syshandle, succeeded=False)

    def playNcoreImdb(self, imdb, title='', thumb=''):
        """Torrent egy IMDb-azonositohoz, netmozi-oldal nelkul (a "Varom" lista nCore-talalata)."""
        if not imdb:
            return self.endDirectory()
        if not ncore.enabled():
            return control.okDialog(u'Az nCore nincs beállítva (Beállítások / nCore).')
        torrents = ncore.sources_for(imdb, 'film')
        for position, source in enumerate(torrents, start=1):
            source['index'] = position
            source['label'] = u'%s | %s' % (format(position, '02'), source['label'])
        if not torrents:
            control.okDialog(u'Ehhez a filmhez most nincs torrent az nCore-on.')
            return self.endDirectory()
        details = {'title': title or imdb, 'thumb': thumb or '', 'plot': u'', 'duration': 0}
        self.force_ncore = True
        try:
            started = self.autoplaySources(torrents, details)
        finally:
            self.force_ncore = False
        if not started:
            control.errorDialog(u'A torrent nem indult el.')
        return xbmcplugin.endOfDirectory(syshandle, succeeded=False)

    def ncoreSetup(self):
        ok, message = ncore.setup_elementum()
        control.okDialog(message)
        return ok

    # --- Mit nézzek ma este? ------------------------------------------------

    def tonight(self):
        """
        Egy jo ertekelesu, szinkronos film a valasztott mufajbol,
        veletlenszeruen. Tavirányitoval ez er a legtobbet: nem kell listat
        bongeszni.
        """
        options = (self.searchOptions() or {}).get('genre') or []
        labels = [u'Bármi'] + [label for _v, label in options]
        choice = xbmcgui.Dialog().select(u'Milyen műfaj?', labels)
        if choice < 0:
            return self.endDirectory()
        genre = options[choice - 1][0] if choice > 0 else ''
        language, _label = self.listLanguage()
        state = {'genre': genre, 'type': config.TONIGHT_TYPE,
                 'language': language or config.LANGUAGE_FALLBACK[0][0],
                 'ratingfrom': config.TONIGHT_RATING}

        first = self.fetch(search.build_url(state, page=1), u'a válogatás',
                           cookie=self.getSiteCookies())
        if first is None:
            return self.endDirectory()
        pages = self.pageCount(first)
        tried = set()
        for _ in range(config.TONIGHT_TRIES):
            page = random.randint(1, max(1, min(pages, config.TONIGHT_MAX_PAGE)))
            html = first if page == 1 else self.fetch(
                search.build_url(state, page=page), u'a válogatás',
                cookie=self.getSiteCookies())
            rows = self.parseRows(html or '')
            rows = [row for row in rows if row['url'] not in tried and not row['isSeries']]
            if not rows:
                continue
            pick = random.choice(rows)
            tried.add(pick['url'])
            grade = u', '.join(part for part in (pick.get('quality'),
                                                 (pick.get('language') or '').lower()) if part)
            text = u'%s%s%s\n\n%s' % (
                pick['title'], u' (%s)' % pick['year'] if pick.get('year') else u'',
                u'  [%s]' % grade if grade else u'',
                (pick.get('plot') or u'')[:400])
            if control.yesnoDialog(u'Mit nézzek?', text,
                                   nolabel=u'Másikat', yeslabel=u'Indítás'):
                return self.playDirect(pick['url'])
        control.infoDialog(u'Nincs több javaslat -- próbáld másik műfajjal.')
        return self.endDirectory()

    def parseRows(self, html):
        """Egy lista-oldal tetelei feldolgozva (hiba nelkul a hibas sorokat kihagyva)."""
        rows = []
        for movie in client.parseDOM(html, 'div', attrs={'class': config.LIST_ITEM_CLASS}):
            try:
                rows.append(self.parseMovieRow(movie, ''))
            except ScrapeError as exc:
                control.log_error(u'Tétel kihagyva, hiányzik: %s' % exc)
        return rows

    @staticmethod
    def pageCount(html):
        """A lapozo utolso ertéke; 1, ha nincs lapozo."""
        pager = client.parseDOM(html or '', 'select', attrs={'name': config.PAGER_SELECT_NAME})
        values = client.parseDOM(pager, 'option', ret='value') if pager else []
        return to_int(values[-1], 1) if values else 1

    # --- Top lista: egyértelmű találat automatikus indítása ------------------

    def playTitle(self, search):
        """
        Top lista címének megnyitása.

        Film esetén automatikusan indítja az első működő forrást. Sorozatnál
        az évadokat listázza -- ott a rész kiválasztása indít majd.
        """
        if not search:
            return self.endDirectory()
        if not self.autoplay:
            return self.getMovies('', 1, 1, search)

        rows = self.searchMovies(search)
        if rows is None:
            return self.endDirectory()
        pick = self.pickBestMatch(rows, search)
        if pick is None:
            control.log(u'Top lista: %d találat "%s"-re, marad a lista'
                        % (len(rows), search))
            return self.getMovies('', 1, 1, search)

        control.log(u'Top lista: "%s" -> "%s" (%s)'
                    % (search, pick['title'], pick['year'] or u'év nélkül'))
        if pick['isSeries']:
            # Sorozatnál nem tudható, melyik rész kell; jöjjenek az évadok, és
            # onnantól a rész megnyitása már automatikusan indít.
            return self.getSeries(pick['url'], auto=True)
        return self.autoplayUrl(pick['url'], u'Ehhez a filmhez nem találtam forrást.')

    def playDirect(self, url):
        """
        Ismert netmozi film automatikus indítása (ajánló, listák).

        Nincs keresés: az URL-t már tudjuk, csak a forrásokat kell
        végigpróbálni. Kikapcsolt automatikánál a szokásos forráslista jön.
        """
        if not url:
            return self.endDirectory()
        watchlist.clear_new(url)                     # film: a "megjott a szinkron" jelzes lekerul
        if not self.autoplay:
            return self.getMovie(url)
        # Felbehagyott film: onnan, ahol abbamaradt -- barmelyik listabol.
        resume = progress.film_resume(url)
        if resume:
            control.log(u'Film folytatása %d mp-től: %s' % (resume, url))
        return self.autoplayUrl(url, u'Ehhez a filmhez nem találtam forrást.',
                                resume=resume)

    def playEpisode(self, url, resume=0):
        """
        Sorozat rész automatikus indítása.

        `resume`: ennyi másodperctől folytatja (a "Már láttam" folytatása).
        """
        if not self.autoplay:
            return self.getMovie(url)
        # A lejátszásnak MINDIG lejátszási listából kell futnia, különben az
        # Up Next hiába fűzi hozzá a következő részt: a Kodi nem talál
        # "következőt" ("Playlist: can't find the next item to play").
        #
        # Up Next telepítve: a lista csak az aktuális részt tartalmazza, a
        # következőt az Up Next teszi mögé, és ő mutatja a visszaszámlálót.
        # Up Next nélkül: mi töltjük fel az évad hátralévő részeivel.
        queue, upnext_data = self.episodePlan(url)
        return self.autoplayUrl(url, u'Ehhez a részhez nem találtam forrást.',
                                queue=queue, upnext_data=upnext_data,
                                on_dead=lambda: self.skipDeadEpisode(url),
                                resume=resume)

    def episodePlan(self, url):
        '''
        (lejátszási lista, Up Next adat) egy rész indításához.

        Egy helyen, mert TÖBB útról is indulhat rész, és mindnek ugyanazt
        kell tennie -- különben a lánc az első továbblépés után megszakad.
        '''
        remaining = self.episodeQueue(url)
        # Az évad listáját úgyis lekértük: a folytatáshoz feljegyezzük, mi
        # jön ez után -- így a "Már láttam" hálózat nélkül tudja kiírni.
        progress.set_next(url, remaining[0]['path'] if remaining else None)
        queue = remaining if self.autoplaynext else None
        upnext_data = None
        if queue and upnext.available():
            upnext_data = self.upnextPayload(url, queue[0])
            if upnext_data:
                queue = []
        return queue, upnext_data

    def upnextPayload(self, url, following):
        '''A most futó és a következő rész leírása az Up Next számára.'''
        match = re.match(config.EPISODE_URL_RE, url or '')
        if not match:
            return None
        season, episode = match.group('season'), match.group('episode')
        show = following.get('showtitle', '')
        art = following.get('thumb', '')
        plot = following.get('plot', '')
        duration = following.get('duration', 0)
        return {
            'current': upnext.episode_info(
                u'%s. évad %s. rész' % (season, episode), show,
                to_int(season), to_int(episode), art, plot, duration),
            'following': upnext.episode_info(
                u'%s. évad %s. rész' % (following['season'], following['episode']), show,
                to_int(following['season']), to_int(following['episode']),
                art, plot, duration),
            # A skip=1 SZÁNDÉKOSAN csak itt megy ki: lejátszási listás
            # módban a további részek már a listában vannak.
            'play_url': '%s&skip=1' % following['url'],
        }

    def episodeQueue(self, url):
        """
        Az évad hátralévő részei (rank, cím, plugin URL) lejátszási listához.

        Csak az adott évadon belül folytat: az évadhatár átlépése külön
        adatlapot igényelne, és ritkán az, amit a néző vár.
        """
        match = re.match(config.EPISODE_URL_RE, url or '')
        if not match:
            return []
        base, season, current = (match.group('base'), match.group('season'),
                                 match.group('episode'))
        content = client.request('%s%s' % (config.BASE_URL, base),
                                 cookie=self.getSiteCookies())
        if not content:
            control.log_error(u'Nem sikerült lekérni az évad listát: %s' % base)
            return []
        try:
            details = self.parseDetails(content)
        except ScrapeError as exc:
            control.log_error(u'Az évad adatlapja megváltozott: %s' % exc)
            details = {}

        episodes = client.parseDOM(
            client.parseDOM(content, 'ul',
                            attrs={'id': '%s%s' % (config.SEASON_LIST_ID, season)}), 'a')
        queue = []
        passed = False
        for episode in episodes:
            if episode == current:
                passed = True
                continue
            if not passed:
                continue
            queue.append({
                'label': u'%s - %s. évad %s. rész' % (details.get('title', ''), season, episode),
                'path': '%s/s%s/e%s' % (base, season, episode),
                'url': '%s?action=resolveepisode&url=%s/s%s/e%s' % (sysaddon, base, season, episode),
                'thumb': details.get('thumb', ''),
                'showtitle': details.get('title', ''),
                'plot': details.get('plot', ''),
                'duration': details.get('duration', 0),
                'season': season,
                'episode': episode,
            })
        control.log(u'Következő részek sorba állítva: %d' % len(queue))
        return queue

    def resolveEpisode(self, url, skip=False):
        """
        Lejátszási listából vagy az Up Next-ből hívva: feloldás a Kodinak.

        Itt a Kodi VÁR ránk, és ha sokáig tartunk, feladja ("Can't find item
        to play"). Ezért kevesebb forrást próbálunk, és azzal kezdünk, ami
        ennél a sorozatnál legutóbb bevált.

        `skip` esetén -- ezt CSAK az Up Next ága kéri -- ha a résznek egyetlen
        forrása sem él, továbblépünk az évad következő részére. Lejátszási
        listás módban ez tilos: ott a további részek már sorban állnak, és
        az ugrás ugyanazt a részt játszaná le kétszer.
        """
        control.log(u'Következő rész feloldása: %s' % url)
        if self.playEpisodeUrl(url):
            return

        if not (skip and self.skipdeadepisode):
            control.errorDialog(u'A következő rész forrása nem elérhető')
            return self.failPlayback()

        candidates = self.episodeQueue(url)[:max(1, self.episodeskipmax)]
        progress = xbmcgui.DialogProgressBG()
        progress.create(u'NetMozi', u'Forrás nélküli rész, tovább...')
        try:
            for position, entry in enumerate(candidates, start=1):
                progress.update(int(100.0 * (position - 1) / len(candidates)),
                                message=u'%s. rész (%d/%d)'
                                        % (entry['episode'], position, len(candidates)))
                control.log(u'Forrás nélküli rész átugrása, jön: %s' % entry['path'])
                if self.playEpisodeUrl(entry['path']):
                    progress.close()
                    control.infoDialog(u'%s. rész indul (a korábbiakhoz nincs forrás)'
                                       % entry['episode'])
                    return
        finally:
            progress.close()
        control.log_error(u'Az évadban nincs több feloldható rész: %s' % url)
        control.errorDialog(u'A következő részekhez nem találtam forrást')
        self.failPlayback()

    def skipDeadEpisode(self, url):
        """
        Ha a résznek nincs élő forrása, próbáljuk az évad következő részeit.

        Ugyanaz a viselkedés, mint a rész végén automatikusan továbblépve --
        csak itt kézi indításnál. A meghívott részeknél `on_dead` nélkül
        megyünk tovább, hogy ne ágazzon el a végtelenbe: a ciklus úgyis
        végigmegy a jelölteken.
        """
        if not self.skipdeadepisode:
            return False
        candidates = self.episodeQueue(url)[:max(1, self.episodeskipmax)]
        progress = xbmcgui.DialogProgressBG()
        progress.create(u'NetMozi', u'Forrás nélküli rész, tovább...')
        try:
          for position, entry in enumerate(candidates, start=1):
            progress.update(int(100.0 * (position - 1) / len(candidates)),
                            message=u'%s. rész (%d/%d)'
                                    % (entry['episode'], position, len(candidates)))
            path = entry['path']
            details, sources = self.movieSources(path)
            if not sources:
                control.log(u'Nincs forrás, tovább: %s' % path)
                continue
            control.log(u'Forrás nélküli rész átugrása, jön: %s' % path)
            history.set_context(path, details, self.episodeLabel(path))
            progress.close()
            # Ugyanaz a terv, mint a rendes indításnál: enélkül az átugrás
            # után elinduló rész végén nem jönne a következő.
            queue, upnext_data = self.episodePlan(path)
            if self.autoplaySources(sources, details, queue=queue,
                                    upnext_data=upnext_data, page=path):
                control.infoDialog(u'%s. rész indul (a korábbiakhoz nincs forrás)'
                                   % entry['episode'])
                xbmcplugin.endOfDirectory(syshandle, succeeded=False)
                return True
            progress.create(u'NetMozi', u'Forrás nélküli rész, tovább...')
        finally:
            progress.close()
        control.log_error(u'Az évadban nincs több elindítható rész: %s' % url)
        return False

    def playEpisodeUrl(self, url):
        """Egy rész feloldása és átadása a Kodinak. True, ha sikerült."""
        details, sources = self.movieSources(url)
        if not sources:
            control.log_error(u'Nincs forrás a részhez: %s' % url)
            return False

        match = re.match(config.EPISODE_URL_RE, url or '')
        prefer = history.site_for_series(match.group('base') if match else '')
        if prefer:
            control.log(u'Kezdés a legutóbb bevált forrással: %s' % prefer)

        for source in self.orderedSources(sources, prefer)[:config.RESOLVE_MAX_SOURCES]:
            stream = self.resolveStream(source['url'], source['subtitled'], quiet=True)
            if stream:
                control.log(u'Rész innen: %s' % source['site'])
                hosts.record(source['site'], True)
                history.set_context(url, details, self.episodeLabel(url))
                history.add(source['site'], quality=source.get('quality', ''),
                            language=source.get('language', ''))
                xbmcplugin.setResolvedUrl(
                    syshandle, True, self.buildPlayItem(stream, details, url))
                # Ezen az úton indítja az Up Next a következő részt. A
                # RÁKÖVETKEZŐRŐL csak az indulás UTÁN szólhatunk -- lásd
                # announceAfterStart.
                self.announceAfterStart(url, stream['url'])
                return True
            hosts.record(source['site'], False)
            control.log(u'Nem oldható fel, jön a következő: %s' % source['site'])
        return False

    @staticmethod
    def pickBestMatch(rows, search):
        """
        Melyik találatot indítsuk el magától.

        Egyetlen találatnál azt. Többnél csak akkor döntünk, ha a cím tényleg
        illeszkedik: a netmozi keresője szavanként, VAGY-kapcsolattal illeszt,
        ezért egy többszavas címre könnyen jön egy teljes oldalnyi érdektelen
        sor -- azok közül vaktában választani rosszabb, mint listát mutatni.

        Azonos című találatok közül a LEGFRISSEBB évszám nyer: a top listák
        aktuális címekről szólnak, nem évtizedes névrokonaikról.
        """
        if not rows:
            return None
        if len(rows) == 1:
            return rows[0]
        wanted = normalize_title(search)
        if not wanted:
            return None
        matches = [row for row in rows if normalize_title(row['title']) == wanted]
        if not matches:
            # A netmozi gyakran zárójelben az eredeti címet is kiírja.
            matches = [row for row in rows
                       if wanted in normalize_title(row['title'])
                       or normalize_title(row['title']) in wanted]
        if not matches:
            return None
        return max(matches, key=lambda row: row['year'])

    def autoplayUrl(self, url, missing_message, queue=None, upnext_data=None,
                    prefer='', on_dead=None, resume=0):
        """
        Egy film vagy rész forrásainak automatikus végigpróbálása.

        `on_dead`: ha egyetlen forrás sem indult el, ezt hívjuk meg utolsó
        esélyként. Sorozatnál ez lépteti tovább a következő részre.
        """
        details, sources = self.movieSources(url)
        if not sources:
            if on_dead and on_dead():
                return
            control.okDialog(missing_message)
            return self.endDirectory()
        history.set_context(url, details, self.episodeLabel(url))
        if self.autoplaySources(sources, details, queue=queue, upnext_data=upnext_data,
                                prefer=prefer, page=url, resume=resume):
            # A lejátszás fut; ne navigáljunk sehova.
            return xbmcplugin.endOfDirectory(syshandle, succeeded=False)

        # Egyik forrás sem indult el. Sorozatnál előbb megpróbáljuk a
        # következő részt; ha az sem megy, jöhet a kézi választás.
        if on_dead and on_dead():
            return
        control.errorDialog(u'Egyik forrás sem indult el, válassz kézzel')
        details = details or {}
        for source in sources:
            self.addDirectoryItem(
                source['label'],
                'playmovie&url=%s&subtitled=%s' % (source['url'],
                                                   'true' if source['subtitled'] else 'false'),
                details.get('thumb', ''), 'DefaultMovies.png', isFolder=False,
                meta={'title': details.get('title', ''), 'plot': details.get('plot', ''),
                      'duration': details.get('duration', 0),
                      'fanart': details.get('thumb', '')})
        self.endDirectory(type='movies')

    def searchMovies(self, search):
        '''Keresés találatai feldolgozva. Hálózati hibánál None.'''
        url = config.LIST_URL % (config.BASE_URL, 1, '', 1, quote_plus(search))
        content = self.fetch(url, u'a keresés', cookie=self.getSiteCookies())
        if content is None:
            return None
        rows = []
        for movie in client.parseDOM(content, 'div', attrs={'class': config.LIST_ITEM_CLASS}):
            try:
                rows.append(self.parseMovieRow(movie, ''))
            except ScrapeError as exc:
                control.log_error(u'Találat kihagyva, hiányzik: %s' % exc)
        return rows

    def movieSources(self, url, extra=True):
        '''
        (részletek, források) egy film adatlapjáról. Hibánál (None, []).
        extra: az nCore forrásai is (ha be van állítva) -- a figyelő próbák
        nélküle járnak, hogy ne terheljék az nCore-t.
        '''
        details, sources = self.siteSources(url)
        if details and extra:
            sources = self.withNcore(url, details, sources)
        return details, sources

    def withNcore(self, url, details, sources):
        '''A netmozi forrásai + az nCore torrentjei ugyanahhoz a címhez (IMDb).'''
        if not ncore.enabled():
            return sources
        imdb = tmdb.imdb_id(details.get('thumb') or '')
        if not imdb:
            return sources
        match = re.match(config.EPISODE_URL_RE, url or '')
        try:
            if match:
                extra = ncore.sources_for(imdb, 'series', match.group('season'), match.group('episode'))
            else:
                extra = ncore.sources_for(imdb, 'film')
        except Exception as exc:
            control.log_exception(u'nCore források', exc)
            extra = []
        for position, source in enumerate(extra, start=len(sources) + 1):
            source['index'] = position
            source['label'] = u'%s | %s' % (format(position, '02'), source['label'])
        return list(sources) + extra

    def siteSources(self, url):
        '''(részletek, források) a netmozi adatlapjáról. Hibánál (None, []).'''
        content = self.fetch('%s%s' % (config.BASE_URL, url), u'a film adatlapja',
                             cookie=self.getSiteCookies())
        if content is None:
            return None, []
        if config.REGISTRATION_MARKER in content:
            control.log_error(u'A tartalom regisztrációhoz kötött: %s' % url)
            return None, []
        try:
            details = self.parseDetails(content)
            movieURL = absolute_url(self.require(
                first(client.parseDOM(content, 'a',
                                      attrs={'class': config.LINKS_BUTTON_CLASS}, ret='href')),
                u'linkek gomb (.%s)' % config.LINKS_BUTTON_CLASS))
        except ScrapeError as exc:
            control.log_error(u'Az adatlap szerkezete megváltozott: %s' % exc)
            return None, []

        # A hozzászólások ugyanebben a HTML-ben vannak; a lejátszás alatti
        # átfedést a háttérszolgáltatás ebből mutatja meg. Nincs extra kérés.
        comments.store(comments.parse(content), details.get('title', ''))

        links = self.fetch(movieURL, u'a forráslista')
        if links is None:
            return details, []
        try:
            return details, self.parseSourceRows(links, movieURL)
        except ScrapeError as exc:
            control.log_error(u'A forrástábla szerkezete megváltozott: %s' % exc)
            return details, []

    @staticmethod
    def episodeLabel(url):
        """"2. évad 5. rész" a rész URL-jéből; filmnél üres."""
        match = re.match(config.EPISODE_URL_RE, url or '')
        if not match:
            return ''
        return u'%s. évad %s. rész' % (match.group('season'), match.group('episode'))

    def byLanguage(self, sources):
        """
        A beállított hangsáv előre, a többi az oldal sorrendjében.

        Stabil rendezés: csak a preferált nyelvet emeli ki, a maradék
        egymáshoz képesti sorrendjét nem bolygatja.
        """
        wanted = self.preferlanguage
        if not wanted or wanted == config.LANGUAGE_ANY:
            return list(sources)
        return ([item for item in sources if item.get('language') == wanted]
                + [item for item in sources if item.get('language') != wanted])

    def orderedSources(self, sources, prefer='', manual=False):
        """
        Próbálkozási sorrend: az érvénytelennek jelöltek a sor végére.

        Nem dobjuk el őket, mert a jelölés lehet elavult -- csak hátrébb
        soroljuk. A darabszámot a beállítás korlátozza.

        Ha `prefer` meg van adva (az előzményből: ez a forrás vált be
        legutóbb), az kerül legelőre -- így újranézéskor elsőre elindul.
        """
        valid = [source for source in sources or [] if source['valid']]
        invalid = [source for source in sources or [] if not source['valid']]
        # Rendezés rétegekben, stabilan: előbb a hoszter tanult megbízhatósága
        # (aki eddig elindult, előrébb), arra jön a hangsáv, ami a preferált
        # nyelvet emeli ki -- így a nyelvi csoporton BELÜL a megbízható marad
        # elöl. Az érvénytelennek jelöltek külön csoportban, a végén.
        ordered = (self.byLanguage(hosts.ordered(valid))
                   + self.byLanguage(hosts.ordered(invalid)))
        if prefer:
            remembered = [item for item in ordered if item.get('site') == prefer]
            ordered = remembered + [item for item in ordered if item.get('site') != prefer]
        return self.placeNcore(ordered, manual)

    def placeNcore(self, ordered, manual=False):
        """
        Hova kerul a torrent a probalkozasi sorban (beallitas):
          manual   -- magatol soha; a kezi listaban (manual=True) a vegen;
          fallback -- a hoszterek UTAN, legfeljebb par torrent: csak ha
                      egyik hoszter sem indult (alapertelmezes: a netmozi
                      olcsobb, mint a torrent);
          better   -- elore, ha a letran jobb, mint a netmozi legjobbja;
          always   -- mindig elore.
        A seed nelkuli torrent csak a kezi listaban latszik, a vegen.
        """
        cap = max(1, self.autoplaymaxsources)
        torrents = [item for item in ordered if item.get('ncore')]
        if not torrents:
            return ordered[:cap]
        if getattr(self, 'force_ncore', False):
            return torrents[:cap]                    # a nezo kifejezetten torrentet kert
        others = [item for item in ordered if not item.get('ncore')]
        live = [item for item in torrents if item.get('valid')]
        dead = [item for item in torrents if not item.get('valid')]
        mode = ncore.mode()
        if mode == 'always' or (mode == 'better' and ncore.better(live, others, self.preferlanguage)):
            return (live + others + (dead if manual else []))[:cap]
        if mode == 'manual' and not manual:
            return others[:cap]
        if manual:
            return others[:cap] + live + dead        # a kezi listaban mind latszik
        return others[:cap] + live[:config.NCORE_FALLBACK_TRIES]

    def autoplaySources(self, sources, details, queue=None, upnext_data=None, prefer='',
                        page='', resume=0):
        '''
        Sorban próbálja a forrásokat, az első elinduló nyer.

        A folyamatjelző VÉGIG látszik -- a feloldás alatt és a lejátszás
        beindulására várva is --, és megmutatja, melyik forrás bukott el.
        '''
        ordered = self.orderedSources(sources, prefer)
        if not ordered:
            return False

        total = len(ordered)
        # A folyamatjelzo: a kezdokepernyo sajat ablaka (ha az van elol), kulonben a Kodie.
        progress = playprogress.PlayProgress((details or {}).get('title', u''), (details or {}).get('thumb', u''))
        progress.create(u'NetMozi', u'Forrás keresése...')
        previous = ''
        cancelled = False
        try:
            for position, source in enumerate(ordered, start=1):
                if progress.iscanceled():
                    control.log(u'Automatikus lejátszás megszakítva')
                    cancelled = True
                    return False
                percent = int(100.0 * (position - 1) / total)
                header = u'[B]%d/%d[/B]  %s  %s  %s' % (
                    position, total, source['site'], source['language'], source['quality'])

                # Az első után mondjuk ki, hogy TOVÁBBLÉPTÜNK -- eddig csak a
                # "2/6" számláló jelezte, ami könnyen elsikkad.
                step = (u'Forrás ellenőrzése...' if position == 1
                        else u'Tovább a következő forrásra, ellenőrzés...')
                progress.show(percent, header, step, previous)
                stream = self.resolveStream(source['url'], source['subtitled'], quiet=True)
                if not stream:
                    hosts.record(source['site'], False)
                    previous = self.autoplayNote(source, u'nem elérhető')
                    control.log(u'Forrás nem oldható fel, jön a következő: %s' % source['site'])
                    continue

                if not source.get('ncore') and not client.looks_playable(
                        stream['url'], config.PLAYABLE_CHECK_TIMEOUT):
                    hosts.record(source['site'], False)
                    previous = self.autoplayNote(source, u'nem játszható')
                    control.log(u'A feloldott cím nem videó, jön a következő: %s'
                                % source['site'])
                    continue

                progress.show(percent, header, u'Lejátszás indítása...', previous, starting=True)
                # Torrentnel az Elementum elobb puffereli: tobb turelem kell.
                timeout = config.NCORE_START_TIMEOUT if source.get('ncore') else None
                if self.startPlayback(self.buildPlayItem(stream, details, page), stream['url'],
                                      progress, header, percent, previous, queue,
                                      upnext_data, resume=resume, timeout=timeout):
                    control.log(u'Automatikus lejátszás innen: %s' % source['site'])
                    hosts.record(source['site'], True)
                    history.add(source['site'], quality=source.get('quality', ''),
                                language=source.get('language', ''))
                    return True
                hosts.record(source['site'], False)
                previous = self.autoplayNote(source, u'nem indult el')
                control.log(u'A lejátszás nem indult el, jön a következő: %s' % source['site'])
        finally:
            # Sikernel a startPlayback mar zarta; kudarcnal a sajat ablak a hibat mutatja meg.
            progress.close(failed=not cancelled and not self.playing_now(), message=u'Egyik forrás sem indult el.')
        return False

    @staticmethod
    def playing_now():
        try:
            return xbmc.Player().isPlaying()
        except Exception:
            return False

    @staticmethod
    def autoplayNote(source, reason):
        '''A legutóbbi kudarc egy sorban -- így látszik, mesterséges várakozás nélkül.'''
        return u'\n[COLOR red]%s: %s[/COLOR]' % (source['site'], reason)

    @staticmethod
    def seekTo(player, monitor, seconds):
        """
        Folytatás adott másodperctől -- ELLENŐRIZVE.

        1) Megvárjuk, hogy a stream megnyíljon (a hossz ismert legyen);
           lassú HLS-forrásnál ez fél perc is lehet.
        2) Ha a StartOffset már odatette, kész. Ha nem, tekerünk, várunk,
           megnézzük, hova ért, és ha nem oda, újra -- a Kodi az indulás
           első pillanataiban néha elengedi a tekerést.
        """
        for _ in range(max(1, config.RESUME_WAIT)):
            try:
                if player.isPlaying() and player.getTotalTime() > 0:
                    break
            except RuntimeError:
                pass
            if monitor.waitForAbort(1):
                return False
        else:
            control.log(u'Folytatás: a stream nem nyílt meg %d mp alatt, nem tekerünk'
                        % config.RESUME_WAIT, control.LOGWARNING)
            return False

        target = int(seconds)
        for attempt in range(1, max(1, config.RESUME_RETRIES) + 1):
            try:
                if player.getTime() >= target - config.RESUME_TOLERANCE:
                    control.log(u'Folytatás rendben: %d mp (%d. próba)' % (target, attempt))
                    return True
                xbmcgui.Window(10000).setProperty('netmozi.seek', str(target))
                player.seekTime(target)
            except RuntimeError as exc:
                control.log_exception(u'visszatekerés', exc)
            if monitor.waitForAbort(config.RESUME_SETTLE):
                return False
        try:
            landed = player.getTime()
        except RuntimeError:
            landed = -1
        ok = landed >= target - config.RESUME_TOLERANCE
        control.log(u'Folytatás %s: cél %d mp, itt tart: %d mp'
                    % (u'rendben' if ok else u'NEM SIKERÜLT', target, landed),
                    control.LOGINFO if ok else control.LOGWARNING)
        return ok

    def startPlayback(self, play_item, direct_url, progress=None, header='',
                      percent=0, previous='', queue=None, upnext_data=None, resume=0,
                      timeout=None):
        '''
        Elindítja a lejátszást, és megvárja, hogy tényleg fusson-e.

        A visszaszámlálás látszik a folyamatjelzőn: korábban ez a szakasz
        némán telt, ezért tűnt úgy, hogy a bővítmény csak áll.

        Ha van `queue`, lejátszási listaként indul, és a Kodi magától lépteti
        a további részeket -- a bővítmény ekkorra már rég kilépett.
        '''
        player = xbmc.Player()
        if resume:
            # A Kodi sajat, megbizhato utja: a tetelre rakott kezdopozicio --
            # a lejatszo mar ott nyitja meg, nem nekunk kell tekerni. A
            # tekeres (seekTo) csak tartalek, ha ez megsem ervenyesulne.
            play_item.setProperty('StartOffset', str(int(resume)))
            # Az intro-tanulo ezt az ugrast ne tanulja meg.
            xbmcgui.Window(10000).setProperty('netmozi.seek', str(int(resume)))
        # queue=None -> önálló elem (film). queue=[] -> egyelemű lejátszási
        # lista: kell, hogy az Up Next mögé tudja fűzni a következő részt.
        if queue is not None:
            player.play(self.buildPlaylist(play_item, direct_url, queue))
        else:
            player.play(direct_url, play_item)
        monitor = xbmc.Monitor()
        timeout = max(1, timeout or self.autoplaytimeout)
        for elapsed in range(1, timeout + 1):
            if player.isPlaying():
                # Azonnal el az útból, hogy a videó teljes képre válthasson.
                if progress:
                    progress.close()
                # Az Up Next csak futó lejátszás mellett tudja a részhez kötni.
                # Türelmi idő: ha előtte más futott, annak a leállási eseménye
                # törölné a most küldött adatot.
                if upnext_data:
                    monitor.waitForAbort(config.UPNEXT_GRACE)
                    upnext.notify(upnext_data['current'], upnext_data['following'],
                                  upnext_data['play_url'])
                if resume:
                    self.seekTo(player, monitor, resume)
                return True
            if progress:
                if progress.iscanceled():
                    self.stopPlayer(player)
                    return False
                progress.show(percent, header, u'Lejátszás indítása... (%d/%d mp)' % (elapsed, timeout),
                              previous, starting=True)
            if monitor.waitForAbort(1):
                return False
        if player.isPlaying():
            if progress:
                progress.close()
            return True
        self.stopPlayer(player)
        return False

    @staticmethod
    def buildPlaylist(play_item, direct_url, queue):
        """Az aktuális rész + a hátralévők egy lejátszási listában."""
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.add(direct_url, play_item)
        for entry in queue:
            item = xbmcgui.ListItem(label=entry['label'])
            item.setArt({'icon': entry['thumb'], 'thumb': entry['thumb'],
                         'poster': entry['thumb']})
            item.setInfo('Video', {'title': entry['label'], 'mediatype': 'episode'})
            item.setProperty('IsPlayable', 'true')
            playlist.add(entry['url'], item)
        return playlist

    @staticmethod
    def stopPlayer(player):
        try:
            player.stop()
        except Exception as exc:
            control.log_exception(u'lejátszás leállítása', exc)

    # --- Keresés -----------------------------------------------------------

    def getSearches(self):
        self.addDirectoryItem('[COLOR lightgreen]Új keresés[/COLOR]', 'newsearch', '', 'DefaultFolder.png')
        self.addDirectoryItem('[COLOR gold]Részletes keresés[/COLOR]', 'searchbuilder',
                              '', 'DefaultFolder.png')
        for item in self.readSearchHistory():
            self.addDirectoryItem(
                item, 'movies&page=1&type=&order=1&search=%s' % quote_plus(item),
                '', 'DefaultFolder.png')
        if self.readSearchHistory():
            self.addDirectoryItem('[COLOR red]Keresési előzmények törlése[/COLOR]',
                                  'deletesearchhistory', '', 'DefaultFolder.png')
        self.endDirectory()

    def readSearchHistory(self):
        '''Egyedi, magyar ábécé szerint rendezett keresési előzmények.'''
        try:
            with safeopen(self.searchFileName, 'r') as handle:
                olditems = handle.read().splitlines()
        except (IOError, OSError):
            return []
        items = sorted(set(item for item in olditems if item.strip()),
                       key=self.sortKey())
        if len(items) != len(olditems):
            try:
                with safeopen(self.searchFileName, 'w') as handle:
                    handle.write('\n'.join(items))
            except (IOError, OSError) as exc:
                control.log_exception(u'keresési előzmények tömörítése', exc)
        return items

    @staticmethod
    def sortKey():
        '''Magyar rendezés, ha a rendszer tudja; különben egyszerű kisbetűs.'''
        for loc in ('hu_HU.UTF-8', ''):
            try:
                locale.setlocale(locale.LC_COLLATE, loc)
                return locale.strxfrm
            except locale.Error:
                continue
        return lambda value: value.lower()

    def deleteSearchHistory(self):
        try:
            if os.path.exists(self.searchFileName):
                os.remove(self.searchFileName)
            control.refresh()
        except OSError as exc:
            control.log_exception(u'keresési előzmények törlése', exc)
            control.errorDialog(u'A keresési előzmények törlése nem sikerült')

    def doSearch(self):
        search_text = self.getSearchText()
        if not search_text:
            return
        # A rejtett lista kulcsszava ITT valik el -- meg mielott a keresesi
        # elozmenybe irnank. Kulonben a szo ott maradna, es a rejtes semmit
        # sem erne.
        if search_text.strip().lower() == config.ADULT_KEYWORD.lower():
            return self.adultList()
        try:
            if not os.path.exists(self.base_path):
                os.makedirs(self.base_path)
            with safeopen(self.searchFileName, 'a') as handle:
                handle.write('%s\n' % search_text)
        except (IOError, OSError) as exc:
            # A keresés mehet tovább akkor is, ha az előzményt nem tudtuk menteni.
            control.log_exception(u'keresési előzmény mentése', exc)
        self.getMovies('', 1, 1, search_text)

    # --- Rejtett lista -----------------------------------------------------

    def adultList(self):
        """
        A rejtett lista belepo kepernyoje.

        Szandekosan nem hasznal semmit a netmozi-agbol: sem keresesi
        elozmenyt, sem "Mar lattam" naplot nem ir. Aki nem ismeri a
        kulcsszot, nem talal nyomot rola a feluleten.
        """
        rows = adult.homepage()
        if rows is None:
            control.okDialog(u'A lista jelenleg nem érhető el.')
            return self.endDirectory()
        self.addDirectoryItem(u'[COLOR lightgreen]Keresés[/COLOR]', 'adultsearch',
                              '', 'DefaultFolder.png')
        self.addAdultItems(rows)
        control.log(u'Rejtett lista: %d elem' % len(rows))
        self.endDirectory(type='videos')

    def adultSearch(self):
        """Kereses a rejtett listan belul. A kifejezes sehova nem naplozodik."""
        text = self.getSearchText(u'Keresend\xF5 kifejez\xE9s')
        if not text:
            return
        return self.adultResults(text, 1)

    def adultResults(self, query, page=1):
        """Talalatok egy oldala. Ez -- a cimlappal ellentetben -- lapozhato."""
        page = to_int(page, 1)
        rows = adult.search(query, page)
        if rows is None:
            control.okDialog(u'A keresés jelenleg nem érhető el.')
            return self.endDirectory()
        if not rows:
            control.okDialog(u'Nincs találat.')
            return self.endDirectory()
        self.addAdultItems(rows)
        # Lapozo csak akkor, ha tele jott az oldal -- kulonben ez az utolso.
        if len(rows) >= config.ADULT_PAGE_SIZE:
            self.addDirectoryItem(
                u'[COLOR lightgreen]Következő oldal (%d.)[/COLOR]' % (page + 1),
                'adultresults&query=%s&page=%d' % (quote_plus(query), page + 1),
                '', 'DefaultFolder.png')
        control.log(u'Rejtett találatok: %d elem (%d. oldal)' % (len(rows), page))
        self.endDirectory(type='videos')

    def addAdultItems(self, rows):
        """A tetelek felvitele -- kozos a cimlaphoz es a talalatokhoz."""
        for row in rows:
            label = row['title']
            if row['quality']:
                label = u'%s  [COLOR gray][%s][/COLOR]' % (label, row['quality'])
            self.addDirectoryItem(
                label, 'adultplay&url=%s' % quote_plus(row['url']),
                row['thumb'], 'DefaultVideo.png', isFolder=False,
                meta={'title': row['title'], 'duration': row['duration'],
                      'mediatype': 'video'})

    def adultPlay(self, url):
        """Egy tetel lejatszasa. Nem naplozza a "Mar lattam" listaba."""
        if not url:
            return
        # Semmi nem tartozik netmozi adatlaphoz: a háttérszolgáltatás ne
        # írja ezt a lejátszást egy sorozat folytatásába.
        history.clear_context()
        stream = adult.stream(url)
        if not stream:
            control.okDialog(u'Ez a videó nem elérhető.')
            return xbmcplugin.setResolvedUrl(syshandle, False, xbmcgui.ListItem())
        item = xbmcgui.ListItem(path=stream['url'])
        if stream['thumb']:
            item.setArt({'icon': stream['thumb'], 'thumb': stream['thumb'],
                         'poster': stream['thumb']})
        item.setInfo('Video', {'title': stream['title'], 'mediatype': 'video'})
        xbmcplugin.setResolvedUrl(syshandle, True, item)

    def getSearchText(self, heading=None):
        keyb = xbmc.Keyboard('', heading or u'Add meg a keresend\xF5 film c\xEDm\xE9t')
        keyb.doModal()
        return keyb.getText() if keyb.isConfirmed() else ''

    # --- Részletes keresés ---------------------------------------------------

    def searchOptions(self):
        """A választható értékek az oldal keresőűrlapjából, napi frissítéssel."""
        return cache.get(search.fetch_options, config.CACHE_HOURS_NETFLIX) or {}

    @staticmethod
    def searchState(params):
        """A feltételek kiolvasása a plugin URL-ből."""
        return {key: (params.get(key) or '') for key in search.ALL_FIELDS}

    @staticmethod
    def searchQuery(state, extra=''):
        """A feltételek visszaírása plugin URL-be."""
        parts = ['%s=%s' % (key, quote_plus(state.get(key, '') or ''))
                 for key in search.ALL_FIELDS]
        return '&'.join(parts) + (('&' + extra) if extra else '')

    def getSearchBuilder(self, params):
        """
        A feltételek összeállítása. SZÁNDÉKOSAN nem keres semmit magától --
        csak akkor, amikor a néző a keresés sorra lép.
        """
        state = self.searchState(params)
        options = self.searchOptions()
        query = self.searchQuery(state)

        self.addDirectoryItem(
            u'[COLOR lightgreen][B]KERESÉS INDÍTÁSA[/B][/COLOR]',
            'searchrun&%s' % query, '', 'DefaultFolder.png',
            meta={'title': u'Keresés', 'plot': search.describe(state, options)})

        # A megjelenítési sorrend a netmozi űrlapját követi.
        for key in search.FIELD_ORDER:
            value = state.get(key)
            if value and key in options:
                shown = search.label_for(options, key, value)
            else:
                shown = value or u'mind'
            self.addDirectoryItem(
                u'%s:  [COLOR %s]%s[/COLOR]' % (search.field_label(key),
                                                'gold' if value else 'gray', shown),
                'searchpick&field=%s&%s' % (key, query), '', 'DefaultFolder.png')

        self.addDirectoryItem(u'[COLOR red]Feltételek törlése[/COLOR]', 'searchbuilder',
                              '', 'DefaultFolder.png')
        self.endDirectory()

    def pickSearchField(self, field, params):
        """Egy feltétel beállítása, majd vissza az összeállítóba."""
        state = self.searchState(params)
        options = self.searchOptions()

        choices = search.choice_values(field)
        if choices is not None:
            # Rögzített értékkészlet (pl. IMDb 0-10): TV-n a választó
            # kényelmesebb, mint a beírás.
            labels = [u'-- mind --'] + list(choices)
            choice = control.selectDialog(labels)
            if choice < 0:
                return self.getSearchBuilder(state)
            state[field] = '' if choice == 0 else choices[choice - 1]
        elif field in options:
            labels = [u'-- mind --'] + [label for _value, label in options[field]]
            choice = control.selectDialog(labels)
            if choice < 0:
                return self.getSearchBuilder(state)
            state[field] = '' if choice == 0 else options[field][choice - 1][0]
        elif field in search.TYPED_FIELDS:
            state[field] = self.getSearchText(search.field_label(field)) or ''
        else:
            control.errorDialog(u'Ez a szűrő most nem érhető el')
            return self.getSearchBuilder(state)

        # A frissített összeállítót EBBEN a hívásban rajzoljuk ki. A korábbi
        # Container.Update azért nem működött, mert a Kodi közben listát várt
        # tőlünk, amit sosem kapott meg -- innen jött a "Working" és az, hogy
        # a választás nem érvényesült.
        return self.getSearchBuilder(state)

    def runSearch(self, params):
        """A összeállított feltételekkel listázás."""
        state = self.searchState(params)
        page = to_int(params.get('page'), 1)
        url = search.build_url(state, page)
        content = self.fetch(url, u'a keresés', cookie=self.getSiteCookies())
        if content is None:
            return self.endDirectory()

        movies = client.parseDOM(content, 'div', attrs={'class': config.LIST_ITEM_CLASS})
        if not movies:
            control.okDialog(u'Nincs találat a megadott feltételekkel.')
            return self.endDirectory()
        for movie in movies:
            try:
                self.addMovieItem(movie, state.get('type', ''), auto=self.autoplay)
            except ScrapeError as exc:
                control.log_error(u'Találat kihagyva, hiányzik: %s' % exc)

        pager = first(client.parseDOM(content, 'select',
                                      attrs={'name': config.PAGER_SELECT_NAME}))
        if pager is not None:
            options = client.parseDOM(pager, 'option', ret='value')
            last = to_int(at(options, -1, '0'))
            if last > page:
                self.addDirectoryItem(
                    u'[I]K\u00F6vetkez\u0151 oldal  (%d/%s)>>[/I]' % (page + 1, last),
                    'searchrun&%s' % self.searchQuery(state, 'page=%d' % (page + 1)),
                    '', 'DefaultFolder.png')
        control.log(u'Részletes keresés: %d találat (%s)'
                    % (len(movies), search.describe(state, self.searchOptions())))
        self.endDirectory(type='movies')

    # --- Lista -------------------------------------------------------------

    def getInfo(self, infoBlock, label):
        '''Egy címkézett adatsor értéke az adatlap "col-sm-8" blokkjából.'''
        result = '0'
        for row in client.parseDOM(infoBlock, 'div', attrs={'class': config.LIST_ROW_CLASS}):
            divs = client.parseDOM(row, 'div')
            key, value = at(divs, 0), at(divs, 1)
            if key is not None and value is not None and label in key:
                result = value.strip()
        return result

    @staticmethod
    def parseCategories(infoRows):
        """A listaelem kategóriái ("Kategória: Horror , Thriller")."""
        for row in infoRows or []:
            if config.LABEL_CATEGORY not in row:
                continue
            text = re.sub(r'<[^>]+>', ' ', row)
            text = client.replaceHTMLCodes(text).replace(config.LABEL_CATEGORY, ' ')
            parts = re.split(config.CATEGORY_SPLIT_RE, text)
            return [p.strip() for p in parts if p.strip()]
        return []

    @staticmethod
    def getInfoData(infoRows, label, regex, default=''):
        '''Regexszel kinyert érték a listaelem adatsorai közül.'''
        for row in infoRows or []:
            if label in row:
                match = re.search(regex, row)
                if match:
                    return match.group(1)
        return default

    def getMovies(self, tipus, page, order, search, year=None):
        search = search or ''
        page = to_int(page, 1)
        year = self.validYear(year)
        url = config.LIST_URL % (config.BASE_URL, page, tipus, order, quote_plus(search))
        if year:
            url += config.YEAR_FILTER % (year, year)
        # A nyelv-szűrő csak böngészésre: egy konkrét címre keresve ne
        # tűnjön el a találat azért, mert még nincs szinkronja.
        language, _label = self.listLanguage()
        if language and not search:
            url += config.LANGUAGE_FILTER % language
        url_content = self.fetch(url, u'a lista', cookie=self.getSiteCookies())
        if url_content is None:
            return self.endDirectory()

        movies = client.parseDOM(url_content, 'div', attrs={'class': config.LIST_ITEM_CLASS})
        if not movies:
            control.okDialog(u'Nem található forrás!')
            xbmcplugin.setResolvedUrl(syshandle, False, xbmcgui.ListItem())
            return self.endDirectory()

        for movie in movies:
            try:
                # Az automatikus indítás MINDEN listára érvényes: Filmek,
                # Sorozatok, keresés. Kikapcsolva a szokásos adatlap jön.
                self.addMovieItem(movie, tipus, auto=self.autoplay)
            except ScrapeError as exc:
                # Egy hibás elem ne vigye el az egész listát.
                control.log_error(u'Listaelem kihagyva, hiányzik: %s' % exc)

        self.addPager(url_content, page, tipus, order, search, year)
        self.endDirectory(type='movies')

    def addMovieItem(self, movie, tipus, auto=False):
        """
        Listaelem hozzáadása.

        `auto` esetén a film megnyitása egyből indítja a lejátszást, a
        sorozat pedig az évadokon át viszi tovább az automatikus ágat --
        ugyanúgy, mint a Stream Top 10-nél.
        """
        row = self.parseMovieRow(movie, tipus)
        if row['isSeries']:
            watched = self.watchData().get(row['url']) or {}
            if watched.get('new'):
                # Netflix "Uj epizod": a figyelt sorozatnal a listaban is.
                row['label'] += u' [új rész]'
        if auto:
            query = ('series&url=%s&auto=1' % row['url'] if row['isSeries']
                     else 'playdirect&url=%s' % row['url'])
        else:
            query = '%s&url=%s' % (row['action'], row['url'])
        # Hosszan nyomva a Kodi helyi menüje nyílik meg; ide tesszük a
        # kézi forrásválasztást, hogy az automatika megkerülhető legyen.
        context = None
        if not row['isSeries']:
            context = [(u'Források', 'sources&url=%s' % row['url'])]
            if row['url'] in self.watchData():
                context.append((u'Figyelés megszüntetése',
                                'watchremove&url=%s' % row['url']))
            else:
                context.append((u'Szólj, ha lesz jó minőségű szinkron',
                                'watchdub&url=%s&mode=dub' % row['url']))
                context.append((u'Szólj, ha jobb minőség jön (bármilyen nyelv)',
                                'watchdub&url=%s&mode=quality' % row['url']))
        elif row['url'] in self.watchData():
            context = [(u'Figyelés megszüntetése', 'watchremove&url=%s' % row['url'])]
        else:
            context = [(u'Figyelés (új részek jelzése)', 'watchadd&url=%s' % row['url'])]
        self.addDirectoryItem(
            row['label'], query, row['thumb'],
            'DefaultTVShows.png' if row['isSeries'] else 'DefaultMovies.png',
            meta={'title': row['title'], 'duration': row['duration'],
                  'fanart': row['thumb'], 'genre': ' / '.join(row['categories'])},
            context=context)

    def parseMovieRow(self, movie, tipus):
        '''Egy listaelem adatai -- a listing modulbol (Kodi nelkuli, kozos).'''
        try:
            return listing.parse_row(movie, tipus)
        except listing.ScrapeError as exc:
            raise ScrapeError(str(exc))

    def watchData(self):
        '''A figyelt lista egyszer betoltve a listaepites idejere (24 sor = 1 olvasas).'''
        if getattr(self, '_watch_data', None) is None:
            self._watch_data = watchlist.load()
        return self._watch_data

    def forgetWatchData(self):
        '''Iras utan: a kovetkezo lista friss allapotot lasson.'''
        self._watch_data = None

    @staticmethod
    def parseBadge(infoRows):
        '''(nyelv, minoseg) a listasor utolso sorabol; ('', '') ha nincs.'''
        for row in reversed(infoRows or []):
            match = re.search(config.LIST_BADGE_RE, row, re.S)
            if not match:
                continue
            flag, quality = match.group(1), (match.group(2) or '').strip()
            language = next((name for marker, name in config.LANGUAGE_FLAGS
                             if marker in flag), '')
            return language, quality
        return '', ''

    def addPager(self, url_content, page, tipus, order, search, year=None):
        pager = first(client.parseDOM(url_content, 'select',
                                      attrs={'name': config.PAGER_SELECT_NAME}))
        if pager is None:
            return
        options = client.parseDOM(pager, 'option', ret='value')
        last = to_int(at(options, -1, '0'))
        if last > page:
            self.addDirectoryItem(
                u'[I]K\u00F6vetkez\u0151 oldal  (%d/%s)>>[/I]' % (page + 1, last),
                'movies&page=%d&type=%s&order=%s&search=%s&year=%s' % (
                    page + 1, tipus, order, search, year or config.YEAR_ALL),
                '', 'DefaultFolder.png')

    # --- Adatlap -----------------------------------------------------------

    def parseDetails(self, url_content):
        '''Az adatlap közös részei: cím, borító, leírás, hossz.'''
        container = self.require(
            first(client.parseDOM(url_content, 'div', attrs={'class': config.DETAIL_CONTAINER_CLASS})),
            u'tartalom keret (.%s)' % config.DETAIL_CONTAINER_CLASS)
        heading = first(client.parseDOM(container, config.DETAIL_TITLE_TAG), '')
        title = client.replaceHTMLCodes(first(client.parseDOM(heading, 'a'), '')).strip()
        infoBlock = first(client.parseDOM(container, 'div', attrs={'class': config.DETAIL_INFO_CLASS}), '')
        thumbBlock = first(client.parseDOM(container, 'div', attrs={'class': config.DETAIL_THUMB_CLASS}), '')
        return {
            'title': title,
            'plot': self.getInfo(infoBlock, config.LABEL_PLOT),
            'duration': to_int(self.getInfo(infoBlock, config.LABEL_DURATION)) * 60,
            'thumb': absolute_url(first(client.parseDOM(thumbBlock, 'img', ret='src'))),
        }

    def getSeries(self, url, auto=False):
        # Az evadok megnyitasa = a nezo latta, hogy van uj: a jelzes lekerul.
        watchlist.clear_new(url)
        url_content = self.fetch('%s%s' % (config.BASE_URL, url), u'a sorozat adatlapja',
                                 cookie=self.getSiteCookies())
        if url_content is None:
            return self.endDirectory()
        try:
            details = self.parseDetails(url_content)
        except ScrapeError as exc:
            return self.handle_scrape_error(exc)

        seasonList = client.parseDOM(url_content, 'ul', attrs={'id': config.SEASON_LIST_ID})
        for serie in client.parseDOM(seasonList, 'a'):
            self.addDirectoryItem(
                '%s. évad' % serie,
                'episodes&url=%s&serie=%s%s' % (url, serie, '&auto=1' if auto else ''),
                details['thumb'], 'DefaultTVShows.png',
                meta={'title': '%s - %s. évad' % (details['title'], serie),
                      'plot': details['plot'], 'duration': details['duration'],
                      'fanart': details['thumb']})
        self.endDirectory(type='movies')

    def getEpisodes(self, url, serie, auto=False):
        url_content = self.fetch('%s%s' % (config.BASE_URL, url), u'az évad adatlapja',
                                 cookie=self.getSiteCookies())
        if url_content is None:
            return self.endDirectory()
        try:
            details = self.parseDetails(url_content)
        except ScrapeError as exc:
            return self.handle_scrape_error(exc)

        episodeList = client.parseDOM(url_content, 'ul',
                                      attrs={'id': '%s%s' % (config.SEASON_LIST_ID, serie)})
        # Top listáról érkezve a rész megnyitása egyből indítja a lejátszást.
        action = 'playepisode' if auto else 'movie'
        # Amit már láttunk, és ahol félbehagytuk: a listában látszódjon.
        watched = set(entry.get('page', '') for entry in history.load())
        current = progress.get(url)
        # A részek saját adatai (cím, leírás, állókép): TMDB magyarul / IMDb.
        from resources.lib.modules import episodes as episodes_mod
        extra = {}
        try:
            extra = episodes_mod.season(tmdb.imdb_id(details.get('thumb', '')), serie)
        except Exception as exc:
            control.log_exception(u'részadatok', exc)
        for episode in client.parseDOM(episodeList, 'a'):
            page = '%s/s%s/e%s' % (url, serie, episode)
            data = extra.get(str(episode)) or {}
            plot = data.get('overview') or details['plot']
            if data.get('date'):
                plot = u'%s\n\n%s' % (data['date'], plot) if plot else data['date']
            self.addDirectoryItem(
                '%s%s' % (episodes_mod.label(episode, data), self.episodeMarker(page, watched, current)),
                '%s&url=%s' % (action, page),
                data.get('still') or details['thumb'], 'DefaultTVShows.png',
                meta={'title': '%s - %s. évad %s. rész%s' % (details['title'], serie, episode,
                                                             u' – %s' % data['title'] if data.get('title') else u''),
                      'plot': plot, 'duration': (data.get('runtime') or 0) * 60 or details['duration'],
                      'fanart': data.get('still') or details['thumb']})
        self.endDirectory(type='movies')

    @staticmethod
    def episodeMarker(page, watched, current):
        """
        "  [félbehagyva, 25. perc]" / "  [megnézve]" / "" egy részhez.

        A félbehagyás csak a sorozat LEGUTÓBBI részére értelmezett (a
        folytatás-bejegyzés csak azt tartja); a többi megnézettségét az
        előzményből tudjuk.
        """
        if current and current.get('page') == page:
            if progress.finished(current):
                return u'  [megnézve]'
            seconds = progress.resume_seconds(current)
            if seconds:
                return u'  [félbehagyva, %d. perc]' % (seconds // 60)
            return u'  [elkezdve]'
        if page in watched:
            return u'  [megnézve]'
        return u''

    def getMovie(self, url):
        url_content = self.fetch('%s%s' % (config.BASE_URL, url), u'a film adatlapja',
                                 cookie=self.getSiteCookies())
        if url_content is None:
            return self.endDirectory()

        if config.REGISTRATION_MARKER in url_content:
            control.okDialog(u'Lista lekérés sikertelen. A hozzáféréshez regisztráció szükséges.')
            xbmcplugin.setResolvedUrl(syshandle, False, xbmcgui.ListItem())
            return self.endDirectory()

        try:
            details = self.parseDetails(url_content)
            movieURL = absolute_url(self.require(
                first(client.parseDOM(url_content, 'a',
                                      attrs={'class': config.LINKS_BUTTON_CLASS}, ret='href')),
                u'linkek gomb (.%s)' % config.LINKS_BUTTON_CLASS))
        except ScrapeError as exc:
            return self.handle_scrape_error(exc)

        serieInfo = first(client.parseDOM(url_content, config.DETAIL_SUBTITLE_TAG))
        details['title'] += ' - %s' % serieInfo if serieInfo else ''

        links_content = self.fetch(movieURL, u'a forráslista')
        if links_content is None:
            return self.endDirectory()
        # Sikeres indításkor ebből áll össze az előzmény-bejegyzés.
        history.set_context(url, details, self.episodeLabel(url))
        comments.store(comments.parse(url_content), details.get('title', ''))
        try:
            self.addSourceItems(links_content, movieURL, details)
        except ScrapeError as exc:
            return self.handle_scrape_error(exc)
        self.endDirectory(type='movies')

    def addSourceItems(self, links_content, movieURL, details):
        for source in self.parseSourceRows(links_content, movieURL):
            self.addDirectoryItem(
                source['label'],
                'playmovie&url=%s&subtitled=%s' % (source['url'],
                                                   'true' if source['subtitled'] else 'false'),
                details['thumb'], 'DefaultMovies.png', isFolder=False,
                meta={'title': details['title'], 'plot': details['plot'],
                      'duration': details['duration'], 'fanart': details['thumb']})

    def parseSourceRows(self, links_content, movieURL):
        '''A forrástábla sorai. Megjelenítés nélkül, hogy a lejátszó is használhassa.'''
        card = self.require(
            first(client.parseDOM(links_content, 'div', attrs={'class': config.SOURCE_CARD_CLASS})),
            u'forrás kártya (.card)')
        tableDiv = self.require(
            first(client.parseDOM(card, 'div', attrs={'class': config.SOURCE_TABLE_WRAP_CLASS})),
            u'forrás tábla (.%s)' % config.SOURCE_TABLE_WRAP_CLASS)
        table = client.parseDOM(tableDiv, 'table', attrs={'class': config.SOURCE_TABLE_CLASS})
        if not table:
            return []

        origin = urlparse.urlsplit(movieURL)
        origin = '%s://%s' % (origin.scheme, origin.netloc)

        sources = []
        for index, row in enumerate(client.parseDOM(table, 'tr'), start=1):
            cols = client.parseDOM(row, 'td')
            href = at(client.parseDOM(at(cols, config.COL_PLAY, ''), 'a',
                                      attrs={'class': config.SOURCE_PLAY_BTN_CLASS}, ret='href'), -1)
            if href is None:
                control.log(u'Forrássor kihagyva (nincs lejátszás gomb): %d' % index, control.LOGDEBUG)
                continue

            flags = at(cols, config.COL_LANGUAGE, '')
            nyelv = config.LANGUAGE_UNKNOWN
            for marker, label in config.LANGUAGE_FLAGS:
                if marker in flags:
                    nyelv = label
                    break
            isValid = config.INVALID_SOURCE_MARKER not in at(cols, config.COL_VALID, '')
            valid = '' if isValid else '| [COLOR red]Érvénytelen[/COLOR]'
            site = at(cols, config.COL_SITE, '').strip()
            quality = at(cols, config.COL_QUALITY, '').strip()

            sources.append({
                'index': index,
                'label': '%s | [B]%s[/B] | [COLOR limegreen]%s[/COLOR] | [COLOR blue]%s[/COLOR] %s' % (
                    format(index, '02'), site, nyelv, quality, valid),
                'url': urlparse.urljoin(origin, href),
                'subtitled': nyelv == config.LANGUAGE_SUBTITLED,
                'language': nyelv,
                'site': site,
                'quality': quality,
                'valid': isValid,
            })
        return sources

    def showSources(self, url, rescan=False):
        """
        Felugró forráslista, mért sebességgel.

        SZÁNDÉKOSAN dialógus és nem menü: a helyi menü RunPlugin-nal hív, ami
        eldobja a bővítmény által épített listát -- menüt onnan nem lehet
        nyitni, felugró ablakot igen.

        A mérés forrásonként másodpercekbe telik, ezért az eredményt
        megjegyezzük; újraellenőrzést a lista első sora indít.
        """
        details, sources = self.movieSources(url)
        if not sources:
            return control.okDialog(u'Ehhez a filmhez nem találtam forrást.')

        speeds, measured_at = sourcecache.load(url)
        while True:
            if rescan:
                speeds = self.measureSources(sources)
                measured_at = int(time.time())
                # Az eredményt megjegyezzük: a mérés forrásonként másodperc.
                sourcecache.save(url, speeds)
                rescan = False
            choice, ordered = self.pickSource(details, sources, speeds, measured_at)
            if choice < 0:
                return
            if choice == 0:
                rescan = True
                continue
            break

        source = ordered[choice - 1]
        stream = self.resolveStream(source['url'], source['subtitled'])
        if not stream:
            return
        history.set_context(url, details, self.episodeLabel(url))
        history.add(source['site'])
        control.log(u'Kézi forrásválasztás: %s' % source['site'])
        xbmc.Player().play(stream['url'], self.buildPlayItem(stream, details, url))

    @staticmethod
    def sourceKey(url):
        """
        Állandó kulcs egy forráshoz.

        A forrás-URL tokent tartalmaz, ami néhány óránként lejár -- azzal
        kulcsolva a megjegyzett mérések a token cseréjekor elvesznének.
        Az URL-ben lévő azonosító viszont állandó.
        """
        match = re.search(config.SOURCE_ID_RE, url or '')
        return match.group(1) if match else (url or '')

    def pickSource(self, details, sources, speeds, measured_at):
        """
        A felugró lista összeállítása és megjelenítése.

        (választás, a listában szereplő források) párral tér vissza. A 0.
        elem mindig az ellenőrzés/újraellenőrzés.
        """
        ordered = self.orderedSources(sources, '', manual=True)
        if speeds:
            # Sorrend: mért gyorsak elöl, utánuk az elérhető de nem mérhetők,
            # majd a még nem mértek, végül a nem elérhetők.
            def rank(item):
                speed = speeds.get(self.sourceKey(item['url']))
                if speed is None:
                    return (2, 0)          # még nem mértük
                if speed > 0:
                    return (0, -speed)     # mért: a gyorsabb előrébb
                if speed == client.SPEED_UNMEASURABLE:
                    return (1, 0)          # elérhető, de nem mérhető
                return (3, 0)              # nem elérhető
            ordered = sorted(ordered, key=rank)

        labels = [u'[COLOR gold]Sebesség ellenőrzése[/COLOR]' if not speeds
                  else u'[COLOR gold]Újraellenőrzés[/COLOR]  (mérve: %s)'
                       % self.historyDate(measured_at)]
        for source in ordered:
            speed = speeds.get(self.sourceKey(source['url']))
            if source.get('ncore'):
                colour = 'lightgreen' if source.get('seeders', 0) > 0 else 'gray'
                mark = u'[COLOR %s]%d seed[/COLOR]' % (colour, source.get('seeders', 0))
            elif speed is None:
                mark = u'[COLOR gray]?[/COLOR]'
            elif speed > 0:
                colour = 'red' if speed < config.CHECK_SLOW_LIMIT else 'lightgreen'
                mark = u'[COLOR %s]%s kB/s[/COLOR]' % (colour, speed)
            elif speed == client.SPEED_UNMEASURABLE:
                # Pl. HLS lejátszólista, aminek a darabjait sem sikerült mérni.
                mark = u'[COLOR lightgreen]elérhető[/COLOR]'
            else:
                mark = u'[COLOR gray]nem elérhető[/COLOR]'
            trust = hosts.describe(source['site'])
            labels.append(u'%s  %s%s' % (mark, source['label'],
                                        u'  [COLOR gray]%s[/COLOR]' % trust if trust else u''))

        choice = control.selectDialog(labels, heading=details.get('title') or u'Források')
        return choice, ordered

    def measureSources(self, sources):
        """
        Végigméri a forrásokat: {forrás URL: kB/s}. A feloldhatatlan 0-t kap.

        A feloldás sikere csak azt mondja meg, hogy a forrás ÉL -- az
        akadozást a sebesség okozza, ezért mintát is letöltünk.
        """
        ordered = self.orderedSources(sources, '', manual=True)[:config.CHECK_MAX_SOURCES]
        speeds = {}
        progress = xbmcgui.DialogProgress()
        progress.create(u'NetMozi', u'Források ellenőrzése...')
        try:
            for position, source in enumerate(ordered, start=1):
                if progress.iscanceled():
                    break
                progress.update(int(100.0 * (position - 1) / len(ordered)),
                                u'%s  %s\n%d/%d forrás'
                                % (source['site'], source['language'],
                                   position, len(ordered)))
                if source.get('ncore'):
                    # Torrent: nincs mit merni, a seederek szama a mertek.
                    speeds[self.sourceKey(source['url'])] = client.SPEED_UNMEASURABLE
                    continue
                stream = self.resolveStream(source['url'], source['subtitled'], quiet=True)
                if not stream:
                    speeds[self.sourceKey(source['url'])] = 0
                    hosts.record(source['site'], False)
                    continue
                measured = client.measure_speed(stream['url'],
                                                sample_bytes=config.CHECK_SAMPLE_BYTES,
                                                timeout=config.CHECK_TIMEOUT)
                # None = nem érhető el; a -1 (elérhető, nem mérhető) marad -1.
                speeds[self.sourceKey(source['url'])] = 0 if measured is None else measured
                hosts.record(source['site'], measured is not None)
        finally:
            progress.close()
        control.log(u'Mérés kész: %d forrás' % len(speeds))
        return speeds

    # --- Lejátszás ---------------------------------------------------------

    def resolveRedirect(self, url):
        '''A közvetítő oldalak mögötti valódi forrás URL kibontása.'''
        final_url = client.request(url, cookie=self.getSiteCookies(), output='geturl')
        if not final_url:
            return None

        if config.REDIRECT_HOST_MARKER in final_url:
            content = client.request(final_url)
            if content is None:
                control.log_error(u'A közvetítő oldal nem tölthető le: %s' % final_url)
                return final_url
            match = re.search(config.REDIRECT_B64_RE, content, re.S)
            if match:
                try:
                    final_url = base64.b64decode(match.group(5)).decode('utf-8')
                except (ValueError, UnicodeDecodeError) as exc:
                    control.log_exception(u'base64 forrás dekódolása', exc)
            else:
                iframe = re.search(config.REDIRECT_IFRAME_RE, content, re.IGNORECASE)
                if iframe:
                    final_url = iframe.group(1)
                else:
                    control.log_error(u'Nincs sem base64 link, sem iframe ezen: %s' % final_url)

        if any(host in final_url for host in config.JSUNHUNT_HOSTS):
            final_url = self.unhuntSource(final_url) or final_url
        return final_url

    def unhuntSource(self, final_url):
        '''streamplay/sbot: a JS-be rejtett <iframe src> kibontása.'''
        html = client.request(final_url)
        if html is None:
            return None
        try:
            from resolveurl.lib import jsunhunt
            if not jsunhunt.detect(html):
                return None
            html = jsunhunt.unhunt(html)
        except Exception as exc:
            control.log_exception(u'jsunhunt deobfuszkálás', exc)
            return None
        match = re.search(config.JSUNHUNT_SRC_RE, html)
        if not match:
            return None
        return client.request(urlparse.urljoin(final_url, match.group(1)), output='geturl')

    def playmovie(self, url, subtitled):
        control.log(u'Lejátszás indul innen: %s' % url)
        stream = self.resolveStream(url, subtitled)
        if not stream:
            return self.failPlayback()
        history.add(urlparse.urlparse(url).hostname or '')
        # A netmozi adatlap útvonala, amit a forráslista építésekor rögzítettünk.
        page = history.get_context().get('page', '')
        details = self.contextDetails()
        xbmcplugin.setResolvedUrl(syshandle, True,
                                  listitem=self.buildPlayItem(stream, details, page))
        self.announceAfterStart(page, stream['url'])

    @staticmethod
    def contextDetails():
        """Az utoljára megnyitott adatlap adatai a lejátszó feliratozásához."""
        context = history.get_context()
        if not context.get('page'):
            return None
        return {'title': context.get('title', ''), 'plot': context.get('plot', ''),
                'duration': context.get('duration', 0), 'thumb': context.get('thumb', '')}

    def nextEpisodePayload(self, page):
        """Az Up Next adat a rákövetkező részről, vagy None, ha nincs mit."""
        if not (page and self.autoplaynext and upnext.available()):
            return None
        if not re.match(config.EPISODE_URL_RE, page):
            return None
        queue = self.episodeQueue(page)
        progress.set_next(page, queue[0]['path'] if queue else None)
        if not queue:
            return None
        return self.upnextPayload(page, queue[0])

    def announceAfterStart(self, page, stream_url):
        """
        Up Next értesítés a setResolvedUrl-es utakon -- de csak MIUTÁN az új
        rész ténylegesen fut.

        Az Up Next a következő részt Player.Open-nel indítja: az ELŐBB oldat
        fel velünk, és csak utána állítja le az előző részt. Az előző rész
        leállási eseménye viszont törli az Up Next-nél lévő adatot. Ha a
        feloldás közben szólunk, pontosan ez törli ki: az első ugrás megy
        (nincs előző rész), a második soha.

        Ezért megvárjuk, hogy a lejátszó a MI fájlunkat játssza -- addigra
        az előző biztosan leállt --, és hagyunk még egy kis türelmi időt.
        """
        payload = self.nextEpisodePayload(page)
        if not payload:
            return False
        wanted = (stream_url or '').split('|')[0]
        player = xbmc.Player()
        monitor = xbmc.Monitor()
        # Ami MOST fut (az előző rész, vagy semmi). Ha a Kodi átírná a
        # fájl útvonalát, a pontos egyezés helyett a VÁLTÁS ténye is elég.
        try:
            before = player.getPlayingFile() if player.isPlaying() else ''
        except RuntimeError:
            before = ''
        for _ in range(max(1, config.UPNEXT_START_TIMEOUT)):
            try:
                now = player.getPlayingFile() if player.isPlaying() else ''
            except RuntimeError:
                now = ''
            playing = bool(now) and (now.split('|')[0] == wanted or now != before)
            if playing:
                if monitor.waitForAbort(config.UPNEXT_GRACE):
                    return False
                upnext.notify(payload['current'], payload['following'],
                              payload['play_url'])
                control.log(u'Up Next: a következő rész bejelentve')
                return True
            if monitor.waitForAbort(1):
                return False
        control.log(u'Up Next: a rész nem indult el időben, nincs bejelentés',
                    control.LOGWARNING)
        return False

    def resolveStream(self, url, subtitled, quiet=False):
        """
        Egy forrás feloldása lejátszható URL-lé.

        quiet=True esetén nem dobál dialógusokat -- az automatikus
        próbálkozásnál ugyanis csak csendben a következő forrásra lépünk.
        Visszatérés: {'url': ..., 'subs': ...} vagy None.
        """
        def fail(message, detail):
            control.log_error(detail)
            if not quiet:
                control.okDialog(message)
            return None

        if ncore.is_source(url):
            play = ncore.resolve(url)
            if not play:
                return fail(u'Az nCore forrás nem indítható (Elementum, belépés, vagy a rész nincs a pakkban).',
                            u'nCore forrás nem oldható fel: %s' % url)
            control.log(u'nCore forrás -> Elementum: %s' % play)
            return {'url': play, 'subs': None}

        with control.timed(u'átirányítás feloldása'):
            final_url = self.resolveRedirect(url)
        if not final_url:
            return fail(u'Törölt tartalom!',
                        u'Nem sikerült feloldani az átirányítást: %s' % url)
        control.log(u'Feloldandó URL: %s' % final_url)

        import resolveurl   # lustan: csak itt kell, es dragan importalodik
        hmf = resolveurl.HostedMediaFile(final_url, subs=self.downloadsubtitles)
        if not hmf:
            host = urlparse.urlparse(final_url).hostname
            control.log_error(u'A ResolveURL nem ismeri ezt a hostot: %s' % final_url)
            if not quiet:
                control.errorDialog(u'Nem támogatott forrás: %s' % host)
            return None
        try:
            with control.timed(u'ResolveURL feloldás'):
                resp = hmf.resolve()
        except Exception as exc:
            control.log_exception(u'ResolveURL feloldás (%s)' % final_url, exc)
            if not quiet:
                control.okDialog(u'ResolveURL hiba: Forrás feloldása sikertelen!')
            return None
        if not resp:
            return fail(u'ResolveURL hiba: Forrás feloldása sikertelen!',
                        u'A ResolveURL üres eredményt adott: %s' % final_url)

        direct_url = resp.get('url') if self.downloadsubtitles else resp
        if not direct_url:
            return fail(u'ResolveURL hiba: Forrás feloldása sikertelen!',
                        u'Nincs lejátszható URL a válaszban: %s' % final_url)
        control.log(u'Feloldott URL: %s' % direct_url)
        return {'url': direct_url,
                'subs': resp.get('subs') if self.downloadsubtitles else None}

    def buildPlayItem(self, stream, details=None, page=''):
        """Lejátszható ListItem a feloldott streamből."""
        play_item = xbmcgui.ListItem(path=stream['url'])
        if details:
            # Automatikus indításnál nincs mögötte listaelem, ezért a
            # lejátszóra magunk tesszük rá a címet és a borítót.
            play_item.setArt({'icon': details['thumb'], 'thumb': details['thumb'],
                              'poster': details['thumb']})
            info = {'title': details['title'],
                    'plot': details['plot'],
                    'duration': details['duration'],
                    'mediatype': 'movie'}
            # Résznél EPISODE kell: az Up Next csak akkor követi a lejátszást,
            # ha a Kodi epizódnak jelenti a tartalmat.
            match = re.match(config.EPISODE_URL_RE, page or '')
            if match:
                info.update({'mediatype': 'episode',
                             'tvshowtitle': details['title'],
                             'season': to_int(match.group('season')),
                             'episode': to_int(match.group('episode')),
                             'title': u'%s. évad %s. rész' % (match.group('season'),
                                                              match.group('episode'))})
            play_item.setInfo('Video', info)
        if 'm3u8' in stream['url']:
            with control.timed(u'inputstream ellenőrzés'):
                self.setupAdaptiveStream(play_item, stream['url'])
        if stream.get('subs'):
            with control.timed(u'felirat letöltés'):
                self.attachSubtitles(play_item, stream['subs'])
        return play_item

    @staticmethod
    def failPlayback():
        '''A Kodi különben "lejátszás indul" állapotban ragadna.'''
        xbmcplugin.setResolvedUrl(syshandle, False, xbmcgui.ListItem())

    @staticmethod
    def setupAdaptiveStream(play_item, direct_url, _checked=[]):
        try:
            from inputstreamhelper import Helper
            # A check_inputstream() lassú tud lenni; hívásonként egyszer elég.
            if not _checked:
                _checked.append(bool(Helper('hls').check_inputstream()))
            if not _checked[0]:
                control.log_error(u'Az inputstream.adaptive nem érhető el')
                return
        except Exception as exc:
            control.log_exception(u'inputstreamhelper', exc)
            return
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # A "url|fejlécek" alak második fele a manifest lekéréséhez kell.
        parts = direct_url.split('|')
        if len(parts) > 1:
            play_item.setProperty('inputstream.adaptive.stream_headers', parts[1])
            play_item.setProperty('inputstream.adaptive.manifest_headers', parts[1])
            play_item.setProperty('inputstream.adaptive.license_key', '|%s' % parts[1])

    @staticmethod
    def preferredSubtitle(subtitles):
        """
        Melyik feliratot töltsük le.

        A magyar nyerne, mert a néző úgyis arra váltana kézzel. Ha nincs,
        az elsőt hozzuk -- egyet mindig, mert minden további letöltés
        késlelteti a lejátszás indulását.
        """
        names = list(subtitles or [])
        if not names:
            return None
        for marker in config.SUBTITLE_PREFERRED:
            for name in names:
                if marker in name.lower():
                    return name
        return names[0]

    def attachSubtitles(self, play_item, subtitles):
        subdir = os.path.join(self.base_path, 'subtitles')
        step = u'a felirat könyvtár létrehozása'
        try:
            if not os.path.exists(subdir):
                os.makedirs(subdir)
            step = u'a korábbi feliratok törlése'
            for name in os.listdir(subdir):
                os.remove(os.path.join(subdir, name))
        except OSError as exc:
            control.log_exception(step, exc)
            control.errorDialog(u'Hiba: %s' % step)
            return

        name = self.preferredSubtitle(subtitles)
        if name is None:
            control.log(u'Nincs letölthető felirat')
            return
        control.log(u'Felirat választva: %s (%d közül)' % (name, len(subtitles)))
        found = []
        try:
            content = client.request(subtitles[name], timeout=config.SUBTITLE_TIMEOUT)
            if content:
                path = os.path.join(subdir, '%s.srt' % name.strip())
                with safeopen(path, 'w') as handle:
                    handle.write(content)
                found.append(path)
            else:
                control.log_error(u'Üres felirat: %s' % name)
        except (IOError, OSError) as exc:
            control.log_exception(u'felirat mentése (%s)' % name, exc)
        if found:
            play_item.setSubtitles(found)
        else:
            control.log(u'Egyetlen feliratot sem sikerült letölteni')

    # --- Cookie-k / cache --------------------------------------------------

    def getCookiesWithoutLogin(self):
        return client.request(config.BASE_URL, output='cookie')

    def getCookiesWithLogin(self):
        login_url = urlparse.urljoin(config.BASE_URL, config.LOGIN_PATH)
        login_cookies = client.request(
            login_url, post={'username': self.username, 'password': self.password},
            output='cookie')
        if login_cookies and config.LOGIN_OK_COOKIE in login_cookies:
            return login_cookies
        control.okDialog(u'Bejelentkez\u00E9si hiba! Érvénytelen felhasználó név/jelszó?')
        return None

    def getSiteCookies(self):
        if self.username and self.password:
            return cache.get(self.getCookiesWithLogin, config.CACHE_HOURS_LOGIN_COOKIE)
        return cache.get(self.getCookiesWithoutLogin, config.CACHE_HOURS_ANON_COOKIE)

    def clearCache(self):
        cache.clear()

    # --- Ajánló -------------------------------------------------------------

    def getRecommended(self):
        """Az oldal ajánló kategóriái."""
        for key, label in config.RECOMMENDED_TYPES:
            self.addDirectoryItem(
                label, 'recommendedlist&type=%s' % quote_plus(key),
                '', 'DefaultFolder.png',
                meta={'title': label,
                      'plot': u'A netmozi "%s" ajánlója.' % label})
        self.endDirectory()

    def getRecommendedList(self, tipus):
        """Egy ajánló kategória tartalma."""
        label = dict(config.RECOMMENDED_TYPES).get(tipus, u'Ajánló')
        url = config.RECOMMENDED_URL % (config.BASE_URL, tipus)
        url_content = self.fetch(url, u'az ajánló', cookie=self.getSiteCookies())
        if url_content is None:
            return self.endDirectory()

        movies = client.parseDOM(url_content, 'div', attrs={'class': config.LIST_ITEM_CLASS})
        if not movies:
            control.okDialog(u'Az ajánló jelenleg üres.')
            return self.endDirectory()
        for movie in movies:
            try:
                # A típus üres: az ajánlóban film és sorozat is lehet.
                self.addMovieItem(movie, '', auto=self.autoplay)
            except ScrapeError as exc:
                control.log_error(u'Ajánló elem kihagyva, hiányzik: %s' % exc)
        control.log(u'Ajánló (%s): %d elem' % (label, len(movies)))
        self.endDirectory(type='movies')

    # --- Figyelt sorozatok -------------------------------------------------

    def seriesPage(self, url):
        """(html, details) egy sorozat adatlapjarol; hibanal (None, None)."""
        html = self.fetch('%s%s' % (config.BASE_URL, url), u'a sorozat adatlapja',
                          cookie=self.getSiteCookies())
        if html is None:
            return None, None
        try:
            return html, self.parseDetails(html)
        except ScrapeError as exc:
            control.log_error(u'A sorozat adatlapja megváltozott: %s' % exc)
            return html, {}

    def episodeHasSources(self, base):
        """Fuggveny, ami egy resz-kulcsrol megmondja, van-e nezheto forrasa."""
        def has_sources(text):
            _details, sources = self.movieSources(watchlist.episode_path(base, text), extra=False)
            return bool(sources)
        return has_sources

    def watchAdd(self, url):
        """Sorozat felvetele a figyeltek koze (helyi menubol)."""
        if not url:
            return
        html, details = self.seriesPage(url)
        if html is None:
            return control.okDialog(u'A sorozat adatlapja most nem érhető el.')
        listed = watchlist.listed_episodes(html)
        if not listed:
            return control.okDialog(u'Ezen az adatlapon nem találtam részeket.')
        title = (details or {}).get('title') or url
        pending = watchlist.add(url, title, (details or {}).get('thumb', ''),
                                listed, self.episodeHasSources(url))
        note = (u' (%d rész még forrás nélkül, figyelem)' % len(pending)
                if pending else u'')
        control.infoDialog(u'Figyelve: %s%s' % (title, note), time=6000)
        control.log(u'Figyelés: %s, %d rész, %d függő' % (url, len(listed), len(pending)))
        self.forgetWatchData()
        xbmc.executebuiltin('Container.Refresh')

    def watchSearch(self, search):
        """
        Figyeles cim alapjan (Stream Top 10): rakeres a netmozin, es ha
        sorozat, felveszi. Tobb sorozat-talalatnal valasztast kinal.
        """
        if not search:
            return
        rows = self.searchMovies(search)
        if rows is None:
            return control.okDialog(u'A netmozi most nem érhető el.')
        series = [row for row in rows if row['isSeries']]
        if not series:
            return control.okDialog(
                u'„%s": a netmozin %s -- sorozatot nem találtam, csak azt lehet figyelni.'
                % (search, u'nincs találat' if not rows else u'csak filmként van meg'))
        # Szigorubb, mint a lejatszasnal hasznalt pickBestMatch: az csak
        # reszleges egyezesnel is valaszt egyet. Figyelesre csendben egy
        # MASIK sorozatot felvenni rosszabb, mint megkerdezni.
        wanted = normalize_title(search)
        exact = [row for row in series if normalize_title(row['title']) == wanted]
        if len(exact) == 1:
            pick = exact[0]
        elif len(series) == 1:
            pick = series[0]
        else:
            labels = [u'%s%s' % (row['title'], u' (%s)' % row['year'] if row['year'] else u'')
                      for row in series]
            choice = xbmcgui.Dialog().select(u'Melyik sorozatot figyeljem?', labels)
            if choice < 0:
                return
            pick = series[choice]
        control.log(u'Figyelés keresésből: "%s" -> %s' % (search, pick['url']))
        return self.watchAdd(pick['url'])

    def watchDub(self, url, mode='dub'):
        """
        Film figyelese. mode='dub': jo minosegu szinkron; mode='quality':
        barmilyen nyelv, de nem gyenge (CAM/TS/TC) minoseg.

        Ha mar van megfelelo forras, nem vesszuk fel, csak szolunk -- a lista
        sorabol ez nem latszik. Ha van szinkron, de csak CAM, azt is
        megmondjuk: pont erre valo a figyeles.
        """
        if not url:
            return
        details, sources = self.movieSources(url)
        if details is None:
            return control.okDialog(u'A film adatlapja most nem érhető el.')
        want = config.LANGUAGE_FLAGS[0][1] if mode != 'quality' else ''   # "Szinkron"
        probe = {'want': want, 'good_quality': True}
        pairs = [(source.get('language'), source.get('quality')) for source in sources]
        have = [(lang, qual) for lang, qual in pairs
                if watchlist.source_matches(probe, lang, qual)]
        if have:
            lang, qual = have[0]
            return control.okDialog(u'Ehhez a filmhez már van megfelelő forrás: %s, %s.'
                                    % (lang, qual or u'?'))
        title = details.get('title') or url
        # Mi van most? Ez adja a figyeles ertelmet ("csak CAM").
        current = sorted(set(u'%s %s' % (lang or u'?', qual or u'?') for lang, qual in pairs))
        watchlist.add_film(url, title, details.get('thumb', ''), want, good_quality=True,
                           current=u', '.join(current)[:60])
        now_text = (u' Most: %s.' % u', '.join(current)[:80]) if current else u''
        control.infoDialog(u'Figyelve: %s -- szólok, ha lesz %s.%s'
                           % (title, watchlist.film_wants(probe), now_text), time=8000)
        self.forgetWatchData()
        xbmc.executebuiltin('Container.Refresh')

    def introClear(self):
        from resources.lib.modules import intro
        intro.clear()
        control.infoDialog(u'A tanult intrók törölve')

    def watchRemove(self, url):
        if watchlist.remove(url):
            control.infoDialog(u'Figyelés megszüntetve')
        self.forgetWatchData()
        xbmc.executebuiltin('Container.Refresh')

    def watchOpen(self, url):
        """
        A figyelt listabol megnyitva a jelzes lekerul. Filmnel a figyeles
        celja teljesult (megjott a szinkron): a bejegyzes le is kerul, es a
        film indul.
        """
        entry = watchlist.load().get(url) or {}
        watchlist.clear_new(url)
        if watchlist.is_appear(entry):
            if entry.get('found'):
                watchlist.remove(url)
                return self.playDirect(entry['found'])
            if entry.get('found_ncore'):
                return self.playNcoreImdb(entry.get('imdb', ''), entry.get('title', ''), entry.get('thumb', ''))
            control.infoDialog(u'%s: még nincs a netmozin -- szólok, ha megjelenik.' % entry.get('title', ''))
            return xbmcplugin.endOfDirectory(syshandle, succeeded=False)
        if watchlist.is_film(entry):
            if entry.get('found'):
                watchlist.remove(url)
            return self.playDirect(url)
        return self.getSeries(url, auto=self.autoplay)

    def watchAppear(self, imdb, title='', thumb=''):
        """'Varom': szolunk, ha a film (IMDb-azonositoval) megjelenik a netmozin."""
        if not imdb:
            return
        if watchlist.is_awaited(imdb):
            control.infoDialog(u'Már várod: %s' % (title or imdb))
        elif watchlist.add_appear(imdb, title, thumb):
            control.infoDialog(u'Szólok, ha megjelenik a netmozin: %s' % (title or imdb))
            control.log(u'Várom: %s (%s)' % (title, imdb))

    def getWatchlist(self):
        rows = watchlist.entries()
        if not rows:
            control.okDialog(u'Még nincs figyelt sorozat.\n\n'
                             u'Egy sorozaton hosszan nyomva: „Figyelés".')
            return self.endDirectory()
        self.addDirectoryItem(u'[COLOR lightgreen]Új részek ellenőrzése most[/COLOR]',
                              'watchcheck', '', 'DefaultFolder.png')
        for row in rows:
            fresh = row.get('new') or []
            label = row['title']
            if watchlist.is_appear(row):
                label += (u'  [COLOR gold]megjelent: %s[/COLOR]' % fresh[0] if fresh
                          else (u'  [COLOR gold]nCore: %s[/COLOR]' % row['found_ncore'] if row.get('found_ncore')
                                else u'  [COLOR gray](várod: szólok, ha megjelenik)[/COLOR]'))
            elif watchlist.is_film(row):
                label += (u'  [COLOR gold]megjött: %s[/COLOR]' % fresh[0] if fresh
                          else u'  [COLOR gray](film -- erre vár: %s; most: %s)[/COLOR]'
                          % (watchlist.film_wants(row), row.get('current') or u'?'))
            elif fresh:
                label = u'%s  [COLOR gold]új: %s%s[/COLOR]' % (
                    label, watchlist.label(fresh[0]),
                    u' (+%d)' % (len(fresh) - 1) if len(fresh) > 1 else u'')
            self.addDirectoryItem(
                label, 'watchopen&url=%s' % row['path'], row.get('thumb', ''),
                'DefaultMovies.png' if watchlist.is_film(row) else 'DefaultTVShows.png',
                context=[(u'Figyelés megszüntetése', 'watchremove&url=%s' % row['path'])])
        self.endDirectory(type='tvshows')

    def watchCheck(self, quiet=False):
        """
        Uj reszek keresese. `quiet`: a hatterszolgaltatas hivja naponta,
        csak az esedekeseket nezi, es csak talalatnal szol. Kezi inditasnal
        mindent megnez, es a vegen osszegez.
        """
        data = watchlist.load()
        paths = watchlist.due() if quiet else list(data)
        if not paths:
            if not quiet:
                control.okDialog(u'Nincs figyelt sorozat.')
            return
        progress = None
        if not quiet:
            progress = xbmcgui.DialogProgressBG()
            progress.create(u'NetMozi', u'Új részek keresése...')
        found = []
        try:
            for position, path in enumerate(paths, start=1):
                entry = data.get(path)
                if not entry:
                    continue
                if progress:
                    progress.update(int(100.0 * (position - 1) / len(paths)),
                                    message=entry.get('title', path))
                if watchlist.is_appear(entry):
                    rows = self.searchMovies(entry.get('imdb', ''))
                    if rows is None:
                        watchlist.mark_failed(entry)
                        continue
                    if watchlist.check_appear(entry, rows):
                        found.append((entry.get('title', path), 'appear', entry))
                    # Az nCore-on is, ha be van allitva: ott gyakran elobb fent van.
                    if not entry.get('found') and not entry.get('found_ncore') and ncore.enabled():
                        try:
                            torrents = ncore.sources_for(entry.get('imdb', ''), 'film')
                        except Exception as exc:
                            control.log_exception(u'várom: nCore', exc)
                            torrents = []
                        if watchlist.check_appear_ncore(entry, torrents):
                            found.append((entry.get('title', path), 'appear_ncore', entry))
                    continue
                if watchlist.is_film(entry):
                    details, sources = self.movieSources(path)
                    if details is None:
                        watchlist.mark_failed(entry)
                        continue
                    pairs = [(s.get('language'), s.get('quality')) for s in sources]
                    entry['current'] = u', '.join(sorted(set(
                        u'%s %s' % (l or u'?', q or u'?') for l, q in pairs)))[:60]
                    if watchlist.check_film(entry, pairs):
                        found.append((entry.get('title', path), None, entry))
                    continue
                html, _details = self.seriesPage(path)
                if html is None:
                    watchlist.mark_failed(entry)
                    continue
                listed = watchlist.listed_episodes(html)
                fresh = watchlist.check_series(entry, listed, self.episodeHasSources(path))
                if fresh:
                    found.append((entry.get('title', path), fresh, entry))
        finally:
            if progress:
                progress.close()
            watchlist.save(data)

        def describe(fresh, entry=None):
            if fresh == 'appear_ncore':
                return u'megjelent az nCore-on (%s)' % (entry or {}).get('found_ncore', u'torrent')
            if fresh == 'appear':
                got = (entry or {}).get('new') or []
                return u'megjelent a netmozin (%s)' % got[0] if got else u'megjelent a netmozin'
            if fresh is None:
                got = (entry or {}).get('new') or []
                return u'megjött: %s' % got[0] if got else u'megjött, amire vártál'
            return u'%s%s' % (watchlist.label(fresh[0]),
                              u' (+%d)' % (len(fresh) - 1) if len(fresh) > 1 else u'')

        for title, fresh, entry in found:
            control.infoDialog(u'%s: %s' % (title, describe(fresh, entry)),
                               heading=u'Film' if fresh in (None, 'appear', 'appear_ncore') else u'Új rész', time=8000)
            control.log(u'Figyelés: %s -- %s' % (title, describe(fresh, entry)))
        if not quiet:
            if found:
                lines = [u'%s: %s' % (title, describe(fresh, entry))
                         for title, fresh, entry in found]
                control.okDialog(u'Újdonságok:\n' + u'\n'.join(lines))
            else:
                control.okDialog(u'Nincs új rész a figyelt sorozatokban.')
            xbmc.executebuiltin('Container.Refresh')

    # --- Megtekintési előzmények -------------------------------------------

    @staticmethod
    def historyGrade(entry):
        '''"DVD, szinkron" az elozmeny-bejegyzesbol (a bevalt forras alapjan).'''
        return u', '.join(part for part in (entry.get('quality'),
                                            (entry.get('language') or '').lower()) if part)

    def continueSeries(self, base):
        """
        Sorozat okos folytatása a "Már láttam" listából.

        Ha a legutóbbi rész nem ment végig: azt, onnan, ahol abbamaradt.
        Ha végigment: a következőt -- évadhatáron is át, a sorozat oldala
        alapján. Ha nincs több: az évadok listája.
        """
        watchlist.clear_new(base)
        entry = progress.get(base)
        if not entry:
            return self.getSeries(base, auto=self.autoplay)
        if not progress.finished(entry):
            seconds = progress.resume_seconds(entry)
            control.log(u'Folytatás: %s (%d mp)' % (entry['page'], seconds))
            return self.playEpisode(entry['page'], resume=seconds)

        next_page = entry.get('next_page')
        if not next_page:
            # Évad vége: a sorozat oldaláról derül ki, van-e következő évad.
            html, _details = self.seriesPage(base)
            if html is not None:
                following = progress.next_key(entry, watchlist.listed_episodes(html))
                if following:
                    next_page = watchlist.episode_path(base, following)
        if not next_page:
            control.infoDialog(u'Nincs újabb rész -- itt az évadok listája.')
            return self.getSeries(base, auto=self.autoplay)
        control.log(u'Folytatás a következő résszel: %s' % next_page)
        return self.playEpisode(next_page)

    def continueRemove(self, base):
        if progress.remove(base):
            control.infoDialog(u'Törölve a folytatásból')
        xbmc.executebuiltin('Container.Refresh')

    def getHistory(self):
        """
        Amit már láttunk, legfrissebb elöl.

        A tételek a netmozi adatlapra mutatnak (az nem jár le), és megnyitva
        ugyanúgy viselkednek, mint bárhol máshol: ha be van kapcsolva az
        automatikus indítás, egyből indul -- azzal a forrással kezdve,
        ami legutóbb bevált.
        """
        entries = history.load()
        # A frissítés előtti sorozatok is kapjanak folytatás-sort (egyszer).
        progress.migrate(entries)
        series = progress.entries('series')
        films = dict((row['base'], row) for row in progress.entries('film'))
        if not entries and not series:
            control.okDialog(u'Még nincs megtekintési előzmény.\n\n'
                             u'Ami elindul, az ide automatikusan felkerül.')
            return self.endDirectory()

        # EGY lista, a legutóbbi nézés ideje szerint -- sorozat és film
        # vegyesen, ahogy történt. A sorozat EGY sor (tudja, hol tartasz), a
        # részenkénti bejegyzései összecsuknak; a sorozat ideje a legutóbbi
        # rész nézése.
        by_page = dict((entry.get('page'), entry) for entry in entries)
        rows = []
        known = set()
        for row in series:
            known.add(row['base'])
            last = by_page.get(row.get('page')) or {}
            stamp = max(row.get('updated', 0), last.get('time', 0))
            rows.append((stamp, 'series', row))
        for entry in entries:
            parts = progress.split_page(entry.get('page', ''))
            if parts and parts[0] in known:
                continue
            rows.append((entry.get('time', 0), 'film', entry))
        rows.sort(key=lambda item: item[0], reverse=True)

        for _stamp, kind, row in rows:
            if kind == 'series':
                self.addSeriesHistoryRow(row, by_page.get(row.get('page')) or {})
            else:
                self.addFilmHistoryRow(row, films.get(row.get('page', '')))

        self.addDirectoryItem(u'[COLOR red]Előzmények törlése[/COLOR]', 'historyclear',
                              '', 'DefaultFolder.png')
        self.endDirectory(type='movies')

    def addSeriesHistoryRow(self, row, last):
        grade = self.historyGrade(last)
        self.addDirectoryItem(
            u'[COLOR deepskyblue]\u25b6[/COLOR] %s%s  [COLOR gold]%s[/COLOR]%s'
            % (row.get('title') or row['base'], u' [%s]' % grade if grade else u'',
               progress.describe(row),
               u'  [COLOR gray]%s[/COLOR]' % self.historyDate(row.get('updated'))
               if self.historyDate(row.get('updated')) else u''),
            'continueseries&url=%s' % quote_plus(row['base']),
            row.get('thumb', ''), 'DefaultTVShows.png',
            meta={'title': row.get('title', ''), 'mediatype': 'tvshow'},
            context=[
                (u'Évadok', self.navigate('series&url=%s&auto=1' % row['base'])),
                (u'Elölről: %s' % progress.episode_label(row.get('season', 0),
                                                          row.get('episode', 0)),
                 self.navigate('playepisode&url=%s' % quote_plus(row.get('page', '')))),
                (u'Törlés a folytatásból',
                 'continueremove&url=%s' % quote_plus(row['base'])),
            ])

    def addFilmHistoryRow(self, entry, film=None):
        title = entry.get('title') or u'(cím nélkül)'
        label = title
        if entry.get('episode_label'):
            label += u' - %s' % entry['episode_label']
        grade = self.historyGrade(entry)
        if grade:
            label += u' [%s]' % grade
        # Félbehagyott film: a sor mondja, honnan folytatja.
        if film and not progress.finished(film) and progress.resume_seconds(film):
            label += u'  [COLOR gold]folytatás: %d. perctől[/COLOR]' % (
                progress.resume_seconds(film) // 60)
        hint = []
        if entry.get('site'):
            hint.append(entry['site'])
        stamp = self.historyDate(entry.get('time'))
        if stamp:
            hint.append(stamp)
        if hint:
            label += u'  [COLOR gray]%s[/COLOR]' % u' | '.join(hint)
        self.addDirectoryItem(
            label,
            'historyplay&url=%s' % quote_plus(entry.get('page', '')),
            entry.get('thumb', ''), 'DefaultMovies.png',
            meta={'title': title, 'plot': entry.get('plot', ''),
                  'duration': entry.get('duration', 0),
                  'fanart': entry.get('thumb', ''), 'mediatype': 'movie'},
            context=[(u'Törlés a listából',
                      'historyremove&url=%s' % quote_plus(entry.get('page', '')))])

    @staticmethod
    def historyDate(stamp):
        """Rövid dátum a bejegyzéshez."""
        if not stamp:
            return ''
        try:
            return time.strftime('%m.%d.', time.localtime(int(stamp)))
        except (ValueError, TypeError, OSError):
            return ''

    def playHistory(self, url):
        """Újranézés: a legutóbb bevált forrással kezdve."""
        entry = history.find(url)
        if not entry:
            control.okDialog(u'Ez a bejegyzés már nincs meg.')
            return self.endDirectory()
        if not self.autoplay:
            return self.getMovie(url)
        return self.autoplayUrl(url, u'Ehhez a tételhez már nem találok forrást.',
                                prefer=entry.get('site', ''),
                                resume=progress.film_resume(url))

    def removeHistory(self, url):
        history.remove(url)
        control.refresh()

    def clearHistory(self):
        if control.yesnoDialog(u'Előzmények törlése', u'Biztos benne?'):
            history.clear()
            control.refresh()

    # --- Hozzászólás-átfedés ------------------------------------------------

    def requestComments(self):
        """
        Az átfedés visszahozása lejátszás közben.

        A plugin nem tud tartós ablakot nyitni (a hívás után kilép), ezért
        csak jelez; a megjelenítést a háttérszolgáltatás végzi, legfeljebb
        egy másodpercen belül.
        """
        if comments.request_show():
            control.log(u'Átfedés visszakérve')
        else:
            control.errorDialog(u'A kérés nem sikerült')

    def learnCommentKey(self):
        """
        Gombtanítás: a néző megnyomja a gombot, mi megjegyezzük a kódját.

        Így nem kell naplót olvasni ahhoz, hogy kiderüljön, milyen kódot
        küld egy-egy távirányító gomb -- TV-n ez kivitelezhetetlen lenne.
        """
        code = overlay.capture_key()
        if not code:
            return control.okDialog(
                u'Nem érkezett gombnyomás.\n\n'
                u'1. Próbáld meg EGY MÁSIK gombbal (pl. egy számgombbal). Ha az '
                u'sikerül, akkor az előbbi gombot a TV nyeli el, és nem jut el a '
                u'Kodiig -- azt nem lehet használni.\n\n'
                u'2. Ha semmilyen gomb nem működik, kapcsold be: Beállítások > '
                u'Rendszer > Naplózás > Hibakeresési naplózás, és próbáld újra.')
        self.writeKeymap(code)
        control.okDialog(u'Kész.\n\nA betanított gomb (kód: %s) lejátszás közben '
                         u'visszahozza a hozzászólásokat.' % code)

    def installCommentKey(self):
        """Alapértelmezett hozzárendelés: sárga gomb, billentyűzeten Y."""
        self.writeKeymap(None)
        control.okDialog(u'Kész.\n\nLejátszás közben a távirányító SÁRGA gombja '
                         u'(billentyűzeten az Y) hozza vissza a hozzászólásokat.\n\n'
                         u'Ha a távirányítódon nincs sárga gomb, használd a '
                         u'"Gomb betanítása" lehetőséget.')

    def writeKeymap(self, code):
        """
        Billentyű-hozzárendelés kiírása a felhasználói profilba (keymap.py).

        A Kodi onnan olvassa, oda viszont TV-n kényelmetlen fájlt másolni --
        ezért a bővítmény írja ki, majd újratölteti. A "Vissza = szünet"
        kötés (beállítás) ugyanabba a fájlba kerül, megmarad.
        """
        from resources.lib.modules import keymap
        if not keymap.write('' if code is None else code, keymap.back_pause_wanted(), sysaddon):
            control.okDialog(u'A hozzárendelés írása nem sikerült.')
            return False
        return True

    # --- Karbantartás ------------------------------------------------------

    def runDiagnostics(self):
        '''Végigjárja az élő oldalt, és megnevezi a hibás szelektorokat.'''
        progress = xbmcgui.DialogProgressBG()
        progress.create(u'NetMozi', u'Diagnosztika fut...')
        try:
            report = diagnostics.run(self.getSiteCookies())
        except Exception as exc:
            control.log_exception(u'diagnosztika', exc)
            progress.close()
            return control.okDialog(u'A diagnosztika hibára futott: %s' % exc)
        finally:
            progress.close()
        control.log(u'Diagnosztika: %d hiba' % report.failures,
                    control.LOGERROR if report.failures else control.LOGINFO)
        xbmcgui.Dialog().textviewer(u'NetMozi diagnosztika', report.text())

    def forceUpdate(self):
        '''
        Azonnali frissítés-ellenőrzés.

        A Kodi magától csak naponta egyszer kérdezi meg a repókat, ezért egy
        frissen kiadott verzió sokáig "nem jön meg". Itt közvetlenül
        megnézzük a repó listáját, és ha van újabb, rászólunk a Kodira,
        hogy olvassa újra a repókat.
        '''
        installed = xbmcaddon.Addon().getAddonInfo('version')
        addon_id = xbmcaddon.Addon().getAddonInfo('id')
        progress = xbmcgui.DialogProgressBG()
        progress.create(u'NetMozi', u'Frissítés keresése...')
        try:
            # Gyorsítótár nélkül: pont az a kérdés, mi van MOST a szerveren.
            page = client.request(config.UPDATE_ADDONS_XML)
            latest = re.search(config.UPDATE_VERSION_RE % re.escape(addon_id),
                               page or '')
            latest = latest.group(1) if latest else None
        except Exception as exc:
            control.log_exception(u'frissítés ellenőrzése', exc)
            progress.close()
            return control.okDialog(u'Nem sikerült elérni a frissítési '
                                    u'forrást: %s' % exc)
        finally:
            progress.close()

        if not latest:
            return control.okDialog(u'A frissítési forrás elérhető, de nem '
                                    u'szerepel benne a bővítmény.\n'
                                    u'Telepítve: %s' % installed)

        if self.versionTuple(latest) <= self.versionTuple(installed):
            return control.okDialog(u'A legfrissebb verzió van fent.\n'
                                    u'Telepítve: %s' % installed)

        # Van újabb: a Kodit rávesszük, hogy olvassa újra a repókat. Ezután
        # a beállításától függően magától telepít, vagy értesítést ad.
        xbmc.executebuiltin('UpdateAddonRepos')
        control.okDialog(
            u'Új verzió érhető el.\n'
            u'Telepítve: %s   ->   elérhető: %s\n\n'
            u'A repók újraolvasása elindult. Ha egy percen belül nem '
            u'települ, a Kodi beállításaiban a bővítmények frissítése '
            u'valószínűleg "Soha" értéken áll.' % (installed, latest))

    @staticmethod
    def versionTuple(text):
        '''"1.0.94" -> (1, 0, 94); így a 94 nagyobb lesz, mint a 9.'''
        return tuple(int(part) for part in re.findall(r'[0-9]+', text or '0'))

    def checkUpstream(self):
        '''Megmutatja, változott-e az eredeti bővítmény.'''
        progress = xbmcgui.DialogProgressBG()
        progress.create(u'NetMozi', u'Eredeti bővítmény lekérdezése...')
        try:
            report, head = upstream.check()
        except Exception as exc:
            control.log_exception(u'upstream ellenőrzés', exc)
            progress.close()
            return control.okDialog(u'Az ellenőrzés hibára futott: %s' % exc)
        finally:
            progress.close()
        xbmcgui.Dialog().textviewer(u'Eredeti bővítmény változásai', report)
        if head and xbmcgui.Dialog().yesno(
                u'NetMozi', u'Átnézted? Akkor a mostani állapot lesz az új alap, '
                            u'és legközelebb csak az ennél újabbakat mutatja.'):
            upstream.save_state({'commit': head})
            control.infoDialog(u'Alapállapot rögzítve')

    # --- Kodi lista-építés -------------------------------------------------

    @staticmethod
    def navigate(query):
        """
        Helyi menuhoz: olyan muvelet, ami LISTAT nyit (vagy lejatszast indit
        lista-agon). A RunPlugin ezt eldobna; a Container.Update ugy
        viselkedik, mintha a tetelre kattintottak volna.
        """
        return 'Container.Update(%s?action=%s)' % (sysaddon, query)

    def addDirectoryItem(self, name, query, thumb, icon, isAction=True, isFolder=True,
                         fanart=None, meta=None, poster=None, context=None):
        url = '%s?action=%s' % (sysaddon, query) if isAction else query
        if not thumb:
            thumb = icon
        item = xbmcgui.ListItem(label=name)
        if context:
            # A RunPlugin ELDOBJA a listat, amit a bovitmeny epit -- csak
            # parbeszedhez es lejatszashoz jo. Lista-nyito menuponthoz kesz
            # builtin kell (lasd navigate()), az valtozatlanul megy tovabb.
            item.addContextMenuItems(
                [(label, action if action.endswith(')')
                  else 'RunPlugin(%s?action=%s)' % (sysaddon, action))
                 for label, action in context])
        # A poszter külön adható meg: van forrás, ami csak FEKVŐ borítót ad, azt
        # poszter helyére téve a poszter-nézet megnyújtaná.
        item.setArt({'icon': thumb, 'thumb': thumb, 'poster': poster or thumb})
        item.setProperty('Fanart_Image', fanart or addonFanart)
        if not isFolder:
            item.setProperty('IsPlayable', 'true')
        if meta:
            item.setInfo(type='Video', infoLabels=meta)
        xbmcplugin.addDirectoryItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)

    @staticmethod
    def endDirectory(type='addons'):
        xbmcplugin.setContent(syshandle, type)
        xbmcplugin.endOfDirectory(syshandle, cacheToDisc=False)
