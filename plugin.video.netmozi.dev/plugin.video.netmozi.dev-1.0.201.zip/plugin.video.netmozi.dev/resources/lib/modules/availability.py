# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Reszenkenti elerhetoseg a sorozat-nezethez: van-e a resznek elo forrasa a
# netmozin (a resz forrastablaja -- reszenkent egy keres, egy napig
# megjegyezve), es az nCore-on (egy kereses az egesz sorozatra, hat oraig).

import json
import os
import time

from resources.lib.modules import control


FILE = 'availability.json'
TTL_NETMOZI = 24 * 3600
TTL_NCORE = 6 * 3600
MAX_ENTRIES = 2000
PAUSE = 0.2             # mp a netmozi-keresek kozt


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'elérhetőség írása', exc)
        return False


def _fresh(entry, ttl, now):
    return bool(entry) and (now - (entry.get('at') or 0)) < ttl


def netmozi_episode(page, fetch, now=None, data=None, store=True):
    '''
    True/False: van-e elo forras a resz oldalan. `fetch(page)` a
    navigator.siteSources: (details, sources). None halozati hibanal.
    '''
    now = now or time.time()
    data = load() if data is None else data
    entry = data.get('nm:' + page)
    if _fresh(entry, TTL_NETMOZI, now):
        return bool(entry.get('ok'))
    try:
        details, sources = fetch(page)
    except Exception as exc:
        control.log_exception(u'elérhetőség (netmozi)', exc)
        return None
    if details is None:
        return None
    ok = any(s.get('valid') for s in sources or [])
    data['nm:' + page] = {'ok': ok, 'at': int(now)}
    if store:
        _trim(data)
        save(data)
    return ok


def ncore_season(imdb, season, numbers, now=None, data=None):
    '''{reszszam: True/False} az nCore-rol (egy kereses), vagy None.'''
    from resources.lib.modules import ncore
    now = now or time.time()
    data = load() if data is None else data
    key = 'nc:%s/%s' % (imdb, int(season))
    entry = data.get(key)
    if _fresh(entry, TTL_NCORE, now):
        known = entry.get('ok') or {}
        return dict((int(n), bool(known.get(str(int(n))))) for n in numbers)
    result = ncore.season_availability(imdb, season, numbers)
    if result is None:
        return None
    data[key] = {'ok': dict((str(n), v) for n, v in result.items()), 'at': int(now)}
    _trim(data)
    save(data)
    return result


def _trim(data):
    if len(data) > MAX_ENTRIES:
        for old in sorted(data, key=lambda k: data[k].get('at', 0))[:len(data) - MAX_ENTRIES]:
            del data[old]


def season(base, imdb, season_number, numbers, fetch, want_ncore, stop=None, progress=None):
    '''
    Egy evad reszeinek elerhetosege: {reszszam: {'netmozi': 'yes'|'no'|'',
    'ncore': 'yes'|'no'|''}}. Az nCore egy keresessel jon eloszor; a
    netmozi reszenkent, sorban -- `progress(partial)` minden resz utan
    hivodik (a csempek frissitesehez), `stop()` igazra megall.
    '''
    out = dict((int(n), {'netmozi': '', 'ncore': ''}) for n in numbers)
    if want_ncore and imdb:
        try:
            found = ncore_season(imdb, season_number, numbers)
        except Exception as exc:
            control.log_exception(u'elérhetőség (nCore)', exc)
            found = None
        if found is not None:
            for n, ok in found.items():
                out[n]['ncore'] = 'yes' if ok else 'no'
        if progress:
            progress(dict((k, dict(v)) for k, v in out.items()))
    data = load()
    for n in numbers:
        if stop and stop():
            break
        page = '%s/s%d/e%d' % (base, int(season_number), int(n))
        was_cached = _fresh(data.get('nm:' + page), TTL_NETMOZI, time.time())
        ok = netmozi_episode(page, fetch, data=data, store=False)
        if ok is not None:
            out[int(n)]['netmozi'] = 'yes' if ok else 'no'
        if progress:
            progress(dict((k, dict(v)) for k, v in out.items()))
        if not was_cached:
            time.sleep(PAUSE)                        # a netmozit ne terheljuk sorozatban
    _trim(data)
    save(data)
    return out
