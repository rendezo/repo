# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import hashlib
import json
import sqlite3
import time

from resources.lib.modules import control

DEFAULT_TABLE = 'rel_list'
ALL_TABLES = ('rel_list', 'rel_lib')

# A tabla neve sosem jon kivulrol, de a biztonsag kedveert szurjuk.
_SAFE_TABLE = frozenset(ALL_TABLES)


def _table_name(table):
    return table if table in _SAFE_TABLE else DEFAULT_TABLE


def _func_key(function):
    '''Stabil, olvashato kulcs a fuggvenyhez (pl. "navigator.getCookiesWithLogin").'''
    try:
        return getattr(function, '__qualname__', None) or function.__name__
    except AttributeError:
        return repr(function)


def _args_key(args):
    digest = hashlib.md5()
    for arg in args:
        # A str() eredmenyet kell bytera alakitani, kulonben py3-ban TypeError.
        digest.update(repr(arg).encode('utf-8'))
    return digest.hexdigest()


def _connect(table):
    control.makeFile(control.dataPath)
    connection = sqlite3.connect(control.cacheFile, timeout=10)
    connection.execute(
        'CREATE TABLE IF NOT EXISTS %s ('
        'func TEXT, args TEXT, response TEXT, added TEXT, '
        'UNIQUE(func, args));' % table)
    return connection


def _read(connection, table, func, args):
    '''(ertek, kor) parral ter vissza, vagy (None, None) ha nincs hasznalhato sor.'''
    row = connection.execute(
        'SELECT response, added FROM %s WHERE func = ? AND args = ?' % table,
        (func, args)).fetchone()
    if not row:
        return None, None
    try:
        value = json.loads(row[0])
    except (ValueError, TypeError):
        # Regi, repr()-alapu bejegyzes egy korabbi verziobol -- eldobjuk.
        control.log('cache: nem JSON bejegyzes eldobva (%s)' % func, control.LOGDEBUG)
        return None, None
    try:
        age_hours = abs(int(time.time()) - int(row[1])) / 3600.0
    except (ValueError, TypeError):
        return None, None
    return value, age_hours


def _write(connection, table, func, args, value):
    connection.execute(
        'INSERT OR REPLACE INTO %s (func, args, response, added) VALUES (?, ?, ?, ?)' % table,
        (func, args, json.dumps(value), int(time.time())))
    connection.commit()


def get(function, timeout_hours, *args, **kwargs):
    '''
    Lefuttatja a fuggvenyt, es az eredmenyt `timeout_hours` oraig cache-eli.

    Ha a fuggveny hibara fut vagy ures eredmenyt ad, a lejart cache-ertek
    meg mindig jobb a semminel -- azt adjuk vissza.
    '''
    table = _table_name(kwargs.get('table', DEFAULT_TABLE))
    func = _func_key(function)
    args_key = _args_key(args)

    cached, age_hours = None, None
    connection = None
    try:
        connection = _connect(table)
        cached, age_hours = _read(connection, table, func, args_key)
        if cached is not None and age_hours is not None and age_hours < timeout_hours:
            return cached
    except sqlite3.Error as exc:
        control.log_exception('cache olvasas (%s)' % func, exc)

    try:
        fresh = function(*args)
    except Exception as exc:
        control.log_exception('cache-elt hivas (%s)' % func, exc)
        return cached

    if fresh is None or fresh == []:
        # Nem sikerult frissiteni: inkabb a lejart ertek, mint a semmi.
        return cached if cached is not None else fresh

    if connection is not None:
        try:
            _write(connection, table, func, args_key, fresh)
        except (sqlite3.Error, TypeError, ValueError) as exc:
            control.log_exception('cache iras (%s)' % func, exc)

    return fresh


def peek(function, *args, **kwargs):
    """
    Csak a gyorsitotarban levo ertek, barmilyen regi -- halozat NELKUL.
    None, ha nincs. A boritos kezdokepernyo ezzel nyilik azonnal; a friss
    adat kesobb, a hatterben jon (get()).
    """
    table = _table_name(kwargs.get('table', DEFAULT_TABLE))
    try:
        connection = _connect(table)
        cached, _age = _read(connection, table, _func_key(function), _args_key(args))
        return cached
    except sqlite3.Error as exc:
        control.log_exception('cache olvasas (%s)' % _func_key(function), exc)
        return None


def clear(table=None, confirm=True):
    '''Cache tablak uritese. `confirm=False` eseten nem kerdez ra.'''
    tables = ALL_TABLES if table is None else (
        (table,) if not isinstance(table, (list, tuple)) else tuple(table))
    try:
        control.idle()
        if confirm and not control.yesnoDialog(u'Gyorsítótár törlése', u'Biztos benne?'):
            return False
        with sqlite3.connect(control.cacheFile, timeout=10) as connection:
            for name in tables:
                connection.execute('DROP TABLE IF EXISTS %s' % _table_name(name))
            connection.commit()
        # A VACUUM nem futhat tranzakcioban, ezert kulon kapcsolaton megy.
        vacuum = sqlite3.connect(control.cacheFile, timeout=10)
        vacuum.isolation_level = None
        vacuum.execute('VACUUM')
        vacuum.close()
        control.infoDialog(u'Folyamat befejeződött')
        return True
    except sqlite3.Error as exc:
        control.log_exception('cache torles', exc)
        control.errorDialog(u'A gyorsítótár törlése nem sikerült')
        return False
