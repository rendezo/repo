# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Minden oldal-specifikus szelektor, regex és szöveges marker EGY helyen.
# Ha a netmozi.com átdesignol, először ITT kell javítani -- a navigator.py-ban
# nem maradhat HTML-osztálynév vagy regex.

BASE_URL = 'https://netmozi.com/'
LOGIN_PATH = 'login/do'

# A bejelentkezés akkor sikeres, ha a válasz cookie-i közt ez szerepel.
LOGIN_OK_COOKIE = 'ca='

# Lista-oldal URL sablonja: page, type, order, search sorrendben.
LIST_URL = '%s?page=%s&type=%s&order=%s&search=%s'

# Ajánló oldalak. Egyoldalasak, nincs lapozó, de a listaelemek szerkezete
# ugyanaz, mint a rendes listáé.
RECOMMENDED_URL = '%s?recommended&recommended_type=%s'
RECOMMENDED_TYPES = (
    ('1', u'Premier'),
    ('2', u'DVD'),
    ('3', u'Sorozatok'),
)

# Év szerinti szűrés. Az oldal szerveroldalon támogatja, ezért a lapozás és
# az elemszám is helyes marad -- nem utólag szórjuk ki a találatokat.
YEAR_FILTER = '&year_from=%s&year_to=%s'

# Nyelv szerinti szures a listakon (ugyanaz a parameter, amit a reszletes
# kereso is hasznal). Az ertekek az oldal urlapjabol jonnek (search.py);
# ha az nem erheto el, ez a tartalek -- elo meresbol: Magyar = 1.
LANGUAGE_FILTER = '&language=%s'
LANGUAGE_FALLBACK = (('1', u'Magyar'),)

# A részletes keresés űrlapja tartalmazza a legnagyobb választható évet.
YEAR_MAX_RE = r'name="year_from"[^>]*?max="([0-9]{4})"'
YEAR_MIN = 1920

# A "nincs év szűrés" jelölése a plugin URL-ekben.
YEAR_ALL = ''


# --- Rendezési lehetőségek (getOrderTypes) ----------------------------------

ORDER_SELECT_ID = 'order_by_select'
ORDER_OPTION_RE = r'<option value="([0-9])"(.*)>(.*)</option>'

# Ezek a rendezések nem jelennek meg a menüben.
# Szándékosan a FELIRAT részlete alapján szűrünk, nem az érték alapján: ha az
# oldal átírja a szöveget, a menüpont legfeljebb visszajelenik (látható, könnyen
# javítható), míg egy átszámozásnál az érték szerinti szűrés némán rossz sort
# tüntetne el.
HIDDEN_ORDERS = (u'Név alapján',)


# --- Lista-oldal (getMovies) ------------------------------------------------

LIST_ITEM_CLASS = 'col-12.*?'
LIST_TITLE_CLASS = 'col_name'
LIST_LINK_CLASS = 'col_a'
LIST_COL_CLASS = 'col-sm-6'          # [0] = borító, [1] = adatblokk
LIST_ROW_CLASS = 'row'

# A title attribútumot ki kell vágni, mert elrontja a col_name keresését.
LIST_TITLE_ATTR_RE = r'(.*?)(title="[^"]*?")(.*)'

SERIES_MARKER = '(sorozat)'
SERIES_MARKER_HTML = '<small>(sorozat)</small>'

# Adatsor-címkék: PONTOSAN úgy, ahogy az oldal HTML-jében szerepelnek.
LABEL_YEAR = 'Év:'
LABEL_DURATION = 'Játékidő:'
LABEL_LINKCOUNT = 'Megtekintő linkek:'
LABEL_PLOT = 'Leírás'
LABEL_CATEGORY = 'Kategória:'

# A kategóriák vesszővel elválasztva érkeznek ("Horror , Misztikus").
CATEGORY_SPLIT_RE = r'\s*,\s*'
# Ennél többet nem írunk ki a listában, hogy a cím ne szoruljon ki.
CATEGORY_BADGE_MAX = 3

# A listasor VEGEN egy zaszlo (nyelv) es mellette a minoseg: a film legjobb
# valtozata. Egy sorban egy par van. A zaszlo fajlneve ugyanaz, mint a
# forrastablaban (LANGUAGE_FLAGS), a minoseg a QUALITY_LADDER egy foka.
LIST_BADGE_RE = r'<img[^>]*src="/pic/([^"]+)"[^>]*>\s*([^<]*)'

YEAR_RE = r'([0-9]{4})'
DURATION_RE = r'([0-9]+) perc'
LINKCOUNT_RE = r'([0-9]+)db'
DURATION_SUFFIX = ' perc'

PAGER_SELECT_NAME = 'page'


# --- Adatlap (getMovie / getSeries / getEpisodes) ---------------------------

DETAIL_CONTAINER_CLASS = 'container'
DETAIL_TITLE_TAG = 'h3'
DETAIL_SUBTITLE_TAG = 'h4'
DETAIL_INFO_CLASS = 'col-sm-8'
DETAIL_THUMB_CLASS = 'col-sm-4'

# A rész URL-je "<sorozat>/s<évad>/e<rész>" alakú; ebből tudjuk kiszedni,
# hol tartunk, amikor a hátralévő részeket sorba állítjuk.
EPISODE_URL_RE = r'^(?P<base>.*)/s(?P<season>\d+)/e(?P<episode>\d+)$'

SEASON_LIST_ID = 'seasonUl'          # évadok; a részekhez: SEASON_LIST_ID + évadszám

# Regisztrációhoz kötött tartalom jelzése az adatlapon.
REGISTRATION_MARKER = 'regeljbe.png'

# --- Hozzászólások az adatlapon ---------------------------------------------
# Szerveroldalon renderelve érkeznek, abban a HTML-ben, amit az adatlaphoz
# amúgy is letöltünk -- nincs szükség külön kérésre.
COMMENT_CARD_CLASS = 'card'
COMMENT_CARD_MARKER = 'Hozzászólások'
COMMENT_ENTRY_TAG = 'fieldset'
COMMENT_HEAD_TAG = 'legend'
COMMENT_DATE_RE = r'([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2})'

# A "megtekintő linkek" gomb, ami a külső forrástáblára mutat.
LINKS_BUTTON_CLASS = 'details_links_btn'


# --- Forrástábla a külső link-oldalon (getMovie második kérés) --------------

SOURCE_CARD_CLASS = 'card .+?'
SOURCE_TABLE_WRAP_CLASS = 'table-responsive'
SOURCE_TABLE_CLASS = 'table'
SOURCE_PLAY_BTN_CLASS = 'btn btn-outline-primary btn-sm action-btn'

# A forrás-URL tokenes és néhány óránként változik, a benne lévő azonosító
# viszont állandó. Bármit, amit forráshoz KÖTVE jegyzünk meg (pl. mért
# sebesség), erre kell kulcsolni -- különben a token lejártával elveszik.
SOURCE_ID_RE = r'/links/open/([0-9]+)'

# Oszlopindexek a forrástábla sorain belül.
COL_LANGUAGE = 0
COL_VALID = 1
COL_PLAY = 3
COL_QUALITY = 4
COL_SITE = 5

# Nyelv-zászlók -> megjelenítendő címke. A sorrend számít: az első találat nyer.
LANGUAGE_FLAGS = (
    ('hungary.gif', 'Szinkron'),
    ('usa.gif', 'Külföldi'),
    ('uk-hu.png', 'Felirat'),
)
LANGUAGE_UNKNOWN = 'Ismeretlen'

# Minoseg-letra, gyengetol a joig -- az oldal reszletes keresojenek sorrendje.
# A "meg nezheto" kuszob beallitas (minquality); ami a letran a kuszob
# ALATT van, az gyenge. Ismeretlen cimke: nem tudjuk, hova tartozik -> nem
# szamit jonak (ovatosan: inkabb egy elmaradt jelzes, mint egy hamis).
QUALITY_LADDER = ('CAM', 'TS', 'TC', 'HCHDRip', 'DVD-Mozis hang', 'DVD')
QUALITY_MIN_DEFAULT = 'TS'

# A beállításban felkínált hangsávok. A "Mindegy" jelenti, hogy nem
# rendezünk át semmit -- marad az oldal saját sorrendje.
LANGUAGE_ANY = u'Mindegy'
LANGUAGE_SUBTITLED = 'Felirat'       # ennél töltünk le feliratot

# Érvénytelen forrás jelzése.
INVALID_SOURCE_MARKER = 'red_mark.png'


# --- Lejátszási lánc (playmovie) -------------------------------------------

# Közvetítő oldal, ami base64-ben vagy iframe-ben rejti a valódi forrást.
REDIRECT_HOST_MARKER = 'mindjart.megnezed'
REDIRECT_B64_RE = r'^(.*)function counter(.*)var link([^=]*)=([^"]*)"([^"]*)";(.*)$'
REDIRECT_IFRAME_RE = r'<iframe[^>]*src=[\'"]([^\'"]+)[\'"]'

# Ezeket a hostokat a ResolveURL előtt JS-deobfuszkálással kell bontani.
JSUNHUNT_HOSTS = ('streamplay', 'sbot')
JSUNHUNT_SRC_RE = r'.*setAttribute\("src","([^"]*)".*'


# --- Cache élettartamok (óra) ----------------------------------------------

CACHE_HOURS_USER_AGENT = 1
CACHE_HOURS_LOGIN_COOKIE = 24
CACHE_HOURS_ANON_COOKIE = 24 * 365
CACHE_HOURS_VISITOR_ID = 24

# A Netflix Top 10 hetente frissül, napi egy letöltés bőven elég (~900 kB).
CACHE_HOURS_NETFLIX = 24


# --- Automatikus lejátszás (Netflix Top 10) --------------------------------

# Ennyi forrásnál tovább nem próbálkozunk: a Kodi megszakítja a túl sokáig
# futó bővítmény-hívást, és a felhasználó sem vár a végtelenségig.
AUTOPLAY_MAX_SOURCES = 6

# Ennyi másodpercig várjuk, hogy a lejátszás TÉNYLEGESEN elinduljon.
# Ha nem indul el, jön a következő forrás.
AUTOPLAY_START_TIMEOUT = 15

# A lejátszási listából / Up Next-ből hívott feloldásnál a Kodi VÁR ránk, és
# ha sokáig tart, feladja ("Can't find item to play"). Ezért itt jóval
# kevesebb forrást próbálunk, mint az interaktív, folyamatjelzős ágon.
RESOLVE_MAX_SOURCES = 3

# Up Next: az ertesitest CSAK AZUTAN kuldjuk, hogy az uj resz tenylegesen
# elindult. Az Up Next a kovetkezo reszt Player.Open-nel inditja, ami eloszor
# feloldat velunk, es csak UTANA allitja le az elozo reszt -- annak a leallasi
# esemenye pedig torli az Up Next-nel levo adatot. Ha a feloldas kozben
# szolunk, elveszik. Ezert megvarjuk, hogy a lejatszo a MI fajlunkat jatssza,
# es meg egy kis turelmi idot is hagyunk az esemenyek lefutasara.
UPNEXT_START_TIMEOUT = 20
UPNEXT_GRACE = 2

# Ha egy résznek egyetlen forrása sem oldható fel, ennyi KÖVETKEZŐ részt
# próbálunk még az évadon belül, mielőtt feladjuk. Beállításból jön; ez
# csak a tartalék, ha nem olvasható.
#
# Minden átugrott rész két oldalletöltés plusz forrásfeloldás, tehát a
# magas érték hosszú várakozást is jelenthet.
EPISODE_SKIP_MAX = 5

# A feliratok a lejátszás ELŐTT töltődnek le, tehát minden másodpercük
# késlelteti az indulást. Ezért CSAK EGYET töltünk le -- de a jót: a magyart.
# Így nem kell lejátszás közben nyelvet váltani, és gyorsabb is.
SUBTITLE_TIMEOUT = 8


# --- Források előzetes ellenőrzése -----------------------------------------
#
# Minden forrás feloldása MÁSODPERCEKBE telik, plusz a sebességminta, ezért
# korlátozzuk. A feloldás sikere csak azt mondja meg, hogy a forrás ÉL --
# az akadozást a sebesség okozza, azt külön mérjük.

CHECK_MAX_SOURCES = 8
CHECK_SAMPLE_BYTES = 384 * 1024
CHECK_TIMEOUT = 8

# Ez alatt a sebesség alatt akadozás várható (kB/s).
CHECK_SLOW_LIMIT = 400

# A lejatszas elotti gyors ellenorzes idokorlatja. Roviden tartjuk: csak azt
# nezi meg, hogy videot kapunk-e vagy weboldalt. Igy egy jatszhatatlan forras
# fel masodperc alatt kiesik ahelyett, hogy AUTOPLAY_START_TIMEOUT masodpercig
# varnank egy lejatszasra, ami sosem indul el.
PLAYABLE_CHECK_TIMEOUT = 5

# Nyelvjelölések, amikre a magyar feliratot felismerjük. Kisbetűsítve,
# részlet-egyezéssel keresünk, mert a források eltérően nevezik el
# ("hu", "hun", "Hungarian", "magyar", "HU_forced" ...).
SUBTITLE_PREFERRED = ('magyar', 'hungarian', 'hun', 'hu')

# --- Saját frissítés ---------------------------------------------------------
#
# A Kodi magától NAPONTA EGYSZER nézi meg a repókat, ezért egy frissen kiadott
# verzió akár egy napig sem jelenik meg. Ez a cím teszi lehetővé, hogy azonnal
# megkérdezzük: van-e újabb, mint ami telepítve van.
UPDATE_ADDONS_XML = 'https://rendezo.github.io/repo/addons.xml'
UPDATE_VERSION_RE = r'id="%s"[^>]*?version="([0-9][0-9.]*)"'


# --- Rejtett, felnottkorhoz kotott lista ------------------------------------
#
# Nincs hozza menupont sehol. Csak ugy jon elo, ha a keresobe PONTOSAN ezt a
# szot irjuk (kis/nagybetu es a szelek szokoze nem szamit). A szo nem kerul be
# a keresesi elozmenybe, es az innen inditott lejatszas nem kerul be a "Mar
# lattam" listaba sem -- kulonben a rejtes ertelmetlen lenne.
#
# Ha meg akarod valtoztatni, itt az egyetlen hely.
# --- Sorozat folytatasa ------------------------------------------------------
#
# A hatterszolgaltatas nezes kozben ennyi masodpercenkent jegyzi fel, hol
# tart a resz. Kilepeskor legfeljebb ennyi vesz el.
PROGRESS_INTERVAL = 15

# Ha a resznek legalabb ekkora hanyada lement, megnezettnek szamit, es a
# folytatas mar a KOVETKEZO reszt inditja. (A stablista miatt nem 100%.)
CONTINUE_DONE_RATIO = 0.9

# Ennel kevesebbnel nem erdemes visszatekerni: az elejerol indul.
CONTINUE_MIN_SECONDS = 60

# Folytatas: a lejatszas inditasa utan ennyi masodpercig varjuk, hogy a
# stream megnyiljon (a hossz ismert legyen). Egy HLS-forras lassu dobozon
# akar fel percig is nyilik -- 10 mp keves volt, es a tekeres elmaradt.
RESUME_WAIT = 60
# A Kodi az indulas elso pillanataiban neha figyelmen kivul hagyja a
# tekerest: ellenorizzuk, hova ert, es ha nem oda, ujra probaljuk.
RESUME_RETRIES = 4
RESUME_SETTLE = 2          # mp: ennyit varunk egy tekeres utan, mielott ellenorzunk
RESUME_TOLERANCE = 30      # mp: ennyivel a cel elott mar "ott vagyunk"

# Egy inditas csak akkor tartozik a legutobb megnyitott adatlaphoz, ha
# ennyi masodpercen belul indult utana. Kesobbi lejatszas (mas bovitmeny,
# vagy a rejtett lista) NEM irhat a folytatasba. Tag, mert az automatikus
# inditas rossz forrasokkal percekig is probalkozhat -- ha kozben lejarna,
# a film folytatasa elveszne.
CONTEXT_FRESH_SECONDS = 900

# --- TMDB (themoviedb.org) a kezdokepernyohoz --------------------------------
# A nezo sajat, ingyenes API-kulcsaval. Egy cimhez EGY keres, valaha (a
# valasz -- hatterkep, szolgaltatok, elozetes -- megjegyzodik). A TMDB nem
# napi keretet, hanem masodpercenkenti tempot korlatoz (~50/mp); mi ennek
# a toredeken megyunk.
TMDB_API = 'https://api.themoviedb.org/3'
TMDB_IMAGE = 'https://image.tmdb.org/t/p/w1280%s'
TMDB_STILL = 'https://image.tmdb.org/t/p/w780%s'   # reszek allokepe
TMDB_POSTER = 'https://image.tmdb.org/t/p/w342%s'  # allo poszter (a mese-sorok netmozi nelkuli cimeihez)

# --- Mese-profil: a szolgaltatok mese-kinalata ---------------------------------
# A TMDB mufajai: 16 Animation, 10751 Family (film), 10762 Kids (sorozat).
TMDB_KIDS_GENRES = {'movie': '16|10751', 'tv': '16|10762'}
KIDS_PROVIDERS = (('disney', u'Disney+ mesék', 337), ('netflix', u'Netflix mesék', 8),
                  ('hbomax', u'HBO Max mesék', 1899), ('skyshowtime', u'SkyShowtime mesék', 1773))
KIDS_PER_KIND = 20                  # TMDB: film + sorozat, ennyi-ennyi szolgaltatonkent
KIDS_SEARCH_MAX = 80                # ennyi netmozi-keresest egy futasban
KIDS_CHECK_TTL = 30 * 24 * 3600     # az IMDb korhatar/mufaj ellenorzese ennyi ideig ervenyes
TMDB_REGION = 'HU'                  # melyik orszag kinalata
TMDB_TIMEOUT = 6
TMDB_MAX_ENTRIES = 1200             # ennyi cimet jegyzunk meg (tmdb.json)
# A kezdokepernyo megnyitasakor a hatterben, a sorok tetelein vegigmegy --
# ennyit egy megnyitasra, es ennyit varva a keresek kozt (mp).
TMDB_PREFETCH_MAX = 150
TMDB_PREFETCH_PAUSE = 0.25

# Streaming-szolgaltatok: a TMDB neve -> rovid felirat a borito alatt.
# Ami nincs itt, a TMDB nevevel jelenik meg; a "with Ads" es az "Amazon
# Channel" valtozatok kimaradnak (ugyanaz a szolgaltato).
TMDB_SERVICE_LABELS = (
    ('Netflix', u'Netflix'),
    ('Amazon Prime Video', u'Prime'),
    ('Disney Plus', u'Disney+'),
    ('HBO Max', u'HBO Max'),
    ('Max', u'HBO Max'),
    ('Apple TV', u'Apple TV'),
    ('Apple TV Plus', u'Apple TV'),
    ('Apple TV+', u'Apple TV'),
    ('SkyShowtime', u'SkyShowtime'),
)
TMDB_SERVICE_SKIP = ('Ads', 'Channel')
TMDB_SERVICE_MAX = 2                # ennyi szolgaltato fer a borito ala

# Szolgaltato-sorok a kezdokepernyon:
#   (sor kulcsa, cim, Movie of the Night szolgaltato, TMDB provider id)
# A cimek forrasa sorrendben: a szolgaltato HIVATALOS top listaja (Movie of
# the Night, ha van kulcs), kulonben a TMDB magyar kinalata nepszeruseg
# szerint (ha van TMDB-kulcs). A Netflix/Apple/Prime sorhoz TMDB-t nem
# hasznalunk: kulcs nelkul marad a netmozi sajat Stream Top-ja. Mindenhol
# csak az latszik, ami megvan a netmozin.
PROVIDER_ROWS = (
    ('netflix', u'Netflix Top', 'netflix', None),
    ('apple', u'Apple Top', 'apple', None),
    ('prime', u'Prime Top', 'prime', None),
    ('disney', u'Disney+ Top', 'disney', 337),
    ('hbomax', u'HBO Max Top', 'hbo', 1899),
    ('skyshowtime', u'SkyShowtime Top', '', 1773),   # a MOTN-nek nincs SkyShowtime listaja
)
PROVIDER_PER_KIND = 20              # TMDB: film + sorozat, ennyi-ennyi szolgaltatonkent
PROVIDER_CHECK_INTERVAL = 24 * 3600 # naponta egyszer a listak
PROVIDER_RECHECK = 7 * 24 * 3600    # a netmozi-talalat (es a "nincs") hetente
PROVIDER_SEARCH_MAX = 80            # ennyi netmozi-keresest egy futasban (a tobbi masnap)
PROVIDER_SEARCH_PAUSE = 0.6         # mp a keresesek kozt

# nCore (torrent, Elementumon at): az inditasra ennyi masodpercet varunk --
# a puffereles lassabb, mint egy hoszter megnyitasa.
NCORE_START_TIMEOUT = 120
NCORE_TEST_IMDB = 'tt0111161'       # a belepes-probahoz: A remeny rabjai
# Mikor induljon az nCore magatol (a beallitas cimkei -- a Kodi a cimket
# tarolja). Alapbol TARTALEK: a netmozi olcsobb, mint a torrent (a torrent
# visszaosztasi kotelezettseg), ezert elobb a hoszterek, es csak ha egyik
# sem indul, jon a torrent.
NCORE_MODES = (
    ('manual', u'Csak kézzel, a Források menüből'),
    ('fallback', u'Tartalék: ha a netmozin egyik forrás sem indul'),
    ('better', u'Ha jobb minőség van rajta, mint a netmozin'),
    ('always', u'Mindig előbb a torrent'),
)
NCORE_MODE_DEFAULT = 'fallback'
NCORE_FALLBACK_TRIES = 2            # tartalekkent ennyi torrentet probal a hoszterek utan

# IMDb (kulcs nelkul, imdb.py): a "Hamarosan" sor -- ennyi napra elore,
# ennyi cim, nepszeruseg szerint.
UPCOMING_DAYS = 45
UPCOMING_COUNT = 24
CACHE_HOURS_UPCOMING = 24

# Movie of the Night (Streaming Availability API): a hivatalos top listak.
MOTN_API = 'https://api.movieofthenight.com/v4'
MOTN_COUNTRY = 'hu'
MOTN_TIMEOUT = 10

# Elozetes a kezdokepernyon: ha ennyi masodpercig ugyanazon a boriton allsz,
# a hatterben elindul az elozetes (YouTube bovitmenyen at), hanggal.
TRAILER_DELAY = 3.0
TRAILER_START_GRACE = 8     # mp: ennyi ideig varjuk, hogy a kesz cim elinduljon
# (A YouTube-os elozetes kivezetve: az elozetes az IMDb-rol jon, trailer.py.)
# A hatterszolgaltatas ennyi masodperc utan mar nem hiszi el a jelzot
# (ha a kezdokepernyo torlés nelkul tunt volna el).
TRAILER_STALE = 1200
TRAILER_PROPERTY = 'netmozi.trailer'   # Window(10000) tulajdonsag: idobelyeg, amig megy


def trailer_marked(now=None):
    '''
    Megy-e eppen elozetes (a kezdokepernyo jelzi). A hatterszolgaltatas
    ebbol tudja, hogy az a lejatszas nem film: nincs folytatas-koveto,
    nincs hozzaszolas. A jelzo idobelyeges: a nagyon regi nem szamit.
    '''
    import time
    import xbmcgui
    try:
        marked = xbmcgui.Window(10000).getProperty(TRAILER_PROPERTY)
    except Exception:
        return False
    if not marked:
        return False
    try:
        return ((now or time.time()) - int(marked)) < TRAILER_STALE
    except ValueError:
        return False

# --- Mit nezzek ma este? -----------------------------------------------------
TONIGHT_TYPE = '1'          # csak film (a sorozat nem "egy este")
TONIGHT_RATING = '7'        # IMDb legalabb
TONIGHT_MAX_PAGE = 20       # ennyi oldal kozul sorsolunk (a legjobbak elol)
TONIGHT_TRIES = 8           # ennyi "Masikat" utan feladjuk

ADULT_KEYWORD = 'makpf'

# Egy talalati oldal utan felkinaljuk a kovetkezot.
ADULT_PAGE_SIZE = 27
