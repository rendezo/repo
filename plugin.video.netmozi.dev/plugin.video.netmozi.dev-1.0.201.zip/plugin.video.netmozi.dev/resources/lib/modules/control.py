# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from xbmcvfs import translatePath


# --- Kodi API rovidítések ---------------------------------------------------

addon = xbmcaddon.Addon
addonInfo = xbmcaddon.Addon().getAddonInfo
lang = xbmcaddon.Addon().getLocalizedString


# A SZEMELYES beallitasok (hang, automatikus inditas, elozetes, intro,
# hozzaszolas, figyeles) a nevvel letrehozott profiloknal a profil sajat
# fajljaban elnek (settings.json a profil mappajaban); amig ott nincs
# ertek, a Kozos (a Kodi altalanos) beallitasa ervenyes. Az eszkozhoz
# kotott dolgok (belepes, kulcsok, nCore, elrendezes, Vissza=szunet)
# mindig kozosek.
PERSONAL_SETTINGS = ('preferlanguage', 'listlanguage', 'listlanguagelabel', 'hometrailer',
                     'trailerdelay', 'homebackdrop', 'autoplay', 'autoplaytimeout',
                     'autoplaymaxsources', 'autoplaynext', 'skipdeadepisode', 'episodeskipmax',
                     'introskip', 'commentoverlay', 'commentdelay', 'minquality', 'watchseries')
PROFILE_SETTINGS_FILE = 'settings.json'
_profile_settings_cache = {'path': None, 'stamp': None, 'data': {}}


def profileSettingsPath():
    return os.path.join(profileDir(), PROFILE_SETTINGS_FILE)


def profileSettings():
    '''{kulcs: ertek}: az aktiv, nevvel letrehozott profil sajat beallitasai ({} a Kozosnel).'''
    if not activeProfile():
        return {}
    import json
    path = profileSettingsPath()
    try:
        stamp = os.stat(path).st_mtime
    except OSError:
        return {}
    cache = _profile_settings_cache
    if cache['path'] == path and cache['stamp'] == stamp:
        return cache['data']
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        data = data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        data = {}
    cache.update(path=path, stamp=stamp, data=data)
    return data


def _writeProfileSettings(data):
    import json
    path = profileSettingsPath()
    makeFile(os.path.dirname(path))
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=1)
    _profile_settings_cache['path'] = None


def setting(key):
    '''
    Mindig FRISS Addon-peldanyon at: a Kodi a mar letrehozott peldanyba nem
    tolti be a kesobb elmentett beallitasokat. A rovid eletu menu-hivasoknal
    ez mindegy, a hosszan futo kezdokepernyonel (es a szolgaltatasnal) nem
    -- ott a beallitas-valtozas kulonben csak ujrainditas utan latszott.
    A szemelyes kulcsoknal elobb az aktiv profil sajat erteke.
    '''
    if key in PERSONAL_SETTINGS:
        own = profileSettings()
        if key in own:
            return own[key]
    try:
        return xbmcaddon.Addon().getSetting(key)
    except RuntimeError:
        # Frissites kozben a Kodi egy pillanatra nem ismeri a bovitmenyt
        # ("Unknown addon id"): a futo kezdokepernyo ne haljon bele.
        return ''


def settingBool(key):
    return (setting(key) or '').strip().lower() == 'true'


def setSetting(key, value):
    '''Friss peldanyon at; a szemelyes kulcsok nevvel letrehozott profilnal a profil fajljaba.'''
    if key in PERSONAL_SETTINGS and activeProfile():
        data = dict(profileSettings())
        data[key] = value
        try:
            _writeProfileSettings(data)
            return True
        except (IOError, OSError, TypeError, ValueError) as exc:
            log_exception(u'profil beállítás írása', exc)
            return False
    try:
        return xbmcaddon.Addon().setSetting(key, value)
    except RuntimeError:
        return False


def addonKnown():
    '''Ismeri-e a Kodi most a bovitmenyt (frissites kozben egy pillanatra nem).'''
    try:
        xbmcaddon.Addon()
        return True
    except RuntimeError:
        return False

addItem = xbmcplugin.addDirectoryItem
directory = xbmcplugin.endOfDirectory
content = xbmcplugin.setContent
resolve = xbmcplugin.setResolvedUrl
item = xbmcgui.ListItem

keyboard = xbmc.Keyboard
condVisibility = xbmc.getCondVisibility
jsonrpc = xbmc.executeJSONRPC
execute = xbmc.executebuiltin
sleep = xbmc.sleep

openFile = xbmcvfs.File
# mkdirs: a profilok mappaja beagyazott (profiles/<nev>/), a mkdir csak egy szintet hozna letre.
makeFile = xbmcvfs.mkdirs
deleteFile = xbmcvfs.delete
listDir = xbmcvfs.listdir
transPath = translatePath


# --- Utvonalak --------------------------------------------------------------

addonPath = translatePath(addonInfo('path'))
dataPath = translatePath(addonInfo('profile'))

# --- Profilok ("Ki nez?") -----------------------------------------------------
#
# A SZEMELYES adatok (elozmeny, folytatas, figyelt lista, tanult introk)
# profilonkent kulon mappaban elnek. A nevtelen "Kozos" profil a gyoker:
# ami eddig volt, az marad ott. Az aktiv profil neve egy kis fajlban van;
# minden olvasas ezt nezi, hogy a plugin es a szolgaltatas (kulon
# folyamatok) ugyanazt lassak.

PROFILE_FILE = 'profile.json'
PROFILES_DIR = 'profiles'


def _profile_state():
    import json
    try:
        with open(os.path.join(dataPath, PROFILE_FILE), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def profileSlug(name):
    """Mappanev egy profilnevbol: csak betu/szam/kotojel."""
    import re as _re
    import unicodedata
    text = unicodedata.normalize('NFKD', name or '')
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    return _re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')[:40]


def activeProfile():
    """Az aktiv profil neve, vagy '' (Kozos)."""
    return (_profile_state().get('active') or '').strip()


def profileDir():
    """Ahova a szemelyes adatok kerulnek."""
    name = activeProfile()
    if not name:
        return dataPath
    return os.path.join(dataPath, PROFILES_DIR, profileSlug(name) or 'profil')
cacheFile = os.path.join(dataPath, 'cache.db')


# --- Naplozas ---------------------------------------------------------------

LOGDEBUG = xbmc.LOGDEBUG
LOGINFO = xbmc.LOGINFO
LOGWARNING = xbmc.LOGWARNING
LOGERROR = xbmc.LOGERROR

ADDON_NAME = 'NetMozi'


def log(message, level=LOGINFO):
    '''Egysegesen prefixelt Kodi-log, hogy a naploban kereshetok legyunk.'''
    try:
        xbmc.log('%s: %s' % (ADDON_NAME, message), level)
    except Exception:
        pass


def log_error(message):
    log(message, LOGERROR)


class timed(object):
    '''
    Egy lépés időtartamának naplózása.

    Lassú indulásnál ebből derül ki, MELYIK szakasz viszi az időt -- a
    bővítményé vagy a Kodié.

        with control.timed(u'felirat letöltés'):
            ...
    '''

    def __init__(self, label):
        self.label = label
        self.started = 0.0

    def __enter__(self):
        self.started = time.time()
        return self

    def __exit__(self, *exc_info):
        log(u'[idő] %s: %.1f mp' % (self.label, time.time() - self.started))
        return False


def log_exception(context, exc):
    '''Kivetel naplozasa a hivas kontextusaval egyutt.'''
    log('%s -- %s: %s' % (context, type(exc).__name__, exc), LOGERROR)


# --- Dialogusok -------------------------------------------------------------

def addonIcon():
    try:
        return os.path.join(addonInfo('path'), 'icon.png')
    except Exception:
        return ''


def infoDialog(message, heading=ADDON_NAME, icon='', time=3000):
    if icon == '':
        icon = addonIcon()
    try:
        xbmcgui.Dialog().notification(heading, message, icon, time, sound=False)
    except Exception:
        execute('Notification(%s,%s, %s, %s)' % (heading, message, time, icon))


def errorDialog(message, heading=ADDON_NAME):
    '''Hibajelzes a felhasznalonak + naplobejegyzes.'''
    log_error(message)
    try:
        xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception:
        pass


def okDialog(message, heading=ADDON_NAME):
    return xbmcgui.Dialog().ok(heading, message)


def yesnoDialog(heading=ADDON_NAME, message='', nolabel='', yeslabel=''):
    return xbmcgui.Dialog().yesno(heading, message, nolabel, yeslabel)


def selectDialog(items, heading=ADDON_NAME):
    return xbmcgui.Dialog().select(heading, items)


def idle():
    return execute('Dialog.Close(busydialog)')


def busy():
    return execute('ActivateWindow(busydialog)')


def refresh():
    return execute('Container.Refresh')


def openSettings(id=None):
    try:
        idle()
        execute('Addon.OpenSettings(%s)' % (id or addonInfo('id')))
    except Exception:
        return


# --- Hibakeresesi naplo kimasolasa ------------------------------------------
#
# Android 11 ota a Kodi mappajaba az ADB nem lat bele. A bovitmeny viszont
# el tudja erni a sajat naplojat (special://logpath), es ki tudja masolni egy
# nyilvanos mappaba (Letoltesek), ahonnan hibakereseskor kiolvashato.

DEBUG_LOG_TARGETS = (
    '/storage/emulated/0/Download/netmozi-kodi.log',
    '/sdcard/Download/netmozi-kodi.log',
)


def exportLog():
    """A kodi.log masolata a Letoltesek mappaba. A celt adja vissza, vagy ''."""
    source = translatePath('special://logpath/kodi.log')
    for target in DEBUG_LOG_TARGETS:
        try:
            folder = os.path.dirname(target)
            if not os.path.isdir(folder):
                continue
            if xbmcvfs.copy(source, target):
                return target
        except Exception as exc:
            log_exception(u'napló kimásolása (%s)' % target, exc)
    return ''