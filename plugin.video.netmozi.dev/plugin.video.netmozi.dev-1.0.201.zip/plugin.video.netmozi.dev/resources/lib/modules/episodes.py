# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Egy sorozat reszeinek sajat adatai: cim, leiras, allokep, hossz, datum,
# ertekeles. A netmozi csak a resz szamat adja a sorozat boritojaval.
#
# Forrasok: a TMDB (a nezo kulcsaval) MAGYARUL adja a resz cimet es
# leirasat + allokepet; az IMDb (kulcs nelkul) angolul, plusz reszenkenti
# ertekelest. Ha van TMDB-kulcs, a TMDB az alap, az IMDb kiegeszit
# (ertekeles, hianyzo kep); kulonben az IMDb.
#
# Evadonkent egy-egy keres, megjegyezve (episodes.json), par napig -- a
# futo sorozatoknal uj reszek jonnek.

import json
import os
import time

from resources.lib.modules import config, control


FILE = 'episodes.json'
MAX_SEASONS = 300
TTL = 3 * 24 * 3600

IMDB_QUERY = '''query E($id: ID!, $season: String!) { title(id: $id) {
  episodes { episodes(first: 100, filter: { includeSeasons: [$season] }) { edges { node {
    titleText { text } plot { plotText { plainText } } primaryImage { url }
    runtime { seconds } ratingsSummary { aggregateRating }
    series { episodeNumber { seasonNumber episodeNumber } }
    releaseDate { day month year } } } } } } }'''


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'részadatok írása', exc)
        return False


def key(imdb, season):
    return '%s/%s' % (imdb, int(season))


def cached(imdb, season, now=None, data=None):
    '''A megjegyzett evad ({resz: adat}), vagy None, ha nincs / lejart.'''
    data = load() if data is None else data
    entry = data.get(key(imdb, season))
    if not entry:
        return None
    if (now or time.time()) - (entry.get('at') or 0) > TTL:
        return None
    return entry.get('episodes') or {}


def _remember(imdb, season, episodes):
    data = load()
    data[key(imdb, season)] = {'at': int(time.time()), 'episodes': episodes}
    if len(data) > MAX_SEASONS:
        for old in sorted(data, key=lambda k: data[k].get('at', 0))[:len(data) - MAX_SEASONS]:
            del data[old]
    save(data)


# --- Forrasok ----------------------------------------------------------------

def from_tmdb(imdb, season):
    '''{resz: {...}} magyarul, vagy None (nincs kulcs / nem sorozat / hiba).'''
    from resources.lib.modules import tmdb
    key_ = tmdb.api_key()
    if not key_:
        return None
    record = tmdb.cached(imdb)
    if record is None:
        record = tmdb.fetch(imdb)
    if not record or record.get('kind') != tmdb.TV or not record.get('id'):
        return None
    status, data = tmdb._get('tv/%s/season/%s' % (record['id'], int(season)), key_, language='hu-HU')
    if status != '200' or not isinstance(data, dict):
        return None
    out = {}
    for row in data.get('episodes') or []:
        number = row.get('episode_number')
        if not number:
            continue
        still = row.get('still_path') or ''
        out[str(number)] = {
            'title': (row.get('name') or '').strip(),
            'overview': (row.get('overview') or '').strip(),
            'still': (config.TMDB_STILL % still) if still else '',
            'runtime': int(row.get('runtime') or 0),
            'date': row.get('air_date') or '',
            'rating': 0.0,
        }
    return out


def from_imdb(imdb, season):
    '''{resz: {...}} angolul (+ ertekeles), vagy None hibanal.'''
    from resources.lib.modules import imdb as imdb_mod
    data = imdb_mod.query(IMDB_QUERY, {'id': imdb, 'season': str(int(season))})
    if data is None:
        return None
    title = data.get('title') or {}
    edges = (((title.get('episodes') or {}).get('episodes') or {}).get('edges')) or []
    out = {}
    for edge in edges:
        node = (edge or {}).get('node') or {}
        numbers = ((node.get('series') or {}).get('episodeNumber')) or {}
        number = numbers.get('episodeNumber')
        if not number:
            continue
        date = node.get('releaseDate') or {}
        rating = (node.get('ratingsSummary') or {}).get('aggregateRating')
        out[str(number)] = {
            'title': ((node.get('titleText') or {}).get('text') or '').strip(),
            'overview': (((node.get('plot') or {}).get('plotText') or {}).get('plainText') or '').strip(),
            'still': imdb_mod.image((node.get('primaryImage') or {}).get('url'), 1280),
            'runtime': int(((node.get('runtime') or {}).get('seconds') or 0) // 60),
            'date': ('%04d-%02d-%02d' % (date['year'], date['month'], date['day'])
                     if date.get('year') and date.get('month') and date.get('day') else ''),
            'rating': float(rating) if rating else 0.0,
        }
    return out


def merge(primary, secondary):
    '''A masodik forras kitolti, ami az elsobol hianyzik (kep, ertekeles, cim...).'''
    out = {}
    for number in set(primary or {}) | set(secondary or {}):
        a = dict((primary or {}).get(number) or {})
        b = (secondary or {}).get(number) or {}
        for field, value in b.items():
            if not a.get(field):
                a[field] = value
        out[number] = a
    return out


def season(imdb, season_number, now=None):
    '''
    Egy evad reszei: {'3': {'title', 'overview', 'still', 'runtime', 'date',
    'rating'}}. Gyorsitotarbol, kulonben lekerve (TMDB + IMDb). {} ha nincs.
    '''
    if not imdb or not season_number:
        return {}
    known = cached(imdb, season_number, now)
    if known is not None:
        return known
    tmdb_rows = None
    try:
        tmdb_rows = from_tmdb(imdb, season_number)
    except Exception as exc:
        control.log_exception(u'részadatok (TMDB)', exc)
    imdb_rows = None
    try:
        imdb_rows = from_imdb(imdb, season_number)
    except Exception as exc:
        control.log_exception(u'részadatok (IMDb)', exc)
    if tmdb_rows is None and imdb_rows is None:
        return {}                                    # halozati hiba: nem jegyezzuk meg
    episodes = merge(tmdb_rows, imdb_rows) if tmdb_rows else (imdb_rows or {})
    _remember(imdb, season_number, episodes)
    return episodes


def info(imdb, season_number, episode_number, now=None):
    '''Egy resz adatai, vagy {}.'''
    return (season(imdb, season_number, now) or {}).get(str(int(episode_number))) or {}


def label(number, data):
    '''"3. rész – A felfedezés" (cim nelkul "3. rész").'''
    title = (data or {}).get('title') or u''
    return u'%s. rész%s' % (number, u' – %s' % title if title else u'')
