# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Tanulo forras-sorrend: melyik hoszter szokott elindulni, es melyik nem.
#
# Az automatika minden filmnel elolrol probalja a forrasokat. Ha szamoljuk,
# hogy egy hoszter (voe.sx, doodstream.com, playmogo.com...) hanyszor indult
# el es hanyszor nem, a jokat elore vehetjuk -- es minden inditas gyorsabb.
#
# A pontszam Laplace-simitott arany: (ok+1)/(ok+hiba+2). Igy az ismeretlen
# hoszter 0.5-ot kap: a bizonyitottan jok utan, a bizonyitottan rosszak
# ELOTT probaljuk. A szamlalok idonkent felezodnek, hogy a KOZELMULT
# szamitson: egy hoszter, ami fel eve rossz volt, de most jo, hamar
# visszakapaszkodik.

import json
import os
import time

from resources.lib.modules import control


FILE = 'hosts.json'

# Ennyi minta felett a szamlalok felezodnek (a frissebb tapasztalat nyer).
DECAY_AT = 40

# Ennyi minta alatt a pontszam meg nem "velemeny", csak sejtes.
MIN_SAMPLES = 3

# Nem tarolunk vegtelen sok hosztert.
MAX_ENTRIES = 200


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'hoszter-statisztika írása', exc)
        return False


def normalize(site):
    '''"www.Voe.sx" -> "voe.sx". A tabla igy irja, de biztos, ami biztos.'''
    site = (site or '').strip().lower()
    if site.startswith('www.'):
        site = site[4:]
    return site


def record(site, success):
    '''Egy probalkozas eredmenye. Ures hosztert nem jegyzunk.'''
    site = normalize(site)
    if not site:
        return False
    data = load()
    entry = data.get(site) or {'ok': 0, 'fail': 0}
    entry['ok' if success else 'fail'] = int(entry.get('ok' if success else 'fail', 0)) + 1
    entry['updated'] = int(time.time())
    if entry['ok'] + entry['fail'] > DECAY_AT:
        entry['ok'] //= 2
        entry['fail'] //= 2
    data[site] = entry
    if len(data) > MAX_ENTRIES:
        for old in sorted(data, key=lambda k: data[k].get('updated', 0))[:-MAX_ENTRIES]:
            del data[old]
    return save(data)


def score(site, data=None):
    '''0..1; ismeretlen hoszter 0.5.'''
    data = load() if data is None else data
    entry = data.get(normalize(site)) or {}
    ok, fail = int(entry.get('ok', 0)), int(entry.get('fail', 0))
    return (ok + 1.0) / (ok + fail + 2.0)


def samples(site, data=None):
    data = load() if data is None else data
    entry = data.get(normalize(site)) or {}
    return int(entry.get('ok', 0)) + int(entry.get('fail', 0))


def ordered(sources, key='site'):
    '''
    Stabil rendezes pontszam szerint, csokkeno. Az azonos pontszamuak
    (pl. az osszes ismeretlen) az eredeti sorrendben maradnak.
    '''
    data = load()
    return sorted(sources or [], key=lambda item: -score(item.get(key, ''), data))


def describe(site, data=None):
    '''"90%" vagy ures, ha meg keves a minta. A forraslistaba.'''
    data = load() if data is None else data
    if samples(site, data) < MIN_SAMPLES:
        return u''
    return u'%d%%' % int(round(100 * score(site, data)))


def clear():
    try:
        os.remove(_path())
        return True
    except OSError:
        return False
