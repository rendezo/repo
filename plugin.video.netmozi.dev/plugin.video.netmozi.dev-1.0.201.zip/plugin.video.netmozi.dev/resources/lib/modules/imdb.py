# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# IMDb -- kulcs es regisztracio nelkul: a weboldal GraphQL-kapuja
# (api.graphql.imdb.com) a web-kliens fejlecevel valaszol. Egy cimrol EGY
# keressel: cim (magyarul, ha van), ev, hossz, mufaj, ertekeles, leiras
# (angolul), poszter, allokepek (hatterkepnek) es az elozetes kozvetlen
# MP4-cimei. Kulon: a hamarosan bemutatott filmek listaja.
#
# Sajat, nem kereskedelmi hasznalatra (az IMDb ezt engedi); a bovitmeny
# privat.
#
# A cim adatai megjegyzodnek (imdb.json); az elozetes cime par oraig
# ervenyes (Expires=...), lejarat elott a cimet ujra kerjuk.

import json
import os
import re
import time

from resources.lib.modules import config, control


FILE = 'imdb.json'
MAX_ENTRIES = 1200

GRAPHQL = 'https://api.graphql.imdb.com/'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/124.0 Safari/537.36',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Accept-Language': 'hu-HU,hu;q=0.9,en;q=0.8',
    'x-imdb-client-name': 'imdb-web-next-localized',
    'x-imdb-user-language': 'hu-HU',
    'x-imdb-user-country': 'HU',
    'Origin': 'https://www.imdb.com',
    'Referer': 'https://www.imdb.com/',
}
TIMEOUT = 10

TITLE_QUERY = '''query T($id: ID!) { title(id: $id) {
  titleText { text } originalTitleText { text } releaseYear { year } runtime { seconds }
  genres { genres { text } } ratingsSummary { aggregateRating voteCount }
  plot { plotText { plainText } }
  primaryImage { url width height }
  images(first: 6, filter: { types: ["still_frame"] }) { edges { node { url width height } } }
  primaryVideos(first: 3) { edges { node { id name { value } runtime { value }
    playbackURLs { displayName { value } videoMimeType url } } } }
} }'''

UPCOMING_QUERY = '''query U($start: Date!, $end: Date!, $first: Int!) { advancedTitleSearch(first: $first,
  constraints: { releaseDateConstraint: { releaseDateRange: { start: $start, end: $end } },
                 titleTypeConstraint: { anyTitleTypeIds: ["movie"] } },
  sort: { sortBy: POPULARITY, sortOrder: ASC }) { edges { node { title {
    id titleText { text } releaseDate { day month year } primaryImage { url } } } } } }'''

TRAILER_PREFERRED = ('720p', '1080p', '480p', 'SD')   # a TV-nek a 720p boven eleg
TRAILER_MARGIN = 600                                   # mp: ennyivel a lejarat elott ujra kerjuk

# Az IMDb angol mufajnevei magyarul.
GENRES_HU = {
    'Action': u'Akció', 'Adventure': u'Kaland', 'Animation': u'Animáció', 'Biography': u'Életrajzi',
    'Comedy': u'Vígjáték', 'Crime': u'Krimi', 'Documentary': u'Dokumentumfilm', 'Drama': u'Dráma',
    'Family': u'Családi', 'Fantasy': u'Fantasy', 'History': u'Történelmi', 'Horror': u'Horror',
    'Music': u'Zenés', 'Musical': u'Musical', 'Mystery': u'Misztikus', 'Romance': u'Romantikus',
    'Sci-Fi': u'Sci-fi', 'Sport': u'Sport', 'Thriller': u'Thriller', 'War': u'Háborús',
    'Western': u'Western', 'Film-Noir': u'Film noir', 'Short': u'Rövidfilm', 'Reality-TV': u'Reality',
    'Talk-Show': u'Talk-show', 'Game-Show': u'Vetélkedő', 'News': u'Hírek', 'Adult': u'Felnőtt',
}
MONTHS_HU = (u'jan.', u'febr.', u'márc.', u'ápr.', u'máj.', u'jún.', u'júl.', u'aug.', u'szept.',
             u'okt.', u'nov.', u'dec.')


# --- Tarolas -----------------------------------------------------------------

def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'IMDb adatok írása', exc)
        return False


def cached(imdb, data=None):
    '''A megjegyzett bejegyzes ({} = tudjuk, hogy nincs), vagy None.'''
    data = load() if data is None else data
    return data.get(imdb)


def _remember(imdb, record):
    store = load()
    store[imdb] = record
    if len(store) > MAX_ENTRIES:
        for old in list(store)[:len(store) - MAX_ENTRIES]:
            del store[old]
    save(store)


# --- Keres -------------------------------------------------------------------

def query(text, variables):
    '''A GraphQL-valasz "data" resze (dict), vagy None hibanal.'''
    from resources.lib.modules import client
    body = json.dumps({'query': text, 'variables': variables})
    response = client.request(GRAPHQL, post=body, headers=HEADERS, output='response', timeout=TIMEOUT)
    if not response:
        return None
    status, raw = response
    if status != '200':
        control.log(u'IMDb: HTTP %s' % status, control.LOGWARNING)
        return None
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(data, dict) or not isinstance(data.get('data'), dict):
        control.log(u'IMDb: váratlan válasz (%s)' % str(data)[:120], control.LOGWARNING)
        return None
    return data['data']


# --- Mese-profil: gyereknek valo-e egy cim (korhatar + mufaj) -------------------
#
# Az IMDb a HU orszagkoddal a MAGYAR korhatart adja (KN, 6, 12, 16, 18),
# ahol nincs, az amerikait (TV-Y, TV-PG, TV-14, R...). A szabaly:
#   - korhatar nelkuli / 6 / TV-Y / G / PG...: igen;
#   - 12 / PG-13 / TV-14: csak ha a mufajai kozt van Family;
#   - ismeretlen korhatar: csak Family mufajjal;
#   - 16 / 18 / R / TV-MA...: nem.
# (South Park: 18; Amerikai fater: 16; Beavis: 12 Family nelkul -> nem.
# Peppa: TV-Y; Coco: 6; Bluey / Oroszlankiraly: KN -> igen.)
# Egy keresben tobb cim (titles(ids:)), az eredmeny egy honapig eltéve.

KIDS_FILE = 'kids.json'
KIDS_QUERY = '''query K($ids: [ID!]!) { titles(ids: $ids) {
  id certificate { rating } genres { genres { text } } isAdult } }'''
KIDS_BATCH = 40
CERT_OK = ('KN', '6', 'TV-Y', 'TV-Y7', 'TV-Y7-FV', 'TV-G', 'G', 'PG', 'TV-PG', 'U', '0', '3', 'APPROVED', 'PASSED')
CERT_FAMILY = ('12', 'PG-13', 'TV-14', '13', '14')


def kid_safe(rating, genres, adult=False):
    '''A szabaly egy cimre.'''
    if adult:
        return False
    rating = (rating or '').strip().upper()
    family = 'Family' in (genres or [])
    if rating in CERT_OK:
        return True
    if rating in CERT_FAMILY or not rating:
        return family
    return False


def _kids_path():
    return os.path.join(control.dataPath, KIDS_FILE)


def kids_load():
    try:
        with open(_kids_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def kids_save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_kids_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'mese-ellenőrzés írása', exc)


def kids_check(ids, network=True, now=None):
    '''
    {imdb: True/False} a kert cimekre, amit tudunk: a tarbol, es (network)
    az IMDb-tol kotegben. Amit nem sikerult lekerni, az hianyzik (= nem
    mutatjuk, amig ki nem derul).
    '''
    now = now or time.time()
    data = kids_load()
    out = {}
    missing = []
    for imdb in ids:
        if not imdb:
            continue
        entry = data.get(imdb)
        if entry and now - (entry.get('at') or 0) < config.KIDS_CHECK_TTL:
            out[imdb] = bool(entry.get('ok'))
        elif imdb not in missing:
            missing.append(imdb)
    if not network or not missing:
        return out
    changed = False
    for start in range(0, len(missing), KIDS_BATCH):
        chunk = missing[start:start + KIDS_BATCH]
        result = query(KIDS_QUERY, {'ids': chunk})
        if result is None:
            break
        for title in result.get('titles') or []:
            if not title or not title.get('id'):
                continue
            genres = [g.get('text') for g in ((title.get('genres') or {}).get('genres') or []) if g]
            ok = kid_safe((title.get('certificate') or {}).get('rating'), genres, bool(title.get('isAdult')))
            data[title['id']] = {'ok': ok, 'at': int(now)}
            out[title['id']] = ok
            changed = True
    if changed:
        kids_save(data)
    return out


def image(url, width=0):
    '''Az IMDb kepe adott szelessegben (a "._V1_" jelolo utan): UX1280 stb.'''
    if not url or not width:
        return url or ''
    return re.sub(r'\._V1_[^.]*\.', '._V1_UX%d_.' % int(width), url, count=1)


def pick_backdrop(edges):
    '''A legjobb fekvo allokep: szeles, kb. 16:9; kulonben a legszelesebb.'''
    rows = []
    for edge in edges or []:
        node = (edge or {}).get('node') or {}
        width, height = node.get('width') or 0, node.get('height') or 0
        if node.get('url') and width and height:
            rows.append((width, float(width) / height, node['url']))
    if not rows:
        return ''
    wide = [row for row in rows if row[0] >= 1000 and 1.55 <= row[1] <= 1.95]
    best = max(wide or rows, key=lambda row: row[0])
    return image(best[2], 1280)


def pick_trailer(edges):
    '''(url, lejarat) az elso elozetes legjobb MP4-jebol; ('', 0) ha nincs.'''
    for edge in edges or []:
        node = (edge or {}).get('node') or {}
        urls = {}
        for row in node.get('playbackURLs') or []:
            if (row.get('videoMimeType') or '').upper() == 'MP4' and row.get('url'):
                urls[(row.get('displayName') or {}).get('value') or ''] = row['url']
        if not urls:
            continue
        url = next((urls[w] for w in TRAILER_PREFERRED if w in urls), next(iter(urls.values())))
        return url, expiry_of(url)
    return '', 0


def expiry_of(url):
    match = re.search(r'[?&]Expires=(\d+)', url or '')
    return int(match.group(1)) if match else 0


def _record(node):
    genres = [g.get('text') for g in ((node.get('genres') or {}).get('genres') or []) if g.get('text')]
    trailer, expires = pick_trailer((node.get('primaryVideos') or {}).get('edges'))
    rating = (node.get('ratingsSummary') or {}).get('aggregateRating')
    return {
        'title': ((node.get('titleText') or {}).get('text') or '').strip(),
        'original': ((node.get('originalTitleText') or {}).get('text') or '').strip(),
        'year': str((node.get('releaseYear') or {}).get('year') or ''),
        'runtime': int(((node.get('runtime') or {}).get('seconds') or 0) // 60),
        'genres': [GENRES_HU.get(g, g) for g in genres][:3],
        'rating': float(rating) if rating else 0.0,
        'votes': int((node.get('ratingsSummary') or {}).get('voteCount') or 0),
        'plot': (((node.get('plot') or {}).get('plotText') or {}).get('plainText') or '').strip(),
        'poster': image((node.get('primaryImage') or {}).get('url'), 600),
        'backdrop': pick_backdrop((node.get('images') or {}).get('edges')),
        'trailer': trailer,
        'trailer_expires': expires,
        'at': int(time.time()),
    }


def fetch(imdb):
    '''Lekeri es megjegyzi. A bejegyzes ({} ha nincs ilyen cim), None hibanal.'''
    if not imdb:
        return None
    data = query(TITLE_QUERY, {'id': imdb})
    if data is None:
        return None
    node = data.get('title')
    record = _record(node) if node else {}
    _remember(imdb, record)
    return record


def title(imdb, data=None):
    '''Gyorsitotarbol, vagy lekerve. {} ha nincs / hiba.'''
    if not imdb:
        return {}
    known = cached(imdb, data)
    if known is not None:
        return known
    return fetch(imdb) or {}


def trailer_url(imdb, now=None):
    '''
    Az elozetes MP4-cime; ha a megjegyzett lejart (vagy nincs), a cimet ujra
    kerjuk. '' ha nincs elozetes.
    '''
    record = cached(imdb)
    now = now or time.time()
    if record is None or (record.get('trailer') and record.get('trailer_expires', 0)
                          and now > record['trailer_expires'] - TRAILER_MARGIN):
        record = fetch(imdb) or record or {}
    return (record or {}).get('trailer') or ''


# --- Hamarosan -----------------------------------------------------------------

def date_label(day, month, year):
    '''"okt. 15." -- ev nelkul, ha az idei.'''
    try:
        text = u'%s %d.' % (MONTHS_HU[int(month) - 1], int(day))
    except (TypeError, ValueError, IndexError):
        return u''
    if year and int(year) != time.localtime().tm_year:
        text = u'%s. %s' % (year, text)
    return text


def upcoming(days=None, first=None, today=None):
    '''
    A kovetkezo `days` nap mozibemutatoi nepszeruseg szerint:
    [{'imdb', 'title', 'date', 'poster', 'day', 'month', 'year'}]. None hibanal.
    '''
    days = days or config.UPCOMING_DAYS
    first = first or config.UPCOMING_COUNT
    start = today or time.strftime('%Y-%m-%d')
    parts = [int(p) for p in start.split('-')]
    end_ts = time.mktime((parts[0], parts[1], parts[2] + days, 12, 0, 0, 0, 0, -1))
    end = time.strftime('%Y-%m-%d', time.localtime(end_ts))
    data = query(UPCOMING_QUERY, {'start': start, 'end': end, 'first': first})
    if data is None:
        return None
    out = []
    for edge in ((data.get('advancedTitleSearch') or {}).get('edges') or []):
        node = ((edge or {}).get('node') or {}).get('title') or {}
        imdb = node.get('id') or ''
        if not imdb.startswith('tt'):
            continue
        date = node.get('releaseDate') or {}
        out.append({'imdb': imdb,
                    'title': ((node.get('titleText') or {}).get('text') or '').strip(),
                    'poster': image((node.get('primaryImage') or {}).get('url'), 600),
                    'day': date.get('day'), 'month': date.get('month'), 'year': date.get('year'),
                    'date': date_label(date.get('day'), date.get('month'), date.get('year'))})
    return out
