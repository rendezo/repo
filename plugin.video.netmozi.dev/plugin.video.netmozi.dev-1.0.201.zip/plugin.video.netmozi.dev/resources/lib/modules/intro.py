# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Intro atugrasa -- TANULVA.
#
# A netmozi nem mondja meg, hol az intro. De a nezo megmutatja: ha egy
# sorozat elso perceiben elore teker, a hatterszolgaltatas megjegyzi,
# honnan hova (ez a modul), es a kovetkezo reszeknel ugyanott magatol
# atugrik. Sorozatonkent tanul; egyszer kell megmutatni.
#
# Ket csapda, amit a service.IntroSkipper kerul ki: a SAJAT tekeresunket
# (folytatas onnan, ahol abbamaradt) nem tanulja meg intronak; es ha az
# automatikus ugras utan a nezo rogton visszateker, a tanult ertek torlodik
# -- rosszul tanulta, ne ismetelje.

import json
import os
import time

from resources.lib.modules import control


FILE = 'intro.json'

# Az intro az elso ennyi masodpercen belul kezdodik. Kesobbi elore-
# tekeres nem intro (unalmas jelenet, vagy bekapcsolt folytatas).
WINDOW = 300

# Ennel kisebb ugras nem "atugras", csak tekergetes.
MIN_JUMP = 15

# Ennel nagyobb ugras nem intro, hanem "fel reszt atugrott".
MAX_JUMP = 240

# Ha az automatikus ugras utan ennyi masodpercen belul visszateker a nezo,
# rossz volt a tanult ertek: elfelejtjuk.
REGRET_SECONDS = 15

MAX_ENTRIES = 200


def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(os.path.dirname(_path()))
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'intró-adatok írása', exc)
        return False


def get(base):
    '''{'start', 'end', 'count'} vagy None.'''
    entry = load().get(base)
    if not entry or not entry.get('end'):
        return None
    return entry


def plausible(start, end):
    '''Intronak nezhet-e ki egy ugras.'''
    if start is None or end is None:
        return False
    jump = end - start
    return 0 <= start <= WINDOW and MIN_JUMP <= jump <= MAX_JUMP


def learn(base, start, end):
    '''
    Egy megfigyelt atugras. Ismetelt tanulasnal az ujabb szamit jobban
    (2/3 uj, 1/3 regi): a nezo pontosit, nem ismetel.
    '''
    if not base or not plausible(start, end):
        return False
    data = load()
    entry = data.get(base) or {}
    if entry.get('end'):
        start = int(round((2 * start + entry.get('start', start)) / 3.0))
        end = int(round((2 * end + entry['end']) / 3.0))
    data[base] = {'start': int(start), 'end': int(end),
                  'count': int(entry.get('count', 0)) + 1,
                  'learned': int(time.time())}
    if len(data) > MAX_ENTRIES:
        for old in sorted(data, key=lambda k: data[k].get('learned', 0))[:-MAX_ENTRIES]:
            del data[old]
    save(data)
    control.log(u'Intró megtanulva: %s  %d -> %d mp' % (base, start, end))
    return True


def forget(base):
    data = load()
    if base in data:
        del data[base]
        save(data)
        control.log(u'Intró elfelejtve (visszatekerés után): %s' % base)
        return True
    return False


def clear():
    try:
        os.remove(_path())
        return True
    except OSError:
        return False
