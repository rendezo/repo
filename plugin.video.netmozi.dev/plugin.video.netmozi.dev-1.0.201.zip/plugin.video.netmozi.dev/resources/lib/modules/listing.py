# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A netmozi LISTA-oldalainak feldolgozasa -- Kodi nelkul.
#
# Ez a logika a navigatorban elt; azert kerult kulon, hogy a boritos
# kezdokepernyo (amit a hatterszolgaltatas rajzol) is tudjon sorokat
# epiteni, es a navigator a tesztek szamara valtozatlanul ugyanezt hivja.

import re

from resources.lib.modules import client, config
from resources.lib.modules.utils import absolute_url, at, first, to_int


class ScrapeError(Exception):
    '''Egy kotelezo elem hianyzik: az uzenet megnevezi, melyik szelektor.'''


def require(value, what):
    if value is None or value == []:
        raise ScrapeError(what)
    return value


def info_data(info_rows, label, regex, default=''):
    '''Regexszel kinyert ertek a listaelem adatsorai kozul.'''
    for row in info_rows or []:
        if label in row:
            match = re.search(regex, row)
            if match:
                return match.group(1)
    return default


def categories_of(info_rows):
    '''A listaelem kategoriai ("Kategoria: Horror , Thriller").'''
    for row in info_rows or []:
        if config.LABEL_CATEGORY not in row:
            continue
        text = re.sub(r'<[^>]+>', ' ', row)
        text = client.replaceHTMLCodes(text).replace(config.LABEL_CATEGORY, ' ')
        parts = re.split(config.CATEGORY_SPLIT_RE, text)
        return [p.strip() for p in parts if p.strip()]
    return []


def badge_of(info_rows):
    '''(nyelv, minoseg) a listasor utolso sorabol; ('', '') ha nincs.'''
    for row in reversed(info_rows or []):
        match = re.search(config.LIST_BADGE_RE, row, re.S)
        if not match:
            continue
        flag, quality = match.group(1), (match.group(2) or '').strip()
        language = next((name for marker, name in config.LANGUAGE_FLAGS if marker in flag), '')
        return language, quality
    return '', ''


def parse_row(movie, tipus=''):
    '''Egy listaelem adatai. ScrapeError, ha egy kotelezo elem hianyzik.'''
    # A title attributum elrontana a col_name kereseset, ezert kivagjuk.
    match = re.search(config.LIST_TITLE_ATTR_RE, movie, re.S)
    if match:
        movie = '%s%s' % (match.group(1), match.group(3))

    temp_title = require(
        first(client.parseDOM(movie, 'div', attrs={'class': config.LIST_TITLE_CLASS})),
        u'cím (.%s)' % config.LIST_TITLE_CLASS)
    title = client.replaceHTMLCodes(temp_title).replace(config.SERIES_MARKER_HTML, '').strip()
    is_series = config.SERIES_MARKER in temp_title
    series_label = ' [COLOR yellow][I]sorozat[/I][/COLOR]' if is_series and tipus != '2' else ''

    url = require(
        first(client.parseDOM(movie, 'a', attrs={'class': config.LIST_LINK_CLASS}, ret='href')),
        u'hivatkozás (.%s)' % config.LIST_LINK_CLASS)

    columns = client.parseDOM(movie, 'div', attrs={'class': config.LIST_COL_CLASS})
    thumb = absolute_url(first(client.parseDOM(at(columns, 0, ''), 'img', ret='src')))
    info_rows = client.parseDOM(at(columns, 1, ''), 'div', attrs={'class': config.LIST_ROW_CLASS})

    year = info_data(info_rows, config.LABEL_YEAR, config.YEAR_RE)
    year_number = to_int(year, 0)
    year = '(%s)' % year if year else ''
    # A Kodi masodpercben varja a hosszt -- korabban itt percben ment.
    duration = to_int(info_data(info_rows, config.LABEL_DURATION, config.DURATION_RE, '0')) * 60
    linkcount = info_data(info_rows, config.LABEL_LINKCOUNT, config.LINKCOUNT_RE)
    linkcount = ' | [COLOR limegreen]%s link[/COLOR]' % linkcount if linkcount else ''
    categories = categories_of(info_rows)
    badge = (' [COLOR darkgray][%s][/COLOR]'
             % ' · '.join(categories[:config.CATEGORY_BADGE_MAX])) if categories else ''
    language, quality = badge_of(info_rows)
    # A minoseg a cim utan, jol lathatoan: ez dont arrol, erdemes-e
    # egyaltalan megnyitni. A nyelv mellette, roviden.
    grade = (' [%s]' % ', '.join(part for part in (quality, language.lower() if language else '')
                                 if part)) if (quality or language) else ''

    return {
        'title': title,
        'label': '%s %s%s%s%s%s' % (title, year, grade, series_label, linkcount, badge),
        'url': url,
        'action': 'series' if is_series else 'movie',
        'isSeries': is_series,
        'thumb': thumb,
        'duration': duration,
        'year': year_number,
        'categories': categories,
        'language': language,
        'quality': quality,
    }


def parse_rows(html, tipus=''):
    '''Egy lista-oldal osszes tetele; a hibas sorok kimaradnak (naplozva).'''
    from resources.lib.modules import control
    rows = []
    for movie in client.parseDOM(html or '', 'div', attrs={'class': config.LIST_ITEM_CLASS}):
        try:
            rows.append(parse_row(movie, tipus))
        except ScrapeError as exc:
            control.log_error(u'Tétel kihagyva, hiányzik: %s' % exc)
    return rows


def grade_of(row):
    '''"DVD, szinkron" -- a boritos nezet feliratahoz.'''
    return u', '.join(part for part in (row.get('quality'), (row.get('language') or '').lower())
                      if part)
