# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A fomenu EGY helyen. Ket helyrol rajzoljuk ki: a navigatorbol (a rendes
# ut), es a default.py gyors agabol -- az utobbi azert, hogy a fomenuhoz ne
# kelljen betolteni a navigatort es a requests-et (lassu dobozon masodpercek,
# es pont a bekapcsolas utani elso kepernyo szenvedne tole).


# Ennyi folytatas-sor a fomenu tetejen -- a Netflix "Folytatas a
# megtekintessel" sora, csak ott, ahol a nezo tenyleg ezt latja eloszor.
CONTINUE_ROWS = 2


def continue_items(limit=CONTINUE_ROWS):
    '''
    [(felirat, query)] a legfrissebb felbehagyott dolgokbol. Sorozatnal a
    folytatas mindig ertelmes (kovetkezo resz); filmnel csak ha tenyleg
    felbe van hagyva.
    '''
    from resources.lib.modules import progress   # konnyu: csak JSON
    rows = []
    for entry in progress.entries():
        if len(rows) >= limit:
            break
        title = entry.get('title') or entry['base']
        if progress.is_film(entry):
            seconds = progress.resume_seconds(entry)
            if not seconds:
                continue
            rows.append((u'\u25b6 Folytatás: %s (%d. perctől)' % (title, seconds // 60),
                         'playdirect&url=%s' % entry['base']))
        else:
            rows.append((u'\u25b6 Folytatás: %s -- %s' % (
                title, progress.describe(entry).replace(u'folytatás: ', u'')),
                         'continueseries&url=%s' % entry['base']))
    return rows


def profile_item():
    '''"Ki nez? (Anya)" -- csak ha vannak nevvel letrehozott profilok.'''
    from resources.lib.modules import profiles
    if not profiles.names():
        return []
    return [(u'Ki néz? (%s)' % profiles.label(), 'profiles')]


def root_items(summary=u'', continues=None):
    '''[(felirat, plugin-query)] sorrendben. `summary`: "2 uj resz, 1 szinkron".'''
    return list(continue_items() if continues is None else continues) + [
        (u'Keresés', 'search'),
        (u'Mit nézzek?', 'tonight'),
        (u'Filmek', 'base&type=1'),
        (u'Sorozatok', 'base&type=2'),
        (u'Ajánló', 'recommended'),
        (u'Stream Top', 'streams'),
        (u'Figyelt sorozatok%s' % (u' (%s)' % summary if summary else u''), 'watchlist'),
        (u'Amit már láttam', 'history'),
    ] + profile_item()
