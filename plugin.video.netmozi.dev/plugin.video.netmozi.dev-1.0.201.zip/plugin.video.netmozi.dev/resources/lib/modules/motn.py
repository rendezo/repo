# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Movie of the Night (Streaming Availability API): a szolgaltatok HIVATALOS
# top listaja orszagonkent -- Netflix, Prime, Disney+, HBO Max, Apple TV.
# Minden tetelhez IMDb-azonosito jon, igy a netmozi keresojevel pontosan
# egyeztetheto (providers.py).
#
# A nezo sajat, ingyenes kulcsaval (developers.movieofthenight.com): havi
# 1000 keres; mi szolgaltatonkent naponta EGYET kuldunk (5/nap).

import json
import os
import re

from resources.lib.modules import config, control


KEY_FILES = (
    '/storage/emulated/0/Download/netmozi-motn.txt',
    '/sdcard/Download/netmozi-motn.txt',
)
KEY_RE = r'^[A-Za-z0-9_-]{16,}$'


def _key_from_files():
    candidates = list(KEY_FILES) + [os.path.join(control.dataPath, 'motn.txt')]
    for path in candidates:
        try:
            with open(path, encoding='utf-8') as handle:
                text = handle.read().strip()
        except (IOError, OSError):
            continue
        if re.match(KEY_RE, text):
            return text
    return ''


def api_key():
    try:
        key = (control.setting('motnkey') or '').strip()
    except Exception:
        key = ''
    return key or _key_from_files()


def top(service, key=None):
    '''
    Egy szolgaltato top listaja itthon: [(imdb, cim, 'movie'|'series')] a
    lista sorrendjeben (IMDb nelkuli tetel kimarad). None halozati hibanal
    vagy ha a szolgaltatonak nincs listaja.
    '''
    from resources.lib.modules import client
    key = key or api_key()
    if not key or not service:
        return None
    url = '%s/shows/top?country=%s&service=%s' % (config.MOTN_API, config.MOTN_COUNTRY, service)
    response = client.request(url, headers={'X-API-Key': key, 'Accept': 'application/json'},
                              output='response', timeout=config.MOTN_TIMEOUT)
    if not response:
        return None
    status, text = response
    if status != '200':
        control.log(u'Movie of the Night: HTTP %s (%s)' % (status, service), control.LOGWARNING)
        return None
    try:
        rows = json.loads(text)
    except ValueError:
        return None
    if not isinstance(rows, list):
        return None
    out = []
    for row in rows:
        imdb = (row.get('imdbId') or '').strip()
        if re.match(r'^tt\d+$', imdb):
            out.append((imdb, row.get('title') or u'', row.get('showType') or ''))
    return out or None
