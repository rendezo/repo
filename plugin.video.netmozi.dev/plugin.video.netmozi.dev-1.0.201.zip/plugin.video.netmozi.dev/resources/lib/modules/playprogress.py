# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A lejatszas inditasanak folyamatjelzoje. Ket alak:
#
#   - a boritos kezdokepernyo elott: a kezdokepernyo SAJAT ablaka
#     (folyamatabra: Forras keresese -> Film inditasa -> Lejatszas), a
#     Kodi Home-ablakanak tulajdonsagain at (Window(Home).Property
#     (netmozi.play.*)) -- a lejatszas kulon folyamatban fut (RunPlugin), a
#     tulajdonsag a ket folyamat kozos hirdetotablaja. A kezdokepernyo mar
#     az OK-ra kirakja (azonnal), a lejatszo folyamat lepteti, es a vegen
#     torli; a Vissza a kezdokepernyon a megszakitas.
#   - kulonben (regi menu, telefon): a Kodi folyamatjelzo parbeszede.

import time

import xbmcgui


HOME_WINDOW = 10000
PREFIX = 'netmozi.play'
STEP_SEARCH, STEP_START, STEP_PLAY, STEP_FAIL = '1', '2', '3', 'fail'
STALE_SECONDS = 120             # ha ennyi ideig nem frissul: a lejatszo folyamat elveszett, torlodik
FAIL_SECONDS = 6                # a hiba ennyi ideig latszik


def _window():
    return xbmcgui.Window(HOME_WINDOW)


def _set(name, value):
    _window().setProperty('%s.%s' % (PREFIX, name), value or '')


def _get(name):
    return _window().getProperty('%s.%s' % (PREFIX, name))


def home_active():
    '''A boritos kezdokepernyo van-e elol (o rajzolja a folyamatabrat).'''
    try:
        window = _window()
        return (window.getProperty('netmozi.home') == '1'
                and str(xbmcgui.getCurrentWindowId()) == window.getProperty('netmozi.home.id'))
    except Exception:
        return False


def begin(title=u'', thumb=u'', text=u'Forrás keresése…'):
    '''A folyamatabra megjelenik (a kezdokepernyo hivja az OK-ra, vagy a lejatszo folyamat).'''
    _window().setProperty(PREFIX, '1')
    _set('cancel', '')
    _set('title', title)
    _set('thumb', thumb)
    _set('step', STEP_SEARCH)
    _set('text', text)
    _set('note', '')
    _set('at', str(int(time.time())))


def update(step, text, note=u''):
    _set('step', step)
    _set('text', text)
    _set('note', note)
    _set('at', str(int(time.time())))


def fail(text=u'Nem sikerült elindítani.'):
    update(STEP_FAIL, text)


def clear():
    _window().setProperty(PREFIX, '')
    for name in ('cancel', 'title', 'thumb', 'step', 'text', 'note', 'at'):
        _set(name, '')


def cancel():
    _set('cancel', '1')


def is_active():
    return _window().getProperty(PREFIX) == '1'


def is_cancelled():
    return _get('cancel') == '1'


def step():
    return _get('step')


def age(now=None):
    '''Hany masodperce frissult utoljara.'''
    try:
        return (now or time.time()) - int(_get('at') or 0)
    except (TypeError, ValueError):
        return 0


class PlayProgress(object):
    '''
    A lejatszo folyamat jelzoje: create / show / iscanceled / close -- a sajat
    ablakon (ha a kezdokepernyo van elol) vagy a Kodi parbeszeden.
    '''

    def __init__(self, title=u'', thumb=u''):
        self.own = home_active()
        self.title, self.thumb = title or u'', thumb or u''
        self.dialog = None

    def create(self, heading, text):
        if self.own:
            if not is_active():
                begin(self.title, self.thumb, text)
            else:
                if self.title:
                    _set('title', self.title)
                if self.thumb:
                    _set('thumb', self.thumb)
                update(STEP_SEARCH, text)
            return
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create(heading, text)

    def show(self, percent, header, step_text, note=u'', starting=False):
        '''header: "2/6  vidoza  szinkron  DVD"; step_text: mi tortenik; note: az elozo kudarc.'''
        if self.own:
            update(STEP_START if starting else STEP_SEARCH, u'%s\n%s' % (header, step_text) if header else step_text,
                   note.replace(u'\n', u'').replace(u'[COLOR red]', u'').replace(u'[/COLOR]', u''))
            return
        if self.dialog is not None:
            self.dialog.update(percent, u'%s\n%s%s' % (header, step_text, note))

    def iscanceled(self):
        if self.own:
            return is_cancelled()
        return bool(self.dialog is not None and self.dialog.iscanceled())

    def close(self, failed=False, message=u''):
        if self.own:
            if failed:
                fail(message or u'Egyik forrás sem indult el.')
            else:
                clear()
            return
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None
