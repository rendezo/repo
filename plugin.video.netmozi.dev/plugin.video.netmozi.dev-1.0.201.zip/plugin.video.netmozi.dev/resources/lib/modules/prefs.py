# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A beallitasok sajat nezete a kezdokepernyon (TV-n), a Kodi
# beallitas-ablaka helyett. A forras UGYANAZ a resources/settings.xml:
#
#   - a rovid, pont nelkuli <setting type="lsep"> egy SZAKASZ cime
#     (Indulas, nCore..., Lejatszas kozben); a kategoria neve is szakasz;
#   - a ponttal vegzodo lsep az elotte allo sor MAGYARAZATA (sugo);
#   - az enable="eq(-N,true)" a kategorian beluli N-edik elozo sorra mutat
#     (a Kodi szamitasa: minden <setting>, az lsep is szamit);
#   - a "- " / "-- " elotag behuzas (al-beallitas).
#
# Ez a modul Kodi nelkul is fut (teszt): csak az XML-t erti, az ertekeket
# a hivo adja/irja (control.setting / setSetting).

import re
import xml.etree.ElementTree as ET


HELP_END = u'.'                 # lsep, ami ponttal vegzodik: sugo, nem szakaszcim
BOOL_ON, BOOL_OFF = u'Be', u'Ki'
TEXT_EMPTY = u'(nincs)'
TEXT_HIDDEN = u'••••••'
ACTION_MARK = u'›'


def _strip_tags(text):
    return re.sub(r'\[/?[A-Z]+[^\]]*\]', '', text or u'').strip()


def _indent(label):
    '''"-- Cim" -> (2, "Cim").'''
    match = re.match(r'^(-+)\s*(.*)$', label or u'')
    if not match:
        return 0, (label or u'').strip()
    return len(match.group(1)), match.group(2).strip()


def _enable(text):
    '''"eq(-2,true)" -> (-2, "true"); None, ha nincs / mas alaku.'''
    match = re.match(r'^eq\((-?\d+),([^)]*)\)$', (text or '').strip())
    if not match:
        return None
    return int(match.group(1)), match.group(2).strip().lower()


def parse(text):
    '''
    Szakaszok: [{'title', 'items': [sor]}]. Egy sor: {'id', 'label',
    'type' (bool / labelenum / slider / text / action), 'values' (lista),
    'default', 'range' (min, step, max), 'hidden', 'action', 'enable'
    ((id, ertek) vagy None), 'help', 'indent'}.
    '''
    root = ET.fromstring(text.lstrip(u'﻿').encode('utf-8') if isinstance(text, str) else text)
    sections = []
    for category in root.findall('category'):
        rows = list(category.findall('setting'))
        section = {'title': category.get('label') or u'', 'items': []}
        sections.append(section)
        by_index = {}
        for index, node in enumerate(rows):
            kind = node.get('type') or ''
            label = node.get('label') or u''
            if kind == 'lsep':
                if label.strip().endswith(HELP_END):
                    # sugo az utolso sorhoz (ha van)
                    if section['items']:
                        item = section['items'][-1]
                        item['help'] = (item['help'] + u' ' + label.strip()).strip()
                else:
                    section = {'title': label.strip(), 'items': []}
                    sections.append(section)
                continue
            if node.get('visible') == 'false' or (not node.get('id') and kind != 'action'):
                continue
            indent, clean = _indent(_strip_tags(label))
            item = {
                'id': node.get('id') or ('action:%d' % index),
                'label': clean,
                'type': kind,
                'values': [v for v in (node.get('values') or '').split('|') if v] if node.get('values') else [],
                'default': node.get('default') or u'',
                'range': None,
                'hidden': node.get('option') == 'hidden',
                'action': node.get('action') or '',
                'enable': None,
                'help': u'',
                'indent': indent,
            }
            if kind == 'slider':
                try:
                    low, step, high = [int(float(v)) for v in (node.get('range') or '0,1,10').split(',')]
                except ValueError:
                    low, step, high = 0, 1, 10
                item['range'] = (low, step, high)
            rule = _enable(node.get('enable'))
            if rule is not None:
                target = by_index.get(index + rule[0])
                if target is not None:
                    item['enable'] = (target, rule[1])
            by_index[index] = item['id']
            section['items'].append(item)
    return [section for section in sections if section['items']]


def is_enabled(item, get):
    '''get(id) -> ertek. A sor aktiv-e (az enable feltetele teljesul-e).'''
    rule = item.get('enable')
    if not rule:
        return True
    return (get(rule[0]) or u'').lower() == rule[1]


def value_of(item, get):
    value = get(item['id'])
    return value if value not in (None, u'') else item.get('default') or u''


def display(item, value):
    '''Az ertek, ahogy a sorban latszik.'''
    kind = item['type']
    if kind == 'bool':
        return BOOL_ON if (value or u'').lower() == 'true' else BOOL_OFF
    if kind == 'action':
        return ACTION_MARK
    if kind == 'text':
        if not value:
            return TEXT_EMPTY
        return TEXT_HIDDEN if item.get('hidden') else value
    return value or u''


def toggled(value):
    return 'false' if (value or u'').lower() == 'true' else 'true'


def stepped(item, value, direction):
    '''A kovetkezo / elozo ertek (labelenum: korbe; slider: a hataron megall).'''
    kind = item['type']
    if kind == 'labelenum' and item['values']:
        values = item['values']
        try:
            index = values.index(value)
        except ValueError:
            index = 0 if direction > 0 else len(values)
            index -= 1 if direction > 0 else 0
        return values[(index + direction) % len(values)]
    if kind == 'slider' and item['range']:
        low, step, high = item['range']
        try:
            current = int(float(value))
        except (TypeError, ValueError):
            current = low
        return str(max(low, min(high, current + direction * step)))
    return value


def editable(item):
    return item['type'] in ('labelenum', 'slider')
