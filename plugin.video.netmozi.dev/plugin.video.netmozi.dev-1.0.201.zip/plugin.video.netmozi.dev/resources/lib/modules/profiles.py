# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# "Ki nez?" -- profilok. Csak a NEVEK es az aktiv profil kezelese; hogy az
# adatok hova kerulnek, azt a control.profileDir() donti el, es minden
# szemelyes modul azt hasznalja. A nevtelen "Kozos" profil mindig letezik.

import json
import os
import shutil

from resources.lib.modules import control


SHARED = u''                       # a nevtelen profil
SHARED_LABEL = u'Közös'
MAX_PROFILES = 8
# A csempek szinei (Netflix-fele): a Kozos az elso, a tobbi sorban; a
# skin ugyanezekkel a sorszamokkal dolgozik (make_home_xml.py PROFILE_COLORS).
COLORS = 6


def color(name):
    '''A profil szin-sorszama (0 = Kozos, 1.. a nevvel letrehozottak sorban).'''
    if not name:
        return 0
    try:
        return names().index(name) % (COLORS - 1) + 1
    except ValueError:
        return 0


def initial(name):
    '''A csempe nagy betuje.'''
    text = (name or SHARED_LABEL).strip()
    return text[:1].upper() if text else u'?'


# --- Mese-profil es PIN --------------------------------------------------------
#
# A mese-profil jeloloje a profil.json-ban ('kids'); a benne aktiv profilnal
# a bovitmeny mindenutt csak a mese-jellegu cimeket mutatja (home.kids_ok).
# A PIN (4 szamjegy, sozott hash-kent tarolva) a NEM mese profilokat es a
# beallitasokat vedi: a gyerek ne tudjon atvaltani.

KIDS_COLOR = 'kids'


def is_kids(name):
    name = (name or '').strip()
    return bool(name) and name in (load().get('kids') or [])


def set_kids(name, flag):
    name = (name or '').strip()
    if not name or name not in names():
        return False
    data = load()
    kids = [item for item in (data.get('kids') or []) if item != name]
    if flag:
        kids.append(name)
    data['kids'] = kids
    return save(data)


def kids_active():
    '''Az aktiv profil mese-profil-e.'''
    return is_kids(active())


def _pin_hash(code, salt):
    import hashlib
    return hashlib.sha256((salt + ':' + code).encode('utf-8')).hexdigest()


def has_pin():
    return bool((load().get('pin') or {}).get('hash'))


def set_pin(code):
    '''4 szamjegy; ures = torles. True, ha sikerult.'''
    import os
    import binascii
    code = (code or '').strip()
    data = load()
    if not code:
        data.pop('pin', None)
        return save(data)
    if not (code.isdigit() and len(code) == 4):
        return False
    salt = binascii.hexlify(os.urandom(8)).decode('ascii')
    data['pin'] = {'salt': salt, 'hash': _pin_hash(code, salt)}
    return save(data)


def check_pin(code):
    pin = load().get('pin') or {}
    if not pin.get('hash'):
        return True
    return _pin_hash((code or '').strip(), pin.get('salt') or '') == pin['hash']


def pin_needed(name):
    '''Kell-e PIN a profil valasztasahoz: ha van PIN, es a cel nem mese-profil.'''
    return has_pin() and not is_kids(name)


def tiles():
    '''[(nev, felirat, szin, aktiv-e, mese-e)] a Ki nez? kepernyore (a Kozos elol).'''
    current = active()
    rows = [(SHARED, SHARED_LABEL, 0, current == SHARED, False)]
    for name in names():
        kids = is_kids(name)
        rows.append((name, name, KIDS_COLOR if kids else color(name), current == name, kids))
    return rows


def ask_dialog():
    '''"Ki nez?" a Kodi valasztojaval (telefonon / szoveges menunel). True, ha valasztott.'''
    import xbmcgui
    current = names()
    if not current:
        return False
    rows = [SHARED_LABEL] + current
    choice = xbmcgui.Dialog().select(u'Ki néz?', rows)
    if choice > 0:
        set_active(current[choice - 1])
    elif choice == 0:
        set_active(SHARED)
    return choice >= 0


def _path():
    return os.path.join(control.dataPath, control.PROFILE_FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'profilok írása', exc)
        return False


def names():
    '''A nevvel letrehozott profilok (a Kozos nincs koztuk).'''
    out = []
    for name in load().get('names') or []:
        name = (name or '').strip()
        if name and name not in out:
            out.append(name)
    return out


def active():
    return control.activeProfile()


def label(name=None):
    name = active() if name is None else name
    return name or SHARED_LABEL


def set_active(name):
    data = load()
    name = (name or '').strip()
    if name and name not in names():
        return False
    data['active'] = name
    save(data)
    control.log(u'Profil: %s' % label(name))
    return True


def add(name):
    name = (name or '').strip()
    if not name or not control.profileSlug(name):
        return False
    data = load()
    current = names()
    if name in current:
        return True
    if len(current) >= MAX_PROFILES:
        return False
    data['names'] = current + [name]
    save(data)
    return True


def remove(name):
    '''A profil es az adatai. Ha az aktiv volt, a Kozosre vált.'''
    name = (name or '').strip()
    data = load()
    current = names()
    if name not in current:
        return False
    data['names'] = [item for item in current if item != name]
    data['kids'] = [item for item in (data.get('kids') or []) if item != name]
    if (data.get('active') or '') == name:
        data['active'] = SHARED
    save(data)
    folder = os.path.join(control.dataPath, control.PROFILES_DIR, control.profileSlug(name))
    shutil.rmtree(folder, ignore_errors=True)
    return True
