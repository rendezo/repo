# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Hol tartok egy sorozatban.
#
# A "Mar lattam" lista reszenkent jegyez, ezert egy sorozatot nem lehet
# belole okosan folytatni. Ez a modul SOROZATONKENT egy bejegyzest tart:
# melyik resz ment utoljara, hany masodpercnel tartott, es mi a kovetkezo.
#
# A pozicio azert kell, mert a Kodi sajat folytatasa nalunk nem mukodik: a
# stream cime orankent valtozik (token), a Kodi pedig a cimhez koti a
# folytatasi pontot. Nezes kozben a hatterszolgaltatas ir ide.

import json
import os
import re
import time

from resources.lib.modules import config, control


FILE = 'progress.json'
MAX_ENTRIES = 60

# A fajlban ez a kulcs nem sorozat, hanem a modul sajat jegyzete (pl. hogy
# az egyszeri atvezetes megtortent-e).
META = '__meta__'


def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'folytatás írása', exc)
        return False


def split_page(page):
    '''"<base>/s1/e3" -> (base, 1, 3); nem resz -> None.'''
    match = re.match(config.EPISODE_URL_RE, page or '')
    if not match:
        return None
    return match.group('base'), int(match.group('season')), int(match.group('episode'))


def episode_label(season, episode):
    return u'%d. évad %d. rész' % (season, episode)


def film_key(page):
    '''Filmnel a kulcs maga az adatlap utvonala; None, ha nem film-utvonal.'''
    page = (page or '').strip()
    if not page or page == META or split_page(page):
        return None
    return page


def update(page, title='', thumb='', position=0, total=0):
    '''
    Nezes kozben: hol tart a resz vagy a film. Sorozatnal a kulcs a sorozat
    (egy bejegyzes sorozatonkent), filmnel maga a film. A cim/borito csak
    akkor irodik felul, ha ertelmes erteket kapunk.
    '''
    parts = split_page(page)
    if parts:
        base, season, episode = parts
        kind = 'series'
    else:
        base = film_key(page)
        if not base:
            return False
        season = episode = 0
        kind = 'film'
    data = load()
    entry = data.get(base) or {}
    same_episode = entry.get('page') == page
    entry.update({
        'kind': kind,
        'page': page,
        'season': season,
        'episode': episode,
        'position': max(0, int(position or 0)),
        'total': max(0, int(total or 0)),
        'updated': int(time.time()),
    })
    if title:
        entry['title'] = title
    if thumb:
        entry['thumb'] = thumb
    if not same_episode:
        # Masik resz indult: a korabban feljegyzett "kovetkezo" mar nem ide
        # tartozik. (A lejatszas inditasakor ujra beallitjuk.)
        entry.pop('next_page', None)
    # Valodi pozicio van: az atvezetesbol orokolt "megnezettnek vesszuk"
    # jeloles innentol nem kell.
    entry.pop('done', None)
    # A set_next altal felretett "kovetkezo" (ha a resz akkor meg nem ment).
    meta = data.get(META) or {}
    pending = meta.get('pending_next') or {}
    if page in pending:
        entry['next_page'] = pending.pop(page)
        meta['pending_next'] = pending
        data[META] = meta
    data[base] = entry
    _trim(data)
    return save(data)


def _trim(data):
    paths = [key for key in data if key != META]
    if len(paths) > MAX_ENTRIES:
        for old in sorted(paths, key=lambda k: data[k].get('updated', 0))[:-MAX_ENTRIES]:
            del data[old]


def set_next(page, next_page):
    '''A lejatszas inditasakor mar tudjuk, mi jon utana az evadon belul.'''
    parts = split_page(page)
    if not parts:
        return
    base = parts[0]
    data = load()
    entry = data.get(base)
    if entry is None:
        # Meg nincs bejegyzes (a resz meg nem indult el): a "kovetkezot" a
        # meta ala tesszuk, es az update() veszi at, amikor tenyleg megy.
        # Igy nem szuletik cim es borito nelkuli "folytatas".
        meta = data.get(META) or {}
        pending = meta.get('pending_next') or {}
        pending[page] = next_page or ''
        meta['pending_next'] = pending
        data[META] = meta
        save(data)
        return
    elif entry.get('page') != page:
        # Uj resz indul: a pozicio a regi reszre vonatkozott.
        entry.update({'page': page, 'season': parts[1], 'episode': parts[2],
                      'position': 0, 'total': 0, 'updated': int(time.time())})
        entry.pop('done', None)
    entry['next_page'] = next_page or ''
    save(data)


def get(base):
    if base == META:
        return None
    return load().get(base)


def remove(base):
    data = load()
    if base in data:
        del data[base]
        return save(data)
    return False


def is_film(entry):
    return (entry or {}).get('kind') == 'film'


def entries(kind=None):
    '''Legfrissebb elol. `kind`: 'series' / 'film' / None (mind).'''
    rows = []
    for base, entry in load().items():
        if base == META:
            continue
        if kind == 'series' and is_film(entry):
            continue
        if kind == 'film' and not is_film(entry):
            continue
        row = dict(entry)
        row['base'] = base
        rows.append(row)
    return sorted(rows, key=lambda row: row.get('updated', 0), reverse=True)


def film_resume(page):
    '''Filmnel: hany masodperctol folytassuk (0 = elejerol / nincs adat).'''
    entry = load().get(film_key(page) or '')
    if not entry or not is_film(entry):
        return 0
    return resume_seconds(entry)


def finished(entry):
    '''Vegigneztuk-e a legutobbi reszt (a vege fele jaro pozicio is annak szamit).'''
    if entry.get('done'):
        # Atvezetett bejegyzes: poziciot nem ismerunk, de a legutobb nezett
        # reszt igen -- azt megnezettnek vesszuk, jon a kovetkezo. Ha megsem,
        # a helyi menu "Elolrol" pontja ott van.
        return True
    total = entry.get('total') or 0
    if total <= 0:
        return False
    return (entry.get('position') or 0) >= total * config.CONTINUE_DONE_RATIO


def resume_seconds(entry):
    '''Honnan folytassuk: 0, ha az elejerol (vagy ha mar vegigment).'''
    if finished(entry):
        return 0
    position = entry.get('position') or 0
    return position if position >= config.CONTINUE_MIN_SECONDS else 0


def next_key(entry, listed):
    '''
    A kovetkezo resz kulcsa ("2x1") a teljes felsorolas alapjan -- evadhataron
    is atlep. None, ha nincs tobb.
    '''
    current = '%dx%d' % (entry.get('season', 0), entry.get('episode', 0))
    if current in listed:
        index = listed.index(current)
        return listed[index + 1] if index + 1 < len(listed) else None
    # Ha a legutobbi resz mar nincs a felsorolasban, az elso nala nagyobb.
    for text in listed:
        season, episode = (int(part) for part in text.split('x', 1))
        if (season, episode) > (entry.get('season', 0), entry.get('episode', 0)):
            return text
    return None


def describe(entry):
    '''A "Mar lattam" sorban: hova visz a kattintas.'''
    last = episode_label(entry.get('season', 0), entry.get('episode', 0))
    if not finished(entry):
        seconds = resume_seconds(entry)
        if seconds:
            return u'folytatás: %s (%d. perctől)' % (last, seconds // 60)
        return u'folytatás: %s' % last
    next_page = entry.get('next_page')
    parts = split_page(next_page) if next_page else None
    if parts:
        return u'folytatás: %s' % episode_label(parts[1], parts[2])
    # Nem tudjuk, mi jon (evad vege, vagy atvezetett bejegyzes): kattintasra
    # a sorozat oldalarol derul ki.
    return u'folytatás: %s után' % last


# --- Egyszeri atvezetes a regi "Mar lattam" bejegyzesekbol --------------------

def migrate(history_entries):
    '''
    A frissites ELOTT nezett sorozatok is kapjanak folytatas-sort.

    A regi bejegyzesekben nincs pozicio, de a legutoljara nezett resz igen:
    azt megnezettnek vesszuk ("done"), igy a folytatas a kovetkezovel megy.
    Csak egyszer fut: aki utana torol egy sorozatot a folytatasbol, annak
    nem jon vissza a regi bejegyzesekbol.

    Visszaad: hany sorozat kerult at.
    '''
    data = load()
    meta = data.get(META) or {}
    if meta.get('migrated'):
        return 0
    latest = {}
    for entry in history_entries or []:
        parts = split_page(entry.get('page', ''))
        if not parts:
            continue
        base = parts[0]
        stamp = entry.get('time') or 0
        if base not in latest or stamp > latest[base][0]:
            latest[base] = (stamp, entry, parts)
    count = 0
    for base, (stamp, entry, parts) in latest.items():
        if base in data:
            continue
        data[base] = {
            'page': entry.get('page', ''),
            'season': parts[1],
            'episode': parts[2],
            'position': 0,
            'total': 0,
            'updated': int(stamp or time.time()),
            'title': entry.get('title', ''),
            'thumb': entry.get('thumb', ''),
            'done': True,
        }
        count += 1
    data[META] = {'migrated': int(time.time())}
    _trim(data)
    save(data)
    if count:
        control.log(u'Folytatás: %d sorozat átvezetve a régi előzményekből' % count)
    return count
