# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Szolgaltato-sorok a kezdokepernyon: Netflix, Apple, Prime, Disney+, HBO
# Max, SkyShowtime Top.
#
# A cimek ket forrasbol johetnek (config.PROVIDER_ROWS): a szolgaltato
# HIVATALOS top listaja (Movie of the Night -- IMDb-azonositoval), vagy a
# TMDB magyar kinalata nepszeruseg szerint. Hogy a netmozin megvan-e, a
# netmozi keresojevel derul ki -- az az IMDb-azonositot is elfogadja, es
# pontosan azt az egy cimet adja vissza.
#
# Naponta egyszer fut (a kezdokepernyo hatterszalabol, vagy a napi Stream
# Top ellenorzessel egyutt). Amit egyszer megtalaltunk (vagy nem), azt egy
# hetig nem keressuk ujra -- a napi futas igy par keresbol all.
#
# Fajl: providers.json
#   {'__meta__': {'last_run'},
#    'ids':   {'movie:123': 'tt...'}          TMDB -> IMDb, orokre
#    'found': {'tt...': {netmozi sor, 'checked'}}   megvan a netmozin
#    'missing': {'tt...': checked}            nincs (egy hetig hisszuk)
#    'rows': {'disney': ['tt...', ...], ...}  a sor cimei, sorrendben}

import json
import os
import time

from resources.lib.modules import config, control


FILE = 'providers.json'
ROW_FIELDS = ('title', 'thumb', 'url', 'isSeries', 'quality', 'language', 'year', 'categories')


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'szolgáltató-sorok írása', exc)
        return False


def due(now=None):
    now = now or time.time()
    meta = load().get('__meta__') or {}
    return (now - (meta.get('last_run') or 0)) >= config.PROVIDER_CHECK_INTERVAL


def rows(data=None):
    '''{sor kulcsa: [netmozi sor]} -- csak ami megvan a netmozin, sorrendben.'''
    data = load() if data is None else data
    found = data.get('found') or {}
    out = {}
    for key, _title, _service, _pid in config.PROVIDER_ROWS:
        items = []
        for imdb in (data.get('rows') or {}).get(key) or []:
            entry = found.get(imdb)
            if entry and entry.get('url'):
                items.append(entry)
        out[key] = items
    return out


def match(rows_found, imdb):
    '''A netmozi talalatai kozul az, amelyik boritoja PONT ezt az IMDb-t hordozza.'''
    from resources.lib.modules import tmdb
    for row in rows_found or []:
        if tmdb.imdb_id(row.get('thumb', '')) == imdb:
            return row
    return None


def interleave(movies, shows):
    '''
    [(fajta, TMDB id)] felvaltva: 1. film, 1. sorozat, 2. film, ... A TMDB
    a filmek es a sorozatok nepszeruseget mas skalan meri, a nyers ertek
    szerint a sorozatok mind elore kerulnenek.
    '''
    out = []
    for index in range(max(len(movies), len(shows))):
        if index < len(movies):
            out.append(('movie', movies[index]))
        if index < len(shows):
            out.append(('tv', shows[index]))
    return out


def _slim(row):
    return dict((field, row.get(field)) for field in ROW_FIELDS if row.get(field) is not None)


def enabled():
    '''Van-e ertelme futni: barmelyik kulcs megvan.'''
    from resources.lib.modules import motn, tmdb
    return bool(motn.api_key() or tmdb.api_key())


def candidates_for(row_key, service, provider_id, ids, keys):
    '''
    Egy sor cimei IMDb-azonositokent, sorrendben. Eloszor a hivatalos lista
    (Movie of the Night), kulonben a TMDB kinalata. None, ha egyik sem
    elerheto (marad a regi sor); 'stop', ha a halozat elment.
    '''
    from resources.lib.modules import motn, tmdb
    if service and keys.get('motn'):
        listed = motn.top(service, keys['motn'])
        if listed:
            return [imdb for imdb, _title, _kind in listed]
        control.log(u'%s: a hivatalos top lista nem érhető el' % row_key, control.LOGWARNING)
    if not (provider_id and keys.get('tmdb')):
        return None
    listed = {}
    for kind in (tmdb.MOVIE, tmdb.TV):
        got = tmdb.discover(kind, provider_id, keys['tmdb'])
        if got is None:
            control.log(u'%s: a TMDB lista nem érhető el' % row_key, control.LOGWARNING)
            continue
        listed[kind] = [tmdb_id for tmdb_id, _popularity in got]
    pairs = interleave(listed.get(tmdb.MOVIE) or [], listed.get(tmdb.TV) or [])
    if not pairs:
        return None
    imdbs = []
    for kind, tmdb_id in pairs:
        id_key = '%s:%s' % (kind, tmdb_id)
        if id_key not in ids:
            imdb = tmdb.external_imdb(kind, tmdb_id, keys['tmdb'])
            if imdb is None:
                return 'stop'
            ids[id_key] = imdb
        if ids[id_key]:
            imdbs.append(ids[id_key])
    return imdbs


# --- Mese-profil: a szolgaltatok mese-kinalata (netmozi nelkul is) ---------------
#
# A mese-sorokba nem csak az kerul, ami megvan a netmozin: a TMDB mese-
# kinalata (Disney+, Netflix, HBO Max, SkyShowtime), az IMDb korhatar-
# szurojen at, es ami nincs a netmozin, azt az nCore-rol lehet inditani.
#   'kids': {'disney': [{'imdb', 'title', 'thumb', 'kind'}, ...]}
#   '__meta__': {'kids_run'}
# A netmozi-talalat / nincs ugyanaz a 'found' / 'missing', mint a tobbi sore.

def kids_due(now=None):
    now = now or time.time()
    meta = load().get('__meta__') or {}
    return (now - (meta.get('kids_run') or 0)) >= config.PROVIDER_CHECK_INTERVAL


def kids_rows(data=None):
    '''{sor kulcsa: [sor]}: a netmozi sora, ha megvan; kulonben a jelolt maga (imdb, title, thumb, kind).'''
    data = load() if data is None else data
    found = data.get('found') or {}
    out = {}
    for key, _title, _pid in config.KIDS_PROVIDERS:
        items = []
        for cand in (data.get('kids') or {}).get(key) or []:
            entry = found.get(cand.get('imdb'))
            items.append(entry if entry and entry.get('url') else dict(cand))
        out[key] = items
    return out


def run_kids(search, now=None, sleep=time.sleep):
    '''
    Napi futas a mese-sorokhoz: TMDB mese-kinalat -> IMDb-azonositok ->
    IMDb korhatar-szuro -> netmozi keresese. Visszaad: hany cimet
    kerestunk a netmozin. TMDB-kulcs nelkul nem csinal semmit.
    '''
    from resources.lib.modules import client, imdb as imdb_mod, tmdb
    key = tmdb.api_key()
    if not key:
        return 0
    now = now or time.time()
    data = load()
    ids = data.setdefault('ids', {})
    found = data.setdefault('found', {})
    missing = data.setdefault('missing', {})
    kids = data.setdefault('kids', {})
    searched = 0
    stop = False
    for row_key, _title, provider_id in config.KIDS_PROVIDERS:
        if stop:
            break
        listed = {}
        for kind in (tmdb.MOVIE, tmdb.TV):
            got = tmdb.discover_kids(kind, provider_id, key)
            if got is None:
                control.log(u'%s mesék: a TMDB lista nem érhető el' % row_key, control.LOGWARNING)
                continue
            listed[kind] = got
        pairs = interleave(listed.get(tmdb.MOVIE) or [], listed.get(tmdb.TV) or [])
        if not pairs:
            continue                                 # marad, ami volt
        candidates = []
        for kind, row in pairs:
            id_key = '%s:%s' % (kind, row['id'])
            if id_key not in ids:
                imdb = tmdb.external_imdb(kind, row['id'], key)
                if imdb is None:
                    stop = True
                    break
                ids[id_key] = imdb
            if ids[id_key] and ids[id_key] not in [c['imdb'] for c in candidates]:
                candidates.append({'imdb': ids[id_key], 'title': row.get('title') or '',
                                   'thumb': row.get('poster') or '', 'kind': kind})
        if stop:
            break
        # Az IMDb korhatar / mufaj szuroje: csak ami gyereknek valo.
        safe = imdb_mod.kids_check([c['imdb'] for c in candidates])
        candidates = [c for c in candidates if safe.get(c['imdb'])]
        for cand in candidates:
            imdb = cand['imdb']
            entry = found.get(imdb)
            fresh = (now - (entry or {}).get('checked', missing.get(imdb, 0))) < config.PROVIDER_RECHECK
            if (entry or imdb in missing) and fresh:
                continue
            if searched >= config.KIDS_SEARCH_MAX or client.blocked_recently():
                continue
            hits = search(imdb)
            searched += 1
            if hits is None:
                control.log(u'mese-sorok: a netmozi keresés nem érhető el', control.LOGWARNING)
                stop = True
                break
            row = match(hits, imdb)
            if row is None:
                found.pop(imdb, None)
                missing[imdb] = int(now)
            else:
                slim = _slim(row)
                slim['checked'] = int(now)
                found[imdb] = slim
                missing.pop(imdb, None)
            sleep(config.PROVIDER_SEARCH_PAUSE)
        if not stop:
            kids[row_key] = candidates
    if not stop:
        meta = data.setdefault('__meta__', {})
        meta['kids_run'] = int(now)
    save(data)
    if searched:
        control.log(u'mese-sorok: %d címet kerestem a netmozin' % searched)
    return searched


def run(search, now=None, sleep=time.sleep):
    '''
    Napi futas. A `search(szoveg)` a netmozi keresese (navigator.searchMovies:
    sorok, vagy None halozati hibanal). Visszaad: hany cimet kerestunk a
    netmozin. Kulcs nelkul nem csinal semmit.
    '''
    from resources.lib.modules import client, motn, tmdb
    keys = {'motn': motn.api_key(), 'tmdb': tmdb.api_key()}
    if not (keys['motn'] or keys['tmdb']):
        return 0
    now = now or time.time()
    data = load()
    ids = data.setdefault('ids', {})
    found = data.setdefault('found', {})
    missing = data.setdefault('missing', {})
    row_lists = data.setdefault('rows', {})
    searched = 0
    stop = False

    for row_key, _title, service, provider_id in config.PROVIDER_ROWS:
        if stop:
            break
        candidates = candidates_for(row_key, service, provider_id, ids, keys)
        if candidates == 'stop':
            stop = True
            break
        if not candidates:
            continue                                 # marad, ami volt
        imdbs = []
        for imdb in candidates:
            if imdb in imdbs:
                continue
            imdbs.append(imdb)
            # Megvan-e a netmozin? Hetente egyszer nezzuk meg ujra.
            entry = found.get(imdb)
            fresh = (now - (entry or {}).get('checked', missing.get(imdb, 0))) < config.PROVIDER_RECHECK
            if (entry or imdb in missing) and fresh:
                continue
            if searched >= config.PROVIDER_SEARCH_MAX or client.blocked_recently():
                continue
            hits = search(imdb)
            searched += 1
            if hits is None:
                control.log(u'szolgáltató-sorok: a netmozi keresés nem érhető el', control.LOGWARNING)
                stop = True
                break
            row = match(hits, imdb)
            if row is None:
                found.pop(imdb, None)
                missing[imdb] = int(now)
            else:
                slim = _slim(row)
                slim['checked'] = int(now)
                found[imdb] = slim
                missing.pop(imdb, None)
            sleep(config.PROVIDER_SEARCH_PAUSE)
        if not stop:
            row_lists[row_key] = imdbs               # felbeszakadt futas: marad a regi sor

    if not stop:
        data['__meta__'] = {'last_run': int(now)}
    # Ami mar egyik sorban sincs, es reg volt: takaritas (a mese-sorok cimei is szamitanak).
    used = set(imdb for lst in row_lists.values() for imdb in lst)
    used |= set(c.get('imdb') for lst in (data.get('kids') or {}).values() for c in lst)
    for store in (found, missing):
        for imdb in list(store):
            if imdb not in used:
                del store[imdb]
    save(data)
    if searched:
        control.log(u'szolgáltató-sorok: %d címet kerestem a netmozin' % searched)
    return searched
