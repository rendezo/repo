# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A "Working..." elrejtese (1.0.149) a skin DialogBusy.xml-jenek modositasaval
# ment -- es mellekhatasa volt (a Kodi a feltetelesen lathato dialogusokat
# ablakvaltaskor maga nyitja/zarja). KIVEZETVE: ez a modul mar csak
# visszaallit -- ha a TV-n meg a modositott fajl van, a mentesbol az
# eredetit irja vissza (a szolgaltatas indulasakor, egyszer).

import os

from resources.lib.modules import control


BACKUP_SUFFIX = '.netmozi-backup'
FILE_NAME = 'DialogBusy.xml'


def skin_root():
    '''A jelenlegi skin mappaja (a Kodi profil alatti addons), vagy ''.'''
    import xbmc
    import xbmcvfs
    try:
        skin = xbmc.getSkinDir()
    except Exception:
        return ''
    if not skin:
        return ''
    return xbmcvfs.translatePath('special://home/addons/%s' % skin)


def find_dialog(root):
    '''A skin DialogBusy.xml-je (az elso talalat a felbontas-mappakban), vagy ''.'''
    if not root or not os.path.isdir(root):
        return ''
    for folder in sorted(os.listdir(root)):
        path = os.path.join(root, folder, FILE_NAME)
        if os.path.isfile(path):
            return path
    return ''


def restore(root=None):
    '''(True, uzenet) ha visszaallitotta; (False, uzenet) ha nem volt mit.'''
    root = skin_root() if root is None else root
    path = find_dialog(root)
    if not path or not os.path.exists(path + BACKUP_SUFFIX):
        return False, u'Nincs mit visszaállítani.'
    try:
        with open(path + BACKUP_SUFFIX, encoding='utf-8') as handle:
            text = handle.read()
        with open(path, 'w', encoding='utf-8') as handle:
            handle.write(text)
        os.remove(path + BACKUP_SUFFIX)
    except (IOError, OSError) as exc:
        return False, u'Nem sikerült: %s' % exc
    control.log(u'DialogBusy.xml visszaállítva az eredetire: %s' % path)
    return True, u'Visszaállítva az eredeti.'


def reload_skin():
    import xbmc
    try:
        xbmc.executebuiltin('ReloadSkin()')
    except Exception:
        pass


def undo_if_patched():
    '''A szolgaltatas hivja indulaskor: ha van mentes, az eredeti vissza, es a skin ujratolt.'''
    try:
        ok, _message = restore()
    except Exception as exc:
        control.log_exception(u'DialogBusy.xml visszaállítása', exc)
        return False
    if ok:
        reload_skin()
    return ok
