# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Stream Top: elore latszodjon, mi van meg a netmozin.
#
# A top listak cimei streaming-szolgaltatoktol jonnek; hogy a netmozin
# megvan-e, csak kattintaskor derult ki. A hatterszolgaltatas naponta
# egyszer rakeres a cimekre, es az eredmenyt itt jegyzi: a lista sora
# mutatja, ha megvan (es akkor a kattintas egybol oda visz, kereses nelkul).
#
# A kereses (navigator.searchMovies) hivhato fuggvenykent erkezik, hogy a
# modul halozat nelkul tesztelheto legyen.

import json
import os
import time

from resources.lib.modules import control
from resources.lib.modules.utils import normalize_title


FILE = 'streamcheck.json'

# Naponta egyszer eleg: a top listak hetente valtoznak.
CHECK_INTERVAL = 24 * 3600

# Egy futasban ennel tobb cimre nem keresunk -- ne terheljuk az oldalt.
MAX_PER_RUN = 40

MAX_ENTRIES = 400

FILM, SERIES, NONE = 'film', 'series', 'none'


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'Stream Top elérhetőség írása', exc)
        return False


def key(title):
    return normalize_title(title)


def status(title, data=None):
    '''A cim bejegyzese, vagy None, ha meg nem neztuk.'''
    data = load() if data is None else data
    return data.get(key(title))


def due(now=None):
    '''Esedekes-e a napi futas (az utolso futas ideje alapjan).'''
    now = now or time.time()
    meta = load().get('__meta__') or {}
    return (now - (meta.get('last_run') or 0)) >= CHECK_INTERVAL


def stale_titles(titles, now=None):
    '''Azok a cimek, amiket meg nem, vagy tul reg neztunk.'''
    now = now or time.time()
    data = load()
    out = []
    seen = set()
    for title in titles:
        k = key(title)
        if not k or k in seen:
            continue
        seen.add(k)
        entry = data.get(k)
        if not entry or (now - entry.get('checked', 0)) >= CHECK_INTERVAL:
            out.append(title)
    return out[:MAX_PER_RUN]


def classify(rows, title, best_match):
    '''
    Egy kereses eredmenye -> (statusz, url). A `best_match(rows, title)` a
    navigator.pickBestMatch: egyertelmu talalatot ad, vagy None-t.
    '''
    if not rows:
        return NONE, '', {}
    pick = best_match(rows, title)
    if pick is None:
        # Van talalat, de nem egyertelmu: ne mondjunk sem igent, sem nemet --
        # a kattintas a talalati listat hozza, mint eddig.
        return '', '', {}
    extra = {'quality': pick.get('quality', ''), 'language': pick.get('language', '')}
    return (SERIES if pick.get('isSeries') else FILM), pick.get('url', ''), extra


def run(titles, search, best_match, now=None):
    '''
    Napi futas: a `search(title)` a netmozi keresese (None = halozati hiba).
    Visszaad: hany cimet neztunk meg.
    '''
    now = now or time.time()
    data = load()
    count = 0
    for title in stale_titles(titles, now):
        rows = search(title)
        if rows is None:
            # Halozati hiba: ne irjuk felul, amit tudunk; a tobbit se eroltessuk.
            control.log(u'Stream Top ellenőrzés: a keresés nem érhető el', control.LOGWARNING)
            break
        state, url, extra = classify(rows, title, best_match)
        entry = {'title': title, 'status': state, 'url': url, 'checked': int(now)}
        entry.update(extra)
        data[key(title)] = entry
        count += 1
    data['__meta__'] = {'last_run': int(now)}
    paths = [k for k in data if k != '__meta__']
    if len(paths) > MAX_ENTRIES:
        for old in sorted(paths, key=lambda k: data[k].get('checked', 0))[:-MAX_ENTRIES]:
            del data[old]
    save(data)
    if count:
        control.log(u'Stream Top ellenőrzés: %d cím' % count)
    return count


def marker(entry):
    '''A lista sorába: "[megvan]" / "[sorozat]" / "[nincs]" / "".'''
    if not entry:
        return u''
    return {FILM: u'  [megvan]', SERIES: u'  [megvan, sorozat]',
            NONE: u'  [nincs a netmozin]'}.get(entry.get('status'), u'')
