# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Figyelt sorozatok: szol, ha egy sorozatnak UJ RESZE jelent meg FORRASSAL.
#
# Nem az erdekel, hogy egy meglevo reszhez jott-e uj forras, hanem hogy van-e
# olyan resz, ami eddig nem volt nezheto, es most az. Ket dolog kell hozza:
#
#   - "listed":  amit a sorozat oldala felsorol (minden evad minden resze);
#   - "seen":    amirol mar tudunk -- vagy mert felvetelkor mar megvolt, vagy
#                mert azota mi jelentettuk.
#
# A ketto kulonbsege a "fuggo" resz: fel van sorolva, de nem tudjuk, van-e
# forrasa. Az oldal ugyanis a meg nem elerheto reszeket is felsorolja
# (helyorzokent). Ezeket napi ellenorzeskor megnezzuk; amelyiknek lett
# forrasa, azt jelentjuk, es atkerul a "seen"-be.
#
# A halozati resz (oldal letoltese, forrasok szamolasa) SZANDEKOSAN nincs
# itt: hivhato fuggvenykent erkezik. Igy a logika fixture-rel tesztelheto,
# es a hatterszolgaltatas sem fugg a navigatortol.

import json
import os
import re
import time

# A client (es vele a requests) SZANDEKOSAN nincs itt importalva: a
# hatterszolgaltatas ezt a modult a Kodi indulasakor tolti be, es neki csak
# a JSON-olvasas kell. A requests importja lassu dobozon masodpercek.
from resources.lib.modules import config, control


FILE = 'watchlist.json'

# Naponta egyszer nezunk ra. Ennel gyakrabban nincs ertelme: a reszek nem
# oranket jonnek, a netmozi pedig nem szereti a sok keresest.
CHECK_INTERVAL = 24 * 3600

# Sikertelen (pl. halozati) probalkozas utan ennyi ideig nem ujrazunk.
RETRY_INTERVAL = 3600

# Felvetelkor a legutolso ennyi reszt nezzuk meg, van-e forrasa. Az elozoket
# ismertnek vesszuk: aki felvesz egy sorozatot, azt a regi reszek nem erdeklik
# -- a helyorzok viszont a VEGEN vannak.
ADD_PROBE = 3

# Napi ellenorzeskor legfeljebb ennyi FORRAS NELKULI (helyorzo) reszt
# probalunk sorozatonkent -- egy helyorzokkel teli evad kulonben sok
# keresest jelentene naponta. A forrassal rendelkezok NEM szamitanak bele:
# ha egy egesz uj evad egyszerre jelenik meg, azt egyben jelentjuk, nem
# napi haromasaval csopogtetve.
CHECK_PROBE = 3

MAX_ENTRIES = 100


# --- Tarolas ----------------------------------------------------------------

def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    '''{sorozat utvonal: bejegyzes}. Hibanal ures.'''
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'figyelt sorozatok írása', exc)
        return False


def entries():
    '''A bejegyzesek listaban, cim szerint rendezve.'''
    data = load()
    rows = []
    for path, entry in data.items():
        row = dict(entry)
        row['path'] = path
        rows.append(row)
    return sorted(rows, key=lambda row: (row.get('title') or '').lower())


def is_watched(path):
    return bool(path) and path in load()


def remove(path):
    data = load()
    if path in data:
        del data[path]
        return save(data)
    return False


def min_quality():
    """A beallitott kuszob; ha nincs vagy ismeretlen, az alapertelmezett."""
    value = (control.setting('minquality') or '').strip()
    return value if value in config.QUALITY_LADDER else config.QUALITY_MIN_DEFAULT


def is_good_quality(quality, minimum=None):
    """A letran eleri-e a kuszobot. Ures/ismeretlen cimke: NEM jo -- ovatosan."""
    ladder = [step.lower() for step in config.QUALITY_LADDER]
    text = (quality or '').strip().lower()
    if text not in ladder:
        return False
    minimum = (minimum or min_quality()).lower()
    return ladder.index(text) >= ladder.index(minimum)


def source_matches(entry, language, quality):
    """Egy forras teljesiti-e a figyeles felteteleit (nyelv es/vagy minoseg)."""
    want = entry.get('want') or ''
    if want and language != want:
        return False
    if entry.get('good_quality', True) and not is_good_quality(quality):
        return False
    return True


def add_film(path, title, thumb, want=u'Szinkron', good_quality=True, current=''):
    """
    Film figyelese. `want`: a kert hangsav ('' = barmilyen); `good_quality`:
    csak nem-gyenge minoseg szamit. A tipikus eset: van szinkron, de csak
    CAM -- akkor a jo minosegu szinkronra varunk.
    """
    data = load()
    data[path] = {
        'kind': 'film',
        'title': title or path,
        'thumb': thumb or '',
        'want': want,
        'good_quality': bool(good_quality),
        'current': current or '',
        'found': False,
        'seen': [],
        'new': [],
        'added': int(time.time()),
        'checked': int(time.time()),
        'failed': 0,
    }
    save(data)


def is_film(entry):
    return (entry or {}).get('kind') == 'film'


# --- "Varom": szolj, ha a film megjelenik a netmozin -----------------------------

APPEAR_PREFIX = 'imdb:'


def appear_key(imdb):
    return APPEAR_PREFIX + (imdb or '')


def is_appear(entry):
    return (entry or {}).get('kind') == 'appear'


def add_appear(imdb, title, thumb=''):
    """Egy meg nem elerheto film (IMDb-azonositoval) figyelese: ha felkerul, szolunk."""
    if not imdb:
        return False
    data = load()
    data[appear_key(imdb)] = {
        'kind': 'appear',
        'imdb': imdb,
        'title': title or imdb,
        'thumb': thumb or '',
        'found': '',
        'found_ncore': '',
        'new': [],
        'added': int(time.time()),
        'checked': 0,
        'failed': 0,
    }
    return save(data)


def is_awaited(imdb):
    return bool(imdb) and appear_key(imdb) in load()


def check_appear(entry, rows, now=None):
    """
    A netmozi keresojenek talalatai (IMDb-vel keresve) alapjan: True, ha
    MOST jelent meg. A talalat oldalat es boritojat elteszi.
    """
    entry['checked'] = int(now or time.time())
    entry['failed'] = 0
    if entry.get('found'):
        return False
    from resources.lib.modules import tmdb
    for row in rows or []:
        if tmdb.imdb_id(row.get('thumb', '')) == entry.get('imdb') and row.get('url'):
            entry['found'] = row['url']
            entry['thumb'] = row.get('thumb') or entry.get('thumb', '')
            grade = u', '.join(part for part in (row.get('quality'), (row.get('language') or '').lower()) if part)
            entry['new'] = [grade or u'megjelent']
            return True
    return False


def check_appear_ncore(entry, torrents, now=None):
    """
    Az nCore torrentjei (ncore.sources_for) alapjan: True, ha MOST jelent
    meg ott (elo torrent). A netmozi-figyeles kozben megy tovabb.
    """
    entry['checked'] = int(now or time.time())
    if entry.get('found_ncore'):
        return False
    live = [t for t in torrents or [] if t.get('seeders', 0) > 0]
    if not live:
        return False
    best = live[0]
    label = u', '.join(part for part in (best.get('resolution') or best.get('quality'),
                                        (best.get('language') or '').lower()) if part)
    entry['found_ncore'] = label or u'torrent'
    entry['new'] = (entry.get('new') or []) + [u'nCore: %s' % (label or u'torrent')]
    return True


def check_film(entry, sources, now=None):
    """
    Egy film ellenorzese: `sources` (nyelv, minoseg) parok. True, ha MOST
    jelent meg a felteteleknek megfelelo forras (es meg nem jeleztuk).
    """
    entry['checked'] = int(now or time.time())
    entry['failed'] = 0
    if entry.get('found'):
        return False
    for language, quality in sources or []:
        if source_matches(entry, language, quality):
            entry['found'] = True
            entry['new'] = [u'%s, %s' % (language or u'?', quality or u'?')]
            return True
    return False


def film_wants(entry):
    """Rovid felirat: mire var a film."""
    want = entry.get('want') or ''
    good = entry.get('good_quality', True)
    if want and good:
        return u'jó minőségű %s' % want.lower()
    if want:
        return want.lower()
    if good:
        return u'jobb minőség'
    return u'bármi'


def new_count():
    '''(uj reszek, megjott szinkronok) -- a fomenu jelzesehez. (A megjelentek: appeared_count.)'''
    episodes = dubs = 0
    for entry in load().values():
        fresh = len(entry.get('new') or [])
        if is_appear(entry):
            continue
        if is_film(entry):
            dubs += fresh
        else:
            episodes += fresh
    return episodes, dubs


def appeared_count():
    '''Hany vart film jelent meg (meg nem nyugtazva).'''
    return sum(1 for entry in load().values() if is_appear(entry) and entry.get('new'))


def new_summary():
    '''"2 uj resz, 1 szinkron, 1 megjelent" vagy ures.'''
    episodes, dubs = new_count()
    appeared = appeared_count()
    parts = []
    if episodes:
        parts.append(u'%d új rész' % episodes)
    if dubs:
        parts.append(u'%d szinkron' % dubs)
    if appeared:
        parts.append(u'%d megjelent' % appeared)
    return u', '.join(parts)


def clear_new(path):
    '''A sorozat megnyitasakor a jelzes lekerul rola.'''
    data = load()
    if path in data and data[path].get('new'):
        data[path]['new'] = []
        save(data)


# --- Reszek kulcsa ----------------------------------------------------------

def key(season, episode):
    return '%sx%s' % (int(season), int(episode))


def split_key(text):
    season, episode = text.split('x', 1)
    return int(season), int(episode)


def episode_path(base, text):
    '''"1x5" -> "<base>/s1/e5", ahogy az oldal cimzi a reszeket.'''
    season, episode = split_key(text)
    return '%s/s%d/e%d' % (base, season, episode)


def label(text):
    season, episode = split_key(text)
    return u'%d. évad %d. rész' % (season, episode)


def listed_episodes(html):
    '''
    A sorozat oldalan felsorolt osszes resz kulcsa, evad es resz szerint
    rendezve. Ugyanazokat a szelektorokat hasznalja, mint a lejatszasi lista.
    '''
    from resources.lib.modules import client   # lustan, lasd fent
    seasons = client.parseDOM(
        client.parseDOM(html or '', 'ul', attrs={'id': config.SEASON_LIST_ID}), 'a')
    keys = []
    for season in seasons:
        season_text = re.sub(r'<[^>]+>', '', season).strip()
        if not season_text.isdigit():
            continue
        episodes = client.parseDOM(
            client.parseDOM(html, 'ul',
                            attrs={'id': '%s%s' % (config.SEASON_LIST_ID, season_text)}),
            'a')
        for episode in episodes:
            episode_text = re.sub(r'<[^>]+>', '', episode).strip()
            if episode_text.isdigit():
                keys.append(key(season_text, episode_text))
    return sorted(set(keys), key=split_key)


# --- Felvetel es ellenorzes -------------------------------------------------

def add(path, title, thumb, listed, has_sources):
    '''
    Felvetel. `has_sources(kulcs)` az utolso ADD_PROBE reszre fut le; ami
    ott forras nelkulinek bizonyul, az fuggo marad, es a napi ellenorzes
    figyeli.
    '''
    data = load()
    tail = listed[-ADD_PROBE:] if ADD_PROBE else []
    pending = []
    for text in tail:
        try:
            if not has_sources(text):
                pending.append(text)
        except Exception as exc:
            control.log_exception(u'forrás ellenőrzése felvételkor', exc)
    seen = [text for text in listed if text not in pending]
    data[path] = {
        'title': title or path,
        'thumb': thumb or '',
        'seen': seen,
        'new': [],
        'added': int(time.time()),
        'checked': int(time.time()),
        'failed': 0,
    }
    if len(data) > MAX_ENTRIES:
        oldest = sorted(data, key=lambda k: data[k].get('added', 0))[:-MAX_ENTRIES]
        for old in oldest:
            del data[old]
    save(data)
    return pending


def due(now=None):
    '''Azok az utvonalak, amiket ideje ujra megnezni.'''
    now = now or time.time()
    out = []
    for path, entry in load().items():
        interval = RETRY_INTERVAL if entry.get('failed') else CHECK_INTERVAL
        if now - entry.get('checked', 0) >= interval:
            out.append(path)
    return out


def check_series(entry, listed, has_sources, now=None):
    '''
    Egy sorozat ellenorzese. A `listed` a friss felsorolas, a `has_sources`
    a fuggo reszekre fut le (legfeljebb CHECK_PROBE-ra).

    Visszaad: az UJ, forrassal rendelkezo reszek kulcsai. A bejegyzest
    helyben frissiti (seen, new, checked).
    '''
    seen = set(entry.get('seen') or [])
    fresh = []
    misses = 0
    for text in listed:
        if text in seen:
            continue
        if misses >= CHECK_PROBE:
            break
        try:
            available = bool(has_sources(text))
        except Exception as exc:
            control.log_exception(u'forrás ellenőrzése (%s)' % text, exc)
            available = False
        if available:
            seen.add(text)
            fresh.append(text)
        else:
            misses += 1
    entry['seen'] = sorted(seen, key=split_key)
    if fresh:
        entry['new'] = sorted(set((entry.get('new') or []) + fresh), key=split_key)
    entry['checked'] = int(now or time.time())
    entry['failed'] = 0
    return fresh


def mark_failed(entry, now=None):
    '''Halozati hiba: hamarabb ujrazunk, de nem azonnal.'''
    entry['failed'] = int(entry.get('failed') or 0) + 1
    entry['checked'] = int(now or time.time())
