# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Az adatlap hozzászólásainak kinyerése.
#
# A hozzászólások ugyanabban a HTML-ben érkeznek, amit a forráslista
# építéséhez amúgy is letöltünk, tehát a megjelenítésük nem jelent extra
# hálózati terhelést.

import json
import os
import re

# A client (requests) lustan: a hatterszolgaltatas is importalja ezt a
# modult a Kodi indulasakor, es neki csak a fajl-muveletek kellenek.
from resources.lib.modules import config, control

# Ennél többet nem tartunk meg: a lejátszás alatti listát úgysem görgeti
# végig senki, a memóriát viszont feleslegesen terhelné.
MAX_COMMENTS = 200


def _strip_tags(html):
    html = re.sub(r'<br\s*/?>', '\n', html, flags=re.I)
    html = re.sub(r'</p\s*>', '\n', html, flags=re.I)
    html = re.sub(r'<[^>]+>', '', html)
    from resources.lib.modules import client   # lustan
    text = client.replaceHTMLCodes(html)
    # A sortöréseket megtartjuk, a fölösleges szóközöket nem.
    lines = [re.sub(r'[ \t]+', ' ', line).strip() for line in text.splitlines()]
    return '\n'.join(line for line in lines if line).strip()


def parse(html):
    '''
    Az adatlap hozzászólásai, legfrissebb elöl.

    [{'date': '2026-08-22 11:33:49', 'user': '...', 'text': '...'}, ...]
    Ha nincs hozzászólás vagy nem értelmezhető a lap, üres lista.
    '''
    if not html:
        return []
    from resources.lib.modules import client   # lustan
    cards = [card for card in client.parseDOM(html, 'div',
                                              attrs={'class': config.COMMENT_CARD_CLASS})
             if config.COMMENT_CARD_MARKER in card]
    if not cards:
        control.log(u'Nincs hozzászólás-kártya az adatlapon', control.LOGDEBUG)
        return []

    entries = []
    for block in client.parseDOM(cards[0], config.COMMENT_ENTRY_TAG):
        heads = client.parseDOM(block, config.COMMENT_HEAD_TAG)
        head = heads[0] if heads else ''
        date = re.search(config.COMMENT_DATE_RE, head)
        users = client.parseDOM(head, 'a')
        # A fejlécet kivágjuk, ami marad, az a hozzászólás szövege.
        body = re.sub(r'<%s>.*?</%s>' % (config.COMMENT_HEAD_TAG, config.COMMENT_HEAD_TAG),
                      '', block, flags=re.S | re.I)
        text = _strip_tags(body)
        if not text:
            continue
        entries.append({
            'date': date.group(1) if date else '',
            'user': _strip_tags(users[0]) if users else '',
            'text': text,
        })
        if len(entries) >= MAX_COMMENTS:
            break

    control.log(u'Hozzászólások: %d db' % len(entries))
    return entries


# --- nCore: a torrent adatlapjanak hozzaszolasai -----------------------------
#
# Torrentenkent kulon oldal (torrents.php?action=details&id=...), a
# hozzaszolasok <div class="hsz_block"> blokkokban, legregebbi elol. A
# szoveg egymasba agyazott div-eket is tartalmazhat (idezet, spoiler,
# beagyazott elozetes), ezert nem a parseDOM-mal, hanem a blokk
# hatarolo elemei kozott vagjuk ki. A spoiler is latszik, jelolve.

NCORE_SOURCE = 'nCore'
NCORE_BLOCK = 'class="hsz_block"'
NCORE_BODY = 'class="hsz_jobb_comment">'
NCORE_BODY_END = ('<div class="hsz_jobb_edit_last"', '<div style="clear:both;">')
NCORE_DATE_RE = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'
NCORE_HIDDEN = '<div style="display: none;">'
SPOILER_MARK = u'Spoiler: '


def _cut_hidden(html):
    '''A rejtett (spoiler) div tartalma marad, csak egy "Spoiler:" jelzest kap (a felhasznalo kerte igy).'''
    return html.replace(NCORE_HIDDEN, '<div>' + SPOILER_MARK)


def parse_ncore(html):
    '''
    Egy nCore torrent adatlapjanak hozzaszolasai, legfrissebb elol, a
    netmozis bejegyzesekkel azonos alakban + 'source': 'nCore', 'votes'.
    '''
    if not html or NCORE_BLOCK not in html:
        return []
    entries = []
    for block in html.split(NCORE_BLOCK)[1:]:
        start = block.find(NCORE_BODY)
        if start < 0:
            continue
        head, body = block[:start], block[start + len(NCORE_BODY):]
        ends = [body.find(marker) for marker in NCORE_BODY_END]
        ends = [end for end in ends if end >= 0]
        if ends:
            body = body[:min(ends)]
        body = re.sub(r'<div[^>]*>\s*\.\.\. spoiler \.\.\.\s*</div>', '', body)
        body = re.sub(r'<a[^>]*>[^<]*Spoiler megjelen[^<]*</a>', '', body, flags=re.I)
        body = re.sub(r'<iframe.*?</iframe>', '', body, flags=re.S | re.I)
        text = _strip_tags(_cut_hidden(body))
        if not text:
            continue
        users = re.findall(r'profile\.php\?id=\d+"[^>]*>([^<]+)</a>', head)
        date = re.search(NCORE_DATE_RE, head)
        votes = re.search(r'id="hsz_pont_\d+">\s*<span[^>]*>\s*([+-]?\d+)', head)
        entries.append({
            'date': date.group(1) if date else '',
            'user': _strip_tags(users[0]) if users else '',
            'text': text,
            'source': NCORE_SOURCE,
            'votes': int(votes.group(1)) if votes else 0,
        })
    entries.reverse()
    control.log(u'nCore hozzászólások: %d db' % len(entries))
    return entries[:MAX_COMMENTS]


def merge_ncore(entries):
    '''Az nCore-os bejegyzesek a tarolt (netmozis) lista ele; a korabbi nCore-osak helyett.'''
    title, current = load()
    kept = [entry for entry in current if entry.get('source') != NCORE_SOURCE]
    return store((entries or []) + kept, title)


def format_line(entry):
    '''Egy hozzászólás egysoros fejléce a listához.'''
    who = entry.get('user') or u'ismeretlen'
    when = (entry.get('date') or '')[:16]
    tag = u'[COLOR gold]%s[/COLOR]  ' % entry['source'] if entry.get('source') else u''
    votes = entry.get('votes') or 0
    score = u'  [COLOR lime]+%d[/COLOR]' % votes if votes > 0 else u''
    return u'%s[B]%s[/B]  [COLOR gray]%s[/COLOR]%s' % (tag, who, when, score)


# --- Átadás a háttérszolgáltatásnak ----------------------------------------
#
# A hozzászólásokat a plugin nyeri ki (nála van az adatlap HTML-je), a
# megjelenítés viszont a szolgáltatás dolga -- külön folyamatban. A fájl
# köti össze a kettőt.

STORE_FILE = 'comments.json'


def _store_path():
    return os.path.join(control.dataPath, STORE_FILE)


def store(entries, title=''):
    """A most induló tartalom hozzászólásainak lerakása."""
    try:
        control.makeFile(control.dataPath)
        with open(_store_path(), 'w', encoding='utf-8') as handle:
            json.dump({'title': title, 'entries': entries or []}, handle,
                      ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'hozzászólások mentése', exc)
        return False


def load():
    """A legutóbb eltárolt hozzászólások. (cím, lista) pár."""
    try:
        with open(_store_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data.get('title', ''), data.get('entries', [])
    except (IOError, OSError, ValueError):
        return '', []


def clear():
    try:
        os.remove(_store_path())
    except OSError:
        pass


# --- Kérés a szolgáltatásnak: hozd vissza az átfedést ----------------------
#
# A plugin nem tud tartós ablakot nyitni, mert a hívás után kilép. Ezért
# csak jelez, a megjelenítést a végig futó szolgáltatás végzi.

REQUEST_FILE = 'comments.request'


def request_show():
    """Jelzés, hogy a néző visszakéri az átfedést."""
    try:
        control.makeFile(control.dataPath)
        with open(os.path.join(control.dataPath, REQUEST_FILE), 'w') as handle:
            handle.write('1')
        return True
    except (IOError, OSError) as exc:
        control.log_exception(u'átfedés-kérés írása', exc)
        return False


def take_request():
    """True, ha volt kérés -- egyben el is veszi."""
    path = os.path.join(control.dataPath, REQUEST_FILE)
    if not os.path.exists(path):
        return False
    try:
        os.remove(path)
    except OSError:
        pass
    return True
