# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A boritos kezdokepernyo ADATAI -- sorok, bennuk tetelek.
#
# Ket fajta sor van:
#   - helyi:    Folytatas, Amit mar lattam, Figyelt sorozatok. Csak JSON-t
#               olvasnak, azonnal megvannak.
#   - halozati: Ajanlo, Felkapottak, Filmek, Sorozatok, Stream Top. Egy-egy
#               oldalletoltes, gyorsitotarral (CACHE_HOURS): a kepernyo
#               azonnal nyilik a regi adattal, a friss a hatterben jon.
#
# Minden tetel egyforma alaku, hogy az ablak ne tudjon semmit a forrasrol:
#   {'label', 'sub', 'thumb', 'mode', 'query', 'context'}
#   mode:  'play' -> RunPlugin (lejatszas, dialogus)
#          'open' -> ActivateWindow(Videos, ...) (lista nyilik a kepernyo fole)
#          'builtin' -> a query maga a Kodi-parancs
#   context: [(felirat, mode, query)] a hosszan nyomashoz

import os
import time
from datetime import date
from urllib.parse import quote_plus

from resources.lib.modules import config, control


CACHE_HOURS = 1
ROW_LIMIT = 30

# Biztonsagi szelep: a jelzofajl a kepernyo megnyitasakor jon letre, es par
# masodperc stabil futas utan torlodik. Ha a kovetkezo indulaskor meg ott
# van, az elozo megnyitas kozben akadt el a Kodi -> akkor a boritos
# kepernyo kimarad, es szolunk. Ne legyen indulasi hurok.
GUARD_FILE = 'home.opening'
GUARD_SECONDS = 5


def _guard_path():
    import os
    return os.path.join(control.dataPath, GUARD_FILE)


def guard_tripped():
    import os
    return os.path.exists(_guard_path())


def guard_set():
    import time
    try:
        control.makeFile(control.dataPath)
        with open(_guard_path(), 'w') as handle:
            handle.write(str(int(time.time())))
    except (IOError, OSError):
        pass


def guard_clear():
    import os
    try:
        os.remove(_guard_path())
    except OSError:
        pass

# (kulcs, cim) -- ebben a sorrendben jelennek meg. A kulcs egyben a lista
# control azonositojanak alapja (lasd homewindow).
ROWS = (
    ('continue', u'Folytatás'),
    ('recommended', u'Ajánló'),
    ('trending', u'Felkapottak'),
    ('movies', u'Filmek \u2013 legújabb'),
    ('series', u'Sorozatok \u2013 legújabb'),
    ('history', u'Amit már láttam'),
    ('watch', u'Figyelt sorozatok'),
    ('netflix', u'Netflix Top'),
    ('apple', u'Apple Top'),
    ('prime', u'Prime Top'),
    ('disney', u'Disney+ Top'),
    ('hbomax', u'HBO Max Top'),
    ('skyshowtime', u'SkyShowtime Top'),
    ('upcoming', u'Hamarosan a mozikban'),
)
LOCAL_ROWS = ('continue', 'history', 'watch')
# A szolgaltato-sorok (providers.py: hivatalos top lista / TMDB): helyi
# JSON-bol, azonnal. A Netflix/Apple/Prime sornal, ha ez ures, a netmozi
# sajat Stream Top-ja jon (STREAM_ROWS).
PROVIDER_ROWS = tuple(key for key, _title, _service, _pid in config.PROVIDER_ROWS)

# Stream-sorok: sor kulcsa -> a streams.PROVIDERS kulcsai (az Apple ket
# listaja -- filmek, sorozatok -- egy sorba kerul).
STREAM_ROWS = (
    ('netflix', ('netflix',)),
    ('apple', ('applemovies', 'appleshows')),
    ('prime', ('prime',)),
)

# A netmozi rendezesei -- a lista-oldal valaszto ertekei (elo fixture-bol).
ORDER_NEWEST_LINKS = '5'
ORDER_MOST_VIEWED = '6'

# --- Mese-profil ---------------------------------------------------------------
#
# A mese-profilban MINDENUTT (sorok, kereso, bongeszo, Mit nezzek, a
# szolgaltato-sorok) csak az a cim latszik, amelynek a netmozi-kategoriai
# kozt van Animacio vagy Csaladi, es nincs koztuk felnottes (horror,
# thriller...). A netmozi minden listasoraban ott vannak a kategoriak, igy
# ez keres nelkul, biztosan eldol. Inkabb hianyozzon egy mese, mint hogy
# bekeruljon, ami nem gyereknek valo.
KIDS_INCLUDE = (u'Animáció', u'Családi')
KIDS_EXCLUDE = (u'Horror', u'Thriller', u'Bűnügyi', u'Háborús', u'Erotikus')
KIDS_GENRES = ('Animation', 'Family')            # a netmozi urlapjanak ertekei
# A mese-profil sorai ugyanazokban a helyekben (ROWS), mas cimmel es tartalommal.
KIDS_TITLES = {
    'recommended': u'Mesék – legújabb',
    'trending': u'Felkapott mesék',
    'movies': u'Családi filmek',
    'series': u'Mesesorozatok',
}
KIDS_TITLES.update((key, title) for key, title, _pid in config.KIDS_PROVIDERS)


def kids_mode():
    from resources.lib.modules import profiles
    try:
        return profiles.kids_active()
    except Exception:
        return False


def kids_ok(categories):
    '''Mese-jellegu-e (a kategoriak szerint).'''
    cats = set(categories or [])
    return bool(cats & set(KIDS_INCLUDE)) and not (cats & set(KIDS_EXCLUDE))


def kids_filter(rows, kids=None, network=True):
    '''
    A listasorok kozul csak a mese-jelleguek, ha mese-profil van; kulonben
    mind. Ket lepcso: a netmozi kategoriai (Animacio / Csaladi, felnottes
    nelkul), aztan az IMDb korhatara es mufaja (imdb.kid_safe) -- a South
    Park-fele "Animacio, Vigjatek" itt esik ki. Az IMDb-ellenorzes tarolva;
    network nelkul csak a mar ismertek maradnak.
    '''
    if not (kids_mode() if kids is None else kids):
        return list(rows or [])
    from resources.lib.modules import imdb as imdb_mod, tmdb
    passed = [row for row in (rows or []) if kids_ok(row.get('categories'))]
    ids = [tmdb.imdb_id(row.get('thumb', '')) for row in passed]
    safe = imdb_mod.kids_check([imdb for imdb in ids if imdb], network=network)
    return [row for row, imdb in zip(passed, ids) if imdb and safe.get(imdb)]


def catalog_item(cand):
    '''
    Egy mese-sor cime, ami NINCS a netmozin (TMDB-poszter, IMDb-azonosito):
    nCore-rol indithato, ha az be van allitva; kulonben "Varom".
    '''
    from resources.lib.modules import ncore
    imdb, title, thumb = cand.get('imdb', ''), cand.get('title', ''), cand.get('thumb', '')
    tail = 'imdb=%s&title=%s&thumb=%s' % (imdb, quote_plus(title), quote_plus(thumb))
    if ncore.enabled():
        return item(title, thumb, 'play', 'ncoreplayimdb&' + tail, sub=u'nCore',
                    sub2=u'sorozat' if cand.get('kind') == 'tv' else u'', imdb=imdb,
                    context=[(u'Várom: szólj, ha megjelenik a netmozin', 'play', 'watchappear&' + tail)])
    return item(title, thumb, 'play', 'watchappear&' + tail, sub=u'nincs a netmozin',
                sub2=u'sorozat' if cand.get('kind') == 'tv' else u'', imdb=imdb)


def row_titles(kids=None):
    '''{sor kulcsa: cim} -- a mese-profilban mas cimek.'''
    titles = dict(ROWS)
    if kids_mode() if kids is None else kids:
        titles.update(KIDS_TITLES)
    return titles


TOP_BAR = (
    (u'Keresés', 'open', 'newsearch'),
    (u'Mit nézzek?', 'open', 'tonight'),
    (u'Filmek', 'open', 'base&type=1'),
    (u'Sorozatok', 'open', 'base&type=2'),
    (u'Beállítások', 'builtin', 'Addon.OpenSettings(%s)'),
    (u'Frissítés', 'play', 'updatecheck'),
    (u'Régi menü', 'open', 'classic'),
)


def item(label, thumb='', mode='play', query='', sub=u'', context=None, sub2=u'', imdb=''):
    '''
    sub:  a cim alatti sor -- a minoseg es a hang ("DVD, szinkron").
    sub2: minden mas info (perc, evad/resz, ev, mufaj, datum) -- a
          reszletezo mutatja.
    imdb: a cim IMDb-azonositoja, ha a boritobol nem derul ki (pl. IMDb-s
          poszter a Hamarosan sorban) -- az elozeteshez es az adatokhoz.
    '''
    return {'label': label or u'', 'sub': sub or u'', 'sub2': sub2 or u'', 'thumb': thumb or '',
            'mode': mode, 'query': query, 'context': list(context or []),
            'imdb': imdb or '', 'badge': u'', 'badgekind': u''}


def new_badges():
    '''
    {sorozat/film utvonal: felirat} a figyelt listabol: "UJ RESZ" / "2 UJ RESZ"
    (sorozat), "SZINKRON" (film, megjott a vart hang/minoseg), "MEGJELENT"
    (vart film, felkerult). A boritora kerul, szalagkent.
    '''
    from resources.lib.modules import watchlist
    out = {}
    for path, entry in watchlist.load().items():
        fresh = entry.get('new') or []
        if not fresh:
            continue
        if watchlist.is_appear(entry):
            out[path] = u'MEGJELENT'
        elif watchlist.is_film(entry):
            out[path] = u'SZINKRON'
        else:
            out[path] = u'ÚJ RÉSZ' if len(fresh) == 1 else u'%d ÚJ RÉSZ' % len(fresh)
    return out


def mark_new(rows, badges=None):
    '''A sorok teteleire rateszi a jelzest (badge), ha a figyelt listan uj van rajta.'''
    badges = new_badges() if badges is None else badges
    if not badges:
        return rows
    for entries in (rows or {}).values():
        for entry in entries or []:
            query = entry.get('query') or ''
            page = _page_of(query)
            key = page
            if query.startswith('watchremove&url=imdb:') or query.startswith('ncoreplayimdb'):
                key = 'imdb:' + (entry.get('imdb') or '')
            elif not page and entry.get('imdb'):
                key = 'imdb:' + entry['imdb']
            label = badges.get(key) or badges.get('imdb:' + (entry.get('imdb') or ''))
            if label:
                entry['badge'] = label
                entry['badgekind'] = u''             # a piros (uj) elsobb a kek visszaszamlalasnal
    return rows


RUNNING_BADGE = u'Új részek'


def aired_missing(watch_entry, record, today=None):
    '''
    A TMDB szerint a legutobbi resz mar kijott (2 heten belul), de a
    figyelt bejegyzes meg nem latta a netmozin (se a "seen", se a "new"
    listaban nincs): ilyenkor "hamarosan" -- es surubben nezzuk.
    '''
    record = record or {}
    season, episode = record.get('last_season') or 0, record.get('last_episode') or 0
    if not (season and episode) or not watch_entry:
        return False
    days = days_until(record.get('last_date'), today)
    if days is None or not (-AIRED_GRACE_DAYS <= days <= 0):
        return False
    key = '%dx%d' % (season, episode)
    return key not in (watch_entry.get('seen') or []) and key not in (watch_entry.get('new') or [])


SOON_BADGE = u'Új rész: hamarosan'


def badge_for(entry, records, watched, today=None):
    '''
    (szalag, fajta) egy tetelre a TMDB szerint: ha a sorozatnak van bejelentett
    kovetkezo resze (fut), a figyelt sorozaton kek visszaszamlalas
    ("Új rész: 5 nap", 'soon'), masutt sarga "Új részek" ('running').
    Ha a legutobbi resz mar kijott, de a netmozin meg nincs: "Új rész:
    hamarosan" (ehhez a watched a figyelt lista dict-je legyen).
    ('', '') ha nincs mit, vagy mar van rajta piros szalag.
    '''
    if entry.get('badge'):
        return entry['badge'], entry.get('badgekind') or u''
    imdb = imdb_of(entry)
    if not imdb:
        return u'', u''
    record = (records or {}).get(imdb) or {}
    page = _page_of(entry.get('query') or '')
    keys = [key for key in (page, 'imdb:' + imdb) if key in watched]
    if keys and isinstance(watched, dict) and aired_missing(watched.get(keys[0]), record, today):
        return SOON_BADGE, u'soon'
    days = days_until(record.get('next_date'), today)
    if days is None or days < -AIRED_GRACE_DAYS:
        return u'', u''
    if keys:
        return next_episode_badge(record, today), u'soon'
    return (RUNNING_BADGE, u'running') if days >= 0 else (u'', u'')


def mark_running(rows, records=None, watched=None, today=None):
    '''
    Minden sorra (es a racsok teteleire): a futo sorozatokra sarga "Új részek",
    a figyeltekre kek visszaszamlalas. A piros (uj / szinkron) elsobb.
    '''
    from resources.lib.modules import tmdb, watchlist
    records = tmdb.load() if records is None else records
    watched = watchlist.load() if watched is None else watched
    for entries in (rows or {}).values():
        for entry in entries or []:
            badge, kind = badge_for(entry, records, watched, today)
            if badge:
                entry['badge'], entry['badgekind'] = badge, kind
    return rows


mark_soon = mark_running


def imdb_of(entry):
    '''A tetel IMDb-azonositoja: a mezobol, vagy a netmozi boritojabol.'''
    from resources.lib.modules import tmdb
    return (entry or {}).get('imdb') or tmdb.imdb_id((entry or {}).get('thumb') or '')


def title_info(imdb, cached_only=False):
    '''
    Egy cim osszevont adatai: az IMDb (kulcs nelkul) + a TMDB (ha van
    kulcs). None, ha cached_only es meg semmit nem tudunk; kulonben dict:
      backdrop (TMDB-e, kulonben IMDb allokep), overview (TMDB magyar,
      kulonben IMDb angol), genres, year, runtime, rating, votes, services
      (TMDB), title.
    '''
    from resources.lib.modules import imdb as imdb_mod, tmdb
    if not imdb:
        return {} if not cached_only else None
    rec_i = imdb_mod.cached(imdb)
    rec_t = tmdb.cached(imdb)
    if not cached_only:
        if rec_i is None:
            rec_i = imdb_mod.fetch(imdb)
        if (rec_t is None or not tmdb.has_details(rec_t)) and tmdb.api_key():
            rec_t = tmdb.fetch(imdb) or rec_t
    if rec_i is None and rec_t is None:
        return None if cached_only else {}
    # "complete": minden forras valaszolt, amit kerdezhetunk (a "nincs" is valasz).
    complete = rec_i is not None and (rec_t is not None or not tmdb.api_key())
    rec_i, rec_t = rec_i or {}, rec_t or {}
    return {
        'title': rec_i.get('title') or u'',
        'backdrop': rec_t.get('backdrop') or rec_i.get('backdrop') or '',
        'overview': rec_t.get('overview') or rec_i.get('plot') or u'',
        'genres': rec_t.get('genres') or rec_i.get('genres') or [],
        'year': rec_t.get('year') or rec_i.get('year') or '',
        'runtime': rec_t.get('runtime') or rec_i.get('runtime') or 0,
        'seasons': rec_t.get('seasons') or 0,
        'rating': rec_i.get('rating') or 0.0,
        'votes': rec_i.get('votes') or 0,
        'services': rec_t.get('services') or [],
        'status': rec_t.get('status') or '',
        'next_date': rec_t.get('next_date') or '',
        'next_season': rec_t.get('next_season') or 0,
        'next_episode': rec_t.get('next_episode') or 0,
        'complete': complete,
    }


# --- Futo sorozat: mikor jon a kovetkezo resz ----------------------------------

def days_until(date_text, today=None):
    '''Hany nap van a datumig (YYYY-MM-DD); None, ha nincs / ertelmetlen.'''
    if not date_text:
        return None
    try:
        target = date(int(date_text[:4]), int(date_text[5:7]), int(date_text[8:10]))
    except (TypeError, ValueError):
        return None
    return (target - (today or date.today())).days


AIRED_GRACE_DAYS = 14           # a bejelentett nap utan ennyi napig "hamarosan" (amig a netmozin meg nincs)


def countdown(days):
    '''"ma" / "holnap" / "3 nap"; a bejelentett nap utan "hamarosan" (a netmozin meg nincs); '' ha nincs / reg volt.'''
    if days is None or days < -AIRED_GRACE_DAYS:
        return u''
    if days < 0:
        return u'hamarosan'
    if days == 0:
        return u'ma'
    if days == 1:
        return u'holnap'
    return u'%d nap' % days


def next_episode_badge(record, today=None):
    '''A szalag a boritora: "Új rész: 5 nap" / "Új rész: holnap" / "Új rész: ma"; '' ha nincs mit.'''
    short = countdown(days_until((record or {}).get('next_date'), today))
    return (u'Új rész: %s' % short) if short else u''


def next_episode_label(record, today=None, pending=False):
    '''
    (rovid, hosszu): "új rész: 3 nap" a reszletezo rovid cimkeje, es "új rész
    3 nap múlva (2. évad 5. rész, 09. 18.)" a reszletezobe; ('', '') ha nincs mit.
    '''
    record = record or {}
    if pending:
        where = u''
        if record.get('last_season') and record.get('last_episode'):
            where = u'%d. évad %d. rész, ' % (record['last_season'], record['last_episode'])
        text = record.get('last_date') or ''
        stamp = u'%s. %s.' % (text[5:7], text[8:10]) if len(text) >= 10 else u''
        return u'új rész: hamarosan', u'új rész már megjelent (%s%s), a netmozin hamarosan' % (where, stamp)
    days = days_until(record.get('next_date'), today)
    short = countdown(days)
    if not short:
        return u'', u''
    when = (u'már megjelent, a netmozin hamarosan' if days < 0 else
            short if days == 0 else (u'holnap' if days == 1 else u'%s múlva' % short))
    where = u''
    if record.get('next_season') and record.get('next_episode'):
        where = u'%d. évad %d. rész, ' % (record['next_season'], record['next_episode'])
    text = record.get('next_date') or ''
    stamp = u'%s. %s.' % (text[5:7], text[8:10]) if len(text) >= 10 else u''
    return u'új rész: %s' % short, u'új rész %s (%s%s)' % (when, where, stamp)


def aired_watched(rows=None, records=None, today=None):
    '''
    A figyelt sorozatok, amelyeknek a bejelentett resze mar kijott, de a
    netmozin meg nem talaltuk (nincs rajtuk "uj"): ezeket surubben nezzuk.
    [oldal-utvonal]
    '''
    from resources.lib.modules import tmdb, watchlist
    records = tmdb.load() if records is None else records
    out = []
    for path, entry in watchlist.load().items():
        if watchlist.is_film(entry) or watchlist.is_appear(entry) or entry.get('new'):
            continue
        imdb = tmdb.imdb_id(entry.get('thumb') or '')
        record = (records.get(imdb) or {}) if imdb else {}
        days = days_until(record.get('next_date'), today)
        if (days is not None and -AIRED_GRACE_DAYS <= days < 0) or aired_missing(entry, record, today):
            out.append(path)
    return out


NEXT_REFRESH_MAX = 60           # a nem figyelt sorok sorozataibol ennyit frissitunk egy menetben


def refresh_next_episodes(rows, stop=None, force=False):
    '''
    A figyelt (es folytatott) sorozatok kovetkezo reszenek datuma a TMDB-tol
    (a hatterszal hivja). True, ha barmelyik frissult -> a helyi sorok ujra.
    '''
    from resources.lib.modules import tmdb
    if not tmdb.api_key():
        return False
    changed = False
    seen = set()
    budget = NEXT_REFRESH_MAX
    # Elobb a figyelt es a folytatott sorozatok (ezekre a visszaszamlalas),
    # aztan a tobbi sor sorozatai (a sarga "Új részek" miatt), keretre.
    others = [key for key, _title in ROWS if key not in ('watch', 'continue')]
    for key in ('watch', 'continue') + tuple(others):
        priority = key in ('watch', 'continue')
        for entry in (rows or {}).get(key) or []:
            if stop and stop():
                return changed
            imdb = imdb_of(entry)
            if not imdb or imdb in seen or entry.get('mode') != 'open' and 'series' not in (entry.get('query') or ''):
                continue
            seen.add(imdb)
            try:
                if tmdb.cached(imdb) is None:
                    if not priority:
                        continue                      # a boritok elolekerese hozza majd
                    tmdb.fetch(imdb)
                if not priority and budget <= 0:
                    continue
                fresh = tmdb.refresh_next(imdb, force=force and priority)
                if fresh:
                    changed = True
                    if not priority:
                        budget -= 1
                    time.sleep(config.TMDB_PREFETCH_PAUSE)
            except Exception as exc:
                control.log_exception(u'következő rész (%s)' % imdb, exc)
    return changed


def listing_info(row):
    '''"2026 · Horror, Thriller" egy listasorbol.'''
    parts = []
    if row.get('year'):
        parts.append(str(row['year']))
    cats = row.get('categories') or []
    if cats:
        parts.append(u', '.join(cats[:2]))
    return u' · '.join(parts)


def film_context(url):
    return [(u'Források', 'play', 'sources&url=%s' % url),
            (u'Szólj, ha lesz jó minőségű szinkron', 'play', 'watchdub&url=%s&mode=dub' % url),
            (u'Szólj, ha jobb minőség jön', 'play', 'watchdub&url=%s&mode=quality' % url)]


def series_context(url, watched):
    if watched:
        return [(u'Figyelés megszüntetése', 'play', 'watchremove&url=%s' % url)]
    return [(u'Figyelés (új részek jelzése)', 'play', 'watchadd&url=%s' % url)]


def from_listing(row, watched=frozenset()):
    '''Egy netmozi listasorbol tetel: film indul, sorozat az evadokra visz.'''
    from resources.lib.modules import listing
    grade = listing.grade_of(row)
    if row.get('isSeries'):
        return item(row['title'], row.get('thumb'), 'open',
                    'series&url=%s&auto=1' % row['url'],
                    sub=grade, sub2=u'sorozat · %s' % listing_info(row),
                    context=series_context(row['url'], row['url'] in watched))
    return item(row['title'], row.get('thumb'), 'play', 'playdirect&url=%s' % row['url'],
                sub=grade, sub2=listing_info(row), context=film_context(row['url']))


# --- Helyi sorok ---------------------------------------------------------------

def _grade_of_page(page, by_page):
    '''"DVD, szinkron" az elozmeny-bejegyzesbol (a bevalt forras), vagy ures.'''
    entry = by_page.get(page) or {}
    return u', '.join(part for part in (entry.get('quality'),
                                        (entry.get('language') or '').lower()) if part)


def continue_row():
    from resources.lib.modules import history, progress
    by_page = dict((e.get('page'), e) for e in history.load())
    out = []
    for entry in progress.entries():
        title = entry.get('title')
        if not title:
            # Csak "betervezett", soha el nem indult tetel (nincs cime, boritoja).
            continue
        if progress.is_film(entry):
            seconds = progress.resume_seconds(entry)
            if not seconds:
                continue
            out.append(item(title, entry.get('thumb'), 'play',
                            'playdirect&url=%s' % entry['base'],
                            sub=_grade_of_page(entry['base'], by_page),
                            sub2=u'%d. perctől' % (seconds // 60),
                            context=[(u'Törlés a folytatásból', 'play',
                                      'continueremove&url=%s' % entry['base'])]))
        else:
            # Rovid felirat, hogy elferjen a borito alatt: "1. evad 9. resz",
            # felbehagyottnal "1. evad 9. resz, 58'".
            if progress.finished(entry):
                if entry.get('next_page', None) == '':
                    # Az utolso elerheto reszt is vegignezte, es tudjuk, hogy nincs
                    # tobb: nincs mit folytatni (az Amit mar lattam sorban marad;
                    # ha uj resz jon, a figyeles jelzi).
                    continue
                nxt = progress.split_page(entry.get('next_page') or '')
                sub = (u'%d. évad %d. rész' % (nxt[1], nxt[2]) if nxt
                       else u'%d. évad %d. rész után' % (entry.get('season', 0), entry.get('episode', 0)))
            else:
                seconds = progress.resume_seconds(entry)
                sub = u'%d. évad %d. rész%s' % (entry.get('season', 0), entry.get('episode', 0),
                                                 u", %d'" % (seconds // 60) if seconds else u'')
            out.append(item(title, entry.get('thumb'), 'play',
                            'continueseries&url=%s' % entry['base'],
                            sub=_grade_of_page(entry.get('page', ''), by_page), sub2=sub,
                            context=[(u'Évadok', 'open', 'series&url=%s&auto=1' % entry['base']),
                                     (u'Törlés a folytatásból', 'play',
                                      'continueremove&url=%s' % entry['base'])]))
        if len(out) >= ROW_LIMIT:
            break
    return out


def _date(stamp):
    import time as _time
    try:
        return _time.strftime('%Y. %m. %d.', _time.localtime(int(stamp)))
    except (TypeError, ValueError, OverflowError):
        return u''


def history_row():
    from resources.lib.modules import history, progress
    out = []
    known = set()
    for entry in history.load():
        page = entry.get('page', '')
        parts = progress.split_page(page)
        if parts:
            if parts[0] in known:
                continue
            known.add(parts[0])
            grade = u', '.join(part for part in (entry.get('quality'),
                                                 (entry.get('language') or '').lower()) if part)
            out.append(item(entry.get('title'), entry.get('thumb'), 'play',
                            'continueseries&url=%s' % parts[0],
                            sub=grade, sub2=u'sorozat',
                            context=[(u'Évadok', 'open', 'series&url=%s&auto=1' % parts[0])]))
        else:
            grade = u', '.join(part for part in (entry.get('quality'),
                                                 (entry.get('language') or '').lower()) if part)
            out.append(item(entry.get('title'), entry.get('thumb'), 'play',
                            'historyplay&url=%s' % page, sub=grade, sub2=_date(entry.get('time')),
                            context=[(u'Törlés a listából', 'play', 'historyremove&url=%s' % page)]
                            + film_context(page)))
        if len(out) >= ROW_LIMIT:
            break
    return out


def appear_context(imdb):
    return [(u'Már nem várom', 'play', 'watchremove&url=%s' % ('imdb:' + imdb))]


def watch_row():
    from resources.lib.modules import watchlist
    out = []
    for entry in watchlist.entries():
        fresh = entry.get('new') or []
        if watchlist.is_appear(entry):
            imdb = entry.get('imdb', '')
            if entry.get('found'):
                # watchopen: a film indul, es a "varom" bejegyzes (a jelzessel) lekerul.
                out.append(item(entry.get('title'), entry.get('thumb'), 'play',
                                'watchopen&url=%s' % entry['path'],
                                sub=fresh[0] if fresh else u'', sub2=u'megjelent a netmozin!',
                                context=appear_context(imdb) + film_context(entry['found']), imdb=imdb))
            elif entry.get('found_ncore'):
                out.append(item(entry.get('title'), entry.get('thumb'), 'play',
                                'ncoreplayimdb&imdb=%s&title=%s&thumb=%s' % (
                                    imdb, quote_plus(entry.get('title') or ''), quote_plus(entry.get('thumb') or '')),
                                sub=u'nCore: %s' % entry['found_ncore'], sub2=u'megjelent az nCore-on!',
                                context=appear_context(imdb), imdb=imdb))
            else:
                out.append(item(entry.get('title'), entry.get('thumb'), 'play',
                                'watchremove&url=%s' % ('imdb:' + imdb),
                                sub=u'', sub2=u'várod: szólok, ha megjelenik',
                                context=appear_context(imdb), imdb=imdb))
            continue
        if watchlist.is_film(entry):
            sub = (u'megjött: %s' % fresh[0]) if fresh else u'szinkronra vár'
        elif fresh:
            sub = u'új: %s' % watchlist.label(fresh[0])
        else:
            sub = u'figyelve'
        current = (entry.get('current') or u'') if watchlist.is_film(entry) else u''
        row = item(entry.get('title'), entry.get('thumb'), 'open',
                   'watchopen&url=%s' % entry['path'], sub=current, sub2=sub,
                   context=[(u'Figyelés megszüntetése', 'play',
                             'watchremove&url=%s' % entry['path'])])
        out.append(row)                              # a visszaszamlalo szalagot a mark_soon teszi ra
    return out[:ROW_LIMIT]


def local_rows():
    '''{kulcs: [tetel]} a helyi sorokra -- halozat nelkul, azonnal.'''
    return {'continue': continue_row(), 'history': history_row(), 'watch': watch_row()}


# --- Halozati sorok ------------------------------------------------------------

def _list_url(tipus, order, year=None, page=1):
    url = config.LIST_URL % (config.BASE_URL, page, tipus, order, '')
    if year:
        url += config.YEAR_FILTER % (year, year)
    return url


def fetch_listing(url, tipus=''):
    '''cache.get() hivja: None = hiba (marad a regi ertek).'''
    from resources.lib.modules import client, listing
    html = client.request(url)
    if not html:
        return None
    rows = listing.parse_rows(html, tipus)
    return rows or None


def fetch_upcoming():
    '''cache.get() hivja: a hamarosan bemutatott filmek (IMDb). None = hiba.'''
    from resources.lib.modules import imdb as imdb_mod
    return imdb_mod.upcoming() or None


def upcoming_row(cached_only=False):
    '''
    "Hamarosan a mozikban": IMDb-s poszterrel; OK -> reszletezo elozetessel,
    a gomb: "Varom" (szolj, ha megjelenik a netmozin).
    '''
    from resources.lib.modules import cache, watchlist
    rows = (cache.peek(fetch_upcoming) if cached_only
            else cache.get(fetch_upcoming, config.CACHE_HOURS_UPCOMING)) or []
    out = []
    for row in rows[:ROW_LIMIT]:
        imdb = row.get('imdb', '')
        awaited = watchlist.is_awaited(imdb)
        query = ('watchremove&url=imdb:%s' % imdb) if awaited else (
            'watchappear&imdb=%s&title=%s&thumb=%s' % (imdb, quote_plus(row.get('title', '')),
                                                       quote_plus(row.get('poster', ''))))
        out.append(item(row.get('title'), row.get('poster'), 'play', query,
                        sub=row.get('date') or u'', sub2=u'várod' if awaited else u'hamarosan a mozikban',
                        context=appear_context(imdb) if awaited else [], imdb=imdb))
    return out


def fetch_provider(key):
    '''Egy szolgaltato top listaja. cache.get() hivja; None = hiba.'''
    from resources.lib.modules import streams
    provider = streams.PROVIDER_BY_KEY.get(key)
    if not provider:
        return None
    data = streams.fetch(key)
    out = []
    for row in (data or {}).get('rows') or []:
        if row.get('title'):
            out.append({'title': row['title'], 'thumb': row.get('poster') or row.get('thumb', ''),
                        'tag': provider['short']})
    return out or None


def network_rows(cached_only=False, force=False):
    '''
    {kulcs: [tetel]} a halozati sorokra. cached_only: csak ami a
    gyorsitotarban van (azonnali), halozat nelkul.
    '''
    from resources.lib.modules import cache, streamcheck, watchlist
    watched = frozenset(watchlist.load())
    year = date.today().year
    kids = kids_mode()
    if kids:
        # Mese-profil: animacio / csaladi listak ugyanazokba a sorokba.
        sources = {
            'recommended': (fetch_listing, genre_url('Animation', order=ORDER_NEWEST_LINKS, tipus='1'), '1'),
            'trending': (fetch_listing, genre_url('Animation', order=ORDER_MOST_VIEWED, tipus='1'), '1'),
            'movies': (fetch_listing, genre_url('Family', order=ORDER_NEWEST_LINKS, tipus='1'), '1'),
            'series': (fetch_listing, genre_url('Animation', order=ORDER_NEWEST_LINKS, tipus='2'), '2'),
        }
    else:
        sources = {
            'recommended': (fetch_listing, config.RECOMMENDED_URL % (config.BASE_URL, '1'), ''),
            'trending': (fetch_listing, _list_url('1', ORDER_MOST_VIEWED, year), '1'),
            'movies': (fetch_listing, _list_url('1', ORDER_NEWEST_LINKS), '1'),
            'series': (fetch_listing, _list_url('2', ORDER_NEWEST_LINKS), '2'),
        }
    out = {}
    hours = 0 if force else CACHE_HOURS               # force: a tarat kihagyva, frissen
    for key, (function, url, tipus) in sources.items():
        rows = (cache.peek(function, url, tipus) if cached_only
                else cache.get(function, hours, url, tipus)) or []
        rows = kids_filter(rows, kids, network=not cached_only)
        if kids and key == 'movies':
            # A Csaladi sorban ne az animaciok ismetlodjenek (azok a Mesek sorban vannak).
            rows = [row for row in rows if KIDS_INCLUDE[0] not in (row.get('categories') or [])]
        out[key] = [from_listing(row, watched) for row in rows[:ROW_LIMIT]]

    from resources.lib.modules import providers
    provider_rows = providers.rows()
    known = streamcheck.load()
    for row_key, provider_keys in STREAM_ROWS:
        if provider_rows.get(row_key):
            continue                                 # a hivatalos lista van (lent)
        if kids:
            out[row_key] = []                        # a Stream Top-nak nincs kategoriaja: mese-profilban nincs
            continue
        rows = []
        for key in provider_keys:
            rows += (cache.peek(fetch_provider, key) if cached_only
                     else cache.get(fetch_provider, config.CACHE_HOURS_NETFLIX, key)) or []
        items = []
        for row in rows[:ROW_LIMIT]:
            entry = streamcheck.status(row['title'], known)
            # CSAK az, ami megvan a netmozin. A nincs, es a meg nem
            # ellenorzott nem jelenik meg; amint a napi ellenorzes
            # megtalalja, bekerul.
            if not (entry and entry.get('url')
                    and entry.get('status') in (streamcheck.FILM, streamcheck.SERIES)):
                continue
            grade = u', '.join(part for part in (entry.get('quality'),
                                                 (entry.get('language') or '').lower()) if part)
            if entry['status'] == streamcheck.SERIES:
                mode, query = 'open', 'series&url=%s&auto=1' % entry['url']
            else:
                mode, query = 'play', 'playdirect&url=%s' % entry['url']
            # Az Apple soraban a masodik infoban latszik, melyik lista (film / sorozat).
            tag = row.get('tag', u'') if len(provider_keys) > 1 else u''
            items.append(item(row['title'], row.get('thumb'), mode, query, sub=grade, sub2=tag))
        out[row_key] = items

    # A szolgaltato-sorok (hivatalos top / TMDB): a napi futas eredmenye, helybol.
    if kids:
        # Mese-profil: a szolgaltatok MESE-kinalata (providers.run_kids), a
        # netmozi nelkuli cimek is (nCore / Varom); a tobbi szolgaltato-sor ures.
        kids_lists = providers.kids_rows()
        for row_key in provider_rows:
            out[row_key] = []
        for row_key, rows in kids_lists.items():
            items = []
            for row in rows[:ROW_LIMIT]:
                items.append(from_listing(row, watched) if row.get('url') else catalog_item(row))
            out[row_key] = items
    else:
        for row_key, rows in provider_rows.items():
            if rows or row_key not in out:
                out[row_key] = [from_listing(row, watched) for row in rows[:ROW_LIMIT]]
    # Hamarosan: az IMDb-rol, naponta. (Mese-profilban nincs: nincs kategoria.)
    try:
        out['upcoming'] = [] if kids else upcoming_row(cached_only)
    except Exception as exc:
        control.log_exception(u'Hamarosan sor', exc)
        out['upcoming'] = []
    return out


def entry_keys(entry):
    '''Amirol egy tetel felismerheto a sorok kozt: az IMDb-azonositoja es/vagy a netmozi-oldala.'''
    entry = entry or {}
    return set(key for key in (imdb_of(entry), _page_of(entry.get('query') or '')) if key)


def dedupe_rows(rows):
    '''
    Egy cim csak az elso (ROWS-sorrendben) halozati sorban jelenjen meg:
    az Ajanlo, a Felkapottak es a Filmek -- legujabb, meg a szolgaltato-
    sorok nagyreszt ugyanabbol a friss kinalatbol meritenek. A szemelyes
    sorok (Folytatas, Amit mar lattam, Figyelt) erintetlenek, es nem is
    szamitanak bele -- amit lattam, az az Ajanloban attol meg ott lehet.
    '''
    seen = set()
    out = dict(rows or {})
    for key, _title in ROWS:
        if key in LOCAL_ROWS or not out.get(key):
            continue
        kept = []
        for entry in out[key]:
            keys = entry_keys(entry)
            if keys & seen:
                continue
            seen |= keys
            kept.append(entry)
        out[key] = kept
    return out


def all_thumbs(rows):
    '''A sorok osszes boritoja (a TMDB elolekeresehez), ismetles nelkul.'''
    out = []
    for key, _title in ROWS:
        for entry in (rows or {}).get(key) or []:
            thumb = entry.get('thumb') or ''
            if thumb and thumb not in out:
                out.append(thumb)
    return out


def service_sub(entry, records):
    '''
    A borito alatti sor a szolgaltatoval: "DVD, szinkron · Netflix". A
    records a tmdb.load() -- egyszer olvasva, minden tetelre.
    '''
    imdb = imdb_of(entry)
    services = ((records or {}).get(imdb) or {}).get('services') if imdb else None
    sub = entry.get('sub') or u''
    if not services:
        return sub
    tag = u', '.join(services)
    return u'%s · %s' % (sub, tag) if sub else tag


def stream_titles(cached_only=True):
    '''Az osszes top-listas cim (az ellenorzeshez).'''
    from resources.lib.modules import cache
    titles = []
    for _row_key, provider_keys in STREAM_ROWS:
        for key in provider_keys:
            rows = (cache.peek(fetch_provider, key) if cached_only
                    else cache.get(fetch_provider, config.CACHE_HOURS_NETFLIX, key)) or []
            titles += [row['title'] for row in rows]
    return titles


def ensure_stream_check(force=False):
    '''
    Ha esedekes, lefuttatja a Stream Top ellenorzest (a netmozi keresojevel).
    A kezdokepernyo hatterszala hivja, a plugin folyamataban -- ott a
    navigator importalhato. True, ha futott.
    '''
    from resources.lib.modules import streamcheck
    if not force and not streamcheck.due():
        return False
    titles = stream_titles(cached_only=True)
    if not titles:
        return False
    from resources.lib.indexers import navigator
    nav = navigator.navigator()
    streamcheck.run(titles, nav.searchMovies, nav.pickBestMatch)
    return True


def ensure_provider_rows(force=False):
    '''
    Ha esedekes (naponta), osszeallitja a szolgaltato-sorokat: hivatalos
    top lista / TMDB, aztan a netmozi keresoje az IMDb-azonositokkal.
    A plugin folyamataban fut (navigator). True, ha futott.
    '''
    from resources.lib.modules import profiles, providers, tmdb
    ran = False
    if providers.enabled() and (force or providers.due()):
        from resources.lib.indexers import navigator
        providers.run(navigator.navigator().searchMovies)
        ran = True
    # A mese-sorok: ha van mese-profil (barmelyik), naponta, TMDB-kulccsal.
    try:
        has_kids = bool(profiles.load().get('kids'))
    except Exception:
        has_kids = False
    if has_kids and tmdb.api_key() and (force or providers.kids_due()):
        from resources.lib.indexers import navigator
        providers.run_kids(navigator.navigator().searchMovies)
        ran = True
    return ran


# --- Reszletezo nezet: egy tetel gombjai es sorai ---------------------------------

def _page_of(query):
    '''A film/sorozat oldala egy query-bol ("playdirect&url=/filmek/1/x" -> "/filmek/1/x").'''
    import re
    match = re.search(r'(?:^|&)url=([^&]+)', query or '')
    return match.group(1) if match else ''


PLAY_GLYPH = 'nm-play.png'


def detail_buttons(entry):
    '''
    A reszletezo gombsora egy tetelhez: [(felirat, mode, query, ikon)].
    A lejatszas gomb csak ikon (haromszog kep -- a TV betukeszleteben nincs
    ilyen jel); a Folytatas ikon + szoveg. Film: Lejatszas, Forrasok, nCore
    (ha be van allitva), aztan a tetel helyi menuje. Sorozat: Folytatas (ha
    van hol), Evadok, helyi menu.
    '''
    from resources.lib.modules import ncore, progress
    mode, query = entry.get('mode', 'play'), entry.get('query', '')
    page = _page_of(query)
    if query.startswith('watchopen&url=') and page and not page.startswith('imdb:'):
        # A figyelt sor tetele: ugyanazok a gombok, mint masutt (a "watchopen"
        # csak a jelzest venne le -- azt az Evadok / Lejatszas is leveszi).
        if page.startswith('/sorozatok/'):
            mode, query = 'open', 'series&url=%s&auto=1' % page
        else:
            mode, query = 'play', 'playdirect&url=%s' % page
    out = []
    if query.startswith('watchappear'):
        out.append((u'Várom: szólj, ha megjelenik', 'play', query, ''))
    elif query.startswith('watchremove&url=imdb:'):
        out.append((u'Már nem várom', 'play', query, ''))
    elif query.startswith('ncoreplayimdb'):
        out.append((u'nCore', 'play', query, PLAY_GLYPH))
    elif page and (query.startswith('continueseries') or query.startswith('series&url=')):
        out.extend(series_buttons(page))
    elif mode == 'play':
        out.append((u'', 'play', query, PLAY_GLYPH))
    elif query:
        out.append((u'Megnyitás', mode, query, ''))
    is_film = (mode == 'play' and page and not query.startswith('continueseries')
               and not query.startswith('watch'))
    if is_film:
        out.append((u'Források', 'play', 'sources&url=%s' % page, ''))
        if ncore.enabled():
            out.append((u'nCore', 'play', 'ncoreplay&url=%s' % page, ''))
    seen = set(label for label, _m, _q, _g in out if label)
    for label, cmode, cquery in entry.get('context') or []:
        if label in seen or cquery in [q for _l, _m, q, _g in out]:
            continue
        seen.add(label)
        out.append((label, cmode, cquery, ''))
    return out


def series_buttons(page):
    '''
    EGYSEGES gombsor minden sorozatra, barmelyik sorbol nyilik (Folytatas,
    Amit mar lattam, Figyelt, Sorozatok, kereso): Folytatas (ha van hol;
    kulonben Lejatszas -- az elso / a kovetkezo nem latott resz), Evadok,
    es a soron kovetkezo resz Forrasai (+ nCore), hogy rossz forrasnal
    kezzel lehessen valasztani.
    '''
    from resources.lib.modules import ncore, progress
    entry = progress.get(page)
    out = [((u'Folytatás' if entry else u'Lejátszás'), 'play', 'continueseries&url=%s' % page, PLAY_GLYPH),
           (u'Évadok', 'open', 'series&url=%s&auto=1' % page, '')]
    target = ''
    if entry:
        target = entry.get('page') if not progress.finished(entry) else (entry.get('next_page') or '')
    parts = progress.split_page(target) if target else None
    if parts:
        where = u'%d. évad %d. rész' % (parts[1], parts[2])
        out.append((u'Források (%s)' % where, 'play', 'sources&url=%s' % target, ''))
        if ncore.enabled():
            out.append((u'nCore (%s)' % where, 'play', 'ncoreplay&url=%s' % target, ''))
    return out


def detail_kind(entry):
    '''('film', oldal) / ('series', oldal) / ('none', '') -- a forras-ellenorzeshez.'''
    mode, query = entry.get('mode', 'play'), entry.get('query', '')
    page = _page_of(query)
    if query.startswith('watchopen&url=') and page and not page.startswith('imdb:'):
        return ('series' if page.startswith('/sorozatok/') else 'film'), page
    if not page or query.startswith('watch') or query.startswith('ncoreplayimdb'):
        return 'none', ''
    if query.startswith('series&url=') or query.startswith('continueseries'):
        return 'series', page
    return 'film', page


def detail_episode(entry):
    '''
    Melyik resz tartozik a tetelhez a reszletezoben: (evad, resz) vagy None.
    Folytatasnal a kovetkezo (vagy a felbehagyott) resz; figyelt sorozatnal
    az uj resz; egyeb sorozatnal az 1x1 (ha nincs folytatas).
    '''
    from resources.lib.modules import progress, watchlist
    query = entry.get('query') or ''
    page = _page_of(query)
    if not page or not (query.startswith('continueseries') or query.startswith('series&url=')
                        or query.startswith('watchopen&url=')):
        return None
    if query.startswith('watchopen&url='):
        fresh = (watchlist.load().get(page) or {}).get('new') or []
        if fresh:
            try:
                return watchlist.split_key(fresh[0])
            except (ValueError, AttributeError):
                pass
    current = progress.get(page)
    if current:
        if progress.finished(current):
            nxt = progress.split_page(current.get('next_page') or '')
            if nxt:
                return int(nxt[1]), int(nxt[2])
        elif current.get('season') and current.get('episode'):
            return int(current['season']), int(current['episode'])
    return 1, 1


def episode_lines(season, number, data):
    '''("2. évad 3. rész – A felfedezés · 49 perc · IMDb 8,7", leiras) egy reszhez.'''
    data = data or {}
    head = u'%d. évad %d. rész' % (int(season), int(number))
    if data.get('title'):
        head += u' – %s' % data['title']
    parts = [head]
    if data.get('runtime'):
        parts.append(u'%d perc' % data['runtime'])
    if data.get('date'):
        parts.append(data['date'].replace('-', '. ') + '.')
    if data.get('rating'):
        parts.append(u'IMDb %s' % (u'%.1f' % data['rating']).replace('.', ','))
    return u' · '.join(parts), data.get('overview') or u''


def detail_lines(entry, record=None, episode=None):
    '''
    (2. sor, 3. sor, leiras) a reszletezoben. 2. sor: ev · mufaj · perc
    (TMDB-bol, kulonben a tetel sub2-je); 3. sor: minoseg/hang · szolgaltato.
    Ha van resz (episode: {'season', 'episode', ...adatok}), a 2. sor es a
    leiras a reszrol szol.
    '''
    record = record or {}
    from resources.lib.modules import watchlist
    watch_entry = watchlist.load().get(_page_of(entry.get('query') or ''))
    _short, upcoming = next_episode_label(record, pending=aired_missing(watch_entry, record))
    if episode and episode.get('season'):
        line2, plot = episode_lines(episode['season'], episode['episode'], episode)
        sub = entry.get('sub') or u''
        services = record.get('services') or []
        line3 = u' · '.join(part for part in (sub, u', '.join(services), upcoming) if part)
        return line2, line3, plot or record.get('overview') or u''
    parts = []
    if record.get('year'):
        parts.append(record['year'])
    if record.get('genres'):
        parts.append(u', '.join(record['genres']))
    if record.get('runtime'):
        parts.append(u'%d perc' % record['runtime'])
    if record.get('seasons'):
        parts.append(u'%d évad' % record['seasons'])
    if record.get('rating'):
        parts.append(u'IMDb %s' % (u'%.1f' % record['rating']).replace('.', ','))
    line2 = u' · '.join(parts) if parts else (entry.get('sub2') or u'')
    if parts and entry.get('sub2') and not record.get('year'):
        line2 = entry['sub2']
    sub = entry.get('sub') or u''
    services = record.get('services') or []
    line3 = u' · '.join(part for part in (sub, u', '.join(services), upcoming) if part)
    return line2, line3, record.get('overview') or u''


# --- Sorozat-nezet: evadok es reszek -----------------------------------------------

def series_seasons(html):
    '''[(evadszam, [reszszam, ...]), ...] a sorozat oldalarol (egy letoltes).'''
    from resources.lib.modules import watchlist
    seasons = {}
    for key in watchlist.listed_episodes(html or ''):
        season, episode = watchlist.split_key(key)
        seasons.setdefault(season, []).append(episode)
    return [(season, sorted(seasons[season])) for season in sorted(seasons)]


def series_start(base, seasons):
    '''
    Hol nyiljon a sorozat-nezet: (evad, resz). Ha van folytatas (felbehagyott
    vagy kovetkezo resz), ott; kulonben az UTOLSO evad elso resze.
    '''
    from resources.lib.modules import progress
    if not seasons:
        return None
    current = progress.get(base)
    if current:
        if progress.finished(current):
            nxt = progress.split_page(current.get('next_page') or '')
            if nxt:
                return int(nxt[1]), int(nxt[2])
        elif current.get('season') and current.get('episode'):
            return int(current['season']), int(current['episode'])
    last, numbers = seasons[-1]
    return last, (numbers[0] if numbers else 1)


def seasons_label(seasons):
    '''Az "Evadok" gomb felirata: az utolso evad szama ("3. évad"), ha tudjuk.'''
    if not seasons:
        return u'Évadok'
    return u'%d. évad' % seasons[-1][0]


def episode_marker(page, watched, current):
    '''"megnézve" / "félbehagyva, 25. perc" / "elkezdve" / "" egy reszhez.'''
    from resources.lib.modules import progress
    if current and current.get('page') == page:
        if progress.finished(current):
            return u'megnézve'
        seconds = progress.resume_seconds(current)
        return u'félbehagyva, %d. perc' % (seconds // 60) if seconds else u'elkezdve'
    return u'megnézve' if page in watched else u''


def episode_context(page):
    '''Egy resz helyi menuje (hosszan nyomva): a forrasok kezzel, ha az automatikus rossz.'''
    from resources.lib.modules import ncore
    out = [(u'Források', 'play', 'sources&url=%s' % page)]
    if ncore.enabled():
        out.append((u'nCore', 'play', 'ncoreplay&url=%s' % page))
    return out


def episode_items(base, season, numbers, thumb, meta=None, avail=None):
    '''
    Egy evad reszei a sorozat-nezet sorába: tetel = {'label': "3. rész",
    'sub': a resz cime, 'sub2': jelzes (megnezve...), 'thumb': allokep vagy
    a sorozat boritoja, 'query': playepisode&url=..., 'netmozi'/'ncore':
    yes / no / '' (elerhetoseg)}.
    '''
    from resources.lib.modules import history, progress
    watched = set(entry.get('page', '') for entry in history.load())
    current = progress.get(base)
    out = []
    for number in numbers:
        page = '%s/s%d/e%d' % (base, int(season), int(number))
        data = (meta or {}).get(str(number)) or {}
        entry = item(u'%d. rész' % int(number), data.get('still') or thumb, 'play',
                     'playepisode&url=%s' % page, sub=data.get('title') or u'',
                     sub2=episode_marker(page, watched, current),
                     context=episode_context(page))
        state = (avail or {}).get(int(number)) or {}
        entry['netmozi'] = state.get('netmozi') or ''
        entry['ncore'] = state.get('ncore') or ''
        out.append(entry)
    return out


# --- Kereso-nezet (a kezdokepernyon belul, TV-n) --------------------------------
#
# A Netflix TV-s keresoje szerint: balra betűrács (szóköz, törlés, a-z, 0-9,
# 6 oszlop) es alatta a mufajok; jobbra a talalatok poszter-racsa. Gepeles
# kozben magatol keres (rovid nyugalom utan); ures mezonel javaslatok (a
# Felkapottak sor). OK egy talalaton: a reszletezo, mint a sorokban.

KEYBOARD = u'abcdefghijklmnopqrstuvwxyz1234567890'
KEYBOARD_COLUMNS = 6
SEARCH_ORDER = '1'              # a kereses rendezese (a regi kereso is ezzel keres)
SEARCH_DEBOUNCE = 0.5           # ennyi nyugalom utan indul a kereses gepeles kozben
SEARCH_LIMIT = 48               # ennyi talalat a racsban (a netmozi 24-et ad oldalankent)
SEARCH_PLACEHOLDER = u'Írd be a címet…'
SEARCH_TITLE_EMPTY = u'Keresési javaslatok'
# A mufajok sorrendje a keresoben: a gyakoriak elol (a Netflix mintajara);
# a tobbi az oldal sorrendjeben utanuk. Az ertekek a netmozi urlapjabol.
GENRE_ORDER = ('Comedy', 'Action', 'Sci-Fi', 'Horror', 'Documentary', 'Animation',
               'Romance', 'Thriller', 'Drama', 'Adventure', 'Crime', 'Family',
               'Fantasy', 'Mystery', 'War', 'History', 'Biography')
SEARCH_HISTORY_FILE = 'search.history'     # ugyanaz, amit a regi kereso olvas


def keyboard_rows():
    '''A betűrács sorai (6 betű soronként), a Netflix elrendezésében.'''
    return [KEYBOARD[i:i + KEYBOARD_COLUMNS] for i in range(0, len(KEYBOARD), KEYBOARD_COLUMNS)]


def search_url(text, page=1):
    return config.LIST_URL % (config.BASE_URL, page, '', SEARCH_ORDER, quote_plus(text))


def genre_url(value, page=1, order=None, tipus=''):
    from resources.lib.modules import search
    return search.build_url({'genre': value, 'type': tipus or ''}, page, order or search.DEFAULT_ORDER)


def order_genres(genres):
    '''A gyakoriak elore, a tobbi a kapott sorrendben.'''
    rank = {value: index for index, value in enumerate(GENRE_ORDER)}
    return sorted(genres, key=lambda pair: (rank.get(pair[0], len(rank)), genres.index(pair)))


def genre_options():
    '''[(ertek, felirat)] a netmozi keresourlapjabol (napi gyorsitotar); mese-profilban csak a mesei.'''
    from resources.lib.modules import cache, search
    options = cache.get(search.fetch_options, config.CACHE_HOURS_NETFLIX) or {}
    genres = order_genres([(value, label) for value, label in (options.get('genre') or [])])
    if kids_mode():
        genres = [pair for pair in genres if pair[0] in KIDS_GENRES]
    return genres


def search_entries(rows):
    from resources.lib.modules import watchlist
    watched = frozenset(watchlist.load())
    return [from_listing(row, watched) for row in kids_filter(rows)[:SEARCH_LIMIT]]


def fetch_entries(url):
    '''Egy lista-oldal tetelei a racsba; None halozati hibanal ([] = nincs talalat).'''
    from resources.lib.modules import client, listing
    html = client.request(url)
    if not html:
        return None
    return search_entries(listing.parse_rows(html, ''))


def fetch_search(text):
    return fetch_entries(search_url(text))


def fetch_genre(value):
    return fetch_entries(genre_url(value))


def search_title(query, genre_label=u'', count=None, busy=False, failed=False, similar=()):
    '''
    A racs cime: mit mutat eppen ("„kaptár” – 15 találat"). similar: a
    talalatok utan mely mufajok cimeivel folytatodik a racs.
    '''
    if query:
        head = u'„%s”' % query
    elif genre_label:
        head = genre_label
    else:
        return SEARCH_TITLE_EMPTY
    if busy:
        return u'%s – keresés…' % head
    if failed:
        return u'%s – nem sikerült (hálózat?)' % head
    if count is None:
        title = head
    elif count == 0:
        title = u'%s – nincs találat' % head
    else:
        title = u'%s – %d találat' % (head, count)
    if similar:
        title += u' · hasonlók: %s' % u', '.join(similar)
    return title


# --- A racs folyama: lapozas kozben tolt tovabb ------------------------------
#
# A racs mogott egy "folyam" all: lista-oldalak sora (szakaszok), amibol a
# kovetkezo oldal akkor jon, amikor a nezo a vege fele er. Ha egy szakasz
# kimerul (rovid oldal), a kovetkezo jon:
#   - javaslatok: a legnezettebb filmek evrol evre visszafele (RECO_YEARS);
#   - kereses: a talalatok, utana a talalatok leggyakoribb mufajainak cimei
#     ("hasonlók") -- igy keves talalatnal sem marad ures a racs;
#   - mufaj: a mufaj oldalai.
# A folyam csak memoriaban el (a fuggvenyek nem menthetok); ami mar
# szerepelt (url), nem kerul be ujra.

PAGE_SIZE = 24          # ennyit ad a netmozi egy lista-oldalon; rovidebb = az utolso
FEED_MAX = 600          # ennel tobb tetel nem kerul a racsba
FEED_AHEAD = 16         # ha ennyi tetel van hatra a racsban (negy sor), tolt tovabb -- gyors lapozasnal is elobb erjen ide
FEED_RETRY = 10         # halozati hiba utan ennyi masodperc mulva probal ujra
RECO_YEARS = 8          # a javaslatok: ennyi ev legnezettebb filmjei visszafele
SIMILAR_GENRES = 2      # a talalatok utan ennyi mufaj cimei jonnek


def new_feed(kind, stages, seen=()):
    return {'kind': kind, 'stages': list(stages), 'stage': 0, 'page': 1, 'done': not stages,
            'seen': set(seen), 'count': 0, 'results': 0, 'genres': {}, 'similar': [],
            'extended': False}


def reco_feed(entries):
    '''A javaslatok folyama a mar mutatott sor (Felkapottak = az idei, 1. oldal) utan.'''
    year = date.today().year
    if kids_mode():
        # Mese-profil: a legnezettebb animaciok, majd a csaladi filmek.
        stages = [{'url': (lambda page, g=g: genre_url(g, page, ORDER_MOST_VIEWED, '1')), 'note': u''}
                  for g in KIDS_GENRES]
    else:
        stages = [{'url': (lambda page, y=y: _list_url('1', ORDER_MOST_VIEWED, y, page)), 'note': u''}
                  for y in range(year, year - RECO_YEARS, -1)]
    feed = new_feed('reco', stages, seen=[_page_of(entry.get('query')) for entry in entries])
    feed['count'] = len(entries)
    if len(entries) >= PAGE_SIZE:
        feed['page'] = 2
    return feed


def query_feed(text):
    return new_feed('query', [{'url': lambda page: search_url(text, page), 'note': u''}])


def genre_feed(value):
    return new_feed('genre', [{'url': lambda page: genre_url(value, page), 'note': u''}])


def top_genres(counts, limit=SIMILAR_GENRES):
    '''A leggyakoribb mufajok feliratai (dontetlennel abece szerint).'''
    return [label for label, _n in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:limit]]


def similar_stages(counts, options):
    '''A talalatok mufajai -> a mufaj-listak szakaszai (a felirat -> az urlap erteke).'''
    values = dict((label, value) for value, label in options)
    stages = []
    for label in top_genres(counts):
        if label in values:
            stages.append({'url': (lambda page, v=values[label]: genre_url(v, page)), 'note': label})
    return stages


def extend_feed(feed):
    '''Kimerult folyam: keresesnel a talalatok mufajainak cimei jonnek (egyszer).'''
    if feed['kind'] != 'query' or feed['extended']:
        return
    feed['extended'] = True
    feed['stages'] += similar_stages(feed['genres'], genre_options())


def feed_page(feed):
    '''
    A folyam kovetkezo oldala (a hatterszal hivja): az uj tetelek ([] ha
    nincs tobb), None halozati hibanal. A folyam allapota lep.
    '''
    if feed['done']:
        return []
    from resources.lib.modules import client, listing, watchlist
    stage = feed['stages'][feed['stage']]
    html = client.request(stage['url'](feed['page']))
    if not html:
        return None
    rows = listing.parse_rows(html, '')
    watched = frozenset(watchlist.load())
    fresh = []
    for row in kids_filter(rows):
        if row['url'] in feed['seen']:
            continue
        feed['seen'].add(row['url'])
        entry = from_listing(row, watched)
        entry['url'] = row['url']
        entry['genres'] = list(row.get('categories') or [])
        fresh.append(entry)
        if feed['kind'] == 'query' and feed['stage'] == 0:
            feed['results'] += 1
            for genre in entry['genres']:
                feed['genres'][genre] = feed['genres'].get(genre, 0) + 1
    if fresh and stage['note'] and stage['note'] not in feed['similar']:
        feed['similar'].append(stage['note'])
    feed['count'] += len(fresh)
    if len(rows) < PAGE_SIZE:
        feed['stage'] += 1
        feed['page'] = 1
        if feed['stage'] >= len(feed['stages']):
            extend_feed(feed)
    else:
        feed['page'] += 1
    if feed['stage'] >= len(feed['stages']) or feed['count'] >= FEED_MAX:
        feed['done'] = True
    return fresh


# --- Bongeszo-nezet: Filmek / Sorozatok racsban, szurokkel -------------------
#
# A felso sav Filmek / Sorozatok tetelere (TV-n): balra a szurok (rendezes,
# nyelv, ev, mufaj -- az oldal urlapjabol), jobbra a racs, ugyanazzal a
# folyammal, mint a kereso. Egyetlen URL-sablon: a reszletes kereso
# vegpontja mindet egyszerre erti (elo meres).

BROWSE_KINDS = (('1', u'Filmek'), ('2', u'Sorozatok'))
BROWSE_ANY_YEAR = u'Minden év'
BROWSE_ANY_GENRE = u'Minden műfaj'
BROWSE_ANY_LANGUAGE = u'Mindegy'


def kind_label(tipus):
    return dict(BROWSE_KINDS).get(tipus, u'')


def parse_orders(html):
    '''{'options': [(ertek, felirat)], 'default': ertek} az oldal rendezes-valasztojabol.'''
    import re
    from resources.lib.modules import client
    match = re.search(r'<select[^>]*id="%s"[^>]*>(.*?)</select>' % config.ORDER_SELECT_ID, html or '', re.S)
    options, default = [], ''
    for value, attrs, label in re.findall(config.ORDER_OPTION_RE, match.group(1) if match else ''):
        label = client.replaceHTMLCodes(label).strip()
        if any(hidden in label for hidden in config.HIDDEN_ORDERS):
            continue
        options.append((value, label))
        if 'selected' in attrs:
            default = value
    return {'options': options, 'default': default or (options[0][0] if options else ORDER_NEWEST_LINKS)}


def fetch_orders():
    '''cache.get() hivja: None = hiba (marad a regi).'''
    from resources.lib.modules import client
    parsed = parse_orders(client.request(config.BASE_URL))
    return parsed if parsed['options'] else None


def browse_options():
    '''A szurok valaszthato ertekei (napi gyorsitotar): rendezesek, nyelvek, mufajok, evek.'''
    from resources.lib.modules import cache, search
    orders = cache.get(fetch_orders, config.CACHE_HOURS_NETFLIX) or {'options': [], 'default': ORDER_NEWEST_LINKS}
    form = cache.get(search.fetch_options, config.CACHE_HOURS_NETFLIX) or {}
    pairs = lambda rows: [(value, label) for value, label in rows]     # a tarbol listak jonnek
    return {'orders': pairs(orders['options']), 'default_order': orders['default'],
            'languages': [('', BROWSE_ANY_LANGUAGE)] + pairs(form.get('language') or config.LANGUAGE_FALLBACK),
            'years': [('', BROWSE_ANY_YEAR)] + [(y, y) for y in search.year_values()],
            'genres': [('', BROWSE_ANY_GENRE)] + genre_options()}


def browse_key(tipus, order, year, genre, language):
    return ('browse', tipus, order or '', year or '', genre or '', language or '')


def browse_url(tipus, order, year, genre, language, page=1):
    from resources.lib.modules import search
    return search.build_url({'type': tipus, 'genre': genre or '', 'language': language or '',
                             'yearfrom': year or '', 'yearto': year or ''}, page, order or ORDER_NEWEST_LINKS)


def browse_feed(tipus, order, year, genre, language):
    return new_feed('browse', [{'url': (lambda page: browse_url(tipus, order, year, genre, language, page)),
                                'note': u''}])


def browse_title(order_label, year, genre_label, language_label):
    '''A racs feje: "Legújabb linkek · 2026 · Akció · Magyar" (csak ami be van allitva).'''
    parts = [order_label] + [part for part in (year, genre_label, language_label) if part]
    return u' · '.join(part for part in parts if part)


# --- Mit nezzek ma este? (a kezdokepernyon belul, TV-n) --------------------------
#
# Egy jo ertekelesu (IMDb >= 7), a nyelv-szuro szerinti (alapbol szinkronos)
# film a valasztott mufajbol, veletlenszeruen -- a regi menu parbeszedablaka
# helyett egy kartya: poszter, cim, adatok, leiras, es Inditas / Masikat /
# Reszletek gombok. Balra a mufajok ("Barmi" + az oldal mufajai).

TONIGHT_ANY = u'Bármi'
TONIGHT_BUTTONS = ((u'', 'play', PLAY_GLYPH), (u'Másikat', 'another', ''), (u'Részletek', 'detail', ''))


def tonight_state(genre, language):
    return {'genre': genre or '', 'type': config.TONIGHT_TYPE,
            'language': language or config.LANGUAGE_FALLBACK[0][0],
            'ratingfrom': config.TONIGHT_RATING}


def page_count(html):
    '''A lapozo utolso erteke; 1, ha nincs lapozo.'''
    from resources.lib.modules import client
    pager = client.parseDOM(html or '', 'select', attrs={'name': config.PAGER_SELECT_NAME})
    values = client.parseDOM(pager, 'option', ret='value') if pager else []
    try:
        return max(1, int(values[-1])) if values else 1
    except (TypeError, ValueError):
        return 1


def tonight_pick(genre, language, tried, pages, rand=None):
    '''
    (sor, allapot): egy veletlen film a mufajbol, amit meg nem ajanlottunk
    (tried: url-ek, bovul). pages: a mar letoltott oldalak (memoria). Az
    allapot 'ok' / 'none' (elfogyott) / 'error' (halozat).
    '''
    import random
    from resources.lib.modules import client, listing, search
    rand = rand or random
    state = tonight_state(genre, language)
    key = (genre or '', language or '')

    def page_rows(page):
        rows = pages.get((key, page))
        if rows is None:
            html = client.request(search.build_url(state, page=page))
            if not html:
                return None
            rows = pages[(key, page)] = listing.parse_rows(html, '')
            if page == 1:
                pages[(key, 'count')] = page_count(html)
        return rows

    if page_rows(1) is None:
        return None, 'error'
    count = max(1, min(pages.get((key, 'count'), 1), config.TONIGHT_MAX_PAGE))
    for _ in range(config.TONIGHT_TRIES):
        rows = page_rows(rand.randint(1, count))
        if rows is None:
            return None, 'error'
        rows = [row for row in kids_filter(rows) if row['url'] not in tried and not row['isSeries']]
        if rows:
            pick = rand.choice(rows)
            tried.add(pick['url'])
            return pick, 'ok'
    return None, 'none'


def tonight_entry(row):
    '''A kartya tetele (mint a sorokban: cim, borito, minoseg, indito query).'''
    from resources.lib.modules import watchlist
    return from_listing(row, frozenset(watchlist.load()))


def feed_wants_more(feed, size, position):
    '''Kell-e a kovetkezo oldal: a nezo a racs vege fele jar (vagy a racs rovid).'''
    if not feed or feed['done']:
        return False
    return size - max(position, 0) <= FEED_AHEAD


def search_history_path():
    return os.path.join(control.transPath(control.addonInfo('profile')), SEARCH_HISTORY_FILE)


def remember_search(text):
    '''A kereses az elozmenyek koze (a regi kereso listaja is ezt mutatja). True, ha uj.'''
    text = (text or u'').strip()
    if not text:
        return False
    path = search_history_path()
    try:
        with open(path, encoding='utf-8') as handle:
            known = set(line.strip() for line in handle)
    except (IOError, OSError):
        known = set()
    if text in known:
        return False
    try:
        control.makeFile(os.path.dirname(path))
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(u'%s\n' % text)
    except (IOError, OSError) as exc:
        control.log_exception(u'keresési előzmény mentése', exc)
        return False
    return True


# --- Frissites (a felso sav gombja): sajat ablak a verzioval ---------------------

UPDATE_WAIT = 120               # ennyi masodpercig varunk a telepulesre a keres utan
UPDATE_RETRY_SECONDS = 2        # a hordozo ilyen surun nezi kozben, frissult-e


def version_tuple(text):
    import re
    return tuple(int(part) for part in re.findall(r'[0-9]+', text or '0'))


def latest_version():
    '''A repo listajaban levo verzio; '' ha nincs benne; None halozati hibanal.'''
    import re
    from resources.lib.modules import client
    page = client.request(config.UPDATE_ADDONS_XML)
    if not page:
        return None
    match = re.search(config.UPDATE_VERSION_RE % re.escape(control.addonInfo('id')), page)
    return match.group(1) if match else ''


def update_status(installed, latest):
    '''
    (allapot, szoveg) a frissites ablakaba: 'newer' (jon), 'same' (ez a
    legfrissebb), 'missing' (a forrasban nincs), 'error' (nem erheto el).
    '''
    if latest is None:
        return 'error', u'Nem sikerült elérni a frissítési forrást. Próbáld később.'
    if not latest:
        return 'missing', u'A frissítési forrás elérhető, de nem szerepel benne a bővítmény.'
    if version_tuple(latest) <= version_tuple(installed):
        return 'same', u'A legfrissebb verzió van fent.'
    return 'newer', (u'Elérhető: %s — hamarosan frissül.\n'
                     u'A frissítés után a felület újraindul, kérlek várj…' % latest)


def top_bar(kids=None):
    '''A felso sav tetelei; a Beallitasok parancsaba a bovitmeny azonositoja kerul. Mese-profilban nincs Regi menu.'''
    out = []
    kids = kids_mode() if kids is None else kids
    for label, mode, query in TOP_BAR:
        if kids and query == 'classic':
            continue
        if mode == 'builtin':
            query = query % control.addonInfo('id')
        out.append(item(label, '', mode, query))
    return out
