# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# nCore mint plusz forras: a nezo sajat belepesevel, Elementumon at.
#
# A protokoll az nCore TV bovitmenybol (heg, 1.0.0 es 1.1.2) es a Jackett
# nCore-definiciojabol jon -- nem talaltunk fel semmit ujra:
#   - belepes: POST login.php (nev, pass, ne_leptessen_ki=1) -> 302 + "pass"
#     suti; a fooldalon az RSS-kulcs (rss.php?key=...) a passkey, amivel a
#     .torrent suti nelkul is letoltheto (ez kell az Elementumnak);
#   - kereses IMDb-azonositoval: torrents.php?miben=imdb&mire=tt...
#     &tipus=kivalasztottak_kozott&kivalasztott_tipus[]=hd_hun...;
#   - a lista sorai: div.box_torrent (torrent_txt > a[title][href id],
#     tipus= a kategoria, box_meret2, box_s2, box_l2, siterank imdb);
#   - evadpakk fajllistaja: ajax.php?action=files&id=...;
#   - lejatszas: plugin://plugin.video.elementum/play?uri=<letolto URL>
#     &file_match=<regex>&doresume=false&position=... (az Elementum
#     api/play.go-ban ellenorzott parameterek).
#
# Szabalyok, amiket a masik bovitmeny tapasztalata adott: a belepest 24
# orankent elég megujitani; sikertelen belepes utan 6 percig nem probalunk
# ujra (az nCore kizar); a "deleted" erteku suti = rossz jelszo.

import json
import os
import re
import socket
import time
from urllib.parse import quote, quote_plus

from resources.lib.modules import config, control


FILE = 'ncore.json'
SITE = 'nCore'
PREFIX = 'ncore://'

BASE = 'https://ncore.pro'
LOGIN_URL = BASE + '/login.php'
SEARCH_URL = BASE + '/torrents.php'
DOWNLOAD_URL = BASE + '/torrents.php?action=download&id=%s&key=%s'
FILES_URL = BASE + '/ajax.php?action=files&id=%s'
DETAILS_URL = BASE + '/torrents.php?action=details&id=%s'

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/102.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Referer': BASE + '/',
}
TIMEOUT = 20

# Kategoriak: film es sorozat, magyar es kulfoldi, SD (xvid) es HD. A DVD
# (ISO) kategoriak kimaradnak: azt az Elementum nem streameli.
FILM_CATEGORIES = ('xvid_hun', 'xvid', 'hd_hun', 'hd')
SERIES_CATEGORIES = ('xvidser_hun', 'xvidser', 'hdser_hun', 'hdser')

SESSION_HOURS = 24
FAIL_COOLDOWN = 6 * 60
PASSKEY_RE = r'rss\.php\?key=([0-9a-zA-Z]+)'
LOGGED_IN_MARKER = 'profile.php'
ERROR_BOX_RE = r'<div[^>]+id="hibauzenet"[^>]*>(.*?)</div>'

ELEMENTUM_ID = 'plugin.video.elementum'
ELEMENTUM_PLAY = 'plugin://plugin.video.elementum/play?uri=%s&doresume=false&position=%d&size_at_start=true'
SAMPLE_FILTER = r'(?i)^(?!.*sample).*$'


# --- Beallitasok es tarolt munkamenet ---------------------------------------------

def enabled():
    try:
        return control.setting('ncore') == 'true' and bool(credentials()[0])
    except Exception:
        return False


def credentials():
    try:
        return ((control.setting('ncoreuser') or '').strip(),
                (control.setting('ncorepass') or ''))
    except Exception:
        return '', ''


def mode():
    '''manual / fallback / better / always -- a beallitas cimkejebol.'''
    try:
        label = (control.setting('ncoremode') or '').strip()
    except Exception:
        label = ''
    for key, text in config.NCORE_MODES:
        if label in (key, text):
            return key
    return config.NCORE_MODE_DEFAULT


def _rank(quality):
    ladder = [step.lower() for step in config.QUALITY_LADDER]
    text = (quality or '').strip().lower()
    return ladder.index(text) if text in ladder else -1


def better(torrents, sources, language=''):
    '''
    Jobb-e a legjobb elo torrent a netmozi legjobb elo forrasanal (a
    minoseg-letran). Ha van preferalt nyelv, azon belul merunk: ha a
    hosztereknel nincs olyan nyelvu forras, de a torrentnel van, az jobb.
    '''
    if not torrents:
        return False
    pool = [item for item in sources or [] if item.get('valid')]
    if language and language != config.LANGUAGE_ANY:
        wanted_t = [item for item in torrents if item.get('language') == language]
        wanted_s = [item for item in pool if item.get('language') == language]
        if wanted_t and not wanted_s:
            return True
        if wanted_t:
            torrents, pool = wanted_t, wanted_s
    if not pool:
        return True
    return (max(_rank(item.get('quality')) for item in torrents)
            > max(_rank(item.get('quality')) for item in pool))


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'nCore munkamenet írása', exc)
        return False


def forget():
    save({})


# --- HTTP (IPv4-en: az ncore.pro IPv6-on egyes halozatokon akadozik) ----------------

def _ipv4_only(host, port, family=0, kind=0, proto=0, flags=0):
    return _REAL_GETADDRINFO(host, port, socket.AF_INET, kind, proto, flags)


_REAL_GETADDRINFO = socket.getaddrinfo


class _ipv4(object):
    def __enter__(self):
        socket.getaddrinfo = _ipv4_only

    def __exit__(self, *_exc):
        socket.getaddrinfo = _REAL_GETADDRINFO


def _get(url, cookies=None):
    '''(statusz, szoveg) vagy (None, '') halozati hibanal.'''
    import requests
    try:
        with _ipv4():
            response = requests.get(url, headers=HEADERS, cookies=cookies or {}, timeout=TIMEOUT)
        return response.status_code, response.text
    except Exception as exc:
        control.log_exception(u'nCore kérés (%s)' % url, exc)
        return None, ''


def _post_login(data):
    '''(statusz, suti-szotar, szoveg) vagy (None, {}, '') halozati hibanal.'''
    import requests
    try:
        with _ipv4():
            response = requests.post(LOGIN_URL, headers=HEADERS, data=data,
                                     allow_redirects=False, timeout=TIMEOUT)
        return response.status_code, dict(response.cookies), response.text
    except Exception as exc:
        control.log_exception(u'nCore belépés', exc)
        return None, {}, ''


# --- Belepes ----------------------------------------------------------------------

def login(user, password, now=None):
    '''
    Belep, es elteszi a sutit + a passkey-t. (True, '') ha sikerult,
    (False, hibauzenet) ha nem. Sikertelen belepes utan FAIL_COOLDOWN-ig nem
    probal ujra -- az nCore a probalgatast kizarassal bunteti.
    '''
    now = now or time.time()
    data = load()
    if (now - (data.get('failed_at') or 0)) < FAIL_COOLDOWN:
        return False, u'Az előző belépés nem sikerült; pár percig nem próbálkozom újra.'
    if not user or not password:
        return False, u'Nincs megadva nCore felhasználónév vagy jelszó.'
    status, cookies, text = _post_login({
        'set_lang': 'hu', 'submitted': '1', 'nev': user, 'pass': password, 'ne_leptessen_ki': '1'})
    if status is None:
        return False, u'Az nCore nem érhető el.'
    pass_cookie = (cookies.get('pass') or '').strip()
    if status != 302 or not pass_cookie or pass_cookie.lower() == 'deleted':
        message = _error_text(text) or u'Hibás felhasználónév vagy jelszó.'
        save({'failed_at': int(now)})
        control.log(u'nCore belépés sikertelen (%s): %s' % (status, message), control.LOGWARNING)
        return False, message
    status, home = _get(BASE + '/', {'nick': user, 'pass': pass_cookie})
    if status is None:
        return False, u'Az nCore nem érhető el.'
    key = _passkey(home)
    if not key or LOGGED_IN_MARKER not in home:
        save({'failed_at': int(now)})
        return False, u'A belépés után nem jött meg a kulcs -- ellenőrizd a fiókot az oldalon.'
    save({'nick': user, 'pass': pass_cookie, 'key': key, 'at': int(now)})
    control.log(u'nCore: belépve')
    return True, u''


def _error_text(html):
    match = re.search(ERROR_BOX_RE, html or '', re.S)
    if not match:
        return u''
    return re.sub(r'<[^>]+>', ' ', match.group(1)).strip()[:200]


def _passkey(html):
    match = re.search(PASSKEY_RE, html or '')
    return match.group(1) if match else ''


def session(now=None, force=False):
    '''
    Ervenyes munkamenet ({'nick', 'pass', 'key'}) -- ha kell, belepessel.
    None, ha nem sikerul (az okot naploztuk).
    '''
    now = now or time.time()
    data = load()
    if (not force and data.get('pass') and data.get('key')
            and (now - (data.get('at') or 0)) < SESSION_HOURS * 3600):
        return data
    user, password = credentials()
    ok, _message = login(user, password, now)
    return load() if ok else None


def cookies(data):
    return {'nick': data.get('nick', ''), 'pass': data.get('pass', '')}


# --- Kereses ----------------------------------------------------------------------

def search_url(imdb, kind):
    categories = SERIES_CATEGORIES if kind == 'series' else FILM_CATEGORIES
    parts = ['nyit_sorozat_resz=true' if kind == 'series' else 'nyit_filmek_resz=true']
    parts += ['kivalasztott_tipus%%5B%%5D=%s' % cat for cat in categories]
    parts += ['miben=imdb', 'tipus=kivalasztottak_kozott', 'mire=%s' % quote_plus(imdb)]
    return SEARCH_URL + '?' + '&'.join(parts)


def parse_rows(html):
    '''A talalati lista sorai, a lap sorrendjeben.'''
    from resources.lib.modules import client
    out = []
    for box in client.parseDOM(html or '', 'div', attrs={'class': 'box_torrent'}):
        # A cim: a torrent_txt div elso linkje (title attributum = a teljes
        # nev; a szoveg csonkolt lehet). Ha a szerkezet mas, a doboz elso
        # adatlap-linkje.
        txt = re.search(r'<div[^>]+class="torrent_txt[^"]*"[^>]*>(.*?)</div>', box, re.S)
        link = re.search(r'<a\s+([^>]+)>(.*?)</a>', txt.group(1) if txt else box, re.S)
        attrs = link.group(1) if link else ''
        id_match = (re.search(r'action=details&(?:amp;)?id=(\d+)', attrs)
                    or re.search(r'action=details&(?:amp;)?id=(\d+)', box))
        if not id_match:
            continue
        title_match = re.search(r'title="([^"]*)"', attrs)
        title = client.replaceHTMLCodes(title_match.group(1)) if title_match else ''
        if not title and link:
            title = client.replaceHTMLCodes(re.sub(r'<[^>]+>', '', link.group(2))).strip()
        cat_match = re.search(r'torrents\.php\?tipus=([a-z0-9_]+)', box)
        imdb_match = re.search(r'imdb\.com/title/(tt\d+)', box)
        rating = re.search(r'\[imdb:\s*([\d.]+)\]', box)
        row = {
            'id': id_match.group(1),
            'title': title,
            'category': cat_match.group(1) if cat_match else '',
            'imdb': imdb_match.group(1) if imdb_match else '',
            'rating': rating.group(1) if rating else '',
            'size': _text(box, 'box_meret2'),
            'seeders': _int(_text(box, 'box_s2')),
            'leechers': _int(_text(box, 'box_l2')),
            'uploaded': _text(box, 'box_feltoltve2'),
        }
        out.append(row)
    return out


def _text(box, css_class):
    match = re.search(r'<div[^>]+class="%s"[^>]*>(.*?)</div>' % css_class, box, re.S)
    if not match:
        return ''
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', match.group(1))).strip()


def _int(text):
    match = re.search(r'\d+', text or '')
    return int(match.group(0)) if match else 0


def search(imdb, kind, data=None):
    '''
    Torrentek egy cimhez. None, ha nincs munkamenet vagy halozati hiba;
    kulonben lista (akar ures). Ha az oldal kileptetett, egyszer ujra belep.
    '''
    if not imdb:
        return []
    data = data or session()
    if not data:
        return None
    status, html = _get(search_url(imdb, kind), cookies(data))
    if status is None:
        return None
    if LOGGED_IN_MARKER not in (html or ''):
        control.log(u'nCore: a munkamenet lejárt, újra belépek', control.LOGWARNING)
        data = session(force=True)
        if not data:
            return None
        status, html = _get(search_url(imdb, kind), cookies(data))
        if status is None:
            return None
    rows = parse_rows(html)
    control.log(u'nCore: %d torrent (%s, %s)' % (len(rows), imdb, kind))
    return rows


# --- A torrent cimebol: minoseg, nyelv, resz -------------------------------------

RESOLUTION_RE = r'(?i)\b(2160p|4k|uhd|1080[pi]|720p|576p|480p)\b'
GRADE_PATTERNS = (
    (r'(?i)\b(hd)?cam(rip)?\b', 'CAM'),
    (r'(?i)\b(hd)?ts\b|\btelesync\b', 'TS'),
    (r'(?i)\b(hd)?tc\b|\btelecine\b', 'TC'),
)
EPISODE_RE = r'(?i)\bS(\d{1,2})[\s._-]?E(\d{1,3})\b'
SEASON_RE = r'(?i)\bS(\d{1,2})\b(?![\s._-]?E\d)|\bSeason[\s._-]?(\d{1,2})\b|\b(\d{1,2})\.?\s?évad\b'
HUNSUB_RE = r'(?i)\bhun(garian)?[\s._-]?sub'


def resolution(title):
    match = re.search(RESOLUTION_RE, title or '')
    if not match:
        return ''
    text = match.group(1).lower()
    return '4K' if text in ('2160p', '4k', 'uhd') else text


def grade(title):
    '''A minoseg-letra foka: CAM / TS / TC, kulonben DVD (kiadott anyag).'''
    for pattern, label in GRADE_PATTERNS:
        if re.search(pattern, title or ''):
            return label
    return 'DVD'


def language(row):
    if (row.get('category') or '').endswith('_hun'):
        return 'Szinkron'
    if re.search(HUNSUB_RE, row.get('title') or ''):
        return 'Felirat'
    return u'Külföldi'


def episode_of(title):
    '''(evad, resz) a cimbol, vagy None.'''
    match = re.search(EPISODE_RE, title or '')
    return (int(match.group(1)), int(match.group(2))) if match else None


def season_of(title):
    '''Evadpakk evadszama a cimbol, vagy None.'''
    match = re.search(SEASON_RE, title or '')
    if not match:
        return None
    return int(next(group for group in match.groups() if group))


def size_label(text):
    match = re.match(r'([\d.,]+)\s*([KMGT])i?B', text or '', re.I)
    if not match:
        return text or ''
    return u'%s %sB' % (match.group(1).replace('.', ','), match.group(2).upper())


# --- Forrasok a netmozi formajaban ----------------------------------------------

def source_url(torrent_id, season=None, episode=None):
    '''
    A forras "URL"-je: ncore://<id>, evadpakknal ncore://<id>?s=1&e=3 --
    a feloldas ismeri fel, es a pakkbol a reszt valasztja.
    '''
    url = PREFIX + str(torrent_id)
    if season is not None and episode is not None:
        url += '?s=%d&e=%d' % (int(season), int(episode))
    return url


def is_source(url):
    return (url or '').startswith(PREFIX)


def parse_source_url(url):
    '''(torrent id, evad, resz) -- az evad/resz None, ha nem pakk.'''
    rest = (url or '')[len(PREFIX):]
    torrent_id, _sep, query = rest.partition('?')
    match = re.match(r's=(\d+)&e=(\d+)$', query or '')
    if match:
        return torrent_id, int(match.group(1)), int(match.group(2))
    return torrent_id, None, None


def sources_for(imdb, kind='film', season=None, episode=None, rows=None):
    '''
    Forras-szotarak (mint a netmozi forrastablaja): {'label', 'url',
    'site', 'language', 'quality', 'valid', 'subtitled', 'seeders', ...}.
    Sorozatnal csak a kert reszhez illo torrentek: a resz sajat torrentje,
    vagy az evad pakkja (abban a fajlt kesobb valasztjuk ki).
    '''
    rows = search(imdb, kind) if rows is None else rows
    if not rows:
        return []
    out = []
    for row in rows:
        title = row.get('title') or ''
        pack = False
        if kind == 'series' and season is not None:
            found = episode_of(title)
            if found:
                if found != (int(season), int(episode)):
                    continue
            else:
                if season_of(title) != int(season):
                    continue
                pack = True                         # a fajlt a lejatszaskor keressuk meg
        quality = grade(title)
        res = resolution(title) or ('SD' if row.get('category', '').startswith('xvid') else '')
        nyelv = language(row)
        detail = u' '.join(part for part in (res, size_label(row.get('size')),
                                             u'%d seed' % row.get('seeders', 0)) if part)
        out.append({
            'index': 0,
            'label': u'[B]%s[/B] | [COLOR limegreen]%s[/COLOR] | [COLOR blue]%s[/COLOR] | %s' % (
                SITE, nyelv, quality, detail),
            'url': source_url(row['id'], season, episode) if pack else source_url(row['id']),
            'subtitled': False,
            'language': nyelv,
            'site': SITE,
            'quality': quality,
            'valid': row.get('seeders', 0) > 0,
            'seeders': row.get('seeders', 0),
            'size': row.get('size', ''),
            'resolution': res,
            'title': title,
            'ncore': True,
        })
    # A tobb seederes elore -- az indul el gyorsan.
    out.sort(key=lambda item: -item['seeders'])
    return out


def season_availability(imdb, season, numbers, rows=None):
    '''
    {reszszam: True/False} egy evadra, EGY keresesbol: a resz sajat
    torrentje vagy az evad pakkja (elo seederrel) teszi elerhetove.
    None, ha a kereses nem ment.
    '''
    rows = search(imdb, 'series') if rows is None else rows
    if rows is None:
        return None
    pack = False
    singles = set()
    for row in rows:
        if row.get('seeders', 0) <= 0:
            continue
        found = episode_of(row.get('title') or '')
        if found:
            if found[0] == int(season):
                singles.add(found[1])
        elif season_of(row.get('title') or '') == int(season):
            pack = True
    return dict((int(n), pack or int(n) in singles) for n in numbers)


# --- Lejatszas: Elementum -------------------------------------------------------

def elementum_installed():
    '''Telepitve ES engedelyezve (a letiltott Elementum nem jatszik).'''
    import xbmc
    try:
        return (bool(xbmc.getCondVisibility('System.HasAddon(%s)' % ELEMENTUM_ID))
                and bool(xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % ELEMENTUM_ID)))
    except Exception:
        return False


def comments(torrent_id, data=None):
    '''A torrent adatlapjanak hozzaszolasai (comments.parse_ncore alakban), vagy [].'''
    from resources.lib.modules import comments as _comments
    data = data or session()
    if not data:
        return []
    status, html = _get(DETAILS_URL % torrent_id, cookies(data))
    if status != 200:
        return []
    return _comments.parse_ncore(html)


def files(torrent_id, data=None):
    '''A torrent fajljai (utvonalak), vagy [] ha nem elerheto.'''
    from resources.lib.modules import client
    data = data or session()
    if not data:
        return []
    status, html = _get(FILES_URL % torrent_id, cookies(data))
    if status != 200:
        return []
    out = []
    for row in client.parseDOM(html, 'tr', attrs={'class': 'listrow_(?:odd|even)'}):
        cells = client.parseDOM(row, 'td')
        if len(cells) >= 2:
            text = re.sub(r'<[^>]+>', '', cells[1]).strip()
            if text:
                out.append(text.replace('\\', '/'))
    return out


VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.ts', '.wmv', '.mov')


def pick_episode_file(paths, season, episode):
    '''Az evadpakk fajljai kozul a kert resz videoja, vagy ''.'''
    for path in paths or []:
        name = path.split('/')[-1]
        if not name.lower().endswith(VIDEO_EXT) or 'sample' in name.lower():
            continue
        found = episode_of(name)
        if found == (int(season), int(episode)):
            return name
    # "1x03" alak
    for path in paths or []:
        name = path.split('/')[-1]
        if re.search(r'(?i)\b%d\s?x\s?%02d\b' % (int(season), int(episode)), name):
            return name
    return ''


def play_url(torrent_id, key, file_name='', position=0):
    '''Az Elementum lejatszo-URL-je egy torrenthez (es fajlhoz).'''
    uri = quote(DOWNLOAD_URL % (torrent_id, key), safe='')
    url = ELEMENTUM_PLAY % (uri, int(position or 0))
    if file_name:
        pattern = r'(?i)(?:^|[\\/])' + re.escape(file_name) + r'$'
    else:
        pattern = SAMPLE_FILTER
    return url + '&file_match=' + quote(pattern, safe='')


def resolve(url, position=0):
    '''
    Egy ncore:// forras -> Elementum URL. None, ha nincs munkamenet, nincs
    Elementum, vagy evadpakknal nem talaljuk a reszt.
    '''
    if not elementum_installed():
        control.log(u'nCore: az Elementum nincs telepítve', control.LOGWARNING)
        return None
    torrent_id, season, episode = parse_source_url(url)
    data = session()
    if not data:
        return None
    file_name = ''
    if season is not None:
        file_name = pick_episode_file(files(torrent_id, data), season, episode)
        if not file_name:
            control.log(u'nCore: az évadpakkban nincs meg a rész (%s)' % torrent_id, control.LOGWARNING)
            return None
    return play_url(torrent_id, data['key'], file_name, position)


# --- Elementum beallitasa a mi hasznalatunkra ------------------------------------

# (beallitas, ertek): memoriabol jatszik (nem ir a TV tarhelyere), a
# torrentet leallitaskor eldobja, lejatszas utan torol, nem kerdez.
ELEMENTUM_SETTINGS = (
    ('download_storage', '1'),          # 1 = memoria
    ('auto_memory_size', 'false'),
    ('memory_size', '400'),             # MB
    ('keep_downloading', '2'),          # leallitasnal: megall
    ('keep_files_playing', '2'),        # felbehagyott: torol
    ('keep_files_finished', '2'),       # vegignezett: torol
    ('silent_stream_start', 'true'),    # nem kerdez inditas elott
    ('seed_forever', 'false'),
)


def setup_elementum():
    '''Beallitja az Elementumot. (True, uzenet) / (False, uzenet).'''
    import xbmcaddon
    if not elementum_installed():
        return False, u'Az Elementum nincs telepítve (Bővítmények / Videó / Elementum).'
    try:
        addon = xbmcaddon.Addon(ELEMENTUM_ID)
        for key, value in ELEMENTUM_SETTINGS:
            addon.setSetting(key, value)
    except Exception as exc:
        control.log_exception(u'Elementum beállítása', exc)
        return False, u'Nem sikerült az Elementum beállítása: %s' % exc
    return True, u'Elementum beállítva: memóriából játszik (400 MB), leállításkor eldob, lejátszás után töröl.'
