# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Rejtett, felnottkorhoz kotott lista.
#
# Nincs hozza menupont sehol: kizarolag ugy erheto el, hogy a keresobe a
# config.ADULT_KEYWORD szot irjuk be. A kulcsszo NEM kerul be sem a keresesi
# elozmenybe, sem a "Mar lattam" listaba -- kulonben a rejtes ertelmetlen lenne.
#
# A netmozi szelektorai a config.py-ban vannak; ez viszont egy masik forras,
# ezert a sajat mintai -- a streams.py es a netflix.py mintajara -- itt, egy
# helyen allnak.

import re

try:
    from urllib.parse import quote_plus
except ImportError:                                   # pragma: no cover
    from urllib import quote_plus

from resources.lib.modules import client


BASE = 'https://xhamster.com'

# Lapozas: az oldalszam az UTVONAL vegen all (a ?page= parameter ugyanazt
# a lapot adja vissza). Az elso oldal szam nelkul.
HOME_URL = BASE + '/newest/%s'
SEARCH_URL = BASE + '/search/%s/%s'
CATEGORY_URL = BASE + '/tags/%s/%s'

# Egy talalati sor a videohoz tartozo azonositoval kezdodik. A CSS-osztalyok
# hash-eltek (barmikor valtozhatnak), az adat-attributumok viszont allandoak.
ROW_SPLIT = r'data-video-id="'

LINK_RE = r'href="(' + BASE.replace('.', r'\.') + r'/videos/[^"]+)"'
# A borito a blokk elso kepe. A lapon a csempek egy reszehez a kep csak
# JavaScriptbol erkezik -- azok a sorok KIMARADNAK (inkabb kevesebb tetel,
# mint ures helyek a racsban); a folyam a kovetkezo oldalrol potolja oket.
THUMB_RE = r'<img[^>]+src="(https://[^"]+\.(?:jpg|webp)[^"]*)"'
# "31:40" vagy "1:02:33" a csempe sarkaban.
DURATION_RE = r'>(\d{1,2}:\d{2}(?::\d{2})?)<'
# A cim a link aria-label-jeben all (a felirat-blokk kulon helyen van).
TITLE_RE = r'aria-label="([^"]*)"'
QUALITY_RE = r'format-(4k|1080p|720p)'
QUALITY_LABELS = {'4k': '4K', '1080p': '1080p', '720p': '720p'}

# A video oldalan a lejatszhato cim egy kozvetlen HLS-lista.
STREAM_RE = r'"(https://[^"]+\.m3u8[^"]*)"'
# A kapott cim egy "master" lista: benne a minosegek kulon listai. A Kodi
# ebbol tekereskor elveszti a fonalat (a valtozat-valtas megszakitja a
# lejatszast), ezert EGY minoseget adunk at -- a legjobbat, amit talalunk.
VARIANT_RE = r'#EXT-X-STREAM-INF:([^\n]*)\n([^\n#]+)'
HEIGHT_RE = r'RESOLUTION=\d+x(\d+)'
MASTER_MARK = '#EXT-X-STREAM-INF'
# Ennel nagyobb felbontas nem kell (a TV-n nem latszik tobb, viszont
# akadozhat): a 720p a felso hatar.
MAX_HEIGHT = 720
# A valtozatok ketfele kodekkel jonnek: a H.264 mindenhol megy (a TV-k
# hardverbol dekodaljak), az AV1 viszont gyakran csak reszben -- ott
# maradhat el a hang. Ezert a H.264 az elsodleges.
PREFERRED_CODEC = 'h264'
# A lap sokszor az AV1-es listat adja meg, de a H.264-es UGYANAZON a cimen
# elerheto, csak a kodek nevevel -- azt keressuk meg elsokent.
ALT_CODECS = (('.av1.', '.h264.'),)
# A szegmensek tipusa szamit a lejatszasnal: a .ts-t a Kodi sajat olvasoja
# kezeli jol (hanggal), a darabolt MP4-et (.m4s) az adaptiv lejatszo.
SEGMENT_RE = r'^[^#\n]+$'
PAGE_TITLE_RE = r'<meta property="og:title" content="([^"]*)"'
PAGE_THUMB_RE = r'<meta property="og:image" content="([^"]*)"'

# A bal oldali lista: az oldal sajat kategoria-lapja abc-sorrendben orszagokat
# sorol (nem mufajokat), ezert a lista ITT all -- mind a 28 cimke ellenorizve.
CATEGORIES = (
    ('amateur', u'Amatőr'), ('anal', u'Anál'), ('asian', u'Ázsiai'), ('bbw', u'BBW'),
    ('big-tits', u'Nagy mell'), ('blonde', u'Szőke'), ('blowjob', u'Orális'),
    ('brunette', u'Barna'), ('cosplay', u'Cosplay'), ('creampie', u'Creampie'),
    ('cumshot', u'Cumshot'), ('hardcore', u'Hardcore'), ('hd', u'HD'),
    ('hentai', u'Hentai'), ('interracial', u'Interracial'), ('latina', u'Latina'),
    ('lesbian', u'Leszbikus'), ('massage', u'Masszázs'), ('masturbation', u'Maszturbáció'),
    ('mature', u'Érett'), ('milf', u'MILF'), ('orgasm', u'Orgazmus'), ('pov', u'POV'),
    ('public', u'Nyilvános'), ('teen', u'Fiatal'), ('threesome', u'Hármas'),
    ('vintage', u'Retró'), ('webcam', u'Webkamera'),
)

# Ennel tobb sort nem dolgozunk fel egy oldalrol.
MAX_ROWS = 60


def _unescape(text):
    '''A cimekben HTML-entitasok es JS-eskapolas is elofordul.'''
    if not text:
        return ''
    try:
        from html import unescape
        text = unescape(text)
    except ImportError:                               # pragma: no cover
        pass
    return text.replace('\\/', '/').replace("\\'", "'").strip()


def _seconds(text):
    """"31:40" -> 1900 masodperc; "1:02:33" -> 3753. Ertelmezhetetlenbol 0."""
    parts = [int(part) for part in (text or '').split(':') if part.isdigit()]
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds


def parse(html):
    """A talalati oldal sorai: [{title, url, thumb, duration, quality}]."""
    rows = []
    seen = set()
    for chunk in re.split(ROW_SPLIT, html or '')[1:MAX_ROWS + 1]:
        link = re.search(LINK_RE, chunk)
        if not link or link.group(1) in seen:
            continue
        seen.add(link.group(1))
        title = re.search(TITLE_RE, chunk)
        thumb = re.search(THUMB_RE, chunk)
        duration = re.search(DURATION_RE, chunk)
        quality = re.search(QUALITY_RE, chunk)
        if not thumb:
            continue                                  # borito nelkul nem tesszuk a racsba
        rows.append({
            'title': _unescape(title.group(1)) if title else link.group(1),
            'url': link.group(1),
            'thumb': thumb.group(1),
            # A Kodi masodpercet var; az oldal ora:perc:masodperc alakban irja ki.
            'duration': _seconds(duration.group(1)) if duration else 0,
            'quality': QUALITY_LABELS.get(quality.group(1), '') if quality else '',
        })
    return rows


def homepage(page=1):
    """A cimlap (a legfrissebbek) egy oldala. Halozati hibanal None."""
    html = client.request(HOME_URL % max(1, int(page or 1)))
    if html is None:
        return None
    return parse(html)


def search(query, page=1):
    """
    Kereses talalatai.

    Halozati hibanal None, hogy meg lehessen kulonboztetni az "ures talalat"
    esettol -- ugyanaz az elv, mint a navigator.searchMovies-nal.
    """
    page = max(1, int(page or 1))
    html = client.request(SEARCH_URL % (quote_plus(query or ''), page))
    if html is None:
        return None
    return parse(html)


def category(slug, page=1):
    """Egy kategoria (a bal oldali lista) videoi. Halozati hibanal None."""
    if not slug:
        return homepage(page)
    html = client.request(CATEGORY_URL % (slug, max(1, int(page or 1))))
    if html is None:
        return None
    return parse(html)


def categories():
    '''A kategoriak a bal oldali listahoz: [(slug, felirat)] -- halozat nelkul.'''
    return list(CATEGORIES)


def h264_master(url):
    """
    A H.264-es lista cime, ha az oldal az AV1-eset adta meg (ugyanaz a cim,
    mas kodeknevvel). Ha nincs ilyen, az eredeti marad.
    """
    for av1, h264 in ALT_CODECS:
        if av1 not in (url or ''):
            continue
        candidate = url.replace(av1, h264)
        playlist = client.request(candidate)
        if playlist and MASTER_MARK in playlist:
            return candidate
    return url


def best_variant(url, max_height=MAX_HEIGHT):
    """
    A master HLS-listabol EGY minoseg sajat listaja (teljes cimmel): a
    legjobb, ami meg belefer a felso hatarba (720p). Ha nem master, vagy
    nem sikerul lekerni, az eredeti cim marad.
    """
    playlist = client.request(url)
    if not playlist or MASTER_MARK not in playlist:
        return url
    variants = []
    for attrs, name in re.findall(VARIANT_RE, playlist):
        name = name.strip()
        height = re.search(HEIGHT_RE, attrs)
        if name:
            variants.append((int(height.group(1)) if height else 0, name))
    if not variants:
        return url
    fitting = [item for item in variants if item[0] <= max_height]
    # Elsokent a megbizhato kodek (H.264), es azon belul a legjobb minoseg;
    # ha olyan nincs, barmelyik belefero; ha semmi nem fer bele, a legkisebb.
    preferred = [item for item in fitting if PREFERRED_CODEC in item[1].lower()]
    best = max(preferred)[1] if preferred else (max(fitting)[1] if fitting else min(variants)[1])
    if best.startswith('http'):
        return best
    return url.rsplit('/', 1)[0] + '/' + best.lstrip('/')


def codec_of(url):
    """A valtozat kepkodekje a nevebol: 'h264', 'av1' vagy ''."""
    name = (url or '').rsplit('/', 1)[-1].lower()
    for codec in ('h264', 'av1'):
        if codec in name:
            return codec
    return ''


def segment_kind(url):
    """
    A lista szegmenseinek tipusa: 'ts' vagy 'mp4' ('' ha nem derul ki). Ettol
    fugg, melyik lejatszo viszi (a hang miatt).
    """
    playlist = client.request(url)
    if not playlist:
        return ''
    for line in re.findall(SEGMENT_RE, playlist, re.M):
        name = line.strip().lower()
        if name.endswith('.ts'):
            return 'ts'
        if name.endswith('.m4s') or name.endswith('.mp4'):
            return 'mp4'
    return ''


def stream(url):
    """
    Egy video lejatszhato cime: {'url', 'title', 'thumb'}. Hibanal None.

    Az oldal egy kozvetlen HLS-listat ad (a tobbi forras titkositva all a
    lapban) -- a Kodi ezt gond nelkul lejatssza.
    """
    html = client.request(url)
    if html is None:
        return None
    found = re.search(STREAM_RE, html)
    if not found:
        return None
    title = re.search(PAGE_TITLE_RE, html)
    thumb = re.search(PAGE_THUMB_RE, html)
    url = best_variant(h264_master(_unescape(found.group(1))))
    return {'url': url, 'segments': segment_kind(url), 'codec': codec_of(url),
            'title': _unescape(title.group(1)) if title else '',
            'thumb': _unescape(thumb.group(1)) if thumb else ''}
