# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A boritos kezdokepernyo ABLAKA.
#
# Az adatok a home.py-bol jonnek (sorok, bennuk egyforma alaku tetelek); az
# ablak csak kirajzol es tovabbit: OK-ra a tetel 'mode'/'query' parja
# alapjan a plugin megfelelo muveletet hivja (RunPlugin lejatszashoz,
# ActivateWindow listahoz), hosszan nyomasra a tetel helyi menujet mutatja.
#
# Az ablakot a BOVITMENY SAJAT FOLYAMATA hordozza (host), nem a hatter-
# szolgaltatas. A szolgaltatasbol nyitott ablak a szolgaltatas leallitasakor
# (pl. bovitmeny-frissiteskor) beakasztotta a Kodi feluletet -- ismert
# csapda. A plugin-folyamat csak addig el, amig az ablak, es tisztan zarul.
# show() + sajat ciklus, nem doModal: igy a friss sorokat es a lejatszas
# utani frissitest is mi kezeljuk, ugyanabbol a szalbol.

import json
import re
import time

import xbmc
import xbmcgui

from resources.lib.modules import control, home


XML_FILE = 'NetmoziHome%d.xml'      # poszterenkent kulon fajl (tools/make_home_xml.py)
POSTER_COUNTS = (4, 5, 6, 7, 8)
POSTER_COUNT_DEFAULT = 7


def poster_count():
    '''Hany poszter ferjen egy sorba (beallitas: homeposters).'''
    try:
        value = int(control.setting('homeposters') or 0)
    except (TypeError, ValueError):
        value = 0
    return value if value in POSTER_COUNTS else POSTER_COUNT_DEFAULT


def touch_mode():
    '''
    Erintokepernyos elrendezes (szellosebb sorok): beallitas "Be"/"Ki", vagy
    "Automatikus" -- akkor telefon-aranyu (2:1-nel nyulankabb) kijelzon.
    '''
    try:
        value = (control.setting('hometouch') or '').strip().lower()
    except Exception:
        value = ''
    if value in ('be', 'true', 'on'):
        return True
    if value in ('ki', 'false', 'off'):
        return False
    return phone_screen()


def phone_screen():
    try:
        width = int(xbmc.getInfoLabel('System.ScreenWidth') or 0)
        height = int(xbmc.getInfoLabel('System.ScreenHeight') or 0)
    except (TypeError, ValueError):
        return False
    if not width or not height:
        return False
    ratio = float(max(width, height)) / min(width, height)
    return ratio >= 2.0


def layout_key():
    return (poster_count(), touch_mode())


def xml_file(count=None, touch=None):
    count = count or poster_count()
    touch = touch_mode() if touch is None else touch
    return XML_FILE % count if not touch else (XML_FILE % count).replace('.xml', 't.xml')

TOP_BAR_ID = 100
GROUPLIST_ID = 50
DETAIL_GROUP_ID = 300
DETAIL_LIST_ID = 310        # a reszletezo gombsora
DETAIL_PLOT_ID = 330        # a leiras (gorgetheto fel-le gombbal)
SERIES_GROUP_ID = 500
BACK_BUTTON_ID = 390        # telefonon: Vissza a jobb felso sarokban
SEASONS_LIST_ID = 400       # sorozat-nezet: az evadok sora
EPISODES_LIST_ID = 410      # sorozat-nezet: a kivalasztott evad reszei
PLOT_STEP = 2               # sor / gombnyomas

# sor kulcsa -> (csoport id, lista id) -- ugyanaz, mint tools/make_home_xml.py
ROW_IDS = {
    'continue': (110, 111),
    'recommended': (120, 121),
    'trending': (130, 131),
    'movies': (140, 141),
    'series': (150, 151),
    'history': (160, 161),
    'watch': (170, 171),
    'netflix': (180, 181),
    'apple': (190, 191),
    'prime': (200, 201),
    'disney': (210, 211),
    'hbomax': (220, 221),
    'skyshowtime': (230, 231),
    'upcoming': (240, 241),
}
ROW_LIST_IDS = frozenset(list_id for _group_id, list_id in ROW_IDS.values())

# Kereso-nezet (TV-n; a make_home_xml.py SEARCH blokkja ugyanezekkel)
SEARCH_EDIT_ID = 600            # szokoz / torles
SEARCH_KEYS_ID = 610            # a betűrács (panel, 6 oszlop)
SEARCH_GENRES_ID = 620          # mufajok (a betűrács alatt)
SEARCH_GENRES_BIG_ID = 625      # ugyanaz nagyban: a betűrács helyen, ha oda lepett a fokusz
SEARCH_RESULTS_ID = 630         # a talalatok poszter-racsa
GRID_PER_ROW, GRID_ROWS = 4, 2  # a racs (make_home_xml.py RESULTS_PANEL): 4 oszlop, 2 sor latszik
# Bongeszo-nezet (Filmek / Sorozatok; a make_home_xml.py BROWSE blokkja)
BROWSE_ORDER_ID = 700           # rendezes
BROWSE_LANGUAGE_ID = 705        # nyelv
BROWSE_YEAR_ID = 710            # ev
BROWSE_GENRE_ID = 720           # mufaj
BROWSE_RESULTS_ID = 730         # a racs
BROWSE_SERVICE_ID = 725         # streaming szolgaltato (csak attol)
BROWSE_FILTER_IDS = (BROWSE_ORDER_ID, BROWSE_LANGUAGE_ID, BROWSE_YEAR_ID, BROWSE_GENRE_ID, BROWSE_SERVICE_ID)
BROWSE_MENU_ID = 740            # a negysoros szuro-menu (cim + ertek); OK nyitja az ertek-listat a helyen
BROWSE_MENU = ((BROWSE_ORDER_ID, u'RENDEZÉS', 'order'), (BROWSE_LANGUAGE_ID, u'NYELV', 'language'),
               (BROWSE_YEAR_ID, u'ÉV', 'year'), (BROWSE_GENRE_ID, u'MŰFAJ', 'genre'),
               (BROWSE_SERVICE_ID, u'STREAMING', 'service'))
# Mit nezzek ma este? (a make_home_xml.py TONIGHT blokkja)
TONIGHT_GENRES_ID = 800         # mufajok (Barmi + az oldal mufajai)
TONIGHT_BUTTONS_ID = 810        # Inditas / Masikat / Reszletek
TONIGHT_STUCK_SECONDS = 15      # ennyi utan a "Masikat" akkor is uj sorsolast indit, ha az elozo meg "keres"
# Beallitasok (a make_home_xml.py SETTINGS blokkja)
SETTINGS_SECTIONS_ID = 900      # szakaszok
SETTINGS_ITEMS_ID = 910         # a szakasz sorai
STATS_GENRES_ID, STATS_MONTHS_ID, STATS_DAYS_ID = 960, 961, 962     # a statisztika listai (nem fokuszalhatok)
STATS_SECTION = {'title': u'Statisztika', 'items': [], 'stats': True}
HOME_BUTTON_ID = 90             # a bal felso "netmozi": vissza a sorokhoz
UPDATE_BUTTON_ID = 1160         # a frissites ablakanak gombja (Rendben)
PROVIDER_GRID_ID = 1410         # a "Tovabb" racsa: a szolgaltato teljes kinalata evenkent
PROVIDER_YEARS_ID = 1420        # a "Tovabb" evvalasztoja (Minden ev, az evek)
SOURCES_LIST_ID = 1310          # a forras-nezet listaja (0. sor: sebessegmeres)
MENU_LIST_ID = 1510             # a csempek helyi menuje (hosszu nyomas): sajat ablak
KEEP_FOCUS_SECONDS = 2.0        # torles utan ennyi ideig tartjuk a fokuszt a soron
PLAY_ROW_KEY = '__play__'       # a forras-nezet "Lejatszas automatikusan" sora (egy reszrol nyitva)
MARK_ROW_KEY = '__mark__'           # a forras-nezetben: "Megnéztem" / "Mégsem néztem meg" (reszrol nyitva)
# Ezekre a parancsokra film / resz indul: a folyamatabra azonnal kirajzolodik.
PLAY_QUERIES = ('playdirect', 'playepisode', 'continueseries', 'ncoreplay', 'historyplay', 'watchopen', 'playsource',
                'adultplay')
PROFILE_BUTTON_ID = 95          # a jobb felso profil-gomb: a Ki nez? kepernyo
TOP_IDS = (TOP_BAR_ID, HOME_BUTTON_ID, PROFILE_BUTTON_ID)    # a felso sav vezerloi
PROFILES_LIST_ID = 1000         # a Ki nez? csempei (Kozos, nevek, Uj profil)
PROFILE_NEW = u'+'              # az "Uj profil" csempe erteke
LAYOUT_SETTINGS = ('homeposters', 'hometouch')     # ezek utan az ablak ujranyilik

UPDATE_CHECK_SECONDS = 30       # ilyen surun nezzuk, frissult-e a bovitmeny
UPDATE_RETRY_SECONDS = 2        # frissites kozben (a bovitmeny epp cserelodik) ilyen surun
RESUME_GAP = 90                 # ha a felmasodperces ciklus ennyit kihagy: keszenletbol ebredtunk

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
MOVE_ACTIONS = (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN)
# Erintokepernyo: a legyintest (SwipeUp/Down, Kodi 531/541) egy ideig sorlepesre
# forditottuk, de a nezo darabosnak talalta -- a Kodi egymasba agyazott listai
# folyamatos, ujjkoveto fuggoleges gorgetest nem engednek. Maradt a Kodi sajat
# viselkedese: a sorok kozti hezagban lehet gorgetni.
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_CONTEXT_MENU = 117
ACTION_MOUSE_RIGHT = 101
CLOSE_ACTIONS = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK)
CONTEXT_ACTIONS = (ACTION_CONTEXT_MENU, ACTION_MOUSE_RIGHT)
# Erintes / eger (Kodi ActionIDs.h): eger 100-109, erintes 401-420, gesztus
# 500-599. A Kodi System.IdleTime-jat az erintes NEM nullazza (csak a
# billentyu es az igazi eger -- InputManager.cpp), ezert a telefonos
# gorgetosav lathatosagat mi jelezzuk a skinnek (Window.Property(touched)).
TOUCH_RANGES = ((100, 109), (401, 420), (500, 599))
TOUCH_SHOW_SECONDS = 3.0       # ennyi ideig latszik a gorgetosav az utolso erintes utan


def is_touch_action(code):
    return any(low <= code <= high for low, high in TOUCH_RANGES)


def plugin_url(query):
    return 'plugin://%s/?action=%s' % (control.addonInfo('id'), query)


def modal_dialog_open():
    '''Nyitva van-e a Kodi egy modalis ablaka (pl. "Playback failed"): alatta nem inditunk lejatszast.'''
    try:
        return bool(xbmc.getCondVisibility('System.HasActiveModalDialog')
                    or xbmc.getCondVisibility('Window.IsActive(DialogConfirm.xml)')
                    or xbmc.getCondVisibility('Window.IsActive(okdialog)'))
    except Exception:
        return False


def builtin_for(mode, query):
    '''A Kodi-parancs egy tetelhez.'''
    if mode == 'builtin':
        return query
    if mode == 'open':
        # "return": a Vissza gomb erre az ablakra hoz vissza.
        return 'ActivateWindow(Videos,%s,return)' % plugin_url(query)
    return 'RunPlugin(%s)' % plugin_url(query)


def list_item(entry, records=None, favs=None):
    '''
    records: a tmdb.load() -- a borito alatti sorba kerul a szolgaltato.
    favs: a kedvencek oldalai -- ezek boritojan (barmelyik sorban) sziv.
    '''
    item = xbmcgui.ListItem(label=entry.get('label', u''), label2=home.service_sub(entry, records))
    thumb = entry.get('thumb') or ''
    if thumb:
        item.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb})
    item.setProperty('sub', entry.get('sub', u''))
    item.setProperty('imdb', home.imdb_of(entry))
    item.setProperty('badge', entry.get('badge') or u'')
    item.setProperty('badgekind', entry.get('badgekind') or u'')
    item.setProperty('more', entry.get('more') or '')
    item.setProperty('netmozi', entry.get('netmozi') or '')
    item.setProperty('ncore', entry.get('ncore') or '')
    item.setProperty('sub2', entry.get('sub2', u''))
    item.setProperty('thumb', thumb)
    item.setProperty('mode', entry.get('mode', 'play'))
    item.setProperty('query', entry.get('query', ''))
    item.setProperty('context', json.dumps(entry.get('context') or []))
    for name in ('state', 'pct10', 'soon', 'date', 'icon', 'compact', 'year', 'fav'):
        item.setProperty(name, str(entry.get(name) or ''))
    if favs and not entry.get('more') and (taste_page(entry.get('query')) in favs
                                           or (item.getProperty('imdb') or '-') in favs):
        item.setProperty('fav', '1')
    item.setProperty('genres', json.dumps(entry.get('genres') or []))
    return item


def favorite_marks():
    '''
    A kedvencek oldalai ES IMDb-azonositoi egy halmazban: a szolgaltato-sorok
    tetele mas oldalra is mutathat, az IMDb-azonosito viszont ugyanaz.
    '''
    try:
        from resources.lib.modules import taste
        out = set()
        for page, entry in taste.load()['favorites'].items():
            out.add(page)
            imdb = home.imdb_of(entry)
            if imdb:
                out.add(imdb)
        return out
    except Exception as exc:
        control.log_exception(u'kedvencek', exc)
        return set()


def taste_page(query):
    '''Egy tetel oldala a kedvencek kulcsaként (a sorozat reszei a sorozathoz).'''
    from resources.lib.modules import taste
    return taste.page_key(home._page_of(query or ''))


def browse_kind_of(query):
    '''A felso sav Filmek / Sorozatok tetele ("base&type=1") -> '1' / '2'; kulonben ''.'''
    import re
    match = re.match(r'base&type=([12])$', query or '')
    return match.group(1) if match else ''


def load_settings_model():
    '''A resources/settings.xml szakaszai (prefs.parse); [] hibanal.'''
    import os
    from resources.lib.modules import prefs
    try:
        with open(os.path.join(control.addonPath, 'resources', 'settings.xml'), encoding='utf-8') as handle:
            return prefs.parse(handle.read())
    except Exception as exc:
        control.log_exception(u'beállítások olvasása', exc)
        return []


def _year_values():
    from resources.lib.modules import search
    return search.year_values()


class Grid(object):
    """
    Poszter-racs egy folyammal (home.feed_page): az elso oldal a hatterben,
    a tobbi lapozas kozben; kulcsonkent tar, hogy ugyanaz masodszor
    azonnal jojjon. A szalak a queue-ba fuzik az oldalakat, a tick (a
    hordozo-ciklusbol) irja a listaba -- a GUI-t csak az erinti.
    """

    def __init__(self, window, control_id, name):
        self.window, self.control_id, self.name = window, control_id, name
        self.wanted = None      # amit mutatni kell, es a folyam-gyara
        self.factory = None
        self.initial = None     # az elso oldal keszen (pl. egy mar betoltott sor)
        self.shown = None       # amit a racs mutat
        self.feed = None
        self.entries = []
        self.busy = None        # a folyamatban levo lekeres kulcsa
        self.retry_at = 0
        self.failed = False
        self.cache = {}
        self.queue = []

    def want(self, key, factory, initial=None):
        '''A racs ezt mutassa (a tick intezi: tarbol / keszrol azonnal, kulonben a hatterben).'''
        self.wanted, self.factory, self.initial = key, factory, initial
        self.tick(load_more=False)

    def clear(self):
        '''A nezet zarult: a racs urul (a tar es a folyamok maradnak).'''
        self.wanted = self.shown = self.feed = None
        self.entries = []
        try:
            self.window.getControl(self.control_id).reset()
        except Exception:
            pass

    def info(self):
        '''A cimhez: mit mutat, hany talalat, mely hasonlok, var-e, hiba-e.'''
        feed = self.feed if self.shown == self.wanted else None
        return {'key': self.wanted, 'shown': self.shown == self.wanted,
                'count': feed['results'] if feed else None,
                'similar': feed['similar'] if feed else [],
                'busy': self.wanted is not None and self.shown != self.wanted,
                'failed': self.failed and self.shown == self.wanted}

    def tick(self, load_more=True):
        '''True, ha valtozott valami (cim-frissiteshez).'''
        changed = False
        while self.queue:
            result = self.queue.pop(0)
            if result.get('more') == 'badges':
                if result['key'] == self.shown:
                    self._apply_badges(result['badges'])
                continue
            if result['key'] == self.busy:
                self.busy = None
            if result['key'] != self.wanted:
                continue
            if result['more']:
                self._append(result['entries'])
            else:
                self._apply(result['key'], result['entries'], result['feed'])
            changed = True
        if self.wanted is None:
            return changed
        if self.wanted != self.shown:
            if self.wanted in self.cache:
                self._apply(self.wanted, **self.cache[self.wanted])
                return True
            if self.initial is not None:
                # Kesz sorbol (pl. "Tovabb"): az ismert hianyzo borito itt sem latszik.
                self._apply(self.wanted, home.cover_filter(list(self.initial), network=False), self.factory())
                self.initial = None
                return True
            if self.busy != self.wanted:
                self._fetch(self.wanted, self.factory(), more=False)
                return True
            return changed
        if load_more and self.busy is None and time.time() >= self.retry_at:
            try:
                control_list = self.window.getControl(self.control_id)
                size, position = control_list.size(), control_list.getSelectedPosition()
            except Exception:
                return changed
            if home.feed_wants_more(self.feed, size, position):
                self._fetch(self.shown, self.feed, more=True)
        return changed

    def _apply(self, key, entries, feed):
        self.shown, self.feed = key, feed
        self.entries = list(entries or [])
        self.failed = entries is None
        # Halozati hiba: nem kerul a tarba, es a folyam kesobb ujra probal.
        self.retry_at = 0 if entries is not None else time.time() + home.FEED_RETRY
        if entries is not None:
            self.cache[key] = {'entries': self.entries, 'feed': feed}
        self._populate(self.entries)

    def _append(self, entries):
        if entries is None:
            self.retry_at = time.time() + home.FEED_RETRY
            return
        self.failed = False
        if entries:
            self.entries += entries
            self._populate(entries, append=True)

    def _populate(self, entries, append=False):
        from resources.lib.modules import tmdb
        try:
            records = tmdb.load()
            home.mark_running({'grid': entries}, records)   # sarga "Új részek" / kek visszaszamlalas
            control_list = self.window.getControl(self.control_id)
            position = control_list.getSelectedPosition() if append else -1
            cursor = self._cursor() if append else None
            had_focus = self.window.getFocusId() == self.control_id
            if not append:
                control_list.reset()
            start = 0 if not append else control_list.size()
            control_list.addItems([list_item(entry, records) for entry in entries])
            self.window.refocus(self.control_id, had_focus)
            self._prefetch_badges(entries, records, start)
            # A Kodi a Pythonos addItems-re az EGESZ listat ujrakoti, es az
            # elso tetelre all (GUI_MSG_LABEL_BIND -> SelectItem(0)): a
            # kijelolest vissza kell allitani. Az ujrakotes utan a kivalasztas
            # azonnali (nincs gorgetes-animacio), de a Kodi a tetelt a lap
            # ALSO soraba tenne -- ha a nezo a felso sorban allt, a kep egy
            # sort ugrana. Ezert elobb a lap utolso soranak egy tetelet
            # valasztjuk (igy a lap eleje ugyanaz marad), aztan az igazit.
            if append and position >= 0:
                if cursor is not None:
                    first_row = (position - cursor) // GRID_PER_ROW
                    anchor = (first_row + GRID_ROWS - 1) * GRID_PER_ROW
                    control_list.selectItem(max(0, min(anchor, control_list.size() - 1)))
                control_list.selectItem(position)
        except Exception as exc:
            control.log_exception(u'%s: rács' % self.name, exc)

    def _cursor(self):
        '''A kijelolt tetel helye a latszo lapon belul (Container.Position), vagy None.'''
        try:
            value = xbmc.getInfoLabel('Container(%d).Position' % self.control_id)
            cursor = int(value)
        except (TypeError, ValueError):
            return None
        return cursor if 0 <= cursor < GRID_PER_ROW * GRID_ROWS else None

    def _prefetch_badges(self, entries, records, start):
        '''
        A racs uj teteleihez a TMDB-adat a hatterben (ahol meg nincs), hogy a
        futo sorozatokon megjelenjen a szalag es a szolgaltato; az eredmeny
        a queue-n at, a tick irja a tetelekre.
        '''
        import threading
        from resources.lib.modules import tmdb
        if not tmdb.api_key():
            return
        todo = [(start + index, entry) for index, entry in enumerate(entries)
                if home.imdb_of(entry) and home.imdb_of(entry) not in records]
        if not todo:
            return
        queue, key = self.queue, self.shown

        def work():
            try:
                tmdb.prefetch([entry.get('thumb') or '' for _i, entry in todo], stop=lambda: self.window.closed)
                fresh = tmdb.load()
                from resources.lib.modules import watchlist
                watched = watchlist.load()
                badges = []
                for index, entry in todo:
                    badge, kind = home.badge_for(entry, fresh, watched)
                    badges.append((index, badge, kind, home.service_sub(entry, fresh)))
                queue.append({'key': key, 'badges': badges, 'more': 'badges'})
            except Exception as exc:
                control.log_exception(u'%s: szalagok' % self.name, exc)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def _apply_badges(self, badges):
        '''A hatterben lekert szalagok / szolgaltatok a mar kirajzolt tetelekre (a kijeloles marad).'''
        try:
            control_list = self.window.getControl(self.control_id)
            for index, badge, kind, sub in badges:
                if index >= control_list.size():
                    continue
                item = control_list.getListItem(index)
                if badge:
                    item.setProperty('badge', badge)
                    item.setProperty('badgekind', kind)
                    if index < len(self.entries):
                        self.entries[index]['badge'], self.entries[index]['badgekind'] = badge, kind
                if sub and item.getLabel2() != sub:
                    item.setLabel2(sub)
        except Exception as exc:
            control.log_exception(u'%s: szalagok' % self.name, exc)

    def _fetch(self, key, feed, more):
        import threading
        self.busy = key
        queue = self.queue

        def work():
            try:
                entries = home.feed_page(feed)
            except Exception as exc:
                control.log_exception(u'%s: %s' % (self.name, key[1] or key[0]), exc)
                entries = None
            queue.append({'key': key, 'entries': entries, 'feed': feed, 'more': more})
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()


class HomeWindow(xbmcgui.WindowXML):
    """
    SZANDEKOSAN nincs sajat __init__ (lasd overlay.CommentOverlay): a Kodi
    a konstruktor argumentumait a __new__-nak is atadja. A sorokat a
    peldanyositas UTAN adjuk at (set_rows), az onInit rajzol.
    """
    rows = None
    ready = False
    closed = False
    trailer = None          # a hordozo adja (Trailer); OK-ra es zaraskor leall
    focus = None            # a hordozo adja (Focus): a reszletezo azonnal inditja az elozetest
    poster_count = POSTER_COUNT_DEFAULT   # ennyi poszterre keszult az ablak fajlja
    layout = (POSTER_COUNT_DEFAULT, False)  # (poszterek szama, erintos elrendezes)
    series = None           # a sorozat-nezet adatai, amig nyitva van
    series_result = None    # a hatterben letoltott evadok / reszadatok ide erkeznek
    detail = None           # a reszletezo nezet tetele, amig nyitva van
    detail_result = None    # a hatterben lekert TMDB-adat (leiras) ide erkezik
    plot_line = 0           # a leiras gorgetese (sor)
    search = None           # a kereso-nezet allapota, amig nyitva van
    search_grid = None      # a kereso racsa (Grid), az ablak eleteben egyszer
    search_genres = None    # a mufajok (egyszer lekerve az ablak eleteben)
    search_genres_result = None
    browse = None           # a bongeszo-nezet allapota (tipus, szurok), amig nyitva van
    browse_grid = None      # a bongeszo racsa (Grid)
    browse_states = None    # tipus -> a legutobbi szurok (visszanyitaskor ugyanott)
    browse_options = None   # a szurok valaszthato ertekei (egyszer lekerve)
    browse_options_result = None
    tonight = None          # a Mit nezzek ma este allapota, amig nyitva van
    tonight_results = None  # a hatterben sorsolt film ide erkezik
    provider = None         # a "Tovabb" nezet allapota (melyik szolgaltato), amig nyitva van
    provider_grid = None    # a "Tovabb" racsa (Grid), az ablak eleteben egyszer
    provider_results = None # a szolgaltato logoja ide erkezik
    lookup_results = None   # egy TMDB-cim netmozi-keresesenek eredmenye (Tovabb / streaming-szuro)
    lookup_busy = False
    menu = None             # a csempe helyi menuje (sajat ablak), amig nyitva van
    menu_source = None      # a helyi menu tetele (mufajok, IMDb) -- a kedvenc / szavazat ebbol tanul
    keep_focus = None       # torles utan ide kell a fokusz (a Kodi kulonben elvinne)
    focus_prev = 0          # ahonnan a fokusz a felso savra lepett (a lefele oda visz vissza)
    focus_lost = 0          # hany kor ota nincs fokusz sehol (a fokusz-or szamlaloja)
    sources = None          # a forras-nezet allapota, amig nyitva van
    sources_results = None  # a hatterben lekert forraslista / meres ide erkezik
    tonight_pages = None    # a mar letoltott valogatas-oldalak (az ablak eleteben)
    settings = None         # a beallitasok nezete, amig nyitva van
    profiles_open = False   # a Ki nez? kepernyo nyitva
    update_open = False     # a frissites ablaka nyitva
    update_results = None   # a hatterben lekert legfrissebb verzio ide erkezik
    update_requested = 0    # mikor kertuk a Kodit a frissitesre (a hordozo surubben nez)
    rows_dirty = False      # profilvaltas: a hordozo a halozati sorokat ujra lekeri
    local_dirty = False     # a helyi sorok (sajat lista, folytatas) ujra kellenek
    refresh_wanted = None   # 'all' (HOME gomb: minden frissen) / 'resume' (keszenletbol ebredes)
    settings_model = None   # a settings.xml ertelmezve (egyszer)
    layout_dirty = False    # elrendezest erinto beallitas valtozott: a hordozo ujranyit
    touched_at = 0.0        # az utolso erintes ideje (a gorgetosav lathatosagahoz)
    touch_shown = False     # a 'touched' tulajdonsag be van-e allitva

    def close(self):
        self.closed = True
        self.stop_trailer()
        try:
            xbmcgui.Window(10000).setProperty('netmozi.home', '')
        except Exception:
            pass
        xbmcgui.WindowXML.close(self)

    def stop_trailer(self):
        if self.trailer is not None:
            try:
                self.trailer.stop()
            except Exception:
                pass

    def refocus(self, list_id, had_focus):
        '''
        Egy lista ujratoltese (reset + addItems) utan: ha a fokusz rajta
        volt, visszaadjuk. A Kodi a kiuritett listat elengedi (nem tarthatja
        a fokuszt), es utana a nyilak semmire sem mennek -- csak a Vissza.
        '''
        if had_focus:
            try:
                self.setFocusId(list_id)
            except Exception:
                pass

    def set_rows(self, rows, replace=False):
        # A nyers sorokat orizzuk (raw_rows): az ismetlodesek kiszurese
        # mindig a teljes keszletbol indul, igy a sorok erkezesi sorrendje
        # nem szamit.
        self.raw_rows = {} if replace else dict(getattr(self, 'raw_rows', None) or {})
        self.raw_rows.update(home.mark_running(home.mark_new(rows or {})))
        self.refilter()

    def refilter(self):
        '''A sorok ujra a nyers keszletbol: borito nelkul nincs csempe, ismetles sincs.'''
        self.rows = home.dedupe_rows(home.with_covers(getattr(self, 'raw_rows', None) or {}))
        if self.ready and not self.closed:
            self.populate()

    def onInit(self):
        self.ready = True
        self.refresh_profile_button()
        # A lejatszo folyamat innen tudja, hogy a kezdokepernyo van elol
        # (a folyamatabrat mi rajzoljuk, nem a Kodi parbeszede).
        try:
            xbmcgui.Window(10000).setProperty('netmozi.home', '1')
            xbmcgui.Window(10000).setProperty('netmozi.home.id', str(xbmcgui.getCurrentWindowId()))
        except Exception:
            pass
        try:
            self.setProperty('backdrop', '1' if control.setting('homebackdrop') != 'false' else '')
        except Exception:
            self.setProperty('backdrop', '1')
        self.populate()
        self.focus_first_row()

    def populate(self):
        if self.closed:
            return
        from resources.lib.modules import tmdb
        records = tmdb.load()
        try:
            bar = self.getControl(TOP_BAR_ID)
            bar.reset()
            bar.addItems([list_item(entry) for entry in home.top_bar()])
        except Exception as exc:
            control.log_exception(u'kezdőképernyő: felső sáv', exc)
        titles = home.row_titles()
        favs = favorite_marks()
        for key, (group_id, list_id) in ROW_IDS.items():
            items = (self.rows or {}).get(key) or []
            try:
                # A csoport lathatosagat az XML egy ablak-tulajdonsagbol veszi:
                # ures sor -> ures tulajdonsag -> eltunik. A cim is tulajdonsag
                # (a mese-profilban mas).
                self.setProperty('row-%d' % group_id, '1' if items else '')
                self.setProperty('title-%d' % group_id, titles.get(key, u''))
                control_list = self.getControl(list_id)
                had_focus = self.getFocusId() == list_id
                mark = row_mark(control_list)
                control_list.reset()
                if items:
                    control_list.addItems([list_item(entry, records, favs) for entry in items])
                    # Ugyanarra a boritora allunk vissza, amin alltunk: a
                    # hatterben frissulo sor nem rantja el a nezot (es nem
                    # indul el egy masik elozetes).
                    restore_mark(control_list, items, mark)
                    self.refocus(list_id, had_focus)
            except Exception as exc:
                control.log_exception(u'kezdőképernyő: %s sor' % key, exc)

    def refresh_badges(self, records=None):
        '''
        A szolgaltato-feliratok frissitese HELYBEN (a listak ujraepitese
        nelkul, hogy a kijeloles maradjon), miutan a hatterben megjottek
        a TMDB adatok. Visszaad: hany tetel valtozott.
        '''
        if self.closed:
            return 0
        from resources.lib.modules import tmdb
        records = tmdb.load() if records is None else records
        changed = 0
        for key, (_group_id, list_id) in ROW_IDS.items():
            entries = (self.rows or {}).get(key) or []
            try:
                control_list = self.getControl(list_id)
                for index, entry in enumerate(entries[:control_list.size()]):
                    label = home.service_sub(entry, records)
                    item = control_list.getListItem(index)
                    if item.getLabel2() != label:
                        item.setLabel2(label)
                        changed += 1
            except Exception as exc:
                control.log_exception(u'kezdőképernyő: %s feliratok' % key, exc)
        return changed

    def focus_first_row(self):
        for key, _title in home.ROWS:
            if (self.rows or {}).get(key):
                try:
                    self.setFocusId(ROW_IDS[key][1])
                    return
                except Exception:
                    pass
        try:
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def overlay_open(self):
        '''Van-e olyan nezet nyitva, amiben a sorok rejtve vannak.'''
        return (self.menu is not None or self.update_open or self.sources is not None
                or self.provider is not None or self.in_grid_view())

    def view_focus_ids(self):
        '''
        A mostani nezet fokuszalhato vezerloi, fontossagi sorrendben. Ebbol
        valaszt a fokusz-or es a felso savrol lefele lepes -- ures, ha a
        sorok latszanak (ott a focus_first_row a jo).
        '''
        if self.menu is not None:
            return (MENU_LIST_ID,)
        if self.update_open:
            return (UPDATE_BUTTON_ID,)
        if self.sources is not None:
            return (SOURCES_LIST_ID,)
        if self.series is not None:
            return (EPISODES_LIST_ID, SEASONS_LIST_ID)
        if self.detail is not None:
            return (DETAIL_LIST_ID,)
        if self.provider is not None:
            return (PROVIDER_GRID_ID,)
        if self.profiles_open:
            return (PROFILES_LIST_ID,)
        if self.settings is not None:
            return (SETTINGS_SECTIONS_ID, SETTINGS_ITEMS_ID)
        if self.tonight is not None:
            return (TONIGHT_GENRES_ID, TONIGHT_BUTTONS_ID)
        if self.browse is not None:
            return ((self.browse.get('pick') or BROWSE_MENU_ID), BROWSE_MENU_ID, BROWSE_RESULTS_ID)
        if self.search is not None:
            # Kategoria-modban a betűrács REJTVE van: oda a fokusz elveszne.
            return ((SEARCH_GENRES_BIG_ID if self.genre_mode() else SEARCH_KEYS_ID),
                    SEARCH_RESULTS_ID)
        return ()

    def can_focus(self, control_id):
        '''Kaphat-e fokuszt: letezik, latszik, es ha lista, nem ures. (A Kodi
        a rejtett vezerlore allitott fokuszt ELEJTI: utana semmi nem reagal.)'''
        if not control_id or control_id in TOP_IDS:
            return False
        try:
            found = self.getControl(control_id)
        except Exception:
            return False
        try:
            if not found.isVisible():
                return False
        except Exception:
            pass                      # regebbi Kodi / nem lista: a meret dont
        try:
            return found.size() > 0
        except Exception:
            return True               # gomb: eleg, hogy latszik

    def focus_view_default(self):
        '''A mostani nezet elso hasznalhato vezerlojere allunk.'''
        ids = self.view_focus_ids()
        for control_id in ids:
            if self.can_focus(control_id):
                try:
                    self.setFocusId(control_id)
                    return True
                except Exception:
                    pass
        if not ids:
            self.focus_first_row()
            return True
        try:
            self.setFocusId(TOP_BAR_ID)     # vegso menedek: a felso sav mindig ott van
        except Exception:
            pass
        return False

    def focus_below_bar(self):
        '''A felso savrol lefele: oda, ahonnan feljottunk, kulonben a nezet elejere.'''
        if self.focus_prev in self.view_focus_ids() and self.can_focus(self.focus_prev):
            try:
                self.setFocusId(self.focus_prev)
                return
            except Exception:
                pass
        self.focus_view_default()

    def focused_thumb(self):
        '''A fokuszalt lista kijelolt tetelenek boritoja (a reszletezoben a tetele), vagy ''.'''
        if self.detail:
            return self.detail.get('thumb') or ''
        item = self.selected(self.getFocusId())
        if item is None or item.getProperty('more'):
            return ''                                # a "Tovabb" csempe nem hatterkep
        return item.getProperty('thumb')

    def focused_imdb(self):
        '''A fokuszalt tetel IMDb-azonositoja, vagy ''.'''
        if self.detail:
            return self.detail.get('imdb') or ''
        item = self.selected(self.getFocusId())
        return item.getProperty('imdb') if item is not None else ''

    def in_detail(self):
        return self.detail is not None

    def populate_detail_buttons(self, entry, keep=False):
        '''A reszletezo gombsora; keep: a kijeloles marad (pl. kedvenc / szavazat utan).'''
        try:
            control_list = self.getControl(DETAIL_LIST_ID)
            had_focus = self.getFocusId() == DETAIL_LIST_ID
            position = control_list.getSelectedPosition() if keep else 0
            control_list.reset()
            buttons = []
            no_torrent = self.getProperty('detail.ncore') == 'no'
            for label, mode, query, glyph in home.detail_buttons(entry):
                if no_torrent and query.startswith('ncoreplay'):
                    continue                             # nincs torrent: nincs mit mutatni
                button = xbmcgui.ListItem(label=label)
                button.setProperty('mode', mode)
                button.setProperty('query', query)
                button.setProperty('glyph', glyph)
                # a fo gomb piros kor, a tobbi kerek ikon; a torles pirosas; a bekapcsolt (kedvenc, szavazat) piros
                button.setProperty('primary', '1' if glyph == home.PLAY_GLYPH else '')
                button.setProperty('icon', home.action_icon(query))
                button.setProperty('danger', '1' if home.is_remove(query) else '')
                button.setProperty('on', '1' if home.is_taste(query) and home.taste_on(query) else '')
                # A hatter (kivagott borito) a fokuszalt lista tetelenek kepe:
                # a gombokon is a borito, hogy ne tunjon el.
                if entry.get('thumb'):
                    button.setArt({'icon': entry['thumb'], 'thumb': entry['thumb']})
                buttons.append(button)
            control_list.addItems(buttons)
            if keep and 0 <= position < len(buttons):
                control_list.selectItem(position)
            self.refocus(DETAIL_LIST_ID, had_focus)
        except Exception as exc:
            control.log_exception(u'részletező gombjai', exc)

    def taste_local(self, query, title=u'', thumb=u''):
        '''Kedvenc / tetszik / nem tetszik helyben: a gomb es a sorok azonnal frissulnek.'''
        entry = self.detail if self.detail is not None else (self.menu_source or {})
        genres = entry.get('genres') or []
        imdb = home.imdb_of(entry)
        if not genres and imdb:
            genres = (home.title_info(imdb, cached_only=True) or {}).get('genres') or []
        done, message = home.taste_local(query, entry.get('label') or title, entry.get('thumb') or thumb, genres, imdb)
        if not done:
            return
        self.refresh_fav_marks()                         # a sziv AZONNAL (elozetes kozben is)
        if not genres and imdb:
            self.fill_taste_genres(query, imdb)
        control.infoDialog(message)
        if self.detail is not None:
            self.populate_detail_buttons(self.detail, keep=True)
        self.local_dirty = True

    def refresh_fav_marks(self):
        '''A sorok boritoin a sziv, ujratoltes nelkul (a sorok csak lejatszas utan toltodnek ujra).'''
        favs = favorite_marks()
        for _group_id, list_id in ROW_IDS.values():
            try:
                control_list = self.getControl(list_id)
                for index in range(control_list.size()):
                    li = control_list.getListItem(index)
                    on = not li.getProperty('more') and (taste_page(li.getProperty('query')) in favs
                                                         or (li.getProperty('imdb') or '-') in favs)
                    li.setProperty('fav', '1' if on else '')
            except Exception as exc:
                control.log_exception(u'kedvenc-jelzés', exc)

    def fill_taste_genres(self, query, imdb):
        '''A mufaj meg nem ismert (nincs a tarban): a TMDB-bol a hatterben, hogy az izlesbe beszamitson.'''
        import threading
        from resources.lib.modules import taste

        def work():
            try:
                taste.set_genres(home._page_of(query), (home.title_info(imdb) or {}).get('genres') or [])
            except Exception as exc:
                control.log_exception(u'ízlés: műfajok', exc)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def update_hero(self, record=None):
        '''
        A sorok feletti adatok: a fokuszalt tetel cime, adatai (ev, mufaj,
        hossz, IMDb) es a jelzes / megnezett resz. Csak a sorokban allva
        valtozik (a felso savon az utolso marad).
        '''
        focus = self.getFocusId()
        if focus not in ROW_LIST_IDS:
            return
        item = self.selected(focus)
        if item is None or item.getProperty('more'):
            for name in ('hero.title', 'hero.meta', 'hero.info'):
                self.setProperty(name, u'')
            return
        entry = {'query': item.getProperty('query'), 'sub': item.getProperty('sub'), 'sub2': item.getProperty('sub2')}
        try:
            line2, line3, _plot = home.detail_lines(entry, record or {})
        except Exception as exc:
            control.log_exception(u'kezdőképernyő: adatok felül', exc)
            line2, line3 = entry['sub2'], entry['sub']
        badge = item.getProperty('badge')
        self.setProperty('hero.title', item.getLabel())
        self.setProperty('hero.meta', line2 or u'')
        self.setProperty('hero.info', u'  ·  '.join(part for part in (badge, line3) if part))

    # --- Sorozat-nezet: evadok es reszek ----------------------------------------

    def open_series(self):
        '''A reszletezo "Evadok" gombjara: az evadok sora es a reszek, itt az ablakban.'''
        import threading
        entry = self.detail or {}
        base = home._page_of(entry.get('query') or '')
        if not base:
            return
        self.series = {'base': base, 'imdb': entry.get('imdb') or '', 'thumb': entry.get('thumb') or '',
                       'seasons': None, 'shown': None, 'start': None}
        # Az evadok megnyitasa = a nezo latta, hogy van uj resz: a piros
        # jelzes lekerul (mint a regi menuben), es a sajat lista sora ujul
        # -- ott mar a kovetkezo resz visszaszamlalasa jon.
        try:
            from resources.lib.modules import watchlist
            if watchlist.clear_new(base):
                self.local_dirty = True
        except Exception as exc:
            control.log_exception(u'sorozat-nézet: jelzés levétele', exc)
        self.setProperty('series', '1')
        result = {}
        self.series_result = result
        if entry.get('seasons_data') is not None:
            # Az evadok mar megvannak (a reszletezo lekerte): nincs uj letoltes.
            result['seasons'] = entry['seasons_data']
            self.series_tick()
            control.log(u'Sorozat-nézet: %s' % entry.get('label', base))
            return

        def work():
            try:
                from resources.lib.indexers import navigator
                html, _details = navigator.navigator().seriesPage(base)
                result['seasons'] = home.series_seasons(html) if html else []
            except Exception as exc:
                control.log_exception(u'sorozat-nézet: évadok', exc)
                result['seasons'] = []
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()
        control.log(u'Sorozat-nézet: %s' % entry.get('label', base))

    def label_seasons_button(self, seasons):
        '''Az "Evadok" gomb feliratat az utolso evad szamara cserel ("3. évad").'''
        try:
            control_list = self.getControl(DETAIL_LIST_ID)
            for index in range(control_list.size()):
                item = control_list.getListItem(index)
                if item.getProperty('query').startswith('series&url='):
                    item.setLabel(home.seasons_label(seasons))
        except Exception as exc:
            control.log_exception(u'részletező: évadok gombja', exc)

    def close_series(self):
        if self.series is None:
            return
        self.series = None
        self.series_result = None
        self.setProperty('series', '')
        try:
            self.getControl(SEASONS_LIST_ID).reset()
            self.getControl(EPISODES_LIST_ID).reset()
            self.setFocusId(DETAIL_LIST_ID)
        except Exception:
            pass

    def series_tick(self):
        '''A hordozo hivja: az evadok megjottek -> sor; a kijelolt evad valtott -> reszek.'''
        if self.series is None:
            return
        result = self.series_result or {}
        if 'seasons' in result:
            self.series['seasons'] = result.pop('seasons')
            self.series['start'] = home.series_start(self.series['base'], self.series['seasons'])
            self.populate_seasons()
        if 'meta' in result:
            season, meta = result.pop('meta')
            if season == self.series.get('shown'):
                self.series['meta'] = meta
                self.populate_episodes(season, meta, self.series.get('avail'))
        if 'avail' in result:
            season, avail = result.pop('avail')
            if season == self.series.get('shown'):
                self.series['avail'] = avail
                self.update_availability(avail)
        seasons = self.series.get('seasons') or []
        if not seasons:
            return
        try:
            position = self.getControl(SEASONS_LIST_ID).getSelectedPosition()
        except Exception:
            position = -1
        if 0 <= position < len(seasons):
            season = seasons[position][0]
            if season != self.series.get('shown'):
                self.show_season(season)

    def populate_seasons(self):
        seasons = self.series.get('seasons') or []
        try:
            control_list = self.getControl(SEASONS_LIST_ID)
            had_focus = self.getFocusId() == SEASONS_LIST_ID
            control_list.reset()
            items = []
            for season, numbers in seasons:
                li = xbmcgui.ListItem(label=u'%d. évad' % season)
                li.setProperty('season', str(season))
                # Hosszan nyomva: az egesz evad megnezettnek jelolheto.
                li.setProperty('context', json.dumps(home.season_context(self.series['base'], season)))
                if self.series.get('thumb'):
                    li.setArt({'icon': self.series['thumb'], 'thumb': self.series['thumb']})
                items.append(li)
            control_list.addItems(items)
            self.refocus(SEASONS_LIST_ID, had_focus)
            if items:
                # Az utolso evad (vagy ahol a folytatas tart) legyen kijelolve.
                start = self.series.get('start')
                index = next((i for i, (season, _n) in enumerate(seasons) if start and season == start[0]), len(seasons) - 1)
                control_list.selectItem(index)
                self.setFocusId(SEASONS_LIST_ID)
        except Exception as exc:
            control.log_exception(u'sorozat-nézet: évadok sora', exc)
        if not seasons:
            control.infoDialog(u'Ehhez a sorozathoz nem találtam részeket.')

    def show_season(self, season):
        '''A kivalasztott evad reszei: ami megvan (allokep, cim), azonnal; a tobbi jon.'''
        import threading
        from resources.lib.modules import episodes as episodes_mod
        self.series['shown'] = season
        self.series['meta'] = None
        self.series['avail'] = None
        imdb = self.series.get('imdb') or ''
        meta = episodes_mod.cached(imdb, season) if imdb else {}
        self.series['meta'] = meta
        self.populate_episodes(season, meta or {}, None)
        start = self.series.get('start')
        if start and start[0] == season:
            # Megnyitaskor: a fokusz egybol a reszen (az utolso evad elso
            # resze, vagy ahol a folytatas tart); az evadok sora fentebb elerheto.
            self.series['start'] = None
            numbers = dict(self.series.get('seasons') or []).get(season) or []
            try:
                control_list = self.getControl(EPISODES_LIST_ID)
                control_list.selectItem(numbers.index(start[1]) if start[1] in numbers else 0)
                self.setFocusId(EPISODES_LIST_ID)
            except Exception:
                pass
        result = self.series_result if self.series_result is not None else {}
        self.series_result = result
        base = self.series['base']
        numbers = dict(self.series.get('seasons') or []).get(season) or []
        window = self

        def work():
            if imdb and meta is None:
                try:
                    result['meta'] = (season, episodes_mod.season(imdb, season) or {})
                except Exception as exc:
                    control.log_exception(u'sorozat-nézet: részadatok', exc)
                    result['meta'] = (season, {})
            # Elerhetoseg: nCore egy keresessel, netmozi reszenkent -- ahogy
            # jon, a csempek frissulnek (a ciklus irja ki).
            try:
                from resources.lib.modules import availability, ncore
                from resources.lib.indexers import navigator
                fetch = navigator.navigator().siteSources
                availability.season(base, imdb, season, numbers, fetch, ncore.enabled(),
                                    stop=lambda: window.series is None or window.series.get('shown') != season,
                                    progress=lambda partial: result.__setitem__('avail', (season, partial)))
            except Exception as exc:
                control.log_exception(u'sorozat-nézet: elérhetőség', exc)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def populate_episodes(self, season, meta, avail):
        numbers = dict(self.series.get('seasons') or []).get(season) or []
        entries = home.episode_items(self.series['base'], season, numbers, self.series.get('thumb'), meta, avail)
        # A bejelentett kovetkezo resz (ha ebbe az evadba esik) halvanyan a vegen.
        try:
            from resources.lib.modules import tmdb
            soon = home.soon_episode_item(season, numbers, tmdb.cached(self.series.get('imdb') or '') or {})
            if soon:
                entries.append(soon)
        except Exception as exc:
            control.log_exception(u'sorozat-nézet: következő rész', exc)
        try:
            control_list = self.getControl(EPISODES_LIST_ID)
            position = control_list.getSelectedPosition()
            had_focus = self.getFocusId() == EPISODES_LIST_ID
            control_list.reset()
            control_list.addItems([list_item(entry) for entry in entries])
            if 0 <= position < len(entries):
                control_list.selectItem(position)
            self.refocus(EPISODES_LIST_ID, had_focus)
        except Exception as exc:
            control.log_exception(u'sorozat-nézet: részek', exc)

    def update_availability(self, avail):
        '''A pipak a csempeken HELYBEN (a lista ujraepitese nelkul).'''
        numbers = dict(self.series.get('seasons') or []).get(self.series.get('shown')) or []
        try:
            control_list = self.getControl(EPISODES_LIST_ID)
            for index, number in enumerate(numbers[:control_list.size()]):
                state = (avail or {}).get(int(number)) or {}
                item = control_list.getListItem(index)
                for key in ('netmozi', 'ncore'):
                    value = state.get(key) or ''
                    if item.getProperty(key) != value:
                        item.setProperty(key, value)
        except Exception as exc:
            control.log_exception(u'sorozat-nézet: pipák', exc)

    # --- Reszletezo nezet -----------------------------------------------------

    def open_detail(self, item, list_id):
        '''
        OK egy boriton: nem indul semmi -- a tetel bal lent, mellette a
        gombok (Lejatszas, Forrasok, nCore, helyi menu), nagyban az elozetes.
        Vissza: a lista, ugyanott.
        '''
        try:
            position = self.getControl(list_id).getSelectedPosition()
        except Exception:
            position = 0
        try:
            context = json.loads(item.getProperty('context') or '[]')
        except ValueError:
            context = []
        entry = {'label': item.getLabel(), 'sub': item.getProperty('sub'),
                 'sub2': item.getProperty('sub2'), 'thumb': item.getProperty('thumb'),
                 'mode': item.getProperty('mode'), 'query': item.getProperty('query'),
                 'context': context, 'imdb': item.getProperty('imdb')}
        try:
            entry['genres'] = json.loads(item.getProperty('genres') or '[]')
        except ValueError:
            entry['genres'] = []
        self.show_detail(entry, list_id, position)

    def show_detail(self, entry, list_id, position):
        '''A reszletezo egy tetelre (a listak OK-ja es a Mit nezzek ma este is ide jon).'''
        self.detail = dict(entry, list_id=list_id, position=position)
        imdb = entry['imdb']
        record = home.title_info(imdb, cached_only=True) if imdb else {}
        which = home.detail_episode(entry) if imdb else None
        episode = None
        if which:
            from resources.lib.modules import episodes as episodes_mod
            known = episodes_mod.cached(imdb, which[0])
            if known is not None:
                episode = dict(known.get(str(which[1])) or {}, season=which[0], episode=which[1])
        self.detail_episode = which
        self.render_detail(entry, record or {}, episode)
        if imdb and (not (record or {}).get('complete') or (which and episode is None)):
            self.fetch_details(imdb, which)
        self.fetch_availability(entry)
        self.populate_detail_buttons(entry)
        self.setProperty('detail', '1')
        try:
            self.setFocusId(DETAIL_LIST_ID)
        except Exception:
            pass
        if self.trailer is not None:
            self.trailer.played_for = None           # a reszletezoben ujra (azonnal) megy
            # Nem varunk a kovetkezo felmasodperces korre: a keslelteto beallitas
            # itt nem szamit, az elozetes MOST induljon (ha mar fel van oldva).
            if self.focus is not None:
                try:
                    self.focus.tick()
                    self.trailer.tick(self.focus, self.trailer.player.isPlaying())
                except Exception as exc:
                    control.log_exception(u'részletező: előzetes indítása', exc)
        control.log(u'Részletező: %s' % entry['label'])
        # A sajat listarol megnyitva a nezo latta, hogy van uj resz: a piros
        # jelzes lekerul (a regi menuben a "watchopen" ezt csinalta), es a
        # sor ujul -- ott mar a kovetkezo resz visszaszamlalasa johet.
        if (entry.get('query') or '').startswith('watchopen&url='):
            try:
                from resources.lib.modules import watchlist
                if watchlist.clear_new(home._page_of(entry['query'])):
                    self.local_dirty = True
            except Exception as exc:
                control.log_exception(u'részletező: jelzés levétele', exc)

    detail_episode = None

    def render_detail(self, entry, record, episode=None):
        line2, line3, plot = home.detail_lines(entry, record, episode)
        self.plot_line = 0
        self.setProperty('detail.thumb', entry.get('thumb') or '')
        self.setProperty('detail.title', entry.get('label') or u'')
        self.setProperty('detail.line2', line2)
        self.setProperty('detail.line3', line3)
        self.setProperty('detail.plot', plot)
        # A resz allokepe (16:9) a poszter helyen, ha van.
        self.setProperty('detail.still', (episode or {}).get('still') or '')

    def fetch_details(self, imdb, which=None):
        '''A cim (es a resz) adatai a hatterben; a hordozo ciklusa (detail_tick) irja ki.'''
        import threading
        result = {}
        self.detail_result = result

        def work():
            try:
                result['record'] = home.title_info(imdb) or {}
            except Exception as exc:
                control.log_exception(u'részletező: adatok', exc)
                result['record'] = {}
            if which:
                try:
                    from resources.lib.modules import episodes as episodes_mod
                    data = episodes_mod.info(imdb, which[0], which[1])
                    result['episode'] = dict(data, season=which[0], episode=which[1]) if data else None
                except Exception as exc:
                    control.log_exception(u'részletező: rész adatai', exc)
                    result['episode'] = None
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def fetch_availability(self, entry):
        '''
        Van-e forras a netmozin (film: az adatlap forrastablaja) es az
        nCore-on (ha be van allitva) -- a hatterben; a 3. sor pipai.
        '''
        import threading
        from resources.lib.modules import ncore
        kind, page = home.detail_kind(entry)
        imdb = entry.get('imdb') or ''
        want_ncore = bool(imdb) and ncore.enabled()
        self.setProperty('detail.netmozi', 'wait' if kind in ('film', 'series') else '')
        self.setProperty('detail.ncore', 'wait' if want_ncore else '')
        self.avail_result = None
        if kind not in ('film', 'series') and not want_ncore:
            return
        result = {}
        self.avail_result = result

        def work():
            if kind in ('film', 'series'):
                try:
                    from resources.lib.indexers import navigator
                    nav = navigator.navigator()
                    target = page
                    if kind == 'series':
                        # Sorozat: a forrasok reszenkent vannak -- az elso resz
                        # forrastablaja donti el (sorozatoldal + egy resz). Az
                        # evadok listaja is innen jon (a gomb feliratahoz, es a
                        # sorozat-nezet igy nem tolti le ujra).
                        from resources.lib.modules import watchlist
                        html, _details = nav.seriesPage(page)
                        listed = watchlist.listed_episodes(html) if html else []
                        result['seasons'] = home.series_seasons(html) if html else []
                        target = watchlist.episode_path(page, listed[0]) if listed else ''
                    if target:
                        _details, sources = nav.siteSources(target)
                        result['netmozi'] = 'yes' if any(s.get('valid') for s in sources or []) else 'no'
                    else:
                        result['netmozi'] = 'no'
                except Exception as exc:
                    control.log_exception(u'részletező: netmozi források', exc)
                    result['netmozi'] = 'no'
            if want_ncore:
                try:
                    torrents = ncore.sources_for(imdb, 'series' if kind == 'series' else 'film')
                    result['ncore'] = 'yes' if any(t.get('valid') for t in torrents or []) else 'no'
                except Exception as exc:
                    control.log_exception(u'részletező: nCore', exc)
                    result['ncore'] = 'no'
            result['done'] = True
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    avail_result = None

    def detail_tick(self):
        '''A hordozo hivja: ha megjott a leiras vagy a forras-ellenorzes, kiirja.'''
        if self.detail is None:
            return
        if self.avail_result and self.avail_result.get('done'):
            result = self.avail_result
            self.avail_result = None
            for key in ('netmozi', 'ncore'):
                if key in result:
                    self.setProperty('detail.%s' % key, result[key])
            if result.get('ncore') == 'no' and self.detail is not None:
                self.populate_detail_buttons(self.detail, keep=True)     # az nCore gomb kikerul
            if 'seasons' in result:
                self.detail['seasons_data'] = result['seasons']
                self.label_seasons_button(result['seasons'])
        if not self.detail_result or 'record' not in self.detail_result:
            return
        record = self.detail_result.pop('record')
        episode = self.detail_result.pop('episode', None)
        self.detail_result = None
        self.render_detail(self.detail, record, episode)

    def close_detail(self):
        if self.series is not None:
            self.close_series()
        if self.detail is None:
            return
        list_id, position = self.detail.get('list_id'), self.detail.get('position', 0)
        self.detail = None
        self.detail_result = None
        self.avail_result = None
        self.setProperty('detail', '')
        self.setProperty('detail.netmozi', '')
        self.setProperty('detail.ncore', '')
        self.setProperty('detail.still', '')
        try:
            self.setFocusId(list_id)
            self.getControl(list_id).selectItem(position)
        except Exception:
            pass

    def selected(self, control_id):
        if not control_id:
            return None                              # nincs fokusz: a Kodi a 0-ra hibat naplozna
        try:
            return self.getControl(control_id).getSelectedItem()
        except Exception:
            return None

    def onClick(self, control_id):
        if control_id == HOME_BUTTON_ID:
            self.go_home()
            return
        if control_id == PROFILE_BUTTON_ID:
            self.open_profiles()
            return
        if control_id == UPDATE_BUTTON_ID:
            if not self.updating():
                self.close_update()
            return
        if control_id == PROFILES_LIST_ID:
            item = self.selected(control_id)
            if item is not None:
                self.pick_profile(item.getProperty('name'))
            return
        if control_id == BACK_BUTTON_ID:
            # Telefonon a jobb felso sarok gombja = a Vissza gomb.
            if self.series is not None:
                self.close_series()
            elif self.detail is not None:
                self.close_detail()
            return
        item = self.selected(control_id)
        if item is None:
            return
        if control_id == DETAIL_LIST_ID and item.getProperty('query').startswith('series&url=') \
                and self.detail is not None:
            self.open_series()
            return
        if control_id == DETAIL_LIST_ID and item.getProperty('query').startswith('ncoreplay&url=') \
                and self.has_grid_views():
            # Az nCore gomb: a torrentek listaja (nem indul vakon); az elso sor a lejatszas.
            query = item.getProperty('query')
            self.open_sources(home.mark_query(query)[1], (self.detail or {}).get('label') or u'',
                              (self.detail or {}).get('thumb') or u'', play_query=query, ncore_only=True)
            return
        if control_id == SEASONS_LIST_ID:
            try:
                self.setFocusId(EPISODES_LIST_ID)
            except Exception:
                pass
            return
        if control_id == SEARCH_KEYS_ID:
            self.type_key(item.getLabel())
            return
        if control_id == SEARCH_EDIT_ID:
            self.type_key(item.getProperty('key'))
            return
        if control_id in (SEARCH_GENRES_ID, SEARCH_GENRES_BIG_ID):
            self.pick_genre(item.getProperty('value'), item.getLabel())
            return
        if control_id == BROWSE_MENU_ID:
            self.open_filter(int(item.getProperty('list') or 0))
            return
        if control_id == MENU_LIST_ID:
            self.menu_click()
            return
        if control_id == SOURCES_LIST_ID:
            self.sources_click(item)
            return
        if control_id == PROVIDER_YEARS_ID:
            self.provider_year(item.getProperty('year'))
            return
        if control_id == PROVIDER_GRID_ID:
            self.provider_click(item)
            return
        if item.getProperty('query').startswith('providermore&key=') and self.has_grid_views():
            # Honnan nyitottuk: a Vissza ide (ugyanarra a csempere) hoz majd.
            position = 0
            try:
                position = max(self.getControl(control_id).getSelectedPosition(), 0)
            except Exception:
                pass
            self.open_provider(item.getProperty('query').split('=', 1)[1], (control_id, position))
            return
        if control_id in BROWSE_FILTER_IDS:
            self.pick_filter(control_id, item.getProperty('value'))
            self.close_filter()
            return
        if control_id == TONIGHT_GENRES_ID:
            self.pick_tonight_genre(item.getProperty('value'))
            return
        if control_id == TONIGHT_BUTTONS_ID:
            self.tonight_button(item.getProperty('key'))
            return
        if control_id == SETTINGS_SECTIONS_ID:
            self.settings_tick()
            try:
                self.setFocusId(SETTINGS_ITEMS_ID)
            except Exception:
                pass
            return
        if control_id == SETTINGS_ITEMS_ID:
            self.activate_setting(item.getProperty('id'))
            return
        if control_id == TOP_BAR_ID and self.has_grid_views():
            # TV-n a sajat kereso- / bongeszo- / Mit nezzek / beallitas nezet; telefonon (meg) a Kodie.
            query = item.getProperty('query')
            if query == 'newsearch':
                self.open_search()
                return
            if query == 'tonight':
                self.open_tonight()
                return
            if query.startswith('Addon.OpenSettings('):
                self.open_settings()
                return
            if query == 'updatecheck':
                self.open_update()
                return
            tipus = browse_kind_of(query)
            if tipus:
                self.open_browse(tipus)
                return
        if control_id in (TOP_BAR_ID, DETAIL_LIST_ID, EPISODES_LIST_ID):
            title = (self.detail or {}).get('label') or item.getLabel()
            thumb = (self.detail or {}).get('thumb') or item.getProperty('thumb') or ''
            if control_id == EPISODES_LIST_ID and item.getLabel():
                title = u'%s – %s' % ((self.detail or {}).get('label') or u'', item.getLabel())
            self.dispatch(item.getProperty('mode'), item.getProperty('query'), title, thumb)
            return
        if control_id == BROWSE_RESULTS_ID and item.getProperty('query').startswith('provideropen'):
            # Streaming-szuro: a TMDB-cim -- elobb megkeressuk a netmozin.
            self.provider_click(item, BROWSE_RESULTS_ID)
            return
        if control_id == SEARCH_RESULTS_ID:
            if item.getProperty('query').startswith('adultplay'):
                # A rejtett lista tetele: egybol indul (nincs reszletezo, nincs elozmeny).
                self.dispatch('play', item.getProperty('query'), item.getLabel(), item.getProperty('thumb') or '')
                return
            self.remember_query()
        # Egy borito: a reszletezo nyilik, nem indul semmi.
        self.open_detail(item, control_id)

    def onAction(self, action):
        code = action.getId()
        if is_touch_action(code):
            self.note_touch()
        if self.keep_focus and code in MOVE_ACTIONS + CLOSE_ACTIONS:
            self.keep_focus = None        # a nezo lepett: nem tartjuk tovabb
        if code in CLOSE_ACTIONS:
            from resources.lib.modules import playprogress
            if playprogress.is_active():
                # A lejatszas inditasa megy: a Vissza megszakitja (a lejatszo folyamat latja).
                if playprogress.step() == playprogress.STEP_FAIL:
                    playprogress.clear()
                else:
                    playprogress.cancel()
                    playprogress.update(playprogress.STEP_FAIL, u'Megszakítva.')
                return
            if self.menu is not None:
                self.close_menu()
            elif self.update_open:
                if not self.updating():
                    self.close_update()               # frissites kozben az ablak marad
            elif self.sources is not None:
                self.close_sources()
            elif self.series is not None:
                self.close_series()
            elif self.detail is not None:
                self.close_detail()
            elif self.search is not None:
                self.close_search()
            elif self.browse is not None:
                if self.browse.get('pick'):
                    self.close_filter()
                else:
                    self.close_browse()
            elif self.tonight is not None:
                self.close_tonight()
            elif self.provider is not None:
                self.close_provider()
            elif self.settings is not None:
                if self.settings.get('editing'):
                    self.settings['editing'] = None       # a szerkesztes vege, a nezet marad
                    self.populate_settings_items(keep=True)
                else:
                    self.close_settings()
            elif self.profiles_open:
                self.close_profiles()
            elif code == ACTION_PREVIOUS_MENU or not self.has_grid_views():
                # A gyokerben: TV-n csak a HOSSZU Vissza lep ki (a keymap
                # PreviousMenu-t ad ra; a rovid a Back). Telefonon a rovid is.
                self.close()
            else:
                control.log(u'Vissza a kezdőképernyőn: kilépéshez nyomd hosszan')
            return
        if code in CONTEXT_ACTIONS:
            if self.profiles_open and self.getFocusId() == PROFILES_LIST_ID:
                item = self.selected(PROFILES_LIST_ID)
                if item is not None:
                    self.profile_menu(item.getProperty('name'))
                return
            self.context_menu()
            return
        # Kategoria-mod (a kereso bal oldalan): a lista tetejerol felfele
        # visszahozza a betűrácsot; a racsrol balra a kategoriakra lep.
        if self.genre_mode():
            focus = self.getFocusId()
            if focus == SEARCH_GENRES_BIG_ID and code == ACTION_MOVE_UP:
                try:
                    at_top = self.getControl(SEARCH_GENRES_BIG_ID).getSelectedPosition() <= 0
                except Exception:
                    at_top = True
                if at_top:
                    self.leave_genre_mode()
                    return
            elif focus == SEARCH_RESULTS_ID and code == ACTION_MOVE_LEFT:
                try:
                    self.setFocusId(SEARCH_GENRES_BIG_ID)
                except Exception:
                    pass
                return
        # A felso savrol lefele, ha a sorok rejtve vannak (kereso, bongeszo,
        # Mit nezzek, beallitasok, Ki nez?, Tovabb): a Kodi nem talal celt, a
        # fokusz a savon maradna. Oda visszuk, ahonnan feljottunk.
        if self.overlay_open() and code == ACTION_MOVE_DOWN \
                and self.getFocusId() in TOP_IDS:
            self.focus_below_bar()
            return
        # A beallitasok sorain a bal/jobb: szerkesztes kozben az ertek lep;
        # kulonben balra a szakaszok (a lista fuggoleges, a Kodi nem visz sehova).
        if self.settings is not None and self.detail is None and self.getFocusId() == SETTINGS_ITEMS_ID \
                and code in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
            if self.settings.get('editing'):
                self.step_setting(1 if code == ACTION_MOVE_RIGHT else -1)
            elif code == ACTION_MOVE_LEFT:
                try:
                    self.setFocusId(SETTINGS_SECTIONS_ID)
                except Exception:
                    pass
            return
        if self.browse is not None and code in MOVE_ACTIONS:
            self.browse['autofocus'] = False
        if self.tonight is not None and code in MOVE_ACTIONS:
            self.tonight['moved'] = True
        # A reszletezoben fel-le: a leiras gorgetese (a gombsor egy sor, a
        # fel-le ott nem visz sehova).
        if self.detail is not None and self.series is None and code in (ACTION_MOVE_UP, ACTION_MOVE_DOWN):
            self.scroll_plot(PLOT_STEP if code == ACTION_MOVE_DOWN else -PLOT_STEP)
            return
        # A listaban barmerre lepve az elozetes AZONNAL all (nem a kovetkezo
        # felmasodperces korben): a csempe ne utazzon a fokusszal.
        if self.detail is None and code in MOVE_ACTIONS:
            self.stop_trailer()

    # --- Racs-nezetek: kereso es bongeszo (Filmek / Sorozatok) --------------------

    def has_grid_views(self):
        '''Van-e kereso / bongeszo nezet ebben az elrendezesben (TV-n igen, erintosben nincs).'''
        return not (self.layout or (0, False))[1]

    has_search = has_grid_views

    def in_grid_view(self):
        '''A kereso / bongeszo racsan, a Mit nezzek kartyan vagy a beallitasokban (nem a reszletezoben): nincs elozetes.'''
        return (self.search is not None or self.browse is not None or self.tonight is not None
                or self.settings is not None or self.profiles_open) and self.detail is None

    in_search_grid = in_grid_view

    def close_grid_views(self):
        self.close_search()
        self.close_browse()
        self.close_tonight()
        self.close_settings()
        self.close_profiles()

    def go_home(self):
        '''A "netmozi" gomb: minden nezet zar, a sorok elejere -- es MINDEN frissul.'''
        self.stop_trailer()
        self.close_series()
        self.close_detail()
        self.close_grid_views()
        self.focus_first_row()
        self.refresh_wanted = 'all'
        control.infoDialog(u'Frissítés: sorok, figyelt sorozatok, listák…')

    # --- Kereso-nezet: betűrács + mufajok balra, talalatok jobbra ------------------

    def open_search(self):
        '''A felso sav "Keresés" tetelere. Ures mezovel javaslatok (a Felkapottak sor).'''
        if self.search is not None:
            return
        self.close_browse()
        self.close_tonight()
        self.close_settings()
        self.stop_trailer()
        self.search = {'query': u'', 'genre': None, 'due': None}
        if self.search_grid is None:
            self.search_grid = Grid(self, SEARCH_RESULTS_ID, u'kereső')
        self.setProperty('search', '1')
        self.populate_keyboard()
        self.populate_genres(self.search_genres or [])
        if self.search_genres is None and self.search_genres_result is None:
            self.fetch_genres()
        self.show_recommendations()
        self.render_query()
        try:
            self.setFocusId(SEARCH_KEYS_ID)
        except Exception:
            pass
        control.log(u'Kereső-nézet megnyitva')

    def leave_adult(self):
        '''A kereso zarul: a rejtett mod is -- legkozelebb ujra a kulcsszo kell.'''
        if self.search is not None and self.search.get('adult'):
            self.search['adult'] = False
            self.populate_genres(self.search_genres or [])

    def close_search(self):
        if self.search is None:
            return
        self.leave_adult()
        self.search['genremode'] = False
        self.setProperty('search.genres', '')
        self.search = None
        self.search_grid.clear()
        self.setProperty('search', '')
        for name in ('search.text', 'search.query', 'search.title'):
            self.setProperty(name, '')
        try:
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def populate_keyboard(self):
        '''Szokoz + torles, es a betuk (a-z, 0-9) -- egyszer, az elso megnyitaskor.'''
        try:
            edit = self.getControl(SEARCH_EDIT_ID)
            if edit.size() == 0:
                items = []
                for label, key in ((u'szóköz', 'space'), (u'törlés', 'backspace')):
                    li = xbmcgui.ListItem(label=label)
                    li.setProperty('key', key)
                    items.append(li)
                edit.addItems(items)
            keys = self.getControl(SEARCH_KEYS_ID)
            if keys.size() == 0:
                keys.addItems([xbmcgui.ListItem(label=char) for char in home.KEYBOARD])
        except Exception as exc:
            control.log_exception(u'kereső: betűrács', exc)

    def populate_genres(self, genres):
        '''A kategoriak mindket listaba (a kicsibe es a nagyba -- ugyanaz a tartalom).'''
        self.fill_choice_list(SEARCH_GENRES_ID, genres, u'kereső: műfajok')
        self.fill_choice_list(SEARCH_GENRES_BIG_ID, genres, u'kereső: műfajok')

    def genre_mode(self):
        return bool(self.search and self.search.get('genremode'))

    def enter_genre_mode(self):
        '''
        A fokusz a kategoriakra lepett: a betűrács, a szokoz es a torles
        eltunik, a kategoriak a helyukre ugranak (nagyban). Vissza: a lista
        tetejerol felfele.
        '''
        if self.search is None or self.search.get('genremode'):
            return
        self.search['genremode'] = True
        self.setProperty('search.genres', '1')
        try:
            position = max(self.getControl(SEARCH_GENRES_ID).getSelectedPosition(), 0)
            big = self.getControl(SEARCH_GENRES_BIG_ID)
            if big.size():
                big.selectItem(min(position, big.size() - 1))
            self.setFocusId(SEARCH_GENRES_BIG_ID)
        except Exception as exc:
            control.log_exception(u'kereső: kategóriák', exc)

    def leave_genre_mode(self, focus=None):
        '''Vissza a betűráccsal: a kategoriak megint a helyukon, kicsiben.'''
        if self.search is None or not self.search.get('genremode'):
            return
        self.search['genremode'] = False
        self.setProperty('search.genres', '')
        try:
            position = max(self.getControl(SEARCH_GENRES_BIG_ID).getSelectedPosition(), 0)
            small = self.getControl(SEARCH_GENRES_ID)
            if small.size():
                small.selectItem(min(position, small.size() - 1))
            self.setFocusId(focus or SEARCH_KEYS_ID)
        except Exception as exc:
            control.log_exception(u'kereső: kategóriák', exc)

    def onFocus(self, control_id):
        # Ahonnan a felso savra leptunk: a lefele ugyanoda visz vissza.
        if control_id and control_id not in TOP_IDS:
            self.focus_prev = control_id
        # A kis kategoria-lista csak "kapu": ha oda kerul a fokusz, a nagy
        # lista veszi at (a betűrács helyen).
        if control_id == SEARCH_GENRES_ID and self.search is not None:
            self.enter_genre_mode()

    def enter_adult(self):
        '''A rejtett lista modja: a bal oldali lista a sajat kategoriait mutatja.'''
        if self.search is None or self.search.get('adult'):
            return
        self.search['adult'] = True
        self.search['genre'] = None
        self.populate_genres(home.adult_genres())

    def fill_choice_list(self, control_id, options, what, active=None):
        '''(ertek, felirat) tetelek egy listaba; a kivalasztott jelolve, es kijelolve.'''
        try:
            control_list = self.getControl(control_id)
            had_focus = self.getFocusId() == control_id
            control_list.reset()
            items = []
            for value, label in options:
                li = xbmcgui.ListItem(label=label)
                li.setProperty('value', value)
                li.setProperty('active', '1' if active is not None and value == active else '')
                items.append(li)
            control_list.addItems(items)
            if active is not None:
                index = next((i for i, (value, _l) in enumerate(options) if value == active), -1)
                if index >= 0:
                    control_list.selectItem(index)
            self.refocus(control_id, had_focus)
        except Exception as exc:
            control.log_exception(what, exc)

    def fetch_genres(self):
        import threading

        def work():
            try:
                self.search_genres_result = home.genre_options()
            except Exception as exc:
                control.log_exception(u'kereső: műfajok', exc)
                self.search_genres_result = []
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def render_query(self):
        '''A keresomezo (kurzorral) es a racs cime (a folyam allasabol: talalatok, hasonlok).'''
        if self.search is None:
            return
        query = self.search['query']
        genre = self.search.get('genre')
        info = self.search_grid.info()
        count = similar = None
        if info['key'] and info['key'][0] == 'query' and info['shown']:
            count, similar = info['count'], info['similar']
        self.setProperty('search.text', query)
        self.setProperty('search.query', query + u'|')
        if home.adult_keyword(query):
            self.setProperty('search.title', u'Találatok' if not info['busy'] else u'Keresés…')
            return
        self.setProperty('search.title', home.search_title(query, genre[1] if genre else u'', count,
                                                           info['busy'], info['failed'], similar or ()))

    def type_key(self, key):
        '''Egy betu / szokoz / torles: a mezo valtozik, a kereses rovid nyugalom utan indul.'''
        if self.search is None or not key:
            return
        query = self.search['query']
        if key == 'backspace':
            query = query[:-1]
        elif key == 'space':
            if query and not query.endswith(u' '):
                query += u' '
        else:
            query += key
        self.set_query(query)

    def set_query(self, query):
        self.search['query'] = query
        self.search['genre'] = None
        self.search['due'] = time.time() + home.SEARCH_DEBOUNCE
        if not query.strip():
            self.search['due'] = None
            self.show_recommendations()
        self.render_query()

    def pick_genre(self, value, label):
        '''OK egy mufajon: a mufaj cimei a racsba (a mezo urul).'''
        if self.search is None or not value:
            return
        self.search['query'] = u''
        self.search['genre'] = (value, label)
        self.search['due'] = None
        if self.search.get('adult'):
            self.search_grid.want(('adult', value), lambda: home.adult_feed(category=value))
        else:
            self.search_grid.want(('genre', value), lambda: home.genre_feed(value))
        self.render_query()

    def remember_query(self):
        '''OK egy talalaton: a beirt szo az elozmenyek koze (a rejtett kulcsszo SOHA).'''
        if self.search and self.search['query'].strip() and not home.adult_keyword(self.search['query']):
            home.remember_search(self.search['query'].strip())

    def search_key(self):
        '''Mit kell mutatni: ('adult', ...) / ('query', szo) / ('genre', ertek) / ('reco', None).'''
        if home.adult_keyword(self.search['query']):
            return ('adult', u'')
        if self.search.get('adult'):
            # A rejtett listan belul: a beirt szo keres, kulonben a valasztott
            # kategoria, kulonben a cimlap. (Kilepes: Vissza.)
            text = self.search['query'].strip()
            genre = self.search.get('genre')
            return ('adult', text or (genre[0] if genre else u''))
        if self.search['query'].strip():
            return ('query', self.search['query'].strip())
        if self.search['genre']:
            return ('genre', self.search['genre'][0])
        return ('reco', None)

    def show_recommendations(self):
        '''Ures mezo: evenkent a legnezettebbek, VELETLEN ev-sorrendben, a mar latottak nelkul.'''
        self.search_grid.want(('reco', None), lambda: home.reco_feed([]))

    def search_tick(self):
        '''A hordozo hivja: mufajok megjottek -> lista; esedekes kereses -> a racs; a racs lep.'''
        if self.search is None:
            return
        if self.search_genres_result is not None:
            self.search_genres = self.search_genres_result
            self.search_genres_result = None
            self.populate_genres(self.search_genres)
        due = self.search['due']
        if due is not None and time.time() >= due:
            self.search['due'] = None
            key = self.search_key()
            if key[0] == 'adult':
                # A rejtett lista: a kulcsszo a keresobe irva. Sehol nincs menupontja,
                # es az elozmenybe sem kerul be (remember_query szurte).
                self.enter_adult()
                text = self.search['query'].strip()
                text = u'' if home.adult_keyword(text) else text
                category = u'' if text else key[1]
                self.search_grid.want(key, lambda: home.adult_feed(text, category))
            elif key[0] == 'query':
                text = key[1]
                self.search_grid.want(key, lambda: home.query_feed(text))
            else:
                self.show_recommendations()
            self.render_query()
        if self.search_grid.tick(load_more=self.detail is None):
            self.render_query()

    # --- Bongeszo-nezet: Filmek / Sorozatok, szurokkel -------------------------------

    def open_browse(self, tipus):
        '''A felso sav Filmek / Sorozatok tetelere: szurok balra, a racs jobbra.'''
        if self.browse is not None and self.browse['tipus'] == tipus:
            return
        self.close_search()
        self.close_browse()
        self.close_tonight()
        self.close_settings()
        self.stop_trailer()
        if self.browse_grid is None:
            self.browse_grid = Grid(self, BROWSE_RESULTS_ID, u'böngésző')
        state = (self.browse_states or {}).get(tipus) or {
            'order': None, 'year': '', 'genre': '', 'language': control.setting('listlanguage') or '',
            'service': ''}                            # streaming: alapbol nincs kivalasztva
        self.browse = dict(state, tipus=tipus, autofocus=True)
        self.setProperty('browse', '1')
        self.setProperty('browse.kind', home.kind_label(tipus))
        if self.browse_options is None and self.browse_options_result is None:
            self.fetch_browse_options()
        self.populate_filters()
        self.browse_load()
        try:
            self.setFocusId(BROWSE_MENU_ID)
        except Exception:
            pass
        control.log(u'Böngésző-nézet: %s' % home.kind_label(tipus))

    def close_browse(self):
        if self.browse is None:
            return
        if self.browse_states is None:
            self.browse_states = {}
        self.browse_states[self.browse['tipus']] = dict((k, self.browse.get(k)) for k in
                                                        ('order', 'year', 'genre', 'language', 'service'))
        self.browse = None
        self.browse_grid.clear()
        self.setProperty('browse.pick', '')
        self.setProperty('browse', '')
        for name in ('browse.kind', 'browse.title'):
            self.setProperty(name, '')
        try:
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def fetch_browse_options(self):
        import threading

        def work():
            try:
                self.browse_options_result = home.browse_options()
            except Exception as exc:
                control.log_exception(u'böngésző: szűrők', exc)
                self.browse_options_result = {}
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def browse_order(self):
        '''A rendezes: a valasztott, kulonben az oldal alapja.'''
        return self.browse['order'] or (self.browse_options or {}).get('default_order') or home.ORDER_NEWEST_LINKS

    def populate_filters(self):
        options = self.browse_options or {}
        years = options.get('years') or [('', home.BROWSE_ANY_YEAR)] + [(y, y) for y in _year_values()]
        self.fill_choice_list(BROWSE_ORDER_ID, options.get('orders') or [], u'böngésző: rendezés', self.browse_order())
        self.fill_choice_list(BROWSE_LANGUAGE_ID, options.get('languages') or [], u'böngésző: nyelv', self.browse['language'])
        self.fill_choice_list(BROWSE_YEAR_ID, years, u'böngésző: év', self.browse['year'])
        self.fill_choice_list(BROWSE_GENRE_ID, options.get('genres') or [], u'böngésző: műfaj', self.browse['genre'])
        self.fill_choice_list(BROWSE_SERVICE_ID, home.service_options(), u'böngésző: streaming',
                              self.browse.get('service') or '')
        self.populate_filter_menu()

    def filter_value_label(self, list_id, field):
        value = self.browse_order() if field == 'order' else self.browse.get(field) or ''
        label = self.label_of(list_id, value)
        if label:
            return label
        return {'year': home.BROWSE_ANY_YEAR, 'genre': home.BROWSE_ANY_GENRE,
                'language': home.BROWSE_ANY_LANGUAGE, 'service': home.BROWSE_ANY_SERVICE}.get(field, u'')

    def populate_filter_menu(self):
        '''A negy szuro-sor: cim + a beallitott ertek (a kijeloles marad).'''
        try:
            control_list = self.getControl(BROWSE_MENU_ID)
            if control_list.size() != len(BROWSE_MENU):
                had_focus = self.getFocusId() == BROWSE_MENU_ID
                control_list.reset()
                items = []
                for list_id, heading, field in BROWSE_MENU:
                    li = xbmcgui.ListItem(label=u'')
                    li.setProperty('list', str(list_id))
                    li.setProperty('heading', heading)
                    items.append(li)
                control_list.addItems(items)
                self.refocus(BROWSE_MENU_ID, had_focus)
            for index, (list_id, _heading, field) in enumerate(BROWSE_MENU):
                control_list.getListItem(index).setLabel(self.filter_value_label(list_id, field))
        except Exception as exc:
            control.log_exception(u'böngésző: szűrő-menü', exc)

    def open_filter(self, list_id):
        '''OK a menu egy soran: az ertek-lista a menu helyen, a beallitott erteken.'''
        if self.browse is None or list_id not in BROWSE_FILTER_IDS:
            return
        self.browse['pick'] = list_id
        self.setProperty('browse.pick', str(list_id))
        try:
            control_list = self.getControl(list_id)
            for index in range(control_list.size()):
                if control_list.getListItem(index).getProperty('active') == '1':
                    control_list.selectItem(index)
                    break
            self.setFocusId(list_id)
        except Exception as exc:
            control.log_exception(u'böngésző: szűrő nyitása', exc)

    def close_filter(self):
        '''Az ertek-lista zar, a fokusz vissza a menu ugyanazon sorara.'''
        if self.browse is None or not self.browse.get('pick'):
            return
        self.browse['pick'] = None
        self.setProperty('browse.pick', '')
        self.populate_filter_menu()
        try:
            self.setFocusId(BROWSE_MENU_ID)
        except Exception:
            pass

    def label_of(self, control_id, value):
        '''Egy szuro-ertek felirata a listajabol ('' ha nincs / a "mind").'''
        try:
            control_list = self.getControl(control_id)
            for index in range(control_list.size()):
                item = control_list.getListItem(index)
                if item.getProperty('value') == value:
                    return item.getLabel()
        except Exception:
            pass
        return u''

    def render_browse(self):
        if self.browse is None:
            return
        info = self.browse_grid.info()
        if info['busy']:
            title = u'betöltés…'
        elif info['failed']:
            title = u'nem sikerült (hálózat?)'
        else:
            service = self.browse.get('service') or ''
            title = home.browse_title(self.label_of(BROWSE_ORDER_ID, self.browse_order()),
                                      self.browse['year'],
                                      self.label_of(BROWSE_GENRE_ID, self.browse['genre']) if self.browse['genre'] else u'',
                                      self.label_of(BROWSE_LANGUAGE_ID, self.browse['language']) if self.browse['language'] else u'',
                                      self.label_of(BROWSE_SERVICE_ID, service) if service else u'')
        self.setProperty('browse.title', title)

    def browse_load(self):
        b = self.browse
        tipus, order, year, genre, language = b['tipus'], self.browse_order(), b['year'], b['genre'], b['language']
        service = b.get('service') or ''
        self.browse_grid.want(home.browse_key(tipus, order, year, genre, language, service),
                              lambda: home.browse_feed(tipus, order, year, genre, language, service))
        self.render_browse()

    def pick_filter(self, control_id, value):
        '''OK egy szuron: az ertek beall (a jeloles atkerul), a racs ujratolt.'''
        if self.browse is None:
            return
        field = {BROWSE_ORDER_ID: 'order', BROWSE_LANGUAGE_ID: 'language',
                 BROWSE_YEAR_ID: 'year', BROWSE_GENRE_ID: 'genre',
                 BROWSE_SERVICE_ID: 'service'}.get(control_id)
        if not field:
            return
        self.browse['autofocus'] = False
        self.browse[field] = value
        if field == 'language':
            # A nyelv-szuro ragados (a regi menuvel kozos beallitas).
            control.setSetting('listlanguage', value)
            control.setSetting('listlanguagelabel', self.label_of(control_id, value) if value else '')
        try:
            control_list = self.getControl(control_id)
            for index in range(control_list.size()):
                item = control_list.getListItem(index)
                item.setProperty('active', '1' if item.getProperty('value') == value else '')
        except Exception as exc:
            control.log_exception(u'böngésző: szűrő', exc)
        self.browse_load()

    def browse_tick(self):
        '''A hordozo hivja: a szurok ertekei megjottek -> listak; a racs lep; elso oldal -> fokusz a racsra.'''
        if self.browse is None:
            return
        if self.browse_options_result is not None:
            self.browse_options = self.browse_options_result
            self.browse_options_result = None
            self.populate_filters()
            self.render_browse()
        if self.browse_grid.tick(load_more=self.detail is None):
            self.render_browse()
            if self.browse['autofocus'] and self.browse_grid.entries:
                self.browse['autofocus'] = False
                if self.getFocusId() == BROWSE_MENU_ID:
                    try:
                        self.setFocusId(BROWSE_RESULTS_ID)
                    except Exception:
                        pass

    # --- Mit nezzek ma este? kartya ------------------------------------------------

    def open_tonight(self):
        '''A felso sav tetelere: mufajok balra, jobbra a sorsolt film kartyaja.'''
        if self.tonight is not None:
            return
        self.close_search()
        self.close_browse()
        self.close_settings()
        self.stop_trailer()
        self.tonight = {'genre': '', 'tried': set(), 'entry': None, 'busy': False, 'seq': 0}
        self.tonight_results = []
        if self.tonight_pages is None:
            self.tonight_pages = {}
        self.setProperty('tonight', '1')
        self.populate_tonight_genres()
        if self.search_genres is None and self.search_genres_result is None:
            self.fetch_genres()
        self.populate_tonight_buttons(u'')
        self.tonight_draw()
        try:
            self.setFocusId(TONIGHT_GENRES_ID)
        except Exception:
            pass
        control.log(u'Mit nézzek ma este: nézet megnyitva')

    def close_tonight(self):
        if self.tonight is None:
            return
        self.tonight = None
        self.tonight_results = None
        self.setProperty('tonight', '')
        for name in ('title', 'line2', 'line3', 'plot', 'thumb', 'status'):
            self.setProperty('tonight.%s' % name, '')
        try:
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def populate_tonight_genres(self):
        genres = [('', home.TONIGHT_ANY)] + list(self.search_genres or [])
        self.fill_choice_list(TONIGHT_GENRES_ID, genres, u'Mit nézzek: műfajok', self.tonight['genre'])

    def populate_tonight_buttons(self, thumb):
        '''
        A gombsor EGYSZER epul (a nezet megnyitasakor); a kartya cserejekor
        csak a meglevo tetelek boritoja frissul. A reset() + addItems a
        fokuszalt listan elvitte a fokuszt (ures lista nem tarthatja), es
        utana a bal/jobb nyilak semmire sem mentek.
        '''
        try:
            control_list = self.getControl(TONIGHT_BUTTONS_ID)
            if control_list.size() != len(home.TONIGHT_BUTTONS):
                control_list.reset()
                items = []
                for label, key, glyph in home.TONIGHT_BUTTONS:
                    button = xbmcgui.ListItem(label=label)
                    button.setProperty('key', key)
                    button.setProperty('glyph', glyph)
                    # a lejatszovezerlo stilusaban: Inditas pirula, a tobbi kerek ikon
                    button.setProperty('primary', '1' if glyph == home.PLAY_GLYPH else '')
                    button.setProperty('icon', home.TONIGHT_ICONS.get(key, 'nm-dots.png'))
                    items.append(button)
                control_list.addItems(items)
                control_list.selectItem(0)
            for index in range(control_list.size()):
                control_list.getListItem(index).setArt({'icon': thumb or '', 'thumb': thumb or ''})
        except Exception as exc:
            control.log_exception(u'Mit nézzek: gombok', exc)

    def tonight_draw(self):
        '''Sorsolas a hatterben: a kartya "keresek…" allapotba, az eredmeny a tick-ben.'''
        import threading
        t = self.tonight
        t['busy'] = True
        t['since'] = time.time()
        t['seq'] += 1
        seq, genre, tried, pages = t['seq'], t['genre'], t['tried'], self.tonight_pages
        language = control.setting('listlanguage') or ''
        self.setProperty('tonight.status', u'Keresek egy jó filmet…')
        queue = self.tonight_results

        def work():
            entry, record, status = None, {}, 'error'
            try:
                row, status = home.tonight_pick(genre, language, tried, pages)
                if row is not None:
                    entry = home.tonight_entry(row)
                    record = home.title_info(entry.get('imdb')) or {}
            except Exception as exc:
                control.log_exception(u'Mit nézzek ma este', exc)
            if queue is not None:
                queue.append({'seq': seq, 'entry': entry, 'record': record, 'status': status})
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def tonight_tick(self):
        '''A hordozo hivja: a mufajok megjottek -> lista; a sorsolt film -> kartya.'''
        if self.tonight is None:
            return
        if self.search_genres_result is not None:
            self.search_genres = self.search_genres_result
            self.search_genres_result = None
            self.populate_tonight_genres()
        while self.tonight_results:
            result = self.tonight_results.pop(0)
            if result['seq'] != self.tonight['seq']:
                continue                                 # kozben mas mufajt valasztott
            self.tonight['busy'] = False
            self.render_tonight(result['entry'], result['record'], result['status'])

    def render_tonight(self, entry, record, status):
        t = self.tonight
        t['entry'] = entry
        if entry is None:
            self.setProperty('tonight.status', u'Nincs több javaslat -- próbáld másik műfajjal.'
                             if status == 'none' else u'Nem sikerült (hálózat?) -- próbáld újra.')
            return
        line2, line3, plot = home.detail_lines(entry, record or {})
        self.setProperty('tonight.title', entry.get('label') or u'')
        self.setProperty('tonight.line2', line2)
        self.setProperty('tonight.line3', line3)
        self.setProperty('tonight.plot', plot)
        self.setProperty('tonight.thumb', entry.get('thumb') or '')
        self.setProperty('tonight.status', u'')
        self.populate_tonight_buttons(entry.get('thumb') or '')
        if self.getFocusId() == TONIGHT_GENRES_ID and not t.get('moved'):
            # Az elso kartyanal a fokusz az Inditasra ugrik, ha kozben nem mozdult.
            try:
                self.setFocusId(TONIGHT_BUTTONS_ID)
            except Exception:
                pass

    def pick_tonight_genre(self, value):
        t = self.tonight
        t['genre'] = value or ''
        t['tried'] = set()
        t['moved'] = True
        try:
            control_list = self.getControl(TONIGHT_GENRES_ID)
            for index in range(control_list.size()):
                item = control_list.getListItem(index)
                item.setProperty('active', '1' if item.getProperty('value') == t['genre'] else '')
        except Exception as exc:
            control.log_exception(u'Mit nézzek: műfaj', exc)
        self.tonight_draw()

    def tonight_button(self, key):
        t = self.tonight
        entry = t.get('entry')
        if key == 'another':
            # Ha egy kereses beragadt (lassu halozat), egy ido utan a Masikat
            # ujat indit -- a regi eredmenyt a sorszam miatt eldobjuk.
            if not t['busy'] or time.time() - t.get('since', 0) > TONIGHT_STUCK_SECONDS:
                self.tonight_draw()
            return
        if entry is None:
            return
        if key == 'play':
            self.dispatch(entry.get('mode') or 'play', entry.get('query') or '', entry.get('label') or u'', entry.get('thumb') or '')
        elif key == 'detail':
            self.show_detail(dict(entry), TONIGHT_BUTTONS_ID, 2)

    # --- "Tovabb": egy szolgaltato teljes kinalata --------------------------------
    #
    # A szolgaltato-sorok vegi csempe nyitja: a TMDB kinalata evenkent
    # visszafele, nepszeruseg szerint. OK egy cimen: megkeressuk a netmozin
    # (IMDb-azonositoval); ha megvan, a szokasos reszletezo nyilik, ha nincs,
    # felajanljuk a figyelest ("Varom").

    def open_provider(self, row_key, came_from=None):
        if not row_key or not self.has_grid_views():
            return
        self.close_search()
        self.close_browse()
        self.close_tonight()
        self.close_settings()
        self.stop_trailer()
        if self.provider_grid is None:
            self.provider_grid = Grid(self, PROVIDER_GRID_ID, u'kínálat')
        self.provider = {'key': row_key, 'from': came_from}
        self.provider_results = []
        self.setProperty('provider', '1')
        self.setProperty('provider.name', home.provider_title(row_key))
        self.setProperty('provider.title', u'%s – teljes kínálat' % home.provider_title(row_key))
        self.setProperty('fanart', '')
        self.setProperty('provider.logo', '')
        self.fetch_provider_logo(row_key)
        self.provider['marked'] = ''
        self.provider['jump'] = None
        self.provider['focused'] = False
        self.populate_provider_years()
        self.provider_grid.want(('provider', row_key), lambda: home.provider_feed(row_key))
        self.provider_focus()
        control.log(u'Teljes kínálat: %s' % row_key)

    def populate_provider_years(self):
        '''Az evvalaszto: "Minden év" es az evek visszafele; a beallitott jelolve.'''
        try:
            control_list = self.getControl(PROVIDER_YEARS_ID)
            control_list.reset()
            chosen = (self.provider or {}).get('marked') or ''
            items = []
            for year, label in home.provider_year_options():
                item = xbmcgui.ListItem(label=label)
                item.setProperty('year', year)
                item.setProperty('on', '1' if year == chosen else '')
                items.append(item)
            control_list.addItems(items)
        except Exception as exc:
            control.log_exception(u'kínálat: évek', exc)

    def provider_year(self, year):
        '''Evre ugras: a racs annak az evnek az elso cimere all (ha kell, tovabb tolt).'''
        if self.provider is None:
            return
        self.provider['jump'] = year or 'all'
        self.provider_jump_tick()

    def mark_provider_year(self, year):
        '''A piros jelolo az adott evre ('' = Minden ev) -- a lista ujraepitese nelkul.'''
        if self.provider is None or self.provider.get('marked') == year:
            return
        self.provider['marked'] = year
        try:
            years = self.getControl(PROVIDER_YEARS_ID)
            for index in range(years.size()):
                item = years.getListItem(index)
                item.setProperty('on', '1' if item.getProperty('year') == year else '')
        except Exception as exc:
            control.log_exception(u'kínálat: évjelölő', exc)

    def provider_jump_tick(self):
        '''A fuggo evre ugras: ha mar megvan a racsban, oda all; kulonben tovabb tolt.'''
        st = self.provider
        target = (st or {}).get('jump')
        grid = self.provider_grid
        if not target or grid is None:
            return
        entries = grid.entries or []
        if target == 'all':
            index = 0 if entries else None
        else:
            index = next((i for i, e in enumerate(entries) if str(e.get('year') or '') == target), None)
        if index is not None:
            st['jump'] = None
            try:
                self.getControl(PROVIDER_GRID_ID).selectItem(index)
                self.setFocusId(PROVIDER_GRID_ID)
            except Exception:
                pass
            self.mark_provider_year('' if target == 'all' else target)
            return
        older = any((str(e.get('year') or '9999')).isdigit() and int(e.get('year') or 9999) < int(target) for e in entries)
        feed = grid.feed
        if older or feed is None or feed.get('done'):
            st['jump'] = None
            control.infoDialog(u'%s: ebből az évből nincs cím.' % target)
            return
        if grid.busy is None:
            grid._fetch(grid.shown, feed, more=True)

    def fetch_provider_logo(self, row_key):
        '''A szolgaltato logoja a hatterben (egyszer lekerve, havonta frissul).'''
        import threading
        queue = self.provider_results

        def work():
            try:
                logo = home.provider_logo(row_key)
            except Exception as exc:
                control.log_exception(u'szolgáltató logó', exc)
                logo = ''
            if logo and queue is not None:
                queue.append({'logo': logo})
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def provider_focus(self):
        '''A fokusz a racsra -- csak ha mar van benne tetel (ures listat a Kodi nem fogad).'''
        try:
            if self.getControl(PROVIDER_GRID_ID).size() and self.getFocusId() != PROVIDER_GRID_ID:
                self.setFocusId(PROVIDER_GRID_ID)
        except Exception:
            pass

    def close_provider(self):
        if self.provider is None:
            return
        came_from = self.provider.get('from')
        self.provider = None
        self.provider_results = None
        self.setProperty('provider', '')
        self.setProperty('provider.title', '')
        self.setProperty('provider.name', '')
        self.setProperty('provider.logo', '')
        if self.provider_grid is not None:
            self.provider_grid.clear()
        try:
            if came_from:
                # Vissza a sorba, ugyanarra a "Tovább" csempere.
                self.setFocusId(came_from[0])
                self.getControl(came_from[0]).selectItem(came_from[1])
            else:
                self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def provider_click(self, item, list_id=None):
        '''
        OK egy TMDB-cimen (a "Tovabb" racsban vagy a bongeszo streaming-
        szurojeben): a netmozi-oldalat a hatterben keressuk meg (IMDb-vel).
        '''
        if self.lookup_busy:
            return
        try:
            parts = dict(part.split('=', 1) for part in (item.getProperty('query') or '').split('&') if '=' in part)
        except ValueError:
            return
        kind, tmdb_id = parts.get('kind') or 'movie', parts.get('id') or ''
        if not tmdb_id:
            return
        import threading
        list_id = list_id or PROVIDER_GRID_ID
        position = 0
        try:
            position = max(self.getControl(list_id).getSelectedPosition(), 0)
        except Exception:
            pass
        self.lookup_busy = True
        if self.lookup_results is None:
            self.lookup_results = []
        title, thumb = item.getLabel(), item.getProperty('thumb') or ''
        control.infoDialog(u'Keresem a netmozin…', time=2000)
        queue = self.lookup_results

        def work():
            out = {'title': title, 'thumb': thumb, 'row': None, 'imdb': '',
                   'list_id': list_id, 'position': position}
            try:
                from resources.lib.indexers import navigator
                out['row'], out['imdb'] = home.provider_lookup(
                    '', kind, tmdb_id, navigator.navigator().searchMovies)
            except Exception as exc:
                control.log_exception(u'cím keresése a netmozin', exc)
            queue.append(out)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def provider_tick(self):
        '''A hordozo hivja: a logo, a kattintott cim keresesenek eredmenye, a racs lepese.'''
        while self.provider_results:
            result = self.provider_results.pop(0)
            if result.get('logo') and self.provider is not None:
                self.setProperty('provider.logo', result['logo'])
        while self.lookup_results:
            result = self.lookup_results.pop(0)
            self.lookup_busy = False
            row = result.get('row')
            if row:
                from resources.lib.modules import watchlist
                entry = home.from_listing(row, frozenset(watchlist.load()))
                # A reszletezo innen tudja meg, mit kerjen le a TMDB-tol
                # (leiras, elozetes, hatterkep) -- kulonben ures maradna.
                entry['imdb'] = result.get('imdb') or home.imdb_of(entry)
                self.show_detail(entry, result.get('list_id') or PROVIDER_GRID_ID, result.get('position') or 0)
            elif result.get('imdb'):
                # Nincs a netmozin: szoljon, ha megjelenik ("Várom" lista).
                from urllib.parse import quote_plus
                self.dispatch('play', 'watchappear&imdb=%s&title=%s&thumb=%s'
                              % (result['imdb'], quote_plus(result['title'] or u''),
                                 quote_plus(result['thumb'] or u'')))
            else:
                control.infoDialog(u'Ezt most nem találom a netmozin.')
        if self.provider is None:
            return
        if self.provider_grid is not None:
            self.provider_grid.tick(load_more=self.detail is None)
        if self.detail is None and not self.provider.get('focused'):
            # az elso oldal megjott: a racs aktiv lesz -- CSAK egyszer (kulonben az
            # evsavrol minden korben visszarantana a boritokra)
            self.provider_focus()
            try:
                self.provider['focused'] = self.getFocusId() == PROVIDER_GRID_ID
            except Exception:
                pass
        self.provider_jump_tick()
        # a piros jelolo koveti, melyik ev boritojan allsz
        if self.getFocusId() == PROVIDER_GRID_ID:
            item = self.selected(PROVIDER_GRID_ID)
            if item is not None and item.getProperty('year'):
                self.mark_provider_year(item.getProperty('year'))

    # --- Forrasok (sajat nezet) -----------------------------------------------------
    #
    # A film / resz forrasai a mi listankban (nem a Kodi felugro listaja):
    # 0. sor a sebessegmeres (ujrameres), utana a forrasok a mert sebesseggel,
    # a felirattal es a hoszt leirasaval. OK egy forrason: az indul
    # (playsource), a folyamatabraval. Vissza: a reszletezo.

    def open_sources_for_focus(self):
        '''A fokuszalt lejatszas-gomb / resz forrasai; True, ha megnyilt.'''
        if not self.has_grid_views() or self.sources is not None:
            return False
        focus = self.getFocusId()
        if focus not in (DETAIL_LIST_ID, EPISODES_LIST_ID):
            return False
        item = self.selected(focus)
        if item is None:
            return False
        query = item.getProperty('query') or ''
        if not query.startswith(('playdirect', 'playepisode', 'continueseries', 'historyplay')):
            return False
        target = home.sources_target(query)
        if not target:
            return False
        title = (self.detail or {}).get('label') or u''
        if focus == EPISODES_LIST_ID and item.getLabel():
            title = u'%s – %s' % (title, item.getLabel())
        thumb = (self.detail or {}).get('thumb') or item.getProperty('thumb') or ''
        self.open_sources(target, title, thumb, play_query=query)
        return True

    def open_sources(self, page, title=u'', thumb=u'', play_query=u'', ncore_only=False):
        '''
        play_query: ha van, az elso sor az automatikus inditas (egy reszrol
        nyitva). ncore_only: az nCore gomb nezete -- csak a torrentek (a
        legutobb nezett elol, megjelolve), sebessegmeres nelkul.
        '''
        if not page:
            return
        self.sources = {'page': page, 'title': title or u'', 'thumb': thumb or u'', 'entries': None,
                        'sources': None, 'speeds': {}, 'measured_at': 0, 'busy': True, 'seq': 0,
                        'play_query': play_query or u'', 'ncore_only': bool(ncore_only)}
        self.sources_results = []
        self.setProperty('sources', '1')
        self.setProperty('sources.title', (u'nCore – %s' % title) if ncore_only and title else (title or u''))
        self.setProperty('sources.thumb', thumb or u'')
        self.setProperty('sources.status', u'Torrentek keresése az nCore-on…' if ncore_only else u'Források keresése…')
        self.populate_sources()
        try:
            self.setFocusId(SOURCES_LIST_ID)
        except Exception:
            pass
        self.sources_fetch()
        control.log(u'Forrás-nézet: %s' % page)

    def close_sources(self):
        if self.sources is None:
            return
        self.sources = None
        self.sources_results = None
        self.setProperty('sources', '')
        for name in ('title', 'thumb', 'status'):
            self.setProperty('sources.%s' % name, '')
        try:
            self.setFocusId(EPISODES_LIST_ID if self.series is not None else DETAIL_LIST_ID)
        except Exception:
            pass

    def sources_fetch(self, measure=False):
        '''A hatterben: a forraslista (es kerésre a sebessegmeres); az eredmeny a tick-ben.'''
        import threading
        st = self.sources
        st['busy'] = True
        st['seq'] += 1
        seq, page, queue = st['seq'], st['page'], self.sources_results
        known = st.get('sources')
        ncore_only = st.get('ncore_only')
        self.setProperty('sources.status', u'Sebességmérés… (forrásonként pár másodperc)' if measure
                         else u'Források keresése…')

        def work():
            out = {'seq': seq, 'ok': False}
            try:
                from resources.lib.indexers import navigator
                from resources.lib.modules import sourcecache
                nav = navigator.navigator()
                from resources.lib.modules import history
                sources = known
                if sources is None:
                    _details, sources = nav.movieSources(page)
                    if ncore_only:
                        sources = [source for source in sources or [] if source.get('ncore')]
                speeds, measured_at = sourcecache.load(page)
                if measure and sources:
                    speeds = nav.measureSources(sources)
                    measured_at = int(time.time())
                    sourcecache.save(page, speeds)
                out.update(ok=True, sources=sources or [], speeds=speeds or {}, measured_at=measured_at or 0,
                           entries=nav.sourceEntries(sources or [], speeds or {}, history.remembered(page)[1]),
                           measure_label=nav.measureLabel(speeds, measured_at))
            except Exception as exc:
                control.log_exception(u'forrás-nézet', exc)
            if queue is not None:
                queue.append(out)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def sources_tick(self):
        if self.sources is None:
            return
        while self.sources_results:
            result = self.sources_results.pop(0)
            if result['seq'] != self.sources['seq']:
                continue
            st = self.sources
            st['busy'] = False
            if not result.get('ok'):
                self.setProperty('sources.status', u'Nem sikerült (hálózat?) -- próbáld újra.')
                continue
            st.update(sources=result['sources'], speeds=result['speeds'], measured_at=result['measured_at'],
                      entries=result['entries'], measure_label=result['measure_label'])
            self.setProperty('sources.status', u'' if result['entries'] else
                             u'Ehhez nem találtam torrentet az nCore-on.' if st.get('ncore_only')
                             else u'Ehhez nem találtam forrást.')
            count, measured = len(result['entries']), len(result['speeds'] or {})
            self.setProperty('sources.summary', (u'%d %s%s' % (count, u'torrent' if st.get('ncore_only') else u'forrás',
                                                               u', ebből %d megmérve' % measured if measured else u''))
                             if count else u'')
            self.populate_sources()

    def populate_sources(self):
        st = self.sources
        try:
            control_list = self.getControl(SOURCES_LIST_ID)
            position = control_list.getSelectedPosition()
            had_focus = self.getFocusId() == SOURCES_LIST_ID
            control_list.reset()
            items = []
            if st.get('play_query'):
                label = u'Lejátszás -- a legjobb forrással, automatikusan'
                if st.get('ncore_only'):
                    remembered = any(u'legutóbb ezt nézted' in entry['text'] for entry in st.get('entries') or [])
                    label = (u'Lejátszás -- a legutóbb nézett torrenttel' if remembered
                             else u'Lejátszás -- a legjobb torrenttel, automatikusan')
                play = xbmcgui.ListItem(label=label)
                play.setProperty('key', PLAY_ROW_KEY)
                play.setProperty('mark', u'')
                play.setProperty('icon', 'nm-play-64.png')
                items.append(play)
                if self.sources_episode():
                    from resources.lib.modules import marks
                    done = marks.is_marked(self.sources_episode())
                    mark = xbmcgui.ListItem(label=u'Mégsem néztem meg' if done else u'Megnéztem')
                    mark.setProperty('key', MARK_ROW_KEY)
                    mark.setProperty('mark', u'')
                    mark.setProperty('icon', 'nm-cross-64.png' if done else 'nm-check-64.png')
                    items.append(mark)
            if not st.get('ncore_only'):
                # Torrentnel nincs mit merni: a seed a jelzes.
                first = xbmcgui.ListItem(label=st.get('measure_label') or u'[COLOR gold]Sebesség ellenőrzése[/COLOR]')
                first.setProperty('key', '')
                first.setProperty('mark', u'')
                first.setProperty('icon', 'nm-speed.png')
                # a TV-s nezetben szinezes nelkul (a feher kijeloles alatt a "gold" nem latszana)
                first.setProperty('plain', re.sub(r'\[/?COLOR[^\]]*\]', u'', first.getLabel()))
                items.append(first)
            for entry in st.get('entries') or []:
                li = xbmcgui.ListItem(label=entry['text'])
                li.setProperty('key', entry['key'])
                li.setProperty('mark', entry['mark'])
                li.setProperty('trust', entry['trust'])
                li.setProperty('kind', 'source')
                for name in ('speed', 'speedkind', 'host', 'language', 'quality', 'extra'):
                    li.setProperty(name, entry.get(name) or u'')
                li.setProperty('remembered', '1' if entry.get('remembered') else '')
                items.append(li)
            control_list.addItems(items)
            control_list.selectItem(max(0, min(position, len(items) - 1)))
            self.refocus(SOURCES_LIST_ID, had_focus)
        except Exception as exc:
            control.log_exception(u'forrás-nézet: lista', exc)

    def sources_episode(self):
        '''A forras-nezet egy reszrol nyilt? A resz utvonala, kulonben ''.'''
        from resources.lib.modules import progress
        page = home.mark_query((self.sources or {}).get('play_query') or '')[1]
        return page if progress.split_page(page) else ''

    def mark_local(self, query):
        '''"Megnéztem" (resz / evad) helyben: a reszlista jelzese es a helyi sorok azonnal frissulnek.'''
        numbers = None
        _action, _page, season = home.mark_query(query)
        if season and self.series is not None:
            numbers = dict(self.series.get('seasons') or []).get(int(season))
        done, message = home.mark_local(query, numbers)
        if not done:
            return
        control.infoDialog(message)
        if self.series is not None and self.series.get('shown') is not None:
            self.populate_episodes(self.series['shown'], self.series.get('meta') or {}, self.series.get('avail'))
        self.local_dirty = True

    def sources_click(self, item):
        st = self.sources
        if st is None:
            return
        key = item.getProperty('key')
        if key == PLAY_ROW_KEY:
            self.dispatch('play', st.get('play_query') or '', st['title'], st['thumb'])
            return
        if key == MARK_ROW_KEY:
            from resources.lib.modules import marks
            page = self.sources_episode()
            self.close_sources()
            self.mark_local('%s&url=%s' % ('unmarkwatched' if marks.is_marked(page) else 'markwatched', page))
            return
        if not key:
            if not st['busy']:
                self.sources_fetch(measure=True)
            return
        self.dispatch('play', 'playsource&url=%s&key=%s' % (st['page'], key), st['title'], st['thumb'])

    # --- Ki nez? (profilok) -------------------------------------------------------

    def refresh_profile_button(self):
        '''A jobb felso gomb: az aktiv profil neve es szine.'''
        from resources.lib.modules import profiles
        try:
            name = profiles.active()
            self.setProperty('profile.name', profiles.label(name))
            self.setProperty('profile.color', profiles.KIDS_COLOR if profiles.is_kids(name) else str(profiles.color(name)))
            # A kezdobetu csak a nevvel letrehozott profilnal; a Kozosnel csak a fej-ikon.
            self.setProperty('profile.initial', profiles.initial(name) if name else u'')
        except Exception as exc:
            control.log_exception(u'profil-gomb', exc)

    def open_profiles(self):
        '''A Ki nez? kepernyo: csempek (Kozos, a nevek, Uj profil); OK valaszt, hosszan nyomva torol.'''
        if self.profiles_open:
            return
        self.close_series()
        self.close_detail()
        self.close_grid_views()
        self.stop_trailer()
        self.profiles_open = True
        self.setProperty('profiles', '1')
        self.populate_profiles()
        try:
            self.setFocusId(PROFILES_LIST_ID)
        except Exception:
            pass
        control.log(u'Ki néz?: képernyő megnyitva')

    def close_profiles(self):
        if not self.profiles_open:
            return
        self.profiles_open = False
        self.setProperty('profiles', '')
        try:
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def populate_profiles(self):
        from resources.lib.modules import profiles
        try:
            control_list = self.getControl(PROFILES_LIST_ID)
            had_focus = self.getFocusId() == PROFILES_LIST_ID
            control_list.reset()
            items = []
            selected = 0
            for index, (name, label, color, is_active, kids) in enumerate(profiles.tiles()):
                li = xbmcgui.ListItem(label=label)
                li.setProperty('name', name)
                li.setProperty('initial', profiles.initial(name))
                li.setProperty('color', str(color))
                li.setProperty('active', '1' if is_active else '')
                li.setProperty('kids', '1' if kids else '')
                items.append(li)
                if is_active:
                    selected = index
            if len(profiles.names()) < profiles.MAX_PROFILES:
                li = xbmcgui.ListItem(label=u'Új profil')
                li.setProperty('name', PROFILE_NEW)
                li.setProperty('initial', u'+')
                li.setProperty('color', 'new')
                items.append(li)
            control_list.addItems(items)
            self.refocus(PROFILES_LIST_ID, had_focus)
            control_list.selectItem(selected)
        except Exception as exc:
            control.log_exception(u'Ki néz?: csempék', exc)

    def pick_profile(self, name):
        '''OK egy csempen: valtas (a sajat sorok, beallitasok), vagy uj profil neve.'''
        from resources.lib.modules import profiles
        if name == PROFILE_NEW:
            if not self.ask_pin():
                return                                   # mese-profilbol csak PIN-nel
            typed = xbmcgui.Dialog().input(u'Az új profil neve', u'', xbmcgui.INPUT_ALPHANUM)
            if not typed or not typed.strip():
                return
            if not profiles.add(typed.strip()):
                control.okDialog(u'Ezt a nevet nem tudom használni (vagy már túl sok a profil).')
                return
            name = typed.strip()
            if control.yesnoDialog(u'Mese-profil?', u'Mese-profilban csak mesék és családi filmek látszanak '
                                   u'(a kereső, a listák és a Mit nézzek? is csak ezeket mutatja).',
                                   nolabel=u'Nem', yeslabel=u'Igen, mese'):
                profiles.set_kids(name, True)
        elif profiles.pin_needed(name) and not self.ask_pin(force=True):
            return
        if not profiles.set_active(name):
            return
        self.profile_changed()
        control.infoDialog(u'Profil: %s' % profiles.label(name))
        self.close_profiles()
        self.focus_first_row()

    def ask_pin(self, force=False):
        '''
        A PIN bekerese (4 szamjegy). True, ha nincs PIN, vagy jo. force: akkor
        is kerdez, ha nem mese-profil az aktiv (a felnott profil valasztasa);
        kulonben csak a mese-profilbol kilepeshez / beallitasokhoz kell.
        '''
        from resources.lib.modules import profiles
        if not profiles.has_pin():
            return True
        if not force and not profiles.kids_active():
            return True
        code = xbmcgui.Dialog().numeric(0, u'PIN')
        if not code:
            return False
        if not profiles.check_pin(code):
            control.infoDialog(u'Hibás PIN.')
            return False
        return True

    def profile_menu(self, name):
        '''Hosszan nyomva egy csempen: mese-profil be/ki, PIN, torles (PIN-nel, ha van).'''
        from resources.lib.modules import profiles
        if name == PROFILE_NEW or not self.ask_pin():
            return
        entries = []
        if name:
            entries.append((u'Mese-profil: %s' % (u'kikapcsolás' if profiles.is_kids(name) else u'bekapcsolás'), 'kids'))
        entries.append((u'PIN %s (a felnőtt profilok és a beállítások védelme)' % (u'módosítása' if profiles.has_pin() else u'beállítása'), 'pin'))
        if profiles.has_pin():
            entries.append((u'PIN törlése', 'nopin'))
        if name:
            entries.append((u'Profil törlése', 'delete'))
        choice = xbmcgui.Dialog().contextmenu([label for label, _key in entries])
        if choice < 0 or choice >= len(entries):
            return
        key = entries[choice][1]
        if key == 'kids':
            profiles.set_kids(name, not profiles.is_kids(name))
            if name == profiles.active():
                self.profile_changed()
            self.populate_profiles()
        elif key == 'pin':
            code = xbmcgui.Dialog().numeric(0, u'Új PIN (4 számjegy)')
            if code:
                if profiles.set_pin(code):
                    control.infoDialog(u'PIN beállítva.')
                else:
                    control.okDialog(u'A PIN 4 számjegy legyen.')
        elif key == 'nopin':
            profiles.set_pin('')
            control.infoDialog(u'PIN törölve.')
        elif key == 'delete':
            self.delete_profile(name)

    def delete_profile(self, name):
        '''A profil es minden adata torlodik (megerositessel).'''
        from resources.lib.modules import profiles
        if not name or name == PROFILE_NEW:
            return
        if not control.yesnoDialog(u'Profil törlése',
                                   u'„%s” és minden adata (előzmény, folytatás, figyelt lista, beállítások) törlődik. Biztos?' % name):
            return
        profiles.remove(name)
        self.profile_changed()
        self.populate_profiles()
        control.infoDialog(u'Profil törölve: %s' % name)

    def profile_changed(self):
        '''
        Profilvaltas utan: a gomb, a sorok ujra (a szemelyesek helybol, a
        halozatiak a tarbol, es a hordozo frissen is lekeri -- a mese-profil
        mas sorokat kap), a felso sav (mese-profilban nincs Regi menu).
        '''
        self.refresh_profile_button()
        try:
            rows = home.local_rows()
            rows.update(home.network_rows(cached_only=True))
            self.set_rows(rows, replace=True)
        except Exception as exc:
            control.log_exception(u'profilváltás: sorok', exc)
        self.rows_dirty = True
        try:
            self.setProperty('backdrop', '1' if control.setting('homebackdrop') != 'false' else '')
        except Exception:
            pass

    # --- Frissites: sajat ablak a verzioval ----------------------------------------

    def open_update(self):
        '''A felso sav Frissites gombja: a telepitett verzio, es a hatterben a repo lekerese.'''
        import threading
        if self.update_open:
            return
        self.update_open = True
        self.update_results = []
        installed = control.addonInfo('version')
        self.setProperty('update', '1')
        self.setProperty('update.installed', u'Telepítve: %s' % installed)
        self.setProperty('update.status', u'Keresem az újabb verziót…')
        self.setProperty('update.state', 'checking')
        try:
            self.setFocusId(UPDATE_BUTTON_ID)
        except Exception:
            pass
        queue = self.update_results

        def work():
            try:
                latest = home.latest_version()
            except Exception as exc:
                control.log_exception(u'frissítés ellenőrzése', exc)
                latest = None
            if queue is not None:
                queue.append(latest)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def updating(self):
        '''Epp frissul (van ujabb, a Kodi telepiti): az ablak magatol, az ujrainditassal zarul.'''
        return self.update_open and self.getProperty('update.state') == 'newer'

    def close_update(self):
        if not self.update_open:
            return
        self.update_open = False
        self.update_results = None
        self.setProperty('update', '')
        try:
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def update_tick(self):
        '''A hordozo hivja: a repo valasza -> a szoveg; ha van ujabb, a Kodi olvassa ujra a repokat.'''
        if not self.update_open:
            return
        while self.update_results:
            latest = self.update_results.pop(0)
            state, text = home.update_status(control.addonInfo('version'), latest)
            self.setProperty('update.state', state)
            self.setProperty('update.status', text)
            if state == 'newer':
                # A Kodi magatol csak naponta nez ra a repora: most keressuk meg.
                # A hordozo eszreveszi a telepulest, es ujrainditja a feluletet.
                self.update_requested = time.time()
                xbmc.executebuiltin('UpdateAddonRepos')
                control.log(u'Frissítés: %s -> %s, a repók újraolvasása kérve' % (control.addonInfo('version'), latest))
        if self.getProperty('update.state') == 'newer' and self.update_requested \
                and time.time() - self.update_requested > home.UPDATE_WAIT:
            self.update_requested = 0
            self.setProperty('update.state', 'stalled')
            self.setProperty('update.status', u'Nem települt magától. A Kodi beállításaiban a bővítmények '
                                              u'frissítése valószínűleg „Soha” értéken áll.')

    # --- Beallitasok nezete ------------------------------------------------------

    def open_settings(self):
        '''A felso sav Beallitasok tetelere: szakaszok balra, a sorok jobbra, alul a sugo.'''
        if self.settings is not None:
            return
        if not self.ask_pin():
            return                                       # mese-profilban a beallitasok PIN mogott
        self.close_grid_views()
        self.stop_trailer()
        if self.settings_model is None:
            # a vegen a Statisztika: a sorok helyen a sajat lapja
            self.settings_model = load_settings_model() + [STATS_SECTION]
        self.settings = {'section': 0, 'editing': None}
        self.setProperty('settings', '1')
        self.setProperty('settings.stats', '')
        self.populate_settings_sections()
        self.populate_settings_items()
        try:
            self.setFocusId(SETTINGS_SECTIONS_ID)
        except Exception:
            pass
        control.log(u'Beállítások: nézet megnyitva')

    def close_settings(self):
        if self.settings is None:
            return
        self.settings = None
        self.setProperty('settings', '')
        self.setProperty('settings.stats', '')
        # Ami az ablakot azonnal erinti: a hatter kapcsoloja.
        try:
            self.setProperty('backdrop', '1' if control.setting('homebackdrop') != 'false' else '')
        except Exception:
            pass
        try:
            self.getControl(SETTINGS_ITEMS_ID).reset()
            self.setFocusId(TOP_BAR_ID)
        except Exception:
            pass

    def quit_kodi(self):
        '''
        Kilepes a beallitasokbol: eloszor EZ az ablak all le rendben
        (kulonben a Kodi ugy zarna be a plugin-folyamatot, hogy az meg fut),
        aztan a Kodi maga.
        '''
        if not control.yesnoDialog(u'Bezárjuk a Kodit?',
                                   u'Megáll a lejátszás, és a Kodi is kilép.',
                                   u'Mégsem', u'Kilépés'):
            return
        control.log(u'Kilépés: a Kodi bezárása')
        try:
            self.stop_trailer()
        except Exception:
            pass
        try:
            home.guard_clear()
        except Exception:
            pass
        self.closed = True
        try:
            self.close()
        except Exception:
            pass
        xbmc.executebuiltin('Quit')

    def populate_settings_sections(self):
        sections = [(str(index), section['title']) for index, section in enumerate(self.settings_model)]
        self.fill_choice_list(SETTINGS_SECTIONS_ID, sections, u'beállítások: szakaszok', str(self.settings['section']))

    def settings_section_items(self):
        try:
            return self.settings_model[self.settings['section']]['items']
        except (IndexError, TypeError):
            return []

    def populate_settings_items(self, keep=False):
        '''A szakasz sorai: felirat (behuzassal), ertek, sugo; a tiltottak halvanyan.'''
        from resources.lib.modules import prefs
        try:
            control_list = self.getControl(SETTINGS_ITEMS_ID)
            position = control_list.getSelectedPosition() if keep else 0
            had_focus = self.getFocusId() == SETTINGS_ITEMS_ID
            control_list.reset()
            items = []
            for item in self.settings_section_items():
                value = prefs.value_of(item, control.setting)
                shown = prefs.display(item, value)
                if self.settings.get('editing') == item['id']:
                    shown = u'‹  %s  ›' % shown
                li = xbmcgui.ListItem(label=u'   ' * item['indent'] + item['label'])
                li.setProperty('id', item['id'])
                li.setProperty('type', item['type'])
                li.setProperty('value', shown)
                li.setProperty('on', '1' if item['type'] == 'bool' and value.lower() == 'true' else '')
                li.setProperty('disabled', '' if prefs.is_enabled(item, control.setting) else '1')
                li.setProperty('editing', '1' if self.settings.get('editing') == item['id'] else '')
                li.setProperty('help', item['help'])
                items.append(li)
            control_list.addItems(items)
            if items:
                control_list.selectItem(max(0, min(position, len(items) - 1)))
            self.refocus(SETTINGS_ITEMS_ID, had_focus)
        except Exception as exc:
            control.log_exception(u'beállítások: sorok', exc)

    def settings_tick(self):
        '''A hordozo hivja: a kijelolt szakasz valtott -> a sorok.'''
        if self.settings is None:
            return
        try:
            position = self.getControl(SETTINGS_SECTIONS_ID).getSelectedPosition()
        except Exception:
            return
        if 0 <= position < len(self.settings_model) and position != self.settings['section']:
            self.settings['section'] = position
            self.settings['editing'] = None
            self.populate_settings_items()
            if self.settings_model[position].get('stats'):
                self.show_stats()
            else:
                self.setProperty('settings.stats', '')

    def show_stats(self):
        '''A Statisztika lap: a kartyak, a mufajok csikjai, a havi es a heti oszlopok.'''
        from resources.lib.modules import stats
        try:
            data = stats.compute()
        except Exception as exc:
            control.log_exception(u'statisztika', exc)
            return
        for key in ('time', 'time_sub', 'films', 'films_sub', 'episodes', 'episodes_sub', 'taste', 'taste_sub',
                    'daypart', 'language', 'source', 'since'):
            self.setProperty('stats.%s' % key, data.get(key) or u'')
        for index in range(3):
            rows = data.get('top_series') or []
            self.setProperty('stats.top%d' % (index + 1), rows[index] if index < len(rows) else u'')
        if not data.get('top_series'):
            self.setProperty('stats.top1', u'Még nincs megnézett sorozatrész.')
        for list_id, rows, props in ((STATS_GENRES_ID, data.get('genres') or [], ('pct20',)),
                                     (STATS_MONTHS_ID, data.get('months') or [], ('h10',)),
                                     (STATS_DAYS_ID, data.get('weekdays') or [], ('h10',))):
            try:
                control_list = self.getControl(list_id)
                control_list.reset()
                items = []
                for row in rows:
                    li = xbmcgui.ListItem(label=row.get('label') or u'', label2=row.get('value') or u'')
                    for name in props:
                        li.setProperty(name, str(row.get(name) or 0))
                    items.append(li)
                control_list.addItems(items)
            except Exception as exc:
                control.log_exception(u'statisztika: lista', exc)
        self.setProperty('settings.stats', '1')

    def setting_item(self, setting_id):
        for item in self.settings_section_items():
            if item['id'] == setting_id:
                return item
        return None

    def save_setting(self, item, value):
        control.setSetting(item['id'], value)
        if item['id'] in LAYOUT_SETTINGS:
            self.layout_dirty = True
        control.log(u'Beállítás: %s = %s' % (item['id'], u'••••' if item.get('hidden') else value))

    def activate_setting(self, setting_id):
        '''OK egy soron: kapcsolo valt; lista/csuszka szerkeszto mod; szoveg bevitel; gomb fut.'''
        from resources.lib.modules import prefs
        item = self.setting_item(setting_id)
        if item is None or not prefs.is_enabled(item, control.setting):
            return
        if item['id'] == 'quitkodi':
            return self.quit_kodi()
        kind = item['type']
        if kind == 'bool':
            self.save_setting(item, prefs.toggled(prefs.value_of(item, control.setting)))
            self.populate_settings_items(keep=True)
        elif prefs.editable(item):
            self.settings['editing'] = None if self.settings.get('editing') == item['id'] else item['id']
            self.populate_settings_items(keep=True)
        elif kind == 'text':
            current = prefs.value_of(item, control.setting)
            option = xbmcgui.ALPHANUM_HIDE_INPUT if item.get('hidden') else 0
            typed = xbmcgui.Dialog().input(item['label'], u'' if item.get('hidden') else current,
                                           xbmcgui.INPUT_ALPHANUM, option)
            if typed is not None and (typed != u'' or not item.get('hidden')):
                self.save_setting(item, typed)
                self.populate_settings_items(keep=True)
        elif kind == 'action' and item.get('action'):
            control.log(u'Beállítások: %s' % item['action'])
            xbmc.executebuiltin(item['action'])

    def step_setting(self, direction):
        '''Bal / jobb a szerkesztett soron: a kovetkezo / elozo ertek, azonnal mentve.'''
        from resources.lib.modules import prefs
        item = self.setting_item(self.settings.get('editing'))
        if item is None:
            return
        value = prefs.stepped(item, prefs.value_of(item, control.setting), direction)
        self.save_setting(item, value)
        self.populate_settings_items(keep=True)

    def note_touch(self, now=None):
        '''Erintes: a gorgetosav elojon (a hordozo-ciklus tunteti el).'''
        self.touched_at = now or time.time()
        if not self.touch_shown:
            self.touch_shown = True
            self.setProperty('touched', '1')

    def touch_tick(self, now=None):
        '''Az utolso erintes utan TOUCH_SHOW_SECONDS-cel a gorgetosav eltunik.'''
        if self.touch_shown and (now or time.time()) - self.touched_at >= TOUCH_SHOW_SECONDS:
            self.touch_shown = False
            self.setProperty('touched', '')

    def scroll_plot(self, delta):
        self.plot_line = max(0, self.plot_line + delta)
        try:
            self.getControl(DETAIL_PLOT_ID).scroll(self.plot_line)
        except Exception as exc:
            control.log_exception(u'részletező: leírás görgetése', exc)

    # --- Helyi menu (hosszu nyomas egy csempen) -----------------------------------

    def open_menu(self, entries, title=u'', thumb=u''):
        '''A csempe helyi menuje sajat ablakban: borito, cim, a muveletek listaja.'''
        self.stop_trailer()
        came_from = self.getFocusId()
        # A sor es a hely MOST kell: a bezaras utan a Kodi meg a menu listajat
        # mondja fokuszaltnak (a setFocusId nem azonnal ut be).
        self.menu = {'entries': [tuple(entry) for entry in entries],
                     'title': title or u'', 'thumb': thumb or u'',
                     'from': came_from,
                     'list': came_from if came_from in ROW_LIST_IDS else 0}
        self.setProperty('menu', '1')
        self.setProperty('menu.title', title or u'')
        self.setProperty('menu.thumb', thumb or u'')
        self.populate_menu()
        try:
            self.setFocusId(MENU_LIST_ID)
        except Exception:
            pass
        control.log(u'Helyi menü: %s' % (title or u''))

    def populate_menu(self):
        try:
            control_list = self.getControl(MENU_LIST_ID)
            control_list.reset()
            items = []
            for label, _mode, query in self.menu['entries']:
                li = xbmcgui.ListItem(label=label)
                # A torles pirosan -- hogy latszodjon, melyik vesz el valamit.
                li.setProperty('danger', '1' if home.is_remove(query) else '')
                li.setProperty('icon', home.action_icon(query))
                items.append(li)
            control_list.addItems(items)
            control_list.selectItem(0)
        except Exception as exc:
            control.log_exception(u'helyi menü: lista', exc)

    def close_menu(self):
        '''Bezaras: a fokusz oda megy vissza, ahonnan a menu nyilt.'''
        if self.menu is None:
            return
        came_from = self.menu.get('from')
        self.menu = None
        self.setProperty('menu', '')
        self.setProperty('menu.title', '')
        self.setProperty('menu.thumb', '')
        try:
            self.getControl(MENU_LIST_ID).reset()
        except Exception:
            pass
        if came_from:
            try:
                self.setFocusId(came_from)
            except Exception:
                pass

    def menu_click(self):
        st = self.menu
        if st is None:
            return
        try:
            position = self.getControl(MENU_LIST_ID).getSelectedPosition()
        except Exception:
            return
        entries = st['entries']
        if not 0 <= position < len(entries):
            return
        label, mode, query = entries[position]
        title, thumb = st['title'], st['thumb']
        row = st.get('list') or 0
        self.close_menu()
        control.log(u'Helyi menü: %s' % label)
        if home.is_remove(query) and self.has_grid_views():
            # A torles tudja, melyik soron alltunk.
            self.remove_local(query, row)
            return
        self.dispatch(mode, query, title, thumb)

    def remove_local(self, query, list_id=None):
        '''
        Torles a helyi listabol (folytatas / amit mar lattam / figyelt): a sor
        AZONNAL ujraepul, a fokusz ezen a soron marad (a sor elejen), es a
        felszabadult csempen nem indul el rogton az elozetes. A sort a hivo
        adja meg (a menu a megnyitasakor jegyezte meg); kulonben a fokuszbol.
        '''
        if list_id is None:
            list_id = self.getFocusId()
            list_id = list_id if list_id in ROW_LIST_IDS else 0
        self.stop_trailer()
        removed, message = home.remove_local(query)
        if not removed:
            return
        control.infoDialog(message)
        self.set_rows(home.local_rows())
        self.keep_row_focus(list_id)

    def keep_row_focus(self, list_id):
        '''Torles utan: a sor elejere allunk -- a lenyeg, hogy a fokusz ezen a
        soron maradjon; ha a sor kiurult, az elso nem ures sorra.'''
        if not list_id:
            return
        try:
            control_list = self.getControl(list_id)
            size = control_list.size()
        except Exception:
            return
        if not size:
            self.focus_first_row()
            return
        try:
            control_list.selectItem(0)
        except Exception:
            pass
        # A sor ujraepitese utan a Kodi maga is keres fokuszt (rendre a
        # kovetkezo sorra ugrik), es a helyi allomany valtozasa miatt a
        # hordozo meg egyszer ujraepiti a sorokat: ezert par korig tartjuk.
        self.keep_focus = {'list': list_id, 'until': time.time() + KEEP_FOCUS_SECONDS}
        self.apply_keep_focus()

    def apply_keep_focus(self):
        '''Csak a SORT tartjuk: a kijelolest nem mozgatjuk (kulonben ide-oda ugralna).'''
        st = self.keep_focus
        if not st:
            return
        if time.time() > st['until']:
            self.keep_focus = None
            return
        try:
            if not self.getControl(st['list']).size():
                self.keep_focus = None
                return
            if self.getFocusId() != st['list']:
                self.setFocusId(st['list'])
        except Exception as exc:
            control.log_exception(u'törlés utáni fókusz', exc)

    def keep_focus_tick(self):
        '''A hordozo hivja: a torles utani fokuszt tartjuk, amig a nezo nem lep.'''
        if self.keep_focus and self.menu is None and self.detail is None and not self.in_grid_view():
            self.apply_keep_focus()

    def focus_guard_tick(self):
        '''
        Biztositek: ha a fokusz sehol (rejtett vezerlore allt, a Kodi
        elejtette), az ablak nem reagalna semmire. Ket kor utan visszatesszuk.
        '''
        if self.closed or not self.ready:
            return
        try:
            focus = self.getFocusId()
        except Exception:
            return
        if focus:
            self.focus_lost = 0
            return
        if _busy_elsewhere() or _modal_open():
            return                    # parbeszed van elol: nem nyulunk a fokuszhoz
        self.focus_lost += 1
        if self.focus_lost < 2:
            return                    # egy kor lehet nezetvaltas kozben is
        self.focus_lost = 0
        control.log(u'Kezdőképernyő: a fókusz elveszett -- visszatesszük')
        self.focus_view_default()

    def context_menu(self):
        # Hosszan nyomva egy lejatszas-gombon / egy reszen: a forrasok ablaka
        # (OK-ra minden indul, mint eddig -- valasztani csak itt kell).
        if self.menu is not None:
            return
        if self.open_sources_for_focus():
            return
        # A sorozat-nezetben az evad / resz SAJAT menuje (megneztem...), nem a sorozate.
        if self.detail is not None and self.getFocusId() not in (SEASONS_LIST_ID, EPISODES_LIST_ID):
            entries = list(self.detail.get('context') or [])
            title = self.detail.get('label') or u''
            thumb = self.detail.get('thumb') or u''
        else:
            item = self.selected(self.getFocusId())
            if item is None:
                return
            try:
                entries = json.loads(item.getProperty('context') or '[]')
            except ValueError:
                entries = []
            title = item.getLabel()
            thumb = item.getProperty('thumb')
            # kedvenc / tetszik / nem tetszik a borito menujeben is
            if not item.getProperty('more'):
                entries = [tuple(entry) for entry in entries]
                entries += home.taste_menu(item.getProperty('query'), entries)
            try:
                genres = json.loads(item.getProperty('genres') or '[]')
            except ValueError:
                genres = []
            self.menu_source = {'label': title, 'thumb': thumb, 'imdb': item.getProperty('imdb'), 'genres': genres}
        if not entries:
            return
        if self.has_grid_views():
            # TV-n a sajat ablakunk -- a Kodi felugro listaja helyett.
            self.open_menu(entries, title, thumb)
            return
        choice = xbmcgui.Dialog().contextmenu([entry[0] for entry in entries])
        if choice < 0:
            return
        _label, mode, query = entries[choice]
        self.dispatch(mode, query, title, thumb)

    def dispatch(self, mode, query, title=u'', thumb=u''):
        if not query:
            return
        if home.is_mark(query):
            # "Megnéztem": helyben (telefonon a Kodi helyi menujebol is), azonnal latszik.
            self.mark_local(query)
            return
        if home.is_taste(query):
            self.taste_local(query, title, thumb)
            return
        if home.is_remove(query) and self.has_grid_views():
            # Torles a helyi listabol: sajat folyamatban, azonnal (a RunPlugin
            # csak masodpercek mulva latszana, es a fokusz is elugrana).
            self.remove_local(query)
            return
        # Az elozetes ne szoljon bele a filmbe (es a lejatszas indulasat se zavarja).
        self.stop_trailer()
        if mode == 'play' and self.trailer is not None:
            # A film feloldasa masodpercekig tart: kozben NE induljon elozetes (a
            # reszletezoben azonnal indulna) -- kulonben a film az elozetest valtja,
            # es a szolgaltatas a filmet is elozetesnek hinne (nincs folytatas).
            self.trailer.pause_until = max(self.trailer.pause_until, time.time() + self.trailer.PLAY_HOLD)
        if mode == 'play' and query.startswith('sources&url=') and self.has_grid_views():
            # TV-n a forraslista a sajat nezetunk, nem a Kodi felugro listaja.
            self.open_sources(home._page_of(query), title, thumb)
            return
        if mode == 'play' and query.startswith(PLAY_QUERIES) and self.has_grid_views():
            # A lejatszas folyamatabraja AZONNAL (a lejatszo folyamat majd lepteti).
            from resources.lib.modules import playprogress
            playprogress.begin(title, thumb)
        command = builtin_for(mode, query)
        control.log(u'Kezdőképernyő: %s' % command)
        xbmc.executebuiltin(command)

    def play_tick(self, playing):
        '''A hordozo hivja: a folyamatabra eltunik, ha a film mar megy, ha lejart a hiba, vagy ha a folyamat elveszett.'''
        from resources.lib.modules import playprogress
        if not playprogress.is_active():
            return
        if playing:
            playprogress.clear()
        elif playprogress.step() == playprogress.STEP_FAIL and playprogress.age() > playprogress.FAIL_SECONDS:
            playprogress.clear()
        elif playprogress.age() > playprogress.STALE_SECONDS:
            control.log(u'Lejátszás folyamatábrája: nem frissült, törölve', control.LOGWARNING)
            playprogress.clear()


def create(rows):
    '''Ablak peldanyositasa a sorokkal; None, ha nem sikerul.'''
    count, touch = layout_key()
    try:
        window = HomeWindow(xml_file(count, touch), control.addonPath, 'Default', '1080i')
    except Exception as exc:
        control.log_exception(u'kezdőképernyő létrehozása', exc)
        return None
    window.poster_count = count
    window.layout = (count, touch)
    window.set_rows(rows)
    return window


# --- A fokuszalt tetel: hatterkep, szolgaltato, elozetes ------------------------

class Focus(object):
    """
    Figyeli, melyik boriton all a nezo, es a TMDB adatait (hatterkep,
    szolgaltatok, elozetes) a hatterben lekeri -- egyszer, gyorsitotarral.
    Az ablak 'fanart' tulajdonsagaba irja a valodi hatterkepet (az XML azt
    mutatja, ha van, kulonben a kivagott boritot), a borito ala a
    szolgaltatot. A record a Trailer-nek is kell.
    """

    def __init__(self, window):
        self.window = window
        self.thumb = None
        self.imdb = ''
        self.since = 0
        self.record = None          # None: meg nem tudjuk; {}: nincs
        self.result = {}

    def tick(self):
        import threading
        try:
            thumb = self.window.focused_thumb()
            imdb = self.window.focused_imdb()
        except Exception:
            thumb, imdb = '', ''
        if thumb == self.thumb and imdb == self.imdb:
            if 'record' in self.result:
                self._apply(self.result.pop('record'))
            return
        self.thumb = thumb
        self.imdb = imdb
        self.since = time.time()
        self.record = None
        self.result = {}
        if not imdb:
            self._apply({})
            return
        known = home.title_info(imdb, cached_only=True)
        if known is not None and known.get('complete'):
            self._apply(known)
            return
        if known is not None:
            self._apply(known)                       # ami mar van, azonnal; a tobbi jon
        result = self.result

        def work():
            try:
                result['record'] = home.title_info(imdb) or {}
            except Exception as exc:
                control.log_exception(u'cím adatai', exc)
                result['record'] = {}
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def _apply(self, record):
        self.record = record or {}
        try:
            self.window.setProperty('fanart', self.record.get('backdrop') or '')
        except Exception:
            pass
        try:
            self.window.update_hero(self.record)
        except Exception as exc:
            control.log_exception(u'kezdőképernyő: adatok felül', exc)
        if not self.record.get('services'):
            return
        # A borito alatti sor -- csak ezen az egy tetelen, helyben.
        try:
            item = self.window.selected(self.window.getFocusId())
            if item is not None and item.getProperty('thumb') == self.thumb:
                entry = {'thumb': self.thumb, 'sub': item.getProperty('sub'), 'imdb': self.imdb}
                item.setLabel2(home.service_sub(entry, {self.imdb: self.record}))
        except Exception:
            pass

    def dwell(self):
        """Ennyi ideje all ugyanazon a boriton (mp)."""
        return time.time() - self.since if self.thumb else 0


class Trailer(object):
    """
    Elozetes a hatterben, hanggal -- mint a Netflixen. Ket lepcso:

      1. amint a nezo egy boritora lep, a HATTERBEN elkezdjuk feloldani a
         videocimet (trailer.resolve: IMDb) -- a felulet nem all meg;
      2. ha par masodpercig ugyanott all, a KESZ cimet adjuk a lejatszonak,
         ablakban (a poszterek elotte maradnak). Az azonnal indul, es
         elmozdulasra, OK-ra, zarasra azonnal le is all.

    Beallitasbol kapcsolhato. A hatterszolgaltatasnak jelez
    (ablak-tulajdonsag), hogy ez nem film:
    ne kovesse a folytatast, ne mutasson hozzaszolast.
    """

    def __init__(self, window):
        from resources.lib.modules import config
        self.config = config
        self.PROPERTY = config.TRAILER_PROPERTY
        self.window = window
        self.player = xbmc.Player()
        self.active = False         # inditottuk, es meg nem allt le
        self.shown = False          # a video mar megy (az XML a videot mutatja)
        self.played_for = None      # ezen a boriton mar szolt (amig el nem lepsz rola)
        self.last_thumb = None
        self.started_at = 0
        self.resolving = set()      # kulcsok, amiket eppen old fel egy szal

    def enabled(self):
        try:
            return control.setting('hometrailer') != 'false'
        except Exception:
            return True

    def delay(self):
        '''Ennyi masodperc allas utan indul (beallitas; alap a config).'''
        try:
            value = float(control.setting('trailerdelay') or 0)
        except (TypeError, ValueError):
            value = 0
        return value if value > 0 else self.config.TRAILER_DELAY

    def tick(self, focus, playing):
        from resources.lib.modules import trailer
        if focus.thumb != self.last_thumb:
            self.last_thumb = focus.thumb
            self.played_for = None                       # uj boriton: ujra jatszhat
            if self.active:
                self.stop()                              # elmozdult: azonnal all
        # A kulcs: az IMDb-azonosito a boritobol (azonnal megvan); a YouTube
        # kulcs a TMDB-bejegyzesbol, tartaleknak (ha mar ismerjuk).
        key = focus.imdb
        if not key or not self.enabled():
            return
        # 1) feloldas azonnal, a hatterben -- mire letelik a varakozas, kesz.
        if trailer.cached(key) is None:
            self.prefetch(key)
        if self.active:
            if not playing:
                # Kozvetlen cim: par masodperc alatt megy; utana a "nem megy"
                # a veget jelenti.
                if self.shown or time.time() - self.started_at > self.config.TRAILER_START_GRACE:
                    if not self.shown:
                        # el sem indult (a szerver nem adott adatot): ezt a cimet nem
                        # probaljuk ujra, es egy ideig nincs elozetes (a Kodi hibaablaka
                        # alatt uj lejatszas inditasa megakaszthatja a Kodit)
                        trailer.mark_failed(key)
                        self.pause_until = time.time() + self.FAIL_PAUSE
                        control.log(u'Előzetes nem indult el: %s -- szünet' % key, control.LOGWARNING)
                    self._done()                         # magatol veget ert
            elif not self.shown:
                self.shown = True
                self._mark_window(True)
            return
        if playing or focus.thumb == self.played_for:
            return
        if time.time() < self.pause_until or modal_dialog_open():
            return                                       # hiba utan szunet / nyitott Kodi-ablak: nem inditunk
        # A kereso racsan nincs csempe az elozetesnek: ott nem indul.
        if getattr(self.window, 'in_grid_view', lambda: False)():
            return
        # A listaban a beallitott ido allas kell; a reszletezoben azonnal.
        if focus.dwell() < self.delay() and not self.window.in_detail():
            return
        url = trailer.cached(key)
        if url is None:
            return                                       # meg oldodik; jovok ujra
        if not url:
            self.played_for = focus.thumb                # nem jatszhato: ezen nem probalkozunk
            return
        # 2) inditas a kesz cimmel
        self.start(focus.thumb, key, url)

    def prefetch(self, key):
        import threading
        from resources.lib.modules import trailer
        if key in self.resolving:
            return
        self.resolving.add(key)

        def work():
            try:
                trailer.resolve(key)
            except Exception as exc:
                control.log_exception(u'előzetes feloldása', exc)
            finally:
                self.resolving.discard(key)
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    FAIL_PAUSE = 120        # mp: egy el nem indult elozetes utan ennyi ideig nincs uj
    PLAY_HOLD = 90          # mp: a lejatszas inditasa utan (a film feloldasa alatt) nincs elozetes
    pause_until = 0

    def start(self, thumb, key, url):
        self.played_for = thumb
        self.active = True
        self.shown = False
        self.started_at = time.time()
        try:
            xbmcgui.Window(10000).setProperty(self.PROPERTY, str(int(time.time())))
        except Exception:
            pass
        control.log(u'Előzetes indul: %s' % key)
        try:
            # Plugin-utvonalon at (default.py: trailerplay): a Kodi igy a
            # leallitaskor nem ker HEAD-et a videoszervertol (30 mp fagyas).
            from urllib.parse import quote
            play = plugin_url('trailerplay&url=%s' % quote(url, safe=''))
            item = xbmcgui.ListItem(path=play)
            self.player.play(play, item, windowed=True)
        except Exception as exc:
            control.log_exception(u'előzetes indítása', exc)
            self._done()

    def stop(self):
        if not self.active:
            return
        # Akkor is, ha meg csak nyilik (nem "megy"): kulonben a mar elhagyott
        # borito elozetese indulna el egy masodperccel kesobb.
        try:
            self.player.stop()
        except Exception:
            pass
        self._done()

    def _done(self):
        self.active = False
        self.shown = False
        self._mark_window(False)
        try:
            xbmcgui.Window(10000).clearProperty(self.PROPERTY)
        except Exception:
            pass

    def _mark_window(self, on):
        try:
            self.window.setProperty('trailer', '1' if on else '')
        except Exception:
            pass


def trailer_playing(now=None):
    """
    A hatterszolgaltatasnak: megy-e eppen elozetes. A jelzo idobelyeges --
    a nagyon regi (a kezdokepernyo torles nelkul tunt el) nem szamit.
    """
    from resources.lib.modules import config
    return config.trailer_marked(now)


# --- A hordozo: show + ciklus a plugin folyamataban -----------------------------

def _addon_stamp():
    """A bovitmeny addon.xml-jenek valtozasa: frissiteskor mas lesz."""
    import os
    try:
        return int(os.path.getmtime(os.path.join(control.addonPath, 'addon.xml')))
    except OSError:
        return 0


def _busy_elsewhere():
    """Lista, beallitas vagy teljes kepernyos video van a kezdokepernyo elott."""
    try:
        return bool(xbmc.getCondVisibility(
            'Window.IsActive(videos) | Window.IsActive(addonsettings) | Window.IsActive(fullscreenvideo)'))
    except Exception:
        return False


def _modal_open():
    """Parbeszed (kerdes, helyi menu, billentyuzet) van-e a kepernyon."""
    try:
        return bool(xbmc.getCondVisibility('System.HasActiveModalDialog | System.HasVisibleModalDialog'))
    except Exception:
        return False


def row_mark(control_list):
    """(a kijelolt tetel azonositoja, a helye) -- az ujraepites utan ide allunk vissza."""
    try:
        position = max(control_list.getSelectedPosition(), 0)
        item = control_list.getListItem(position)
        return (item.getProperty('query') or item.getLabel() or u''), position
    except Exception:
        return u'', 0


def restore_mark(control_list, entries, mark):
    """Az ujraepitett sorban ugyanaz a tetel legyen kijelolve (ha megvan)."""
    wanted, position = mark
    if not wanted and not position:
        return
    index = -1
    if wanted:
        for at, entry in enumerate(entries):
            if (entry.get('query') or entry.get('label') or u'') == wanted:
                index = at
                break
    if index < 0:                       # kiesett a tetel: maradjunk a helyen
        index = min(position, len(entries) - 1)
    try:
        control_list.selectItem(max(index, 0))
    except Exception:
        pass


def _local_stamp():
    """A helyi adatok utolso valtozasa -- lejatszas utan ebbol tudjuk, hogy frissitsunk."""
    import os
    from resources.lib.modules import history, progress, taste, watchlist
    stamp = 0
    for path in (progress._path(), history._path(history.HISTORY_FILE), watchlist._path(), taste._path()):
        try:
            stamp = max(stamp, int(os.path.getmtime(path)))
        except OSError:
            pass
    return stamp


def host(async_network=True, ask_profile=False):
    """
    Megnyitja a kezdokepernyot, es addig marad, amig a nezo be nem zarja.
    True, ha megnyilt; False, ha nem sikerult letrehozni.

    - azonnal: helyi sorok + ami a gyorsitotarban van;
    - hatterben: friss halozati sorok, a napi ellenorzesek (Stream Top,
      szolgaltato-sorok), es a sorok cimeinek TMDB-adatai (a szal csak
      letolt; az ablakba EZ a ciklus ir);
    - lejatszas utan (a helyi fajlok valtoztak): a helyi sorok frissulnek.
    """
    import threading
    from resources.lib.modules import tmdb
    home.guard_set()
    rows = home.local_rows()
    try:
        rows.update(home.network_rows(cached_only=True))
    except Exception as exc:
        control.log_exception(u'kezdőképernyő: gyorsítótár', exc)
    window = create(rows)
    if window is None:
        home.guard_clear()
        return False
    window.show()
    control.log(u'Kezdőképernyő megnyitva (plugin-folyamat)')
    if ask_profile:
        # Bekapcsolas utan: Ki nez? -- TV-n a sajat kepernyo, erintos elrendezesben a Kodi valasztoja.
        try:
            if window.has_grid_views():
                window.open_profiles()
            else:
                from resources.lib.modules import profiles
                profiles.ask_dialog()
                window.profile_changed()
        except Exception as exc:
            control.log_exception(u'Ki néz?', exc)

    pending = {}

    def fetch():
        try:
            pending['network'] = home.network_rows()
            # Napi ellenorzesek a hatterben -- es utana a sorok ujra, mar a
            # megtalaltakkal.
            refreshed = False
            for ensure in (home.ensure_stream_check, home.ensure_provider_rows):
                try:
                    refreshed = ensure() or refreshed
                except Exception as exc:
                    control.log_exception(u'kezdőképernyő: napi ellenőrzés', exc)
            if refreshed:
                pending['network'] = home.network_rows(cached_only=True)
        except Exception as exc:
            control.log_exception(u'kezdőképernyő: hálózati sorok', exc)
        # A sorok cimeinek TMDB-adatai (szolgaltato, hatterkep, elozetes):
        # egyszer minden cimre, tempoban. Kulcs nelkul nem csinal semmit.
        try:
            all_rows = dict(window.rows or {})
            all_rows.update(pending.get('network') or {})
            if tmdb.prefetch(home.all_thumbs(all_rows), stop=lambda: window.closed):
                pending['badges'] = True
            # A figyelt / folytatott sorozatok kovetkezo resze (visszaszamlalas).
            if home.refresh_next_episodes(all_rows, stop=lambda: window.closed):
                pending['local'] = True
        except Exception as exc:
            control.log_exception(u'kezdőképernyő: TMDB előlekérés', exc)
        # A boritok: ami nem tolt be, az a sorokbol kimarad (ujranezve visszajon).
        try:
            all_rows = dict(window.raw_rows if getattr(window, 'raw_rows', None) else window.rows or {})
            all_rows.update(pending.get('network') or {})
            if home.check_covers(home.all_thumbs(all_rows), stop=lambda: window.closed):
                pending['covers'] = True
        except Exception as exc:
            control.log_exception(u'kezdőképernyő: borítók', exc)
    if async_network:
        thread = threading.Thread(target=fetch)
        thread.daemon = True
        thread.start()
    else:
        fetch()

    monitor = xbmc.Monitor()
    player = xbmc.Player()
    opened_at = time.time()
    guard_cleared = False
    local_stamp = _local_stamp()
    addon_stamp = _addon_stamp()
    next_update_check = opened_at + UPDATE_CHECK_SECONDS
    reload = False
    focus = Focus(window)
    trailer = Trailer(window)
    window.trailer = trailer
    window.focus = focus
    last_tick = time.time()
    refreshing = [False]
    while not window.closed and not monitor.abortRequested():
        if monitor.waitForAbort(0.5):
            break
        # Frissult a bovitmeny? Ez a folyamat meg a REGI kodot futtatja: az
        # ablakot bezarjuk, es az uj kod nyitja ujra -- de csak ha nem megy
        # film, es nem all elotte lista/beallitas.
        soon = window.update_requested and time.time() - window.update_requested < home.UPDATE_WAIT
        if (time.time() >= next_update_check or window.layout_dirty) and window.settings is None:
            # A Frissites gomb utan surubben nezzuk, telepult-e az uj verzio.
            next_update_check = time.time() + (home.UPDATE_RETRY_SECONDS if soon else UPDATE_CHECK_SECONDS)
            window.layout_dirty = False
            try:
                playing_now = player.isPlaying()
            except Exception:
                playing_now = False
            try:
                changed = (_addon_stamp() != addon_stamp or layout_key() != window.layout)
            except Exception as exc:
                # Frissites kozben (a regi torolve, az uj meg nincs): a
                # kovetkezo korben ujra nezzuk.
                control.log(u'Kezdőképernyő: a frissítés-ellenőrzés most nem ment (%s)' % exc, control.LOGWARNING)
                changed = False
            if changed and not control.addonKnown():
                # A bovitmeny epp cserelodik: a RunPlugin most nem menne.
                # Rovidesen ujra nezzuk, es ha visszajott, ujraindulunk az uj koddal.
                next_update_check = time.time() + UPDATE_RETRY_SECONDS
                changed = False
            if changed and not playing_now and not _busy_elsewhere():
                reload = True
                break
        focus.tick()
        try:
            playing = player.isPlaying()
        except Exception:
            playing = False
        trailer.tick(focus, playing)
        if not guard_cleared and time.time() - opened_at > home.GUARD_SECONDS:
            home.guard_clear()
            guard_cleared = True
        # Keszenletbol ebredes (a TV "kikapcsolva" is fut): ha a ciklus sokat
        # kihagyott, minden ugyanugy frissul, mint egy uj indulaskor.
        now_tick = time.time()
        if now_tick - last_tick > RESUME_GAP and window.refresh_wanted is None:
            control.log(u'Kezdőképernyő: ébredés (%d mp kimaradt) -- frissítés' % int(now_tick - last_tick))
            window.refresh_wanted = 'resume'
        last_tick = now_tick
        if window.refresh_wanted and not refreshing[0]:
            force = window.refresh_wanted == 'all'
            window.refresh_wanted = None
            refreshing[0] = True

            def refresh_all(force=force):
                try:
                    pending['network'] = home.network_rows(force=force)
                    for ensure in (home.ensure_stream_check, home.ensure_provider_rows):
                        try:
                            if ensure(force=force):
                                pending['network'] = home.network_rows(cached_only=True)
                        except Exception as exc:
                            control.log_exception(u'frissítés: napi ellenőrzés', exc)
                    all_rows = dict(window.rows or {})
                    all_rows.update(pending.get('network') or {})
                    if home.refresh_next_episodes(all_rows, stop=lambda: window.closed, force=force):
                        pending['local'] = True
                    if home.check_covers(home.all_thumbs(all_rows), stop=lambda: window.closed):
                        pending['covers'] = True
                    # A figyelt sorozatok: a plugin folyamataban (csendben; a gombra mindet).
                    xbmc.executebuiltin('RunPlugin(%s)' % plugin_url('watchcheck&quiet=1' + ('&force=1' if force else '')))
                    pending['local'] = True
                except Exception as exc:
                    control.log_exception(u'frissítés', exc)
                finally:
                    refreshing[0] = False
            thread = threading.Thread(target=refresh_all)
            thread.daemon = True
            thread.start()
        if window.local_dirty:
            # Valami helyben valtozott (pl. lekerult egy "UJ RESZ" jelzes).
            window.local_dirty = False
            pending['local'] = True
        if window.rows_dirty:
            # Profilvaltas: a halozati sorok frissen (a mese-profil mas listakat kap).
            window.rows_dirty = False
            refetch = threading.Thread(target=lambda: pending.__setitem__('network', home.network_rows()))
            refetch.daemon = True
            refetch.start()
        if 'network' in pending:
            window.set_rows(pending.pop('network'))
        if pending.pop('badges', False):
            window.refresh_badges()
        if pending.pop('covers', False):
            window.refilter()
        # Lejatszas (az elozetes is!) alatt nem frissitunk -- de a keres megmarad
        # (kulonben a reszletezoben, elozetes kozben tett kedvenc sosem latszana).
        if not playing and pending.pop('local', False):
            window.set_rows(home.local_rows())
        window.detail_tick()
        window.series_tick()
        window.search_tick()
        window.browse_tick()
        window.tonight_tick()
        window.provider_tick()
        window.sources_tick()
        window.settings_tick()
        window.update_tick()
        window.play_tick(playing)
        window.keep_focus_tick()
        window.focus_guard_tick()
        window.touch_tick()
        if not playing:
            stamp = _local_stamp()
            if stamp != local_stamp:
                local_stamp = stamp
                window.set_rows(home.local_rows())
    trailer.stop()
    if not guard_cleared:
        home.guard_clear()
    if not window.closed:
        try:
            window.close()
        except Exception:
            pass
    control.log(u'Kezdőképernyő bezárva')
    if reload:
        if layout_key() != window.layout:
            control.log(u'Az elrendezés változott: a kezdőképernyő újranyílik')
        else:
            control.log(u'A bővítmény frissült: a kezdőképernyő újraindul az új kóddal')
            try:
                control.infoDialog(u'A netmozi frissült -- a kezdőképernyő újraindul.')
            except Exception:
                pass
            # A skin ujratoltese: a Kodi a betoltott texturakat (maszkok,
            # ikonok) nev szerint tartja memoriaban -- a frissitett fajlok
            # csak igy kerulnek be.
            xbmc.executebuiltin('ReloadSkin()')
        xbmc.executebuiltin('RunPlugin(%s)' % plugin_url('home'))
    return True
