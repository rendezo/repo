# -*- coding: utf-8 -*-
'''
Kezzel megnezettnek jelolt reszek ("Megnéztem" a helyi menuben).

Ha a nezo mashol latta a reszt (telefonon, teve-csatornan), itt jelolheti
meg: a reszlistan "megnézve" lesz, a sajat listan lekerul rola az "uj"
jelzes, es a folytatas a kovetkezo reszre lep. Egy egesz evad is jelolheto.

Kulon fajlban, NEM az elozmenyekben: az a "Nézd meg újra" sor, amit egy
evadnyi jeloles teleszemetelne (es a valodi elozmenyeket kiszoritana).
Profilonkent kulon, mint a tobbi helyi lista.
'''
import json
import os
import time

from resources.lib.modules import control

FILE = 'marked.json'
MAX_PAGES = 3000


def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    '''A megjelolt reszek utvonalai ("<sorozat>/s2/e5"), a jeloles sorrendjeben.'''
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return [page for page in data if isinstance(page, str)] if isinstance(data, list) else []
    except (IOError, OSError, ValueError):
        return []


def save(pages):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(pages[-MAX_PAGES:], handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'megnézett részek írása', exc)
        return False


def pages():
    return set(load())


def is_marked(page):
    return page in pages()


def season_pages(base, season, numbers):
    return ['%s/s%d/e%d' % (base, int(season), int(number)) for number in numbers]


def mark(episode_pages):
    '''Megnezettnek jeloles. Visszaad: hany uj jeloles lett.'''
    from resources.lib.modules import progress, watchlist
    episode_pages = [page for page in episode_pages if progress.split_page(page)]
    if not episode_pages:
        return 0
    stored = load()
    known = set(stored)
    fresh = [page for page in episode_pages if page not in known]
    if fresh:
        save(stored + fresh)
    try:
        watchlist.mark_seen_all(episode_pages)
    except Exception as exc:
        control.log_exception(u'megnéztem: saját lista', exc)
    try:
        _advance(episode_pages)
    except Exception as exc:
        control.log_exception(u'megnéztem: folytatás', exc)
    control.log(u'Megnézettnek jelölve: %d rész' % len(episode_pages))
    return len(fresh)


def unmark(episode_pages):
    '''A jeloles visszavonasa. Visszaad: hany jeloles kerult le.'''
    from resources.lib.modules import progress
    drop = set(episode_pages)
    stored = load()
    remaining = [page for page in stored if page not in drop]
    if len(remaining) != len(stored):
        save(remaining)
    # Ha a folytatas a jeloles miatt lepett tovabb, a visszavont resz ujra
    # "folytatando": onnan indul, nem a kovetkezorol.
    data = progress.load()
    changed = False
    for page in drop:
        parts = progress.split_page(page)
        entry = data.get(parts[0]) if parts else None
        if entry and entry.get('page') == page and entry.get('marked'):
            entry.pop('done', None)
            entry.pop('marked', None)
            changed = True
    if changed:
        progress.save(data)
    return len(stored) - len(remaining)


def _advance(episode_pages):
    '''
    A folytatas a legkesobbi megjelolt reszre all, "megnezve" allapotban --
    igy a kovetkezo resz jon. Csak ha a sorozat mar a folytatasban van, es
    csak elore (egy regebbi resz jelolese nem viszi vissza).
    '''
    from resources.lib.modules import progress
    latest = {}
    for page in episode_pages:
        base, season, episode = progress.split_page(page)
        if base not in latest or (season, episode) > latest[base][0]:
            latest[base] = ((season, episode), page)
    data = progress.load()
    changed = False
    for base, ((season, episode), page) in latest.items():
        entry = data.get(base)
        if not entry or entry.get('kind') != 'series':
            continue
        current = (entry.get('season') or 0, entry.get('episode') or 0)
        if (season, episode) < current or ((season, episode) == current and progress.finished(entry)):
            continue
        entry.update({'page': page, 'season': season, 'episode': episode,
                      'position': 0, 'total': 0, 'done': True, 'marked': True,
                      'updated': int(time.time())})
        entry.pop('next_page', None)
        changed = True
    if changed:
        progress.save(data)
