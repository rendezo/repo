# -*- coding: utf-8 -*-
'''
Sajat lejatszasvezerlo (NetmoziOSD.xml) a Kodi vezerlosavja helyett.

Lejatszas kozben az OK gomb (a bovitmeny billentyu-kiosztasa, keymap.py)
ezt nyitja: negy gomb -- lejatszas/szunet, leallitas, felirat, hangsav --,
fole a cim, az idosav es hogy mikor lesz vege. A felirat es a hangsav
valasztoja a panelen nyilik, a bekapcsolt pipaval.

Csak a NetMozi lejatszasara: a szolgaltatas jelzi (PLAYING_PROP), ha a
futo video a mienk. Mas lejatszasnal a Kodi sajat vezerloje jon (Action(OSD)).
'''
import threading
import time

import xbmc
import xbmcgui

from resources.lib.modules import control, history

XML = 'NetmoziOSD.xml'
PLAYING_PROP = 'netmozi.playing'        # az inditas allitja (history.set_context), a lejatszas vege torli (Window 10000)
BUTTONS_ID = 700
MENU_ID = 710
HIDE_AFTER = 6                          # ennyi mp tetlenseg utan eltunik (szunetben nem)

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
CLOSE_ACTIONS = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK)

BUTTONS = (
    ('playpause', u'', ''),                              # ikon es felirat a skinbol (Player.Paused)
    ('stop', u'Leállítás', 'nm-stop.png'),
    ('subtitles', u'Felirat', 'nm-subtitles.png'),
    ('audio', u'Hangsáv', 'nm-audio.png'),
)

# A Kodi a savokat ISO 639-2 koddal (vagy angol nevvel) adja.
LANGUAGES = {
    'hun': u'Magyar', 'hu': u'Magyar', 'hungarian': u'Magyar',
    'eng': u'Angol', 'en': u'Angol', 'english': u'Angol',
    'ger': u'Német', 'deu': u'Német', 'de': u'Német', 'german': u'Német',
    'fre': u'Francia', 'fra': u'Francia', 'fr': u'Francia', 'french': u'Francia',
    'spa': u'Spanyol', 'es': u'Spanyol', 'spanish': u'Spanyol',
    'ita': u'Olasz', 'it': u'Olasz', 'italian': u'Olasz',
    'rum': u'Román', 'ron': u'Román', 'ro': u'Román', 'romanian': u'Román',
    'cze': u'Cseh', 'ces': u'Cseh', 'cs': u'Cseh', 'czech': u'Cseh',
    'slo': u'Szlovák', 'slk': u'Szlovák', 'sk': u'Szlovák', 'slovak': u'Szlovák',
    'pol': u'Lengyel', 'pl': u'Lengyel', 'polish': u'Lengyel',
    'rus': u'Orosz', 'ru': u'Orosz', 'russian': u'Orosz',
    'jpn': u'Japán', 'ja': u'Japán', 'japanese': u'Japán',
    'kor': u'Koreai', 'ko': u'Koreai', 'korean': u'Koreai',
    'por': u'Portugál', 'pt': u'Portugál', 'portuguese': u'Portugál',
    'dut': u'Holland', 'nld': u'Holland', 'nl': u'Holland', 'dutch': u'Holland',
    'tur': u'Török', 'tr': u'Török', 'turkish': u'Török',
    'hrv': u'Horvát', 'hr': u'Horvát', 'croatian': u'Horvát',
    'srp': u'Szerb', 'sr': u'Szerb', 'serbian': u'Szerb',
    'ukr': u'Ukrán', 'uk': u'Ukrán', 'ukrainian': u'Ukrán',
}


def language_name(code):
    '''"hun" -> "Magyar"; ismeretlennel a kod maga (nagy kezdobetuvel); ures -> "Ismeretlen".'''
    text = (code or '').strip()
    if not text:
        return u'Ismeretlen'
    return LANGUAGES.get(text.lower(), text[:1].upper() + text[1:])


def _same_language(code, current):
    '''A Kodi a "jelenlegi" savot neha koddal, neha nevvel adja: mindkettot egyezteti.'''
    if not code or not current:
        return False
    return code.lower() == current.lower() or language_name(code) == language_name(current)


def _numbered(names):
    '''Ha ket sav azonos nyelvu, sorszamot kapnak: "Magyar (1)", "Magyar (2)".'''
    counts = {}
    for name in names:
        counts[name] = counts.get(name, 0) + 1
    seen = {}
    out = []
    for name in names:
        if counts[name] > 1:
            seen[name] = seen.get(name, 0) + 1
            out.append(u'%s (%d)' % (name, seen[name]))
        else:
            out.append(name)
    return out


def subtitle_entries(streams, enabled, current):
    '''[(felirat, parancs, bekapcsolt-e)]: Kikapcsolva, a savok, Felirat keresese.'''
    names = _numbered([language_name(code) for code in streams or []])
    out = [(u'Kikapcsolva', ('off',), not enabled)]
    marked = False
    for index, code in enumerate(streams or []):
        on = bool(enabled) and not marked and _same_language(code, current)
        marked = marked or on
        out.append((names[index], ('sub', index), on))
    if enabled and not marked and len(out) == 2:
        out[1] = (out[1][0], out[1][1], True)            # egyetlen sav, es be van kapcsolva
    out.append((u'Felirat keresése…', ('search',), False))
    if enabled:
        # ha csuszik: 0,5 mp-enkent (a Kodi a sajat csuszkajan mutatja az erteket)
        out.append((u'Felirat korábban (0,5 mp)', ('delay', -5), False))
        out.append((u'Felirat később (0,5 mp)', ('delay', 5), False))
    return out


def audio_entries(streams, current):
    '''[(felirat, parancs, bekapcsolt-e)] a hangsavokra.'''
    names = _numbered([language_name(code) for code in streams or []])
    out = []
    marked = False
    for index, code in enumerate(streams or []):
        on = not marked and _same_language(code, current)
        marked = marked or on
        out.append((names[index], ('audio', index), on))
    if out and not marked:
        out[0] = (out[0][0], out[0][1], True)            # nem tudjuk: az elso szol
    return out


def should_hide(now, touched, paused, menu_open):
    '''Eltunjon-e: tetlenseg utan, de szunetben es nyitott valasztoval nem.'''
    return not paused and not menu_open and now - touched >= HIDE_AFTER


def ours():
    '''A futo video a NetMozie-e (a szolgaltatas jelzi).'''
    try:
        return xbmcgui.Window(10000).getProperty(PLAYING_PROP) == '1'
    except Exception:
        return False


def show():
    '''Az OK gomb lejatszas kozben: a mi vezerlonk, vagy (nem a mienk) a Kodi sajatja.'''
    player = xbmc.Player()
    mine, video = ours(), player.isPlayingVideo()
    control.log(u'Lejátszásvezérlő (OK): NetMozi-videó=%s, videó megy=%s' % (mine, video))
    if not (mine and video):
        xbmc.executebuiltin('Action(OSD)')
        return False
    try:
        dialog = OSD(XML, control.addonPath, 'Default', '1080i')
        dialog.player = player
        dialog.touched = time.time()
        dialog.doModal()
        del dialog
        return True
    except Exception as exc:
        control.log_exception(u'lejátszásvezérlő', exc)
        xbmc.executebuiltin('Action(OSD)')
        return False


class OSD(xbmcgui.WindowXMLDialog):
    # Konstruktor nincs felulirva (mint a tobbi ablakunknal): a Kodi a
    # WindowXMLDialog argumentumaira kenyes. Az allapot itt, alapertekkel.
    player = None
    menu = None                 # {'kind': 'subtitles'/'audio', 'entries': [...]}
    touched = 0
    done = False
    auto_hide = True            # a tesztek kikapcsoljak (ott nincs valodi varakozas)
    threaded = True             # a feliratkereses a hatterben (a tesztekben helyben)
    found = None                # a legutobbi feliratkereses: {'info', 'hash'}
    FOUND_MAX = 30

    # --- eletciklus -------------------------------------------------------------

    def onInit(self):
        if self.player is None:
            self.player = xbmc.Player()
        context = history.get_context() or {}
        title = context.get('title') or xbmc.getInfoLabel('Player.Title') or u''
        self.setProperty('osd.title', title)
        self.setProperty('osd.sub', context.get('episode_label') or u'')
        self.setProperty('osd.menu', '')
        try:
            buttons = self.getControl(BUTTONS_ID)
            buttons.reset()
            items = []
            for kind, label, glyph in BUTTONS:
                item = xbmcgui.ListItem(label=label)
                item.setProperty('kind', kind)
                item.setProperty('glyph', glyph)
                items.append(item)
            buttons.addItems(items)
            buttons.selectItem(0)
            self.setFocusId(BUTTONS_ID)
        except Exception as exc:
            control.log_exception(u'lejátszásvezérlő: gombok', exc)
        self.touched = time.time()
        if self.auto_hide:
            thread = threading.Thread(target=self.watch)
            thread.daemon = True
            thread.start()

    def watch(self):
        '''Hatterben: ha vege a lejatszasnak, vagy tetlenul all (es megy a film), bezar.'''
        monitor = xbmc.Monitor()
        while not self.done and not monitor.waitForAbort(0.3):
            try:
                playing = self.player.isPlayingVideo()
            except Exception:
                playing = False
            paused = xbmc.getCondVisibility('Player.Paused')
            if not playing or should_hide(time.time(), self.touched, paused, self.menu is not None):
                self.finish()
                return

    def finish(self):
        if self.done:
            return
        self.done = True
        try:
            self.close()
        except Exception:
            pass

    # --- bemenet ----------------------------------------------------------------

    def onAction(self, action):
        self.touched = time.time()
        if action.getId() in CLOSE_ACTIONS:
            if self.menu is not None:
                self.close_menu()
            else:
                self.finish()

    def onClick(self, control_id):
        self.touched = time.time()
        if control_id == BUTTONS_ID:
            item = self.getControl(BUTTONS_ID).getSelectedItem()
            if item is not None:
                self.press(item.getProperty('kind'))
        elif control_id == MENU_ID:
            position = self.getControl(MENU_ID).getSelectedPosition()
            entries = (self.menu or {}).get('entries') or []
            if 0 <= position < len(entries):
                self.choose(entries[position][1])

    def press(self, kind):
        if kind == 'playpause':
            self.player.pause()
        elif kind == 'stop':
            self.finish()
            self.player.stop()
        elif kind == 'subtitles':
            self.open_menu('subtitles')
        elif kind == 'audio':
            self.open_menu('audio')

    # --- felirat / hangsav valaszto ------------------------------------------------

    def open_menu(self, kind):
        try:
            if kind == 'subtitles':
                entries = subtitle_entries(self.player.getAvailableSubtitleStreams(),
                                           xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled'),
                                           xbmc.getInfoLabel('VideoPlayer.SubtitlesLanguage'))
                title = u'Felirat'
            else:
                entries = audio_entries(self.player.getAvailableAudioStreams(),
                                        xbmc.getInfoLabel('VideoPlayer.AudioLanguage'))
                title = u'Hangsáv'
        except Exception as exc:
            control.log_exception(u'lejátszásvezérlő: sávok', exc)
            return
        if not entries:
            control.infoDialog(u'Ehhez a videóhoz nincs választható hangsáv.')
            return
        self.show_entries(kind, title, entries)

    def show_entries(self, kind, title, entries):
        '''A valaszto kitoltese: (felirat, parancs, bekapcsolt-e[, masodik sor]).'''
        self.menu = {'kind': kind, 'entries': entries}
        try:
            menu = self.getControl(MENU_ID)
            menu.reset()
            items = []
            for entry in entries:
                item = xbmcgui.ListItem(label=entry[0], label2=entry[3] if len(entry) > 3 else u'')
                item.setProperty('on', '1' if entry[2] else '')
                items.append(item)
            menu.addItems(items)
            menu.selectItem(next((i for i, entry in enumerate(entries) if entry[2]), 0))
            self.setProperty('osd.menu.title', title)
            self.setProperty('osd.menu', kind)
            self.setFocusId(MENU_ID)
        except Exception as exc:
            control.log_exception(u'lejátszásvezérlő: választó', exc)

    def close_menu(self):
        self.menu = None
        self.setProperty('osd.menu', '')
        try:
            self.setFocusId(BUTTONS_ID)
        except Exception:
            pass

    def choose(self, command):
        name = command[0]
        try:
            if name == 'off':
                self.player.showSubtitles(False)
            elif name == 'sub':
                self.player.setSubtitleStream(command[1])
                self.player.showSubtitles(True)
            elif name == 'audio':
                self.player.setAudioStream(command[1])
            elif name == 'search':
                from resources.lib.modules import subtitles
                if subtitles.enabled():
                    self.search_subtitles()
                    return
                # kulcs nelkul: a Kodi sajat feliratkereso ablaka
                self.finish()
                xbmc.executebuiltin('ActivateWindow(SubtitleSearch)')
                return
            elif name == 'get':
                self.fetch_subtitle(command[1])
                return
            elif name == 'delay':
                action = 'SubtitleDelayPlus' if command[1] > 0 else 'SubtitleDelayMinus'
                for _step in range(abs(command[1])):
                    xbmc.executebuiltin('Action(%s)' % action)
                return                                   # a valaszto nyitva marad: nyomhatja ujra
            elif name == 'noop':
                return
        except Exception as exc:
            control.log_exception(u'lejátszásvezérlő: %s' % name, exc)
        self.close_menu()

    # --- magyar felirat keresese (OpenSubtitles, subtitles.py) ----------------------

    def _run(self, work):
        if not self.threaded:
            work()
            return
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()

    def search_subtitles(self):
        from resources.lib.modules import subtitles
        title = u'Magyar felirat'
        self.show_entries('found', title, [(u'Keresés…', ('noop',), False)])

        def work():
            try:
                info = subtitles.playing_info(self.player)
                rows, moviehash = subtitles.find(info)
                self.found = {'info': info, 'hash': moviehash}
            except Exception as exc:
                control.log_exception(u'felirat keresése', exc)
                rows = None
            if self.done or (self.menu or {}).get('kind') != 'found':
                return                                   # kozben bezartak / mast nyitottak
            if rows is None:
                entries = [(u'A feliratkereső most nem érhető el.', ('noop',), False)]
            elif not rows:
                entries = [(u'Ehhez a videóhoz nincs magyar felirat.', ('noop',), False)]
            else:
                entries = [(name, ('get', row['file_id']), False, detail)
                           for row in rows[:self.FOUND_MAX] for name, detail in [subtitles.label(row)]]
            self.show_entries('found', title, entries)
        self._run(work)

    def fetch_subtitle(self, file_id):
        from resources.lib.modules import subtitles
        control.infoDialog(u'Felirat letöltése…')

        def work():
            try:
                path = subtitles.download(file_id)
            except subtitles.QuotaError as exc:
                control.okDialog(u'%s' % exc)
                return
            except Exception as exc:
                control.log_exception(u'felirat letöltése', exc)
                path = ''
            if not path:
                control.infoDialog(u'A felirat letöltése nem sikerült.')
                return
            subtitles.attach(self.player, path)
            found = self.found or {}
            if found.get('info'):
                subtitles.remember(subtitles.video_key(found['info'], found.get('hash') or ''), path)
            control.infoDialog(u'Magyar felirat betöltve')
            if not self.done:
                self.close_menu()
        self._run(work)


# --- Sajat tekeres (NetmoziSeek.xml): jobbra / balra nyil ------------------------
#
# Minden nyomas +/-1 perc, a gyors egymas utaniak osszeadodnak (5 gyors
# nyomas = +5 perc). Menet kozben latszik, hova ugrik; a tekeres egyben
# tortenik, az utolso nyomas utan kicsivel -- igy a forras (torrent, lassabb
# hoszt) nem toltodik ujra minden nyomasra. OK: azonnal ugrik; Vissza: marad.

SEEK_XML = 'NetmoziSeek.xml'
SEEK_STEP = 60                  # egy nyomas (mp)
SEEK_COMMIT_AFTER = 0.9         # az utolso nyomas utan ennyivel ugrik
SEEK_END_MARGIN = 5             # a vegere tekerve ennyivel elotte all meg
BAR_X, BAR_Y, BAR_W = 120, 986, 1680
MARKER = 28
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_SELECT_ITEM = 7


def clock(seconds):
    '''1:23:45 / 12:05 (ora nelkul, ha nincs).'''
    seconds = max(0, int(seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    return (u'%d:%02d:%02d' % (hours, minutes, secs)) if hours else (u'%d:%02d' % (minutes, secs))


def seek_target(base, total, steps):
    '''Hova ugrik: a mostani hely + lepesek, a video hatarain belul.'''
    end = max(0, total - SEEK_END_MARGIN) if total > 0 else base + steps * SEEK_STEP
    return max(0, min(end, base + steps * SEEK_STEP))


def seek_texts(base, total, steps, now=None):
    '''(nagy, kicsi): "+3 perc", "1:23:45 / 2:01:00 · vége: 22:41" (24 ora).'''
    target = seek_target(base, total, steps)
    big = u'%s%d perc' % (u'+' if steps > 0 else (u'−' if steps < 0 else u'±'), abs(steps))
    if steps > 0 and total > 0 and target >= total - SEEK_END_MARGIN:
        big += u' (a vége)'
    elif steps < 0 and target <= 0:
        big += u' (az eleje)'
    parts = [u'%s / %s' % (clock(target), clock(total)) if total > 0 else clock(target)]
    if total > 0:
        finish = (now or time.time()) + (total - target)
        parts.append(u'vége: %s' % time.strftime('%H:%M', time.localtime(finish)))
    return big, u'  ·  '.join(parts)


def bar_geometry(base, total, target):
    '''A sav elemei: megnezett (x, szel.), a mostani hely es a cel kozti szakasz, a potty helye.'''
    if total <= 0:
        return (BAR_X, 0), (BAR_X, 0), BAR_X - MARKER // 2

    def at(seconds):
        return BAR_X + int(round(BAR_W * max(0.0, min(1.0, float(seconds) / total))))
    here, there = at(base), at(target)
    return (BAR_X, max(0, here - BAR_X)), (min(here, there), abs(there - here)), there - MARKER // 2


def seek(step):
    '''A jobbra / balra nyil lejatszas kozben: a mi tekeresunk, vagy (nem a mienk) a Kodie.'''
    player = xbmc.Player()
    if not (ours() and player.isPlayingVideo()):
        xbmc.executebuiltin('Action(StepForward)' if step > 0 else 'Action(StepBack)')
        return False
    try:
        base, total = player.getTime(), player.getTotalTime()
    except RuntimeError:
        return False
    try:
        dialog = Seek(SEEK_XML, control.addonPath, 'Default', '1080i')
        dialog.player, dialog.base, dialog.total = player, base, total
        dialog.steps, dialog.touched = (1 if step > 0 else -1), time.time()
        dialog.doModal()
        del dialog
        return True
    except Exception as exc:
        control.log_exception(u'tekerés', exc)
        return False


class Seek(xbmcgui.WindowXMLDialog):
    player = None
    base = 0
    total = 0
    steps = 0
    touched = 0
    done = False
    auto_commit = True          # a tesztek kikapcsoljak

    def onInit(self):
        self.render()
        if self.auto_commit:
            thread = threading.Thread(target=self.watch)
            thread.daemon = True
            thread.start()

    def watch(self):
        monitor = xbmc.Monitor()
        while not self.done and not monitor.waitForAbort(0.1):
            if time.time() - self.touched >= SEEK_COMMIT_AFTER:
                self.commit()
                return

    def onAction(self, action):
        code = action.getId()
        if code in (ACTION_MOVE_RIGHT, ACTION_MOVE_LEFT):
            self.steps += 1 if code == ACTION_MOVE_RIGHT else -1
            self.touched = time.time()
            self.render()
        elif code == ACTION_SELECT_ITEM:
            self.commit()
        elif code in CLOSE_ACTIONS:
            self.cancel()

    def render(self):
        big, small = seek_texts(self.base, self.total, self.steps)
        (played_x, played_w), (delta_x, delta_w), marker_x = bar_geometry(
            self.base, self.total, seek_target(self.base, self.total, self.steps))
        try:
            self.getControl(801).setLabel(big)
            self.getControl(802).setLabel(small)
            played = self.getControl(811)
            played.setWidth(max(1, played_w))
            delta = self.getControl(812)
            delta.setPosition(delta_x, BAR_Y)
            delta.setWidth(max(1, delta_w))
            self.getControl(813).setPosition(marker_x, BAR_Y + 4 - MARKER // 2)
        except Exception as exc:
            control.log_exception(u'tekerés: kijelzés', exc)

    def commit(self):
        if self.done:
            return
        self.done = True
        target = seek_target(self.base, self.total, self.steps)
        if self.steps:
            try:
                self.player.seekTime(target)
                control.log(u'Tekerés: %+d perc -> %s' % (self.steps, clock(target)))
            except Exception as exc:
                control.log_exception(u'tekerés', exc)
        try:
            self.close()
        except Exception:
            pass

    def cancel(self):
        if self.done:
            return
        self.done = True
        try:
            self.close()
        except Exception:
            pass
