# -*- coding: utf-8 -*-
'''
Statisztika (Beallitasok / Statisztika): mennyit, mit, mikor nezel.

A nezesi idot a szolgaltatas meri (service.py, ProgressTracker): a
lejatszas alatt eltelt ido szunet nelkul, cimenkent egy bejegyzes a
naplóba (stats.json, profilonkent). A mereres elotti honapokat egyszer,
az elso megnyitaskor becsuljuk a meglevo adatokbol (az elozmenyek es a
folytatas): filmnel a lejatszasi pozicio, resznel a resz hossza.

A tobbi (filmek, reszek, mufajok, nyelv, forras, izles) a meglevo
listakbol szamol, visszamenoleg.
'''
import json
import os
import time
from datetime import datetime

from resources.lib.modules import control

FILE = 'stats.json'
MAX_SESSIONS = 3000
MIN_SECONDS = 60                # ennel rovidebb nezes nem szamit
MONTHS = 6                      # a havi grafikon hossza
GENRES = 6                      # ennyi mufaj a listan
TOP_SERIES = 3
EPISODE_GUESS = 45 * 60         # becslesnel, ha a resz hossza nem ismert
MONTH_NAMES = (u'jan', u'febr', u'márc', u'ápr', u'máj', u'jún', u'júl', u'aug', u'szept', u'okt', u'nov', u'dec')
WEEKDAYS = (u'H', u'K', u'Sze', u'Cs', u'P', u'Szo', u'V')
DAYPARTS = ((5, 12, u'délelőtt'), (12, 18, u'délután'), (18, 23, u'este'), (23, 29, u'éjjel'))


def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
    except (IOError, OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault('sessions', [])
    return data


def save(data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'statisztika írása', exc)
        return False


def kind_of(page):
    return 'episode' if _series_base(page) != (page or '') else 'film'


def _series_base(page):
    from resources.lib.modules import progress
    parts = progress.split_page(page or '')
    return parts[0] if parts else (page or '')


def record(page, title, seconds, at=None):
    '''Egy nezes a naplóba (a szolgaltatas hivja a lejatszas vegen / fajlvaltaskor).'''
    from resources.lib.modules import history
    seconds = int(seconds or 0)
    if not page or seconds < MIN_SECONDS:
        return False
    entry = history.find(page) or {}
    data = load()
    data['sessions'].append({'page': page, 'title': title or entry.get('title') or u'',
                             'kind': kind_of(page), 'seconds': seconds, 'at': int(at or time.time()),
                             'language': entry.get('language') or u'',
                             'source': 'ncore' if entry.get('torrent') else 'netmozi'})
    data['sessions'] = data['sessions'][-MAX_SESSIONS:]
    data.setdefault('since', int(time.time()))
    return save(data)


def backfill(data=None):
    '''
    Egyszer: a mereres elotti nezesek becslese a meglevo adatokbol (a
    folytatas poziciojabol, a resz hosszabol). "est" jeloli oket.
    '''
    from resources.lib.modules import history, progress
    data = data or load()
    if data.get('backfilled'):
        return data
    films = dict((entry['base'], entry) for entry in progress.entries('film'))
    estimated = []
    for entry in history.load():
        page = entry.get('page') or entry.get('key') or ''
        at = int(entry.get('time') or 0)
        if not page or not at:
            continue
        if kind_of(page) == 'film':
            known = films.get(page) or {}
            seconds = known.get('total') if progress.finished(known) and known.get('total') else known.get('position')
            seconds = seconds or (entry.get('duration') or 0)
        else:
            seconds = entry.get('duration') or EPISODE_GUESS
        if int(seconds or 0) < MIN_SECONDS:
            continue
        estimated.append({'page': page, 'title': entry.get('title') or u'', 'kind': kind_of(page),
                          'seconds': int(seconds), 'at': at, 'language': entry.get('language') or u'',
                          'source': 'ncore' if entry.get('torrent') else 'netmozi', 'est': True})
    since = data.get('since') or int(time.time())
    # ami mar a merésbol megvan, azt nem becsuljuk ra
    estimated = [row for row in estimated if row['at'] < since]
    data['sessions'] = sorted(estimated + data['sessions'], key=lambda row: row.get('at') or 0)[-MAX_SESSIONS:]
    data['backfilled'] = True
    data['since'] = since
    save(data)
    return data


# --- Szamitas ------------------------------------------------------------------------

def hours_text(seconds):
    hours = (seconds or 0) / 3600.0
    if hours < 1:
        return u'%d perc' % int(round((seconds or 0) / 60.0))
    return u'%d óra' % int(round(hours)) if hours >= 10 else (u'%.1f óra' % hours).replace('.', ',')


def _month_key(stamp):
    moment = datetime.fromtimestamp(stamp)
    return moment.year, moment.month


def _last_months(now, count):
    moment = datetime.fromtimestamp(now)
    year, month = moment.year, moment.month
    out = []
    for _index in range(count):
        out.append((year, month))
        month -= 1
        if month == 0:
            year, month = year - 1, 12
    return list(reversed(out))


def steps(value, top, count):
    '''Oszlop / csik hossza lepcsokben (0..count); ami nem nulla, legalabb 1.'''
    if not value or not top:
        return 0
    return max(1, min(count, int(round(count * float(value) / top))))


def _genres_of(thumb, stores):
    '''A cim mufajai a tarbol (TMDB, kulonben IMDb) -- a tarakat egyszer toltjuk be, nem cimenkent.'''
    from resources.lib.modules import taste, tmdb
    imdb = tmdb.imdb_id(thumb or '')
    if not imdb:
        return []
    tmdb_store, imdb_store = stores
    genres = (tmdb_store.get(imdb) or {}).get('genres') or (imdb_store.get(imdb) or {}).get('genres') or []
    return taste.normalize_genres(genres)


def _stores():
    from resources.lib.modules import imdb as imdb_mod, tmdb
    try:
        return tmdb.load() or {}, imdb_mod.load() or {}
    except Exception as exc:
        control.log_exception(u'statisztika: tár', exc)
        return {}, {}


def genre_shares(entries):
    '''[(mufaj, szazalek)]: a nezett cimek mufajai (az elsodleges teljes, a tobbi fel sullyal).'''
    from resources.lib.modules import taste
    scores, cache, seen = {}, _stores(), set()
    for entry in entries:
        key = _series_base(entry.get('page') or entry.get('key') or '')
        if not key or key in seen:
            continue
        seen.add(key)
        for index, genre in enumerate(_genres_of(entry.get('thumb'), cache)):
            weight = taste.PRIMARY_WEIGHT if index == 0 else taste.OTHER_WEIGHT
            scores[genre] = scores.get(genre, 0.0) + weight
    total = sum(scores.values())
    if not total:
        return []
    shares = sorted(((genre, int(round(100.0 * score / total))) for genre, score in scores.items()),
                    key=lambda pair: (-pair[1], pair[0]))
    return [pair for pair in shares if pair[1] > 0][:GENRES]


def compute(now=None):
    '''A statisztika oldal minden adata (a homewindow teszi ki).'''
    from resources.lib.modules import history, progress, taste
    now = now or time.time()
    data = backfill()
    sessions = data['sessions']
    watched = history.load()
    this_month = _month_key(now)

    total = sum(row.get('seconds') or 0 for row in sessions)
    month_total = sum(row.get('seconds') or 0 for row in sessions if _month_key(row.get('at') or 0) == this_month)

    films = [entry for entry in watched if kind_of(entry.get('page') or entry.get('key')) == 'film']
    finished = sum(1 for entry in progress.entries('film') if progress.finished(entry))
    episodes = set(entry.get('page') or entry.get('key') for entry in watched
                   if kind_of(entry.get('page') or entry.get('key')) == 'episode')
    episodes |= set(row['page'] for row in sessions if row.get('kind') == 'episode')
    series = {}
    for page in episodes:
        base = _series_base(page)
        series[base] = series.get(base, 0) + 1
    titles = dict((_series_base(entry.get('page') or entry.get('key') or ''), entry.get('title') or u'')
                  for entry in watched)
    top_series = sorted(series.items(), key=lambda pair: (-pair[1], titles.get(pair[0], u'')))[:TOP_SERIES]

    months = []
    per_month = {}
    for row in sessions:
        per_month[_month_key(row.get('at') or 0)] = per_month.get(_month_key(row.get('at') or 0), 0) + (row.get('seconds') or 0)
    keys = _last_months(now, MONTHS)
    peak = max([per_month.get(key, 0) for key in keys] + [0])
    for key in keys:
        seconds = per_month.get(key, 0)
        months.append({'label': MONTH_NAMES[key[1] - 1], 'value': hours_text(seconds) if seconds else u'',
                       'h10': steps(seconds, peak, 10)})

    stamps = [row.get('at') for row in sessions if row.get('at')]
    days = [0] * 7
    parts = dict((name, 0) for _a, _b, name in DAYPARTS)
    for stamp in stamps:
        moment = datetime.fromtimestamp(stamp)
        days[moment.weekday()] += 1
        hour = moment.hour if moment.hour >= 5 else moment.hour + 24
        for start, end, name in DAYPARTS:
            if start <= hour < end:
                parts[name] += 1
    weekdays = [{'label': WEEKDAYS[index], 'h10': steps(count, max(days + [0]), 10)} for index, count in enumerate(days)]
    daypart = max(parts.items(), key=lambda pair: pair[1])[0] if stamps else u''

    dubbed = sum(1 for entry in watched if entry.get('language') == u'Szinkron')
    languages = sum(1 for entry in watched if entry.get('language'))
    torrents = sum(1 for entry in watched if entry.get('torrent'))

    taste_data = taste.load()
    likes = sum(1 for entry in taste_data['ratings'].values() if (entry.get('vote') or 0) > 0)
    dislikes = sum(1 for entry in taste_data['ratings'].values() if (entry.get('vote') or 0) < 0)

    return {
        'time': hours_text(total) if total else u'0 óra',
        'time_sub': u'ebben a hónapban: %s' % hours_text(month_total),
        'films': str(len(films)),
        'films_sub': u'végignézve: %d' % finished,
        'episodes': str(len(episodes)),
        'episodes_sub': u'%d sorozatból' % len(series),
        'taste': str(len(taste_data['favorites'])),
        'taste_sub': u'kedvenc, %d tetszik, %d nem' % (likes, dislikes),
        'genres': [{'label': genre, 'value': u'%d%%' % share, 'pct20': steps(share, 100, 20)}
                   for genre, share in genre_shares(watched)],
        'months': months,
        'weekdays': weekdays,
        'top_series': [u'%s – %d rész' % (titles.get(base) or base, count) for base, count in top_series],
        'daypart': (u'Leginkább %s nézel' % daypart) if daypart else u'',
        'language': (u'Szinkron %d%%, feliratos / eredeti %d%%' % (
            round(100.0 * dubbed / languages), 100 - round(100.0 * dubbed / languages))) if languages else u'',
        'source': (u'netmozi %d%%, nCore %d%%' % (
            100 - round(100.0 * torrents / len(watched)), round(100.0 * torrents / len(watched)))) if watched else u'',
        'since': u'A nézési időt %s óta pontosan mérjük; a korábbi becslés.' % datetime.fromtimestamp(
            data.get('since') or now).strftime('%Y. %m. %d.'),
    }
