# -*- coding: utf-8 -*-
'''
Magyar felirat az OpenSubtitles.com-rol -- a mi valtozatunkhoz illesztve.

A Kodi sajat feliratkeresoje (a regi OpenSubtitles.org szolgaltatas) nem
mukodik: helyette ez. Kereses lejatszas kozben (osd.py: Felirat -> Felirat
keresese), es magatol is, ha a videohoz nincs magyar hang es felirat
(service.py).

Illesztes, erossegi sorrendben:
  1. a video ujjlenyomata (OpenSubtitles "moviehash": a meret, meg az elso es
     az utolso 64 kB osszege) -- ez PONTOSAN a mi fajlunkhoz keszult felirat.
     Az Elementum (nCore) es a kozvetlen MP4-hosztok tartomanyos lekerest
     adnak, igy kiszamolhato; HLS-nel (m3u8) nincs.
  2. a kiadas neve (az nCore-fajl neve, pl. "Film.2023.1080p.BluRay.x264-CSOP"):
     a kiado csoport es a forras (BluRay / WEB) szamit a legtobbet;
  3. a kepkockaszam (fps): ha elter, a felirat biztosan csuszik;
  4. nem gepi forditas, es a nepszeruseg.

Letoltes: fiok nelkul napi 5 (IP-cimenkent), ingyenes fiokkal (Beallitasok)
napi 20. A mar letoltott felirat a lemezen marad: ugyanahhoz a videohoz
(folytataskor) nem kell ujra letolteni.
'''
import json
import math
import os
import re
import struct
import time
from urllib.parse import parse_qsl, unquote, urlparse

from resources.lib.modules import client, control

API = 'https://api.opensubtitles.com/api/v1'
USER_AGENT = 'netmozi v1.0'
LANGUAGE = 'hu'
TIMEOUT = 12
HASH_TIMEOUT = 8
HASH_CHUNK = 65536
TOKEN_FILE = 'opensubtitles.json'
TOKEN_TTL = 20 * 3600           # a token 24 oraig el; kicsit elobb ujat kerunk
FOLDER = 'feliratok'
INDEX_FILE = 'index.json'
INDEX_MAX = 300
LABEL_MAX = 64

HUNGARIAN = ('hun', 'hu', 'hungarian', 'magyar')
VIDEO_EXT_RE = r'(?i)\.(mkv|mp4|avi|m4v|ts|mov|webm|wmv)$'
RESOLUTION_RE = r'^(480|576|720|1080|2160)[pi]$|^4k$'
# A kiadas forrasa: ami egy csoportba esik, az egymashoz idozitheto.
SOURCES = (
    ('bluray', 'bdrip', 'brrip', 'remux', 'bdremux', 'bd'),
    ('web', 'webrip', 'webdl', 'amzn', 'nf', 'dsnp', 'hmax', 'atvp', 'max', 'pmtp'),
    ('hdtv', 'pdtv'),
    ('dvdrip', 'dvd', 'dvdscr'),
    ('cam', 'hdcam', 'ts', 'telesync', 'tc'),
)
RELEASE_HINTS = set(sum((list(group) for group in SOURCES), [])) | {
    'x264', 'x265', 'h264', 'h265', 'hevc', 'avc', 'hdr', 'dv', 'hdrip', 'xvid', 'dl', 'proper', 'repack'}

# A tesztek ezt csereljek (halozat nelkul).
SESSION_FACTORY = client.new_session


class QuotaError(Exception):
    '''Elfogyott a napi letoltesi keret; az uzenet mar magyarul, a nezonek.'''


# --- Kulcs, fiok ------------------------------------------------------------------

def api_key():
    return (control.bundledKey('opensubtitleskey') or '').strip()


def enabled():
    return bool(api_key())


def _headers(token=''):
    headers = {'Api-Key': api_key(), 'User-Agent': USER_AGENT, 'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer %s' % token
    return headers


def _account():
    return (control.setting('osuser') or '').strip(), control.setting('ospass') or ''


def _read_json(path, default):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, type(default)) else default
    except (IOError, OSError, ValueError):
        return default


def _write_json(path, data):
    try:
        control.makeFile(os.path.dirname(path))
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'felirat: írás', exc)


def login(force=False):
    '''(token, API-cim). Fiok nelkul (vagy ha a belepes nem sikerul): ('', API).'''
    user, password = _account()
    if not user or not password:
        return '', API
    path = os.path.join(control.dataPath, TOKEN_FILE)
    saved = _read_json(path, {})
    if not force and saved.get('user') == user and saved.get('token') \
            and time.time() - (saved.get('at') or 0) < TOKEN_TTL:
        return saved['token'], saved.get('base') or API
    try:
        response = SESSION_FACTORY().post(API + '/login', json={'username': user, 'password': password},
                                          headers=dict(_headers(), **{'Content-Type': 'application/json'}),
                                          timeout=TIMEOUT)
    except Exception as exc:
        control.log_exception(u'OpenSubtitles belépés', exc)
        return '', API
    if response.status_code != 200:
        control.log(u'OpenSubtitles belépés sikertelen (%s): fiók nélkül megyünk' % response.status_code,
                    control.LOGWARNING)
        return '', API
    data = response.json() or {}
    host = (data.get('base_url') or '').strip().strip('/')
    base = ('https://%s/api/v1' % host) if host and '/' not in host else API
    _write_json(path, {'user': user, 'token': data.get('token') or '', 'base': base, 'at': int(time.time())})
    return data.get('token') or '', base


# --- A video: ujjlenyomat, kiadasnev ------------------------------------------------

def hash_of(size, head, tail):
    '''Az OpenSubtitles ujjlenyomata: meret + az elso es utolso 64 kB 64 bites szavainak osszege.'''
    if size < 2 * HASH_CHUNK or len(head) < HASH_CHUNK or len(tail) < HASH_CHUNK:
        return ''
    value = size
    for chunk in (head[:HASH_CHUNK], tail[-HASH_CHUNK:]):
        for (word,) in struct.iter_unpack('<Q', chunk):
            value = (value + word) & 0xFFFFFFFFFFFFFFFF
    return '%016x' % value


def split_url(url):
    '''Kodi-alak ("cim|Fejlec=ertek&...") -> (cim, {fejlec: ertek}).'''
    base, _sep, tail = (url or '').partition('|')
    return base, dict(parse_qsl(tail)) if tail else {}


def _read_part(response, limit):
    data = b''
    for chunk in response.iter_content(16384):
        data += chunk
        if len(data) >= limit:
            break
    response.close()
    return data[:limit]


def _total_size(response):
    match = re.search(r'/(\d+)\s*$', response.headers.get('Content-Range') or '')
    return int(match.group(1)) if match else 0


def remote_hash(url):
    '''A futo video ujjlenyomata tartomanyos lekeressel; '' ha nem lehet (HLS, nincs Range).'''
    base, headers = split_url(url)
    if not base.lower().startswith(('http://', 'https://')) or '.m3u8' in base.lower():
        return ''
    try:
        session = SESSION_FACTORY()
        first = session.get(base, headers=dict(headers, Range='bytes=0-%d' % (HASH_CHUNK - 1)),
                            timeout=HASH_TIMEOUT, stream=True)
        size = _total_size(first)
        if first.status_code != 206 or size < 2 * HASH_CHUNK:
            first.close()
            return ''
        head = _read_part(first, HASH_CHUNK)
        last = session.get(base, headers=dict(headers, Range='bytes=%d-%d' % (size - HASH_CHUNK, size - 1)),
                           timeout=HASH_TIMEOUT, stream=True)
        if last.status_code != 206:
            last.close()
            return ''
        return hash_of(size, head, _read_part(last, HASH_CHUNK))
    except Exception as exc:
        control.log(u'Felirat: az ujjlenyomat nem számolható (%s)' % exc, control.LOGDEBUG)
        return ''


def _tokens(name):
    return [token for token in re.split(r'[^a-z0-9]+', (name or '').lower()) if token]


def release_of(url):
    '''A lejatszott fajl neve, ha kiadasnevnek latszik ("Film.2023.1080p.WEB-DL-CSOP"), kulonben ''.'''
    path = unquote(urlparse(split_url(url)[0]).path or '')
    name = re.sub(VIDEO_EXT_RE, '', os.path.basename(path))
    tokens = _tokens(name)
    if len(tokens) >= 3 and any(token in RELEASE_HINTS or re.match(RESOLUTION_RE, token) for token in tokens):
        return name
    return ''


def _group(name):
    match = re.search(r'-([a-z0-9]+)$', re.sub(VIDEO_EXT_RE, '', (name or '').strip().lower()))
    return match.group(1) if match else ''


def _source(tokens):
    for index, group in enumerate(SOURCES):
        if any(token in group for token in tokens):
            return index + 1
    return 0


def _resolution(tokens):
    return next((token for token in tokens if re.match(RESOLUTION_RE, token)), '')


def release_score(ours, theirs):
    '''Mennyire ugyanaz a kiadas: a csoport, a forras, a felbontas es a kozos szavak.'''
    if not ours or not theirs:
        return 0
    mine, other = _tokens(ours), _tokens(theirs)
    score = 0
    if _group(ours) and _group(ours) == _group(theirs):
        score += 50
    if _source(mine) and _source(mine) == _source(other):
        score += 30
    if _resolution(mine) and _resolution(mine) == _resolution(other):
        score += 10
    return score + min(10, len(set(mine) & set(other)))


# --- Kereses, rangsor ----------------------------------------------------------------

def parse(data):
    '''Az API valasza -> [{file_id, release, fps, downloads, hash_match, machine, hearing}].'''
    out = []
    for row in (data or {}).get('data') or []:
        attributes = row.get('attributes') or {}
        files = attributes.get('files') or []
        if not files or not files[0].get('file_id'):
            continue
        if (attributes.get('language') or LANGUAGE) != LANGUAGE:
            continue
        try:
            fps = float(attributes.get('fps') or 0)
        except (TypeError, ValueError):
            fps = 0.0
        out.append({'file_id': int(files[0]['file_id']),
                    'release': (attributes.get('release') or files[0].get('file_name') or u'').strip(),
                    'fps': fps,
                    'downloads': int(attributes.get('download_count') or 0),
                    'hash_match': bool(attributes.get('moviehash_match')),
                    'machine': bool(attributes.get('machine_translated') or attributes.get('ai_translated')),
                    'hearing': bool(attributes.get('hearing_impaired'))})
    return out


def score(row, release='', fps=0.0):
    value = 1000 if row.get('hash_match') else 0
    value += release_score(release, row.get('release'))
    if fps and row.get('fps'):
        value += 30 if abs(fps - row['fps']) < 0.02 else -40
    if row.get('machine'):
        value -= 60
    if row.get('hearing'):
        value -= 5
    return value + min(20, int(math.log10((row.get('downloads') or 0) + 1) * 5))


def rank(rows, release='', fps=0.0):
    '''A legjobban illo elol (azonos pontnal az API sorrendje marad).'''
    return sorted(rows or [], key=lambda row: -score(row, release, fps))


def label(row):
    '''A valasztoba (ket sor): (a kiadas neve, ami szamit: egyezes, fps, gepi, letoltesek).'''
    name = row.get('release') or u'Magyar felirat'
    if len(name) > LABEL_MAX:
        name = name[:LABEL_MAX - 3] + u'...'
    tags = []
    if row.get('hash_match'):
        tags.append(u'PONTOS EGYEZÉS')
    if row.get('fps'):
        tags.append(u'%s fps' % (u'%.3f' % row['fps']).rstrip('0').rstrip('.'))
    if row.get('machine'):
        tags.append(u'gépi fordítás')
    if row.get('downloads'):
        tags.append(u'%d letöltés' % row['downloads'])
    return name, u', '.join(tags) or u'magyar'


def search(imdb='', season=None, episode=None, moviehash='', title='', year=''):
    '''
    Magyar feliratok. Resznel a sorozat IMDb-je + evad + resz. None: hiba
    (nem erjuk el), []: nincs.
    '''
    if not enabled():
        return None
    number = re.sub(r'\D', '', imdb or '')
    params = {'languages': LANGUAGE}
    if number:
        if season is not None and episode is not None:
            params.update({'parent_imdb_id': str(int(number)), 'season_number': str(int(season)),
                           'episode_number': str(int(episode))})
        else:
            params['imdb_id'] = str(int(number))
    elif title:
        params['query'] = title.lower()
        if year:
            params['year'] = str(year)
    else:
        return []
    if moviehash:
        params['moviehash'] = moviehash
    try:
        # Az API a betusorrendbe rakott parametereket keri (kulonben atiranyit).
        response = SESSION_FACTORY().get(API + '/subtitles', params=sorted(params.items()),
                                         headers=_headers(), timeout=TIMEOUT)
    except Exception as exc:
        control.log_exception(u'felirat keresése', exc)
        return None
    if response.status_code != 200:
        control.log(u'Felirat keresése: HTTP %s' % response.status_code, control.LOGWARNING)
        return None
    return parse(response.json())


# --- Letoltes, a letoltottek megorzese --------------------------------------------------

def folder():
    return os.path.join(control.dataPath, FOLDER)


def cached_path(file_id):
    # A ".hu." a nevben: a Kodi ebbol tudja, hogy magyar.
    return os.path.join(folder(), 'netmozi-%s.hu.srt' % int(file_id))


def quota_message(data):
    allowed = (data or {}).get('requests') or (data or {}).get('allowed_downloads') or 0
    when = (data or {}).get('reset_time') or u''
    text = u'Mára elfogyott a feliratletöltés%s.' % (u' (napi %s)' % allowed if allowed else u'')
    if when:
        text += u' Újra: %s múlva.' % when.replace('hours', u'óra').replace('hour', u'óra') \
            .replace('minutes', u'perc').replace('minute', u'perc').replace(' and ', u' ')
    if not _account()[0]:
        text += u' Ingyenes OpenSubtitles-fiókkal napi 20 (Beállítások / Bejelentkezés).'
    return text


def download(file_id):
    '''A felirat fajlja (a lemezrol, ha mar megvan). '' ha nem sikerult; QuotaError, ha elfogyott a keret.'''
    path = cached_path(file_id)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path
    token, base = login()
    session = SESSION_FACTORY()

    def ask(token, base):
        return session.post(base + '/download', json={'file_id': int(file_id)},
                            headers=dict(_headers(token), **{'Content-Type': 'application/json'}), timeout=TIMEOUT)
    try:
        response = ask(token, base)
        if response.status_code == 401 and token:
            token, base = login(force=True)                # lejart a token
            response = ask(token, base)
        if response.status_code in (406, 429):
            try:
                data = response.json()
            except ValueError:
                data = {}
            raise QuotaError(quota_message(data))
        if response.status_code != 200:
            control.log(u'Felirat letöltése: HTTP %s' % response.status_code, control.LOGWARNING)
            return ''
        data = response.json() or {}
        content = session.get(data.get('link') or '', timeout=TIMEOUT).content if data.get('link') else b''
    except QuotaError:
        raise
    except Exception as exc:
        control.log_exception(u'felirat letöltése', exc)
        return ''
    if not content:
        return ''
    try:
        control.makeFile(folder())
        with open(path, 'wb') as handle:
            handle.write(content)
    except (IOError, OSError) as exc:
        control.log_exception(u'felirat mentése', exc)
        return ''
    control.log(u'Felirat letöltve: %s (ma még %s)' % (file_id, data.get('remaining', '?')))
    return path


def video_key(info, moviehash=''):
    '''Ugyanaz a video (folytataskor is): az ujjlenyomat, vagy a cim + resz + kiadas.'''
    if moviehash:
        return 'hash:%s' % moviehash
    return u'%s:%s:%s:%s' % (info.get('imdb') or info.get('title') or '', info.get('season'),
                             info.get('episode'), info.get('release') or '')


def remembered(key):
    path = (_read_json(os.path.join(folder(), INDEX_FILE), {}).get(key) or {}).get('path') or ''
    return path if path and os.path.exists(path) else ''


def remember(key, path):
    index_path = os.path.join(folder(), INDEX_FILE)
    index = _read_json(index_path, {})
    index[key] = {'path': path, 'at': int(time.time())}
    if len(index) > INDEX_MAX:
        for old in sorted(index, key=lambda name: index[name].get('at') or 0)[:len(index) - INDEX_MAX]:
            index.pop(old)
    _write_json(index_path, index)


# --- A futo video --------------------------------------------------------------------

def playing_info(player):
    '''A futo video adatai a kereseshez (a NetMozi inditasakor mentett adatlapbol es a fajlbol).'''
    import xbmc
    from resources.lib.modules import history, tmdb
    try:
        url = player.getPlayingFile()
    except Exception:
        url = ''
    context = history.get_context() or {}
    page = context.get('page') or ''
    match = re.search(r'/s(\d+)/e(\d+)/?$', page)
    try:
        fps = float(xbmc.getInfoLabel('Player.Process(VideoFPS)') or 0)
    except (TypeError, ValueError):
        fps = 0.0
    return {'url': url, 'page': page, 'title': context.get('title') or u'',
            'imdb': tmdb.imdb_id(context.get('thumb') or ''),
            'season': int(match.group(1)) if match else None,
            'episode': int(match.group(2)) if match else None,
            'release': release_of(url), 'fps': fps}


def find(info, moviehash=None):
    '''(rangsorolt talalatok vagy None, ujjlenyomat).'''
    if moviehash is None:
        moviehash = remote_hash(info.get('url') or '')
    rows = search(info.get('imdb'), info.get('season'), info.get('episode'), moviehash, info.get('title'))
    if rows is None:
        return None, moviehash
    return rank(rows, info.get('release'), info.get('fps') or 0.0), moviehash


def is_hungarian(code):
    return (code or '').strip().lower() in HUNGARIAN


def good_enough(row, info):
    '''Magatol csak olyat, ami jo esellyel illik: pontos egyezes, vagy nem gepi es nem mas fps.'''
    if row.get('hash_match'):
        return True
    if row.get('machine'):
        return False
    return not (info.get('fps') and row.get('fps') and abs(info['fps'] - row['fps']) >= 0.02)


def attach(player, path):
    player.setSubtitles(path)
    try:
        player.showSubtitles(True)
    except Exception:
        pass


def auto_attach(player):
    '''
    Lejatszas elejen (service.py): ha a videonak nincs magyar hangja es
    felirata, a legjobban illo magyar feliratot betolti. True, ha betoltott.
    '''
    from resources.lib.modules import history
    if not enabled() or control.setting('autosubtitles') == 'false':
        return False
    try:
        audio = player.getAvailableAudioStreams() or []
        subs = player.getAvailableSubtitleStreams() or []
    except Exception:
        return False
    if any(is_hungarian(code) for code in audio + subs):
        return False
    info = playing_info(player)
    language = ((history.find(info['page']) or {}).get('language') or u'') if info['page'] else u''
    # Szinkronos forras (a hangsav jelolese gyakran ures): nem kell felirat.
    # Feliratos forrasnal a hoszt felirata mar rajta van.
    if language == u'Szinkron' or (language == u'Felirat' and subs):
        return False
    moviehash = remote_hash(info.get('url') or '')
    key = video_key(info, moviehash)
    path = remembered(key)                               # folytatas: a mar letoltott, kereses nelkul
    if not path:
        rows, moviehash = find(info, moviehash)
        best = next((row for row in rows or [] if good_enough(row, info)), None)
        if best is None:
            control.log(u'Magyar felirat magától: nincs illő (%s)' % (info.get('title') or ''))
            return False
        try:
            path = download(best['file_id'])
        except QuotaError as exc:
            control.log(u'Magyar felirat magától: %s' % exc, control.LOGWARNING)
            return False
        if not path:
            return False
        remember(key, path)
    attach(player, path)
    control.infoDialog(u'Magyar felirat betöltve')
    return True
