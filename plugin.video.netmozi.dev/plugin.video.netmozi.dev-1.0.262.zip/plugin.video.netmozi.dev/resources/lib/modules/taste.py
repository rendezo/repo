# -*- coding: utf-8 -*-
'''
Izles: kedvencek, tetszik / nem tetszik, es belole a mufaj-preferencia.

A kedvencek a Figyelolistaban latszanak (szivvel). A tetszik es a kedvenc
a cim mufajait pontozza: az elsodleges (elso) mufaj teljes sullyal, a
tobbi fel sullyal; ez rendezi az Ajanlo sort (elore, ami az izlesedhez
illik). A nem tetszik NEM von le a mufajbol (a sci-fit szeretheted, csak
a rossz sci-fit nem): az a cim egyszeruen kimarad az Ajanlobol.

Profilonkent kulon (control.profileDir), mint a tobbi helyi lista.
'''
import json
import os
import re
import time

from resources.lib.modules import control

FILE = 'taste.json'
MAX_FAVORITES = 200
PRIMARY_WEIGHT = 1.0            # az elso (elsodleges) mufaj
OTHER_WEIGHT = 0.5              # a tobbi mufaj
LIKE = 1.0
FAVORITE = 1.5                  # a kedvenc erosebb jel, mint a tetszik

# A TMDB magyar mufajnevei -> a netmozi kategoriai (hogy egy mufaj egy nev legyen).
GENRE_ALIASES = {
    u'animációs': [u'Animáció'], u'zenei': [u'Zene'], u'tudományos-fantasztikus': [u'Sci-Fi'],
    u'sci-fi & fantasy': [u'Sci-Fi', u'Fantasy'], u'akció és kaland': [u'Akció', u'Kaland'],
    u'háború és politika': [u'Háborús'], u'rejtély': [u'Misztikus'], u'tévéfilm': [],
    u'hírek': [], u'talk': [], u'szappanopera': [u'Dráma'], u'gyerek': [u'Családi'],
}


def _path():
    return os.path.join(control.profileDir(), FILE)


def page_key(page):
    '''Egy sorozat reszenek oldala a sorozate: "/sorozatok/2/x/s2/e5" -> "/sorozatok/2/x".'''
    return re.sub(r'/s\d+/e\d+/?$', '', page or '')


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
    except (IOError, OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    for name in ('favorites', 'ratings'):
        # a regebben reszrol mentett bejegyzes a sorozathoz tartozik
        entries = data.get(name) if isinstance(data.get(name), dict) else {}
        data[name] = dict((page_key(page), entry) for page, entry in entries.items())
    return data


def save(data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'ízlés írása', exc)
        return False


def normalize_genres(names):
    '''A mufajnevek egysegesen (a TMDB-nevek a netmozi kategoriaira), ismetles nelkul, sorrendben.'''
    out = []
    for name in names or []:
        text = (name or u'').strip()
        if not text:
            continue
        for mapped in GENRE_ALIASES.get(text.lower(), [text]):
            if mapped and mapped not in out:
                out.append(mapped)
    return out


# --- Kedvencek -------------------------------------------------------------------

def is_favorite(page, data=None):
    return bool(page) and page_key(page) in (data or load())['favorites']


def favorite_pages(data=None):
    return set((data or load())['favorites'])


def favorites(data=None):
    '''A kedvencek, a legutobb hozzaadott elol.'''
    items = [dict(entry, page=page) for page, entry in (data or load())['favorites'].items()]
    return sorted(items, key=lambda entry: -(entry.get('added') or 0))


def toggle_favorite(page, title=u'', thumb=u'', genres=None, imdb=u''):
    '''Kedvenc be / ki. Visszaad: most kedvenc-e.'''
    page = page_key(page)
    if not page:
        return False
    data = load()
    if page in data['favorites']:
        data['favorites'].pop(page)
        save(data)
        return False
    data['favorites'][page] = {'title': title or u'', 'thumb': thumb or u'', 'genres': normalize_genres(genres),
                               'series': page.startswith('/sorozatok/'), 'added': int(time.time()),
                               'imdb': imdb or u''}
    if len(data['favorites']) > MAX_FAVORITES:
        oldest = sorted(data['favorites'], key=lambda key: data['favorites'][key].get('added') or 0)
        for key in oldest[:len(data['favorites']) - MAX_FAVORITES]:
            data['favorites'].pop(key)
    save(data)
    return True


def remove_favorite(page):
    data = load()
    if data['favorites'].pop(page_key(page), None) is None:
        return False
    return save(data)


# --- Tetszik / nem tetszik ---------------------------------------------------------

def vote_of(page, data=None):
    '''1: tetszik, -1: nem tetszik, 0: nincs.'''
    return int(((data or load())['ratings'].get(page_key(page)) or {}).get('vote') or 0) if page else 0


def set_vote(page, value, title=u'', genres=None):
    '''
    Szavazat: ugyanaz masodszor visszavonja (0). Visszaad: az uj ertek.
    '''
    page = page_key(page)
    if not page:
        return 0
    data = load()
    value = 1 if value > 0 else -1
    if vote_of(page, data) == value:
        data['ratings'].pop(page, None)
        save(data)
        return 0
    data['ratings'][page] = {'vote': value, 'title': title or u'', 'genres': normalize_genres(genres),
                             'at': int(time.time())}
    save(data)
    return value


def set_genres(page, genres):
    '''Utolag kiderult mufajok (a TMDB-bol) a kedvencre / szavazatra, ha meg nem volt.'''
    page, genres = page_key(page), normalize_genres(genres)
    if not page or not genres:
        return False
    data = load()
    changed = False
    for name in ('favorites', 'ratings'):
        entry = data[name].get(page)
        if entry is not None and not entry.get('genres'):
            entry['genres'] = genres
            changed = True
    return save(data) if changed else False


def reset_votes():
    '''A szavazatok torlese (a kedvencek maradnak).'''
    data = load()
    data['ratings'] = {}
    return save(data)


# --- Mufaj-preferencia ---------------------------------------------------------------

def _weights(genres):
    '''[(mufaj, suly)]: az elso teljes, a tobbi fel sullyal.'''
    return [(genre, PRIMARY_WEIGHT if index == 0 else OTHER_WEIGHT) for index, genre in enumerate(genres or [])]


def genre_scores(data=None):
    '''{mufaj: pontszam} a szavazatokbol es a kedvencekbol.'''
    data = data or load()
    scores = {}
    for entry in data['ratings'].values():
        if (entry.get('vote') or 0) <= 0:
            continue                                     # a nem tetszik csak az adott cimre szol
        for genre, weight in _weights(entry.get('genres')):
            scores[genre] = scores.get(genre, 0.0) + LIKE * weight
    for entry in data['favorites'].values():
        for genre, weight in _weights(entry.get('genres')):
            scores[genre] = scores.get(genre, 0.0) + FAVORITE * weight
    return scores


def genre_percentages(data=None, limit=None):
    '''[(mufaj, szazalek)] a tetszo mufajokra (a pozitiv pontok aranyaban), csokkeno sorrendben.'''
    scores = dict((genre, score) for genre, score in genre_scores(data).items() if score > 0)
    total = sum(scores.values())
    if not total:
        return []
    out = sorted(((genre, int(round(100.0 * score / total))) for genre, score in scores.items()),
                 key=lambda pair: (-pair[1], pair[0]))
    return out[:limit] if limit else out


def affinity(genres, scores):
    '''Mennyire illik egy cim az izleshez (a mufajai pontjai, sulyozva).'''
    return sum(scores.get(genre, 0.0) * weight for genre, weight in _weights(normalize_genres(genres)))


def disliked(data=None):
    '''A nem tetszett cimek oldalai.'''
    return set(page for page, entry in (data or load())['ratings'].items() if (entry.get('vote') or 0) < 0)


def _entry_page(entry):
    match = re.search(r'(?:^|&)url=([^&]+)', (entry or {}).get('query') or '')
    return page_key(match.group(1)) if match else ''


def rank(entries, data=None):
    '''
    Az Ajanlo: a nem tetszett cimek kimaradnak; a tobbi sorrendje az izles
    szerint (elore, ami illik). Izles nelkul valtozatlan; egyenlo pontnal az
    eredeti sorrend marad.
    '''
    data = data or load()
    skip = disliked(data)
    entries = [entry for entry in entries or [] if not skip or _entry_page(entry) not in skip]
    scores = genre_scores(data)
    if not scores:
        return entries
    indexed = list(enumerate(entries))
    indexed.sort(key=lambda pair: (-affinity(pair[1].get('genres'), scores), pair[0]))
    return [entry for _index, entry in indexed]
