# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# TMDB (themoviedb.org) egy cimrol: hatterkep, hol nezheto itthon, elozetes.
#
# A netmozi boritojanak URL-je tartalmazza az IMDb-azonositot
# (pic/imdb/tt1234567.jpg). A TMDB a filmet KOZVETLENUL az IMDb-azonositoval
# adja ki (egy keres: adatok + szolgaltatok + videok); sorozatnal elobb a
# TMDB-azonosito kell (find), aztan a sorozat -- ketto.
#
# Egy cim EGYSZER kerul lekeresre, valaha: a valasz (a "nincs" is)
# megjegyzodik a tmdb.json-ban. Kulcs nelkul semmi nem tortenik, a
# kezdokepernyo marad a boritonal.

import json
import os
import re
import time

from resources.lib.modules import config, control


FILE = 'tmdb.json'
IMDB_RE = r'/imdb/(tt\d+)\.'

# A kulcs fajlbol is johet -- 32 karaktert taviranyitoval begepelni kin.
# A Letoltesek mappa ADB-vel is irhato, a bovitmeny sajat mappaja csak a
# Kodin belulrol. Az elso letezo, ertelmes tartalmu fajl nyer.
KEY_FILES = (
    '/storage/emulated/0/Download/netmozi-tmdb.txt',
    '/sdcard/Download/netmozi-tmdb.txt',
)
KEY_RE = r'^[0-9a-f]{32}$'

MOVIE, TV = 'movie', 'tv'


def imdb_id(thumb):
    '''"tt1234567" egy netmozi borito-URL-bol, vagy ''.'''
    match = re.search(IMDB_RE, thumb or '')
    return match.group(1) if match else ''


def _key_from_files():
    candidates = list(KEY_FILES) + [os.path.join(control.dataPath, 'tmdb.txt')]
    for path in candidates:
        try:
            with open(path, encoding='utf-8') as handle:
                text = handle.read().strip()
        except (IOError, OSError):
            continue
        if re.match(KEY_RE, text):
            return text
    return ''


def api_key():
    try:
        key = (control.setting('tmdbkey') or '').strip()
    except Exception:
        key = ''
    return key or _key_from_files() or control.bundledKey('tmdbkey')


# --- Tarolas -----------------------------------------------------------------

def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'TMDB adatok írása', exc)
        return False


def cached(imdb, data=None):
    '''A megjegyzett bejegyzes ({} = tudjuk, hogy nincs), vagy None, ha meg nem kertuk.'''
    data = load() if data is None else data
    return data.get(imdb)


def _remember(imdb, record):
    store = load()
    store[imdb] = record
    if len(store) > config.TMDB_MAX_ENTRIES:
        for old in list(store)[:len(store) - config.TMDB_MAX_ENTRIES]:
            del store[old]
    save(store)


# --- Keresek -----------------------------------------------------------------

def _get(path, key, **params):
    '''Egy API-hivas: (statusz, JSON) vagy (None, None) halozati hibanal.'''
    from resources.lib.modules import client
    params['api_key'] = key
    url = '%s/%s?%s' % (config.TMDB_API, path,
                        '&'.join('%s=%s' % (k, v) for k, v in sorted(params.items())))
    response = client.request(url, output='response', timeout=config.TMDB_TIMEOUT)
    if not response:
        return None, None
    status, text = response
    try:
        return status, json.loads(text)
    except ValueError:
        return status, None


def service_labels(providers):
    '''
    A "watch/providers" valaszbol az itthoni ELOFIZETESES szolgaltatok
    rovid feliratai, a TMDB sorrendjeben, ismetles nelkul.
    '''
    region = ((providers or {}).get('results') or {}).get(config.TMDB_REGION) or {}
    labels = {name: short for name, short in config.TMDB_SERVICE_LABELS}
    out = []
    for row in region.get('flatrate') or []:
        name = row.get('provider_name') or ''
        if not name or any(word in name for word in config.TMDB_SERVICE_SKIP):
            continue
        short = labels.get(name, name)
        if short not in out:
            out.append(short)
    return out[:config.TMDB_SERVICE_MAX]


def trailer_pick(videos):
    '''
    (kulcs, nyelv) a legjobb YouTube-elozetesre: magyar elozetes, magyar
    teaser, angol elozetes, angol teaser -- ebben a sorrendben. ('', '') ha nincs.
    '''
    rows = [row for row in ((videos or {}).get('results') or [])
            if row.get('site') == 'YouTube' and row.get('key')]
    for lang in ('hu', 'en'):
        for kind in ('Trailer', 'Teaser'):
            picks = [row for row in rows if row.get('iso_639_1') == lang and row.get('type') == kind]
            if picks:
                # A hivatalos elore.
                picks.sort(key=lambda row: 0 if row.get('official') else 1)
                return picks[0]['key'], lang
    return '', ''


def trailer_key(videos):
    return trailer_pick(videos)[0]


def _record(kind, data):
    path = data.get('backdrop_path') or ''
    date = data.get('release_date') or data.get('first_air_date') or ''
    runtime = data.get('runtime') or (data.get('episode_run_time') or [0])[0] or 0
    trailer, trailer_lang = trailer_pick(data.get('videos'))
    return {'kind': kind, 'id': data.get('id'),
            'backdrop': config.TMDB_IMAGE % path if path else '',
            'services': service_labels(data.get('watch/providers')),
            'trailer': trailer,
            'trailer_lang': trailer_lang,
            # A reszletezo nezethez (magyarul, ha van):
            'overview': (data.get('overview') or '').strip(),
            'genres': [g.get('name') for g in data.get('genres') or [] if g.get('name')][:3],
            'runtime': int(runtime or 0),
            'year': date[:4] if date else '',
            'seasons': int(data.get('number_of_seasons') or 0),
            # Futo sorozat: mikor jon a kovetkezo resz (next_episode_to_air).
            'status': data.get('status') or '',
            'next_date': _next(data).get('air_date') or '',
            'next_season': int(_next(data).get('season_number') or 0),
            'next_episode': int(_next(data).get('episode_number') or 0),
            # ... es mikor jott a legutobbi (last_episode_to_air): a netmozin
            # meg hianyzo, mar kijott resz felismeresehez.
            'last_date': _last(data).get('air_date') or '',
            'last_season': int(_last(data).get('season_number') or 0),
            'last_episode': int(_last(data).get('episode_number') or 0),
            'next_at': int(time.time())}


def _next(data):
    nxt = data.get('next_episode_to_air')
    return nxt if isinstance(nxt, dict) else {}


def _last(data):
    last = data.get('last_episode_to_air')
    return last if isinstance(last, dict) else {}


NEXT_TTL = 12 * 3600            # a kovetkezo resz datumat ilyen surun frissitjuk
NEXT_STALE_TTL = 2 * 3600       # ha a tarolt "kovetkezo" resz mar kijott: az adat elavult, surubben


def refresh_next(imdb, key=None, now=None, force=False):
    '''
    Egy sorozat kovetkezo reszenek datumat frissiti (naponta ketszer), a
    bejegyzesbe irva. True, ha a halozatrol frissult.
    '''
    key = key or api_key()
    record = cached(imdb)
    if not key or not record or record.get('kind') != TV or not record.get('id'):
        return False
    ttl = NEXT_TTL
    next_date = record.get('next_date') or ''
    if next_date and next_date < time.strftime('%Y-%m-%d', time.localtime(now or time.time())):
        ttl = NEXT_STALE_TTL
    if not force and (now or time.time()) - (record.get('next_at') or 0) < ttl:
        return False
    status, data = _get('tv/%s' % record['id'], key, language='hu-HU')
    if status != '200' or not isinstance(data, dict):
        return False
    record = dict(record)
    record.update({'status': data.get('status') or '',
                   'next_date': _next(data).get('air_date') or '',
                   'next_season': int(_next(data).get('season_number') or 0),
                   'next_episode': int(_next(data).get('episode_number') or 0),
                   'last_date': _last(data).get('air_date') or '',
                   'last_season': int(_last(data).get('season_number') or 0),
                   'last_episode': int(_last(data).get('episode_number') or 0),
                   'next_at': int(now or time.time())})
    _remember(imdb, record)
    return True


def has_details(record):
    '''A regebbi bejegyzesekben nincs leiras: azokat a reszletezo ujra keri.'''
    return bool(record) and 'overview' in record


def fetch(imdb, key=None):
    '''
    Lekeri es megjegyzi egy cim adatait. A bejegyzes ({} ha a TMDB nem
    ismeri), None halozati hibanal (akkor nem jegyzunk meg semmit).
    '''
    key = key or api_key()
    if not imdb or not key:
        return None
    # language=hu-HU: magyar leiras es mufajnevek; a hatterkep es a videok
    # listaja ugyanaz marad (ellenorizve).
    extra = {'append_to_response': 'watch/providers,videos', 'include_video_language': 'hu,en',
             'language': 'hu-HU'}
    status, data = _get('movie/%s' % imdb, key, **extra)
    if status is None:
        return None
    if status == '200' and isinstance(data, dict) and data.get('id'):
        record = _record(MOVIE, data)
    else:
        # Nem film: sorozat lehet. A find adja a TMDB-azonositot.
        status, found = _get('find/%s' % imdb, key, external_source='imdb_id')
        if status is None:
            return None
        tv_rows = (found or {}).get('tv_results') or []
        if not tv_rows:
            record = {}
        else:
            status, data = _get('tv/%s' % tv_rows[0].get('id'), key, **extra)
            if status is None:
                return None
            record = _record(TV, data) if status == '200' and isinstance(data, dict) else {}
    _remember(imdb, record)
    return record


def lookup(thumb, data=None):
    '''
    Egy borito cimenek adatai: gyorsitotarbol, vagy lekerve. {} ha nincs
    (vagy nincs kulcs, vagy halozati hiba).
    '''
    imdb = imdb_id(thumb)
    if not imdb:
        return {}
    known = cached(imdb, data)
    if known is not None:
        return known
    if not api_key():
        return {}
    return fetch(imdb) or {}


def backdrop(thumb, data=None):
    '''A valodi hatterkep URL-je egy boritohoz, vagy ''.'''
    return (lookup(thumb, data) or {}).get('backdrop') or ''


def missing(thumbs, data=None):
    '''Azok az IMDb-azonositok a boritokbol, amiket meg nem kertunk le.'''
    data = load() if data is None else data
    out = []
    for thumb in thumbs:
        imdb = imdb_id(thumb)
        if imdb and imdb not in data and imdb not in out:
            out.append(imdb)
    return out


def prefetch(thumbs, limit=None, pause=None, stop=None):
    '''
    A hatterben, egyenkent lekeri a meg ismeretlen cimeket -- ennyit
    (limit), ennyi szunettel (pause). stop(): ha igazat ad, abbahagyja.
    Visszaad: hany cimet kert le.
    '''
    key = api_key()
    if not key:
        return 0
    limit = config.TMDB_PREFETCH_MAX if limit is None else limit
    pause = config.TMDB_PREFETCH_PAUSE if pause is None else pause
    count = 0
    for imdb in missing(thumbs)[:limit]:
        if stop and stop():
            break
        if fetch(imdb, key) is None:
            break                                    # halozati hiba: ne eroltessuk
        count += 1
        if pause:
            time.sleep(pause)
    return count


# --- Szolgaltatok listai (Disney+, HBO Max, ...) ------------------------------

def discover(kind, provider_id, key=None):
    '''
    Egy szolgaltato itthoni kinalata nepszeruseg szerint: [(TMDB id,
    nepszeruseg)] filmre (movie) vagy sorozatra (tv). None halozati hibanal.
    '''
    key = key or api_key()
    if not key:
        return None
    status, data = _get('discover/%s' % kind, key, watch_region=config.TMDB_REGION,
                        with_watch_providers=provider_id, with_watch_monetization_types='flatrate',
                        sort_by='popularity.desc')
    if status != '200' or not isinstance(data, dict):
        return None
    out = []
    for row in data.get('results') or []:
        if row.get('id'):
            out.append((row['id'], float(row.get('popularity') or 0)))
    return out[:config.PROVIDER_PER_KIND]


PROVIDER_LOGOS = '__providers__'      # a szolgaltatok logoi (tmdb.json), havonta
PROVIDER_LOGO_TTL = 30 * 24 * 3600


def provider_logos(key=None, now=None):
    """{TMDB szolgaltato-azonosito: logo URL} itthon -- megjegyezve, havonta frissitve."""
    store = load()
    record = store.get(PROVIDER_LOGOS) or {}
    now = now or time.time()
    if record.get('logos') and now - (record.get('at') or 0) < PROVIDER_LOGO_TTL:
        return record['logos']
    key = key or api_key()
    if not key:
        return record.get('logos') or {}
    status, data = _get('watch/providers/movie', key, watch_region=config.TMDB_REGION)
    if status != '200' or not isinstance(data, dict):
        return record.get('logos') or {}
    logos = {}
    for row in data.get('results') or []:
        path = row.get('logo_path') or ''
        if row.get('provider_id') and path:
            logos[str(row['provider_id'])] = config.TMDB_LOGO % path
    if logos:
        _remember(PROVIDER_LOGOS, {'logos': logos, 'at': int(now)})
    return logos or record.get('logos') or {}


def catalog(kind, provider_id, year, page=1, key=None):
    """
    Egy szolgaltato kinalata EGY evbol, nepszeruseg szerint (a sor vegi
    "Tovabb" racsahoz): [{'id', 'title', 'year', 'poster'}]. None hibanal,
    [] ha abban az evben nincs tobb.
    """
    key = key or api_key()
    if not key:
        return None
    params = {'watch_region': config.TMDB_REGION, 'with_watch_providers': provider_id,
              'with_watch_monetization_types': 'flatrate', 'sort_by': 'popularity.desc',
              'language': 'hu-HU', 'page': page}
    params['primary_release_year' if kind == MOVIE else 'first_air_date_year'] = year
    status, data = _get('discover/%s' % kind, key, **params)
    if status != '200' or not isinstance(data, dict):
        return None
    out = []
    for row in data.get('results') or []:
        date_text = row.get('release_date') or row.get('first_air_date') or ''
        poster = row.get('poster_path') or ''
        out.append({'id': row.get('id'), 'kind': kind,
                    'title': (row.get('title') or row.get('name') or '').strip(),
                    'year': date_text[:4], 'poster': config.TMDB_POSTER % poster if poster else ''})
    return [row for row in out if row['id'] and row['title']]


def discover_kids(kind, provider_id, key=None):
    '''
    Egy szolgaltato itthoni MESE-kinalata (animacio / csaladi / gyerek
    mufaj) nepszeruseg szerint, magyar cimmel es poszterrel:
    [{'id', 'title', 'poster'}]. None halozati hibanal.
    '''
    key = key or api_key()
    if not key:
        return None
    status, data = _get('discover/%s' % kind, key, watch_region=config.TMDB_REGION,
                        with_watch_providers=provider_id, with_watch_monetization_types='flatrate',
                        with_genres=config.TMDB_KIDS_GENRES.get(kind, '16'), include_adult='false',
                        sort_by='popularity.desc', language='hu-HU')
    if status != '200' or not isinstance(data, dict):
        return None
    out = []
    for row in data.get('results') or []:
        if not row.get('id'):
            continue
        poster = row.get('poster_path') or ''
        out.append({'id': row['id'], 'title': (row.get('title') or row.get('name') or '').strip(),
                    'poster': (config.TMDB_POSTER % poster) if poster else ''})
    return out[:config.KIDS_PER_KIND]


def external_imdb(kind, tmdb_id, key=None):
    '''Egy TMDB-cim IMDb-azonositoja ('' ha nincs), None halozati hibanal.'''
    key = key or api_key()
    if not key:
        return None
    status, data = _get('%s/%s/external_ids' % (kind, tmdb_id), key)
    if status is None:
        return None
    return ((data or {}).get('imdb_id') or '') if status == '200' else ''
