# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Elozetes feloldasa a HATTERBEN -- az IMDb-rol.
#
# Az IMDb GraphQL-kapuja (api.graphql.imdb.com) a web-kliens fejlecevel a
# cim elozeteseinek KOZVETLEN MP4-cimeit adja (1080p/720p/480p),
# bejelentkezes nelkul; a cimek par oraig ervenyesek (Expires=...). Az
# IMDb-azonosito a netmozi boritojabol megvan, igy ehhez kulcs sem kell.
#
# A YouTube-ot kivezettuk: bejelentkezes nelkul nem ad videot, a bovitmeny
# feloldoja lassu volt, es hibas cimekkel "failed to play" uzeneteket
# okozott.
#
# Miert nem a plugin://...youtube/play cimet adtuk a lejatszonak? Mert azt a
# Kodi a fo (kepernyo-) szalon oldja fel, es amig dolgozik, a felulet all.
# A kesz videocimet viszont a Kodi azonnal inditja es azonnal le is allitja.
#
# A feloldott cimeket megjegyezzuk (a munkamenetre, a lejaratig): a boritora
# visszalepve nincs ujabb varakozas. Inditas elott gyorsan ellenorizzuk,
# hogy a szerver tenyleg ad-e videot: ha nem, nem is probalkozunk (a Kodi
# kulonben "failed to play" uzenetet dobna).

import time

from resources.lib.modules import config, control


CACHE = {}              # kulcs -> {'url', 'expires'}
CACHE_MAX = 60
EXPIRY_MARGIN = 600     # mp: ennyivel a lejarat elott mar ujra kerjuk
CHECK_TIMEOUT = 4       # mp: az elozetes cimenek gyors ellenorzese


def resolve_imdb(imdb):
    '''Az IMDb elozetes MP4-cime (imdb.py: egy keres a cim minden adataval).'''
    from resources.lib.modules import imdb as imdb_mod
    if not imdb:
        return ''
    return imdb_mod.trailer_url(imdb)


def expiry_of(url):
    from resources.lib.modules import imdb as imdb_mod
    return imdb_mod.expiry_of(url)


FAILED = set()          # a munkamenetben el nem indult elozetesek (IMDb-azonosito)


def mark_failed(key):
    '''Ez az elozetes nem indult el: a munkamenetben tobbet nem probaljuk.'''
    if key:
        FAILED.add(key)
        CACHE.pop(key, None)


def playable(url):
    '''A szerver tenyleg ad videot? (gyors GET az elejere)'''
    from resources.lib.modules import client
    try:
        return bool(client.looks_playable(url, CHECK_TIMEOUT))
    except Exception as exc:
        control.log_exception(u'előzetes ellenőrzése', exc)
        return False


def _store(key, url):
    if len(CACHE) >= CACHE_MAX:
        CACHE.pop(next(iter(CACHE)))
    CACHE[key] = {'url': url, 'expires': expiry_of(url)}


def cached(key, now=None):
    '''None: meg nem oldottuk fel (vagy lejart); '' : nem megy; kulonben az URL.'''
    if key in FAILED:
        return ''
    entry = CACHE.get(key)
    if not entry:
        return None
    if entry['expires'] and (now or time.time()) > entry['expires'] - EXPIRY_MARGIN:
        return None
    return entry['url']


def resolve(key):
    '''
    Egy cim (IMDb-azonosito) elozetese -> lejatszhato URL ('' ha nem megy).
    Gyorsitotarbol, ha mar volt (es nem jart le). Hatterszalbol hivando.
    '''
    if not key:
        return ''
    known = cached(key)
    if known is not None:
        return known
    url = resolve_imdb(key) if key.startswith('tt') else ''
    if url and not playable(url):
        control.log(u'Előzetes: a videoszerver nem válaszol (%s)' % key, control.LOGWARNING)
        url = ''
    _store(key, url)
    if not url:
        control.log(u'Előzetes: nincs játszható folyam (%s)' % key, control.LOGWARNING)
    return url
