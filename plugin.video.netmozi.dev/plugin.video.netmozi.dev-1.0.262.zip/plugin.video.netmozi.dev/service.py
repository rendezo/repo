# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Háttérszolgáltatás: a hozzászólás-átfedés megjelenítése lejátszás közben.
#
# Erre azért van szükség, mert a plugin rövid életű -- a lista felépítése
# vagy az URL feloldása után kilép, tehát nem tud ott lenni a film alatt.
# A szolgáltatás viszont végig fut, és figyeli a lejátszót.
#
# A hozzászólásokat NEM ez tölti le: a plugin nyeri ki őket az adatlapból,
# amit amúgy is letölt, és fájlba teszi. Így itt nincs hálózati munka.

import os
import time

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.modules import (comments, config, control, history,
                                   intro, overlay, progress, streamcheck,
                                   watchlist)

# Ennyit várunk a lejátszás indulása után, hogy a kép már fent legyen.
# Beállításból jön; ez csak a tartalék, ha nem olvasható.
DEFAULT_DELAY = 2


def show_delay():
    try:
        value = int(control.setting('commentdelay'))
    except (ValueError, TypeError, Exception):
        return DEFAULT_DELAY
    return max(0, value)


def enabled():
    try:
        return control.settingBool('commentoverlay')
    except Exception:
        return False


def show_overlay():
    """Átfedés megnyitása. None-t ad, ha nincs mit vagy nem sikerült."""
    title, entries = comments.load()
    if not entries:
        control.log(u'Átfedés kihagyva: nincs eltárolt hozzászólás')
        return None
    window = overlay.create(title, entries)
    if window is None:
        control.log_error(u'Az átfedés ablakot nem sikerült létrehozni')
        return None
    try:
        # show() és nem doModal(): nem visszük el a fókuszt a lejátszótól.
        window.show()
    except Exception as exc:
        control.log_exception(u'átfedés megjelenítése', exc)
        return None
    control.log(u'Hozzászólás-átfedés megjelenítve: %d db' % len(entries))
    return window


def close_overlay(window):
    if window is None:
        return None
    try:
        window.close()
    except Exception as exc:
        control.log_exception(u'átfedés bezárása', exc)
    return None


# --- Figyelt sorozatok: napi ellenorzes inditasa ----------------------------
#
# A szolgaltatas CSAK IDOZITO. Az ellenorzest maga a bovitmeny vegzi
# (RunPlugin), a sajat scraper-kodjaval -- a navigator ugyanis a bovitmeny
# hivasi kornyezetet varja, a szolgaltatasbol nem importalhato.

# Inditas utan ennyit varunk az elso ellenorzessel: a Kodi bootolasakor
# ne mi terheljuk a halozatot.
WATCH_FIRST_DELAY = 120
# Ilyen gyakran nezzuk meg, esedekes-e valami. Az igazi napi ritmust a
# watchlist.due() adja; ez csak a lekerdezes surusege.
WATCH_POLL = 600
RESUME_GAP = 90                 # ha a ciklus ennyit kihagy: keszenletbol ebredtunk


def watch_enabled():
    try:
        return control.settingBool('watchseries')
    except Exception:
        return True


# Kodi indulasa utan ennyivel mutatjuk az emlekeztetot: a skin addigra
# betoltott, es a nezo mar a kepernyo elott ul.
REMINDER_DELAY = 30


def startup_reminder():
    """
    Emlekezteto a meg meg nem nezett uj reszekrol.

    A napi ellenorzes toastja konnyen elszalad -- akkor jon, amikor a
    Kodi eppen nem jatszik le semmit, es lehet, hogy senki nem ul a TV
    elott. Ez a jelzes a bekapcsolaskor szembejon. Csak a helyi fajlt
    olvassa, a netmozitol nem ker semmit.
    """
    try:
        summary = watchlist.new_summary()
    except Exception as exc:
        control.log_exception(u'új részek számolása', exc)
        return False
    if not summary:
        return False
    control.infoDialog(u'%s vár a figyelt listában' % summary,
                       heading=u'NetMozi', time=8000)
    control.log(u'Emlékeztető: %s' % summary)
    return True


# --- Indulaskor egybol a netmozi ----------------------------------------------
#
# Idos felhasznalonak a "Kiegeszitok -> Video kiegeszitok -> netmozi" ut
# ertelmezhetetlen. A szolgaltatas a Kodival egyutt indul: amint a
# fokepernyo megjelent, megnyitja a netmozi menujet. Csak a fokepernyorol
# lep tovabb (ha valaki mar valahol jar -- pl. bovitmeny-frissites utan a
# szolgaltatas ujraindul --, nem ugrik a szeme ele), es csak ha nem megy
# lejatszas. Egyszer, az elso percben.

OPEN_ON_START_WINDOW = 60
ADDON_ROOT = 'plugin://%s/'


def open_on_start_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('openonstart')
    except Exception:
        return False


def ask_profile_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('askprofile')
    except Exception:
        return False


def ask_profile():
    """'Ki nez?' a bekapcsolas utan -- csak ha vannak profilok es kertek."""
    from resources.lib.modules import profiles
    if not profiles.names() or not ask_profile_enabled():
        return
    profiles.ask_dialog()


def ask_profile_wanted():
    """Kell-e a kerdes (vannak profilok es kertek)."""
    from resources.lib.modules import profiles
    try:
        return bool(profiles.names()) and ask_profile_enabled()
    except Exception:
        return False


# --- Boritos kezdokepernyo -----------------------------------------------------
#
# A szolgaltatas CSAK ELINDITJA (RunPlugin): az ablakot a bovitmeny sajat
# folyamata hordozza. Szolgaltatasbol nyitott ablak a szolgaltatas
# leallitasakor (pl. frissiteskor) beakasztotta a Kodit -- tobbe nem.


def home_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('homeview')
    except Exception:
        return True


def open_home(ask=False):
    from resources.lib.modules import home
    if home.guard_tripped():
        # Az elozo megnyitas elakadt: most a szoveges ut, es szolunk.
        home.guard_clear()
        control.log(u'Kezdőképernyő kihagyva indításkor: az előző elakadt', control.LOGWARNING)
        control.infoDialog(u'A borítós kezdőképernyő most kimaradt (az előző indulás '
                           u'elakadt). Beállításokban kikapcsolható.', time=10000)
        return False
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    xbmc.executebuiltin('RunPlugin(plugin://%s/?action=home%s)' % (addon_id, '&askprofile=1' if ask else ''))
    control.log(u'Indulás: a borítós kezdőképernyő indítva%s' % (u' (Ki néz?)' if ask else u''))
    return True


def open_addon_root():
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    # "return": a vissza gomb a Kodi fokepernyojere visz, nem a semmibe.
    xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % (ADDON_ROOT % addon_id))
    control.log(u'Indulás: a netmozi menü megnyitva')


KODI_START_RE = r'^\ufeff?(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'
FRESH_BOOT_SECONDS = 180


def kodi_started_recently(now=None):
    """
    Valodi Kodi-indulas-e ez (True), vagy a szolgaltatast a bovitmeny
    frissitese inditotta ujra (False)? A kodi.log elso sora a Kodi
    indulasanak ideje. Ha nem olvashato: True (ne maradjon el a megnyitas).
    """
    import re
    import time as _time
    try:
        path = control.transPath('special://logpath/kodi.log')
        with open(path, 'rb') as handle:
            head = handle.read(200).decode('utf-8', errors='replace')
        match = re.match(KODI_START_RE, head)
        if not match:
            return True
        started = _time.mktime(_time.strptime(match.group(1), '%Y-%m-%d %H:%M:%S'))
        return ((now or _time.time()) - started) < FRESH_BOOT_SECONDS
    except Exception:
        return True


def try_open_on_start(playing):
    """True, ha most megnyitottuk (vagy nem kell); False, ha meg varni kell."""
    if not open_on_start_enabled():
        return True
    if not kodi_started_recently():
        # A szolgaltatast a bovitmeny frissitese inditotta ujra: a
        # kezdokepernyo maga inditja ujra magat, ne nyissunk masodikat.
        control.log(u'Indulás: nem friss Kodi-indulás (frissítés utáni újraindítás), nincs megnyitás')
        return True
    if playing:
        return False
    try:
        at_home = xbmc.getCondVisibility('Window.IsActive(home)')
    except Exception:
        at_home = False
    if not at_home:
        return False
    # A boritos kezdokepernyo a sajat "Ki nez?" kepernyojet mutatja; a
    # szoveges menu elott a Kodi valasztoja kerdez.
    if home_enabled() and open_home(ask=ask_profile_wanted()):
        return True
    try:
        ask_profile()
    except Exception as exc:
        control.log_exception(u'profilkérdés', exc)
    open_addon_root()
    return True


DEBUG_LOG_INTERVAL = 60


def debug_log_enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('debuglog')
    except Exception:
        return False


def trigger_stream_check():
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    xbmc.executebuiltin('RunPlugin(plugin://%s/?action=streamcheck&quiet=1)' % addon_id)
    control.log(u'Stream Top: napi elérhetőség-ellenőrzés indítva')


SUBTITLES_AUTO_AFTER = 5       # mp: ennyi utan a savok mar ismertek


def trigger_auto_subtitles():
    '''Magyar felirat magatol (subtitles.py), ha nincs magyar hang es felirat -- a hatterben.'''
    import threading

    def work():
        try:
            from resources.lib.modules import subtitles
            subtitles.auto_attach(xbmc.Player())
        except Exception as exc:
            control.log_exception(u'magyar felirat magától', exc)
    thread = threading.Thread(target=work)
    thread.daemon = True
    thread.start()


def trigger_watch_check():
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    xbmc.executebuiltin('RunPlugin(plugin://%s/?action=watchcheck&quiet=1)' % addon_id)
    control.log(u'Figyelt sorozatok: napi ellenőrzés indítva')


# --- Sorozat folytatasa: hol tart a resz ------------------------------------

def mark_ours(flag):
    '''A futo video a NetMozie-e -- az osd.py ebbol tudja, a mi vezerlonk jon-e.'''
    try:
        from resources.lib.modules import osd
        window = xbmcgui.Window(10000)
        if flag:
            window.setProperty(osd.PLAYING_PROP, '1')
        else:
            window.clearProperty(osd.PLAYING_PROP)
    except Exception as exc:
        control.log_exception(u'lejátszásvezérlő jelzése', exc)


class ProgressTracker(object):
    """
    Nezes kozben feljegyzi, hol tart a resz -- ebbol tud a "Mar lattam"
    okosan folytatni.

    Csak olyan lejatszast kovet, ami FRISSEN megnyitott netmozi adatlaphoz
    tartozik: az adatlap kontextusa idobelyeges, es ha a lejatszas nem
    rovid idon belul indult utana, nem a mienk (mas bovitmeny, vagy a
    rejtett lista). Az Up Next lanca kozben nincs leallas, a fajl megallas
    nelkul valt -- ezert a fajlvaltast is figyeljuk, nem csak az indulast.
    """

    STATS_FLUSH = 600           # mp: ennyi nezes utan a naplóba (ha a Kodi leallna, se vesszen el)

    def __init__(self):
        self.file = None
        self.page = None
        self.was_playing = False
        self.title = ''
        self.thumb = ''
        self.last_write = 0
        self.watched = 0.0      # a statisztikanak: a tenyleges nezes (szunet nelkul), mp
        self.last_tick = 0

    def _count(self):
        '''A nezesi ido: ket utem kozti ido, ha megy (nem all szunetben).'''
        now = time.time()
        if self.page and self.last_tick and not xbmc.getCondVisibility('Player.Paused'):
            self.watched += min(now - self.last_tick, 2.0)
        self.last_tick = now
        if self.watched >= self.STATS_FLUSH:
            self._flush()

    def _flush(self):
        from resources.lib.modules import stats
        if self.page and self.watched:
            try:
                stats.record(self.page, self.title, self.watched)
            except Exception as exc:
                control.log_exception(u'statisztika', exc)
        self.watched = 0.0

    def _bind(self):
        """Az eppen indult fajlhoz tartozo adatlap -- vagy None."""
        context = history.get_context() or {}
        page = context.get('page') or ''
        fresh = (time.time() - (context.get('set') or 0)) <= config.CONTEXT_FRESH_SECONDS
        # Sorozat-resz VAGY film: mindkettonek van folytatasa.
        if not (page and fresh and (progress.split_page(page) or progress.film_key(page))):
            return None
        self.title = context.get('title', '')
        self.thumb = context.get('thumb', '')
        return page

    def tick(self, player, playing):
        if not playing:
            if self.was_playing:
                # Vege a lejatszasnak: a kovetkezo video mar nem feltetlenul a mienk.
                mark_ours(False)
                self._flush()
            self.last_tick = 0
            self.was_playing = False
            self.file = None
            self.page = None
            return
        self.was_playing = True
        try:
            current = player.getPlayingFile()
        except RuntimeError:
            return
        if current != self.file:
            self._flush()                                # az elozo resz ideje (Up Next lanc)
            self.file = current
            self.page = self._bind()
            self.last_write = 0
            # A sajat lejatszasvezerlo (OK gomb) csak a mi videonkon: ha a
            # kovetes ehhez kotott, biztosan a mienk (a jelzest az inditas is allitja).
            if self.page:
                mark_ours(True)
            if self.page:
                control.log(u'Folytatás követése: %s' % self.page)
        if not self.page:
            return
        self._count()
        if time.time() - self.last_write < config.PROGRESS_INTERVAL:
            return
        try:
            position, total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if total <= 0:
            return
        self.last_write = time.time()
        progress.update(self.page, self.title, self.thumb, position, total)


# --- Intro atugrasa: tanul a nezo tekeresebol ---------------------------------

def intro_skip_enabled():
    try:
        return control.settingBool('introskip')
    except Exception:
        return True


class IntroSkipper(object):
    """
    Ket dolga van, mindketto csak sorozat-resznel:

    TANUL: ha a nezo az elso percekben elore teker (a pozicio egy tick alatt
    sokkal elorebb ugrik), az intro vege ott van, ahova ert. A sajat
    tekeresunket (folytatas) a plugin ablak-tulajdonsaggal jelzi; azt
    kihagyjuk.

    ATUGRIK: ha a sorozathoz mar van tanult intro, es a lejatszas magatol
    eleri a kezdetet, a vegere ugrik -- fajlonkent egyszer. Ha utana a nezo
    rogton visszateker, a tanult ertek torlodik.
    """

    def __init__(self):
        self.file = None
        self.base = None
        self.last_pos = None
        self.last_at = 0
        self.skipped = False
        self.skipped_at = 0
        self.skipped_to = 0

    def _own_seek(self, target):
        """A plugin (folytatas) vagy mi magunk tekertunk ide?"""
        try:
            window = xbmcgui.Window(10000)
            marked = window.getProperty('netmozi.seek')
        except Exception:
            return False
        if not marked:
            return False
        try:
            ours = abs(int(marked) - target) <= 5
        except ValueError:
            ours = False
        if ours:
            window.clearProperty('netmozi.seek')
        return ours

    def tick(self, player, page, playing):
        if not playing or not page:
            self.file = None
            self.base = None
            self.last_pos = None
            return
        parts = progress.split_page(page)
        if not parts:
            return                                   # film: nincs intro
        try:
            current = player.getPlayingFile()
            pos = int(player.getTime())
            total = int(player.getTotalTime())
        except RuntimeError:
            return
        now = time.time()
        if current != self.file:
            self.file, self.base = current, parts[0]
            self.last_pos, self.last_at = pos, now
            self.skipped, self.skipped_at = False, 0
            return

        # 1) TANULAS: elore-ugras egy tick alatt, az elso percekben.
        if self.last_pos is not None and (now - self.last_at) <= 3:
            jump = pos - self.last_pos
            if jump >= intro.MIN_JUMP and intro.plausible(self.last_pos, pos):
                if self._own_seek(pos) or (self.skipped and abs(pos - self.skipped_to) <= 5):
                    pass                             # a mienk volt, nem a nezoe
                else:
                    intro.learn(self.base, self.last_pos, pos)
                    self.skipped = True              # ebben a fajlban mar nem ugrunk
            # 2) MEGBANAS: az automatikus ugras utan rogton vissza -> felejtsuk el.
            elif (self.skipped and self.skipped_at
                  and (now - self.skipped_at) <= intro.REGRET_SECONDS
                  and pos < self.skipped_to - 10 and self.last_pos >= self.skipped_to - 5):
                intro.forget(self.base)
                control.infoDialog(u'Rendben, ezt a sorozatot nem ugrom át többé.')
                self.skipped_at = 0
        self.last_pos, self.last_at = pos, now

        # 3) ATUGRAS: tanult intro, es a lejatszas magatol eleri a kezdetet.
        if self.skipped or not intro_skip_enabled():
            return
        learned = intro.get(self.base)
        if not learned:
            return
        start, end = learned['start'], learned['end']
        if total and total < end + 60:
            return
        if start - 1 <= pos <= start + 3:
            try:
                xbmcgui.Window(10000).setProperty('netmozi.seek', str(int(end)))
                player.seekTime(end)
            except RuntimeError as exc:
                control.log_exception(u'intró átugrása', exc)
                return
            self.skipped, self.skipped_at, self.skipped_to = True, now, end
            self.last_pos = end
            control.infoDialog(u'Intró átugorva (%d:%02d -> %d:%02d)'
                               % (start // 60, start % 60, end // 60, end % 60), time=4000)
            control.log(u'Intró átugorva: %s %d -> %d' % (self.base, start, end))


def main():
    """
    Lejátszás figyelése LEKÉRDEZÉSSEL, nem visszahívásokkal.

    A lejátszó visszahívásainak gyorsan vissza kell térniük -- ott várakozni
    megbízhatatlan. Másodpercenként megnézzük, megy-e a lejátszás, és pár
    másodperc után nyitjuk az átfedést, hogy a kép már fent legyen.
    """
    control.log(u'Szolgáltatás indul')
    # 1.0.149 hagyateka: ha a skin DialogBusy.xml-je meg modositva van, vissza.
    try:
        from resources.lib.modules import skinfix
        skinfix.undo_if_patched()
    except Exception as exc:
        control.log_exception(u'skin visszaállítása', exc)
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    window = None
    started = None
    subs_tried = False
    delay = show_delay()
    shown_once = False
    # Fél másodperces ütem: a gombnyomásra adott válasz feleannyit várat.
    tick = 0.5
    boot = time.time()
    next_watch_poll = boot + WATCH_FIRST_DELAY
    reminder_at = boot + REMINDER_DELAY
    tracker = ProgressTracker()
    skipper = IntroSkipper()
    next_log_export = boot + 20
    open_until = boot + OPEN_ON_START_WINDOW
    opened = False

    last_tick = time.time()
    while not monitor.abortRequested():
        if monitor.waitForAbort(tick):
            break
        # Keszenletbol ebredes (a TV "kikapcsolva" is fut a Kodi): a figyelt
        # sorozatok es a Stream Top ellenorzese ne varjon a kovetkezo korre.
        if time.time() - last_tick > RESUME_GAP:
            control.log(u'Szolgáltatás: ébredés (%d mp kimaradt)' % int(time.time() - last_tick))
            next_watch_poll = time.time() + 5
        last_tick = time.time()
        try:
            playing = player.isPlaying()
        except Exception:
            playing = False
        # A kezdokepernyo elozetese nem film: a kovetok es az atfedes
        # szamara "nem megy semmi".
        if playing and config.trailer_marked():
            playing = False

        try:
            tracker.tick(player, playing)
        except Exception as exc:
            control.log_exception(u'folytatás követése', exc)
        try:
            skipper.tick(player, tracker.page, playing)
        except Exception as exc:
            control.log_exception(u'intró átugrása', exc)



        # Indulaskor egybol a netmozi (beallitastol fuggoen), az elso percben.
        if not opened and time.time() <= open_until:
            try:
                opened = try_open_on_start(playing)
            except Exception as exc:
                control.log_exception(u'indulási megnyitás', exc)
                opened = True
        elif not opened:
            opened = True

        # Hibakeresesi naplo: percenkent a Letoltesek mappaba, ha kertek.
        if time.time() >= next_log_export:
            next_log_export = time.time() + DEBUG_LOG_INTERVAL
            if debug_log_enabled():
                try:
                    control.exportLog()
                except Exception as exc:
                    control.log_exception(u'napló kimásolása', exc)
            # A "Vissza = szunet" billentyu-kiosztas kovesse a beallitast.
            try:
                from resources.lib.modules import keymap
                keymap.sync()
            except Exception as exc:
                control.log_exception(u'billentyű-kiosztás', exc)

        # Bekapcsolaskor egyszer: van-e meg meg nem nezett uj resz.
        if reminder_at and time.time() >= reminder_at and not playing:
            reminder_at = None
            try:
                startup_reminder()
            except Exception as exc:
                control.log_exception(u'indulási emlékeztető', exc)

        # Figyelt sorozatok: ritkan, es csak ha nem megy lejatszas -- a
        # halozati munka ne akassza meg a filmet.
        if time.time() >= next_watch_poll:
            next_watch_poll = time.time() + WATCH_POLL
            if not playing and watch_enabled():
                try:
                    if watchlist.due():
                        trigger_watch_check()
                    if streamcheck.due():
                        trigger_stream_check()
                except Exception as exc:
                    control.log_exception(u'figyelt sorozatok időzítése', exc)

        if not playing:
            window = close_overlay(window)
            started = None
            subs_tried = False
            shown_once = False
            # Új lejátszásnál a friss beállítás érvényesüljön.
            delay = show_delay()
            continue

        if started is None:
            started = time.time()

        # Csak a NetMozi videojan (a rejtett lista vagy mas bovitmeny videojan
        # a legutobbi netmozis cim hozzaszolasai nem valok).
        from resources.lib.modules import osd
        if not osd.ours():
            comments.take_request()
            continue

        if not subs_tried and time.time() - started >= SUBTITLES_AUTO_AFTER:
            subs_tried = True
            trigger_auto_subtitles()

        # A néző visszakérte (távirányító gomb -> plugin -> kérés-fájl).
        if comments.take_request():
            window = close_overlay(window)
            window = show_overlay()
            continue

        if window is not None or (time.time() - started) < delay:
            continue
        if not enabled() or shown_once:
            continue
        window = show_overlay()
        # Sikertelen megjelenítést ne ismételgessünk másodpercenként.
        shown_once = True

    close_overlay(window)
    comments.clear()
    control.log(u'Szolgáltatás leáll')


if __name__ == '__main__':
    main()
