# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# bithumen mint plusz torrent-forras, az nCore mintajara (Elementumon at).
#
# Amit az oldalrol elesben (2026-10) es a nezo seeder-projektjebol tudunk:
#   - belepes: a jelszavas belepes interaktiv captchat ker -- ezt NEM
#     probaljuk kitolteni. A nezo egyszer belep a bongeszoben ("emlekezz
#     ram"), es a ket suti erteket (uid, pass) beirja a beallitasokba;
#   - kereses IMDb-azonositoval: browse.php?search=tt...&page=N (N 0-tol;
#     oldalankent 15 sor, a lapozo linkjeibol latszik az utolso lap);
#   - a sorok: table#torrenttable, a kategoria az elso cella kepenek alt-ja
#     ("Film/Hun/1080p", "Sorozat/Eng/SD"), a nev a details.php link title-je,
#     utana fajlok, hozzaszolasok, datum, meret, letoltve, seed, leech;
#   - a .torrent a sutivel: download.php/<id>/x.torrent; suti NELKUL a
#     passkey-es linkkel: download/<passkey>/<id>.torrent -- ez kell az
#     Elementumnak. A passkey a torrent tracker-cimeben van
#     (http://t2.bithumen.be/announce/<passkey>/announce): az elso
#     letoltesbol kiolvassuk es eltesszuk.
# Az oldal ISO-8859-2 kodolasu.

import json
import os
import re
import time
from urllib.parse import quote

from resources.lib.modules import control


FILE = 'bithumen.json'
SITE = 'bithumen'
PREFIX = 'bithumen://'

BASE = 'https://bithumen.be'
BROWSE_URL = BASE + '/browse.php'
COOKIE_DOWNLOAD_URL = BASE + '/download.php/%s/%s.torrent'
DOWNLOAD_URL = BASE + '/download/%s/%s.torrent'          # passkey, id -- suti nelkul

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'hu-HU,hu;q=0.9,en;q=0.5',
    'Referer': BASE + '/',
}
TIMEOUT = 20
ENCODING = 'iso-8859-2'
MAX_PAGES = 5                   # egy keresesbol legfeljebb ennyi lap (75 sor)

# A lemezkep-kategoriak (Blu-ray, DVD) kimaradnak: azt az Elementum nem streameli.
SKIP_CATEGORY_RE = r'(?i)blu-?ray|dvd'
PASSKEY_RE = r'/announce/([0-9a-f]{32})/'
LOGIN_MARKERS = ('id="loginform"', 'takelogin.php')
EXPIRED_TEXT = u'A bithumen süti lejárt: lépj be újra a böngészőben, és írd be az új uid / pass értéket.'


# --- Beallitasok es tarolt adatok ---------------------------------------------------

def credentials():
    '''
    (uid, pass) a beallitasokbol. Ha a nezo a teljes sutit masolta be
    ("uid=123; pass=abc..."), abbol is kiolvassuk.
    '''
    try:
        uid = (control.setting('bhuid') or '').strip()
        secret = (control.setting('bhpass') or '').strip()
    except Exception:
        return '', ''
    return parse_cookie(uid, secret)


def _cookie_values(text):
    '''
    {nev: ertek} a bemasolt sutibol, barmelyik szokasos alakban: a "Cookie:"
    sor / "uid=...; pass=..." (Header String), a Cookie-Editor es az
    EditThisCookie JSON-exportja, vagy a Netscape cookies.txt. Ha mas oldal
    sutije is benne van, csak a bithumenet nezzuk.
    '''
    found = {}
    ours = lambda chunk: 'bithumen' in chunk or 'bithumen' not in text
    for block in re.findall(r'\{[^{}]*\}', text):
        name = re.search(r'"name"\s*:\s*"([^"]*)"', block)
        value = re.search(r'"value"\s*:\s*"([^"]*)"', block)
        if name and value and ours(block):
            found.setdefault(name.group(1), value.group(1))
    for line in text.splitlines():
        cells = line.strip().split('\t')
        if len(cells) >= 7 and ours(cells[0]):
            found.setdefault(cells[5].strip(), cells[6].strip())
    for name, value in re.findall(r'(?:^|[;\s,])([A-Za-z_]\w*)=([^;\s,]*)', text):
        found.setdefault(name, value)
    return found


def parse_cookie(uid, secret):
    text = u'%s; %s' % (uid or u'', secret or u'')
    structured = lambda value: bool(re.search(r'[=\t"]', value or u''))
    if structured(text):
        found = _cookie_values(text)
        uid = found.get('uid') or (uid if not structured(uid) else '')
        secret = found.get('pass') or (secret if not structured(secret) else '')
    uid = re.sub(r'\D', '', uid or '')
    secret = re.sub(r'[^0-9a-fA-F]', '', secret or '').lower()
    return uid, secret


# A suti a TV Letoltesek mappajabol is jöhet (hogy ne kelljen a TV-n gepelni):
# a fajlban a suti-sor ("uid=...; pass=...", a teljes is jo). Beolvasas utan
# beallitasba kerul, a bithumen bekapcsol, a fajl torlodik.
IMPORT_FILES = (
    '/storage/emulated/0/Download/netmozi-bithumen.txt',
    '/sdcard/Download/netmozi-bithumen.txt',
)


def import_from_downloads(paths=None):
    '''
    A Letoltesekbe tett suti beolvasasa. True, ha talalt ervenyeset (es
    beallitotta). A fajlt torli (ha a rendszer engedi), hogy a titok ne
    maradjon a kozos mappaban.
    '''
    for path in paths or IMPORT_FILES:
        try:
            with open(path, encoding='utf-8', errors='replace') as handle:
                text = handle.read()
        except (IOError, OSError):
            continue
        uid, secret = parse_cookie('', text)
        if not (uid and len(secret) == 32):
            control.log(u'bithumen: a Letöltésekben levő fájlban nincs érvényes süti (uid, pass)', control.LOGWARNING)
            continue
        control.setSetting('bhuid', uid)
        control.setSetting('bhpass', secret)
        control.setSetting('bithumen', 'true')
        forget()
        try:
            os.remove(path)
            control.log(u'bithumen: a süti beolvasva a Letöltésekből (a fájl törölve)')
        except OSError:
            control.log(u'bithumen: a süti beolvasva a Letöltésekből -- a fájlt töröld kézzel', control.LOGWARNING)
        return True
    return False


def enabled():
    try:
        if control.setting('bithumen') != 'true':
            return False
    except Exception:
        return False
    uid, secret = credentials()
    return bool(uid and secret)


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'bithumen adatok írása', exc)
        return False


def forget():
    save({})


# --- HTTP -------------------------------------------------------------------------

def _cookies():
    uid, secret = credentials()
    return {'uid': uid, 'pass': secret}


def _get(url, params=None, cookies=None, binary=False):
    '''(statusz, tartalom) -- a tartalom szoveg (ISO-8859-2) vagy bajt; (None, '') hibanal.'''
    import requests
    try:
        response = requests.get(url, params=params, headers=HEADERS, cookies=cookies or {},
                                timeout=TIMEOUT, allow_redirects=False)
    except Exception as exc:
        control.log_exception(u'bithumen kérés', exc)
        return None, b'' if binary else ''
    if binary:
        return response.status_code, response.content
    return response.status_code, response.content.decode(ENCODING, 'replace')


def logged_out(status, html):
    '''Kileptetett-e az oldal (atiranyitas a belepesre, vagy a belepo urlap).'''
    return status in (301, 302, 303) or any(marker in (html or '') for marker in LOGIN_MARKERS)


# --- Kereses ----------------------------------------------------------------------

_TABLE_RE = re.compile(r'<table[^>]*id="?torrenttable"?[^>]*>(.*?)</table>\s*(?:<p|<div|<table|$)', re.S | re.I)
_ROW_RE = re.compile(r'<tr[^>]*>(.*?)</tr>', re.S | re.I)
_CELL_RE = re.compile(r'<td[^>]*>(.*?)</td>', re.S | re.I)
_LINK_RE = re.compile(r'''<a\s+href=["']?details\.php\?id=(\d+)["']?([^>]*)>(.*?)</a>''', re.S | re.I)
_TITLE_ATTR_RE = re.compile(r'''title=(["'])(.*?)\1''', re.S)
_SIZE_RE = re.compile(r'([\d.,]+)\s*([KMGT]i?B)', re.I)
_CATEGORY_RE = re.compile(r'''alt=["']([^"']+)["']''')
_PAGE_RE = re.compile(r'browse\.php\?[^"\']*?page=(\d+)')


def _text(fragment):
    from resources.lib.modules import client
    return re.sub(r'\s+', ' ', client.replaceHTMLCodes(re.sub(r'<[^>]+>', ' ', fragment or ''))).strip()


def _int(text):
    match = re.search(r'\d[\d,.]*', text or '')
    return int(re.sub(r'[,.]', '', match.group(0))) if match else 0


def parse_rows(html):
    '''A talalati lista sorai, a lap sorrendjeben.'''
    from resources.lib.modules import client
    match = _TABLE_RE.search(html or '')
    table = match.group(1) if match else (html or '')
    out = []
    for row in _ROW_RE.findall(table):
        link = _LINK_RE.search(row)
        if not link:
            continue                                     # fejlec
        cells = _CELL_RE.findall(row)
        if len(cells) < 9:
            continue
        category = _CATEGORY_RE.search(cells[0])
        imdb = re.search(r'imdb\.com/title/(tt\d+)', row)
        rating = re.search(r'\[\s*</b>\s*imdb:\s*([\d.]+)', row) or re.search(r'imdb:\s*([\d.]+)', row)
        hungarian = re.search(r'<span>([^<]+)</span>\s*<a[^>]+imdb\.com', row)
        # A teljes nev a title-ben (a szoveg csonkolt lehet); rovid nevnel nincs title.
        named = _TITLE_ATTR_RE.search(link.group(2))
        size = _SIZE_RE.search(_text(cells[5]))
        out.append({
            'id': link.group(1),
            'title': client.replaceHTMLCodes(named.group(2) if named else _text(link.group(3))).strip(),
            'category': category.group(1) if category else '',
            'imdb': imdb.group(1) if imdb else '',
            'rating': rating.group(1) if rating else '',
            'hu_title': client.replaceHTMLCodes(hungarian.group(1)).strip() if hungarian else '',
            'size': ('%s %s' % size.groups()) if size else _text(cells[5]),     # a "× 0.5" szorzo nelkul
            'seeders': _int(_text(cells[7])),
            'leechers': _int(_text(cells[8])),
            'uploaded': _text(cells[4])[:16],
        })
    return out


def last_page(html):
    '''A lapozo legnagyobb lapszama (0, ha egy lap van).'''
    numbers = [int(number) for number in _PAGE_RE.findall(html or '')]
    return max(numbers) if numbers else 0


def wanted(row, kind):
    '''A keresett fajtaba (film / sorozat) tartozik-e, es streamelheto-e.'''
    category = row.get('category') or ''
    if re.search(SKIP_CATEGORY_RE, category):
        return False
    if kind == 'series':
        return category.startswith('Sorozat')
    return category.startswith('Film')


def search(imdb, kind):
    '''
    Torrentek egy cimhez (az osszes lap, legfeljebb MAX_PAGES). None, ha
    nincs beallitva, lejart a suti, vagy halozati hiba; kulonben lista.
    '''
    if not imdb:
        return []
    cookies = _cookies()
    if not (cookies['uid'] and cookies['pass']):
        return None
    status, html = _get(BROWSE_URL, {'search': imdb}, cookies)
    if status is None:
        return None
    if logged_out(status, html):
        control.log(u'bithumen: a süti lejárt vagy rossz', control.LOGWARNING)
        _mark_expired()
        return None
    rows = parse_rows(html)
    pages = list(range(1, min(last_page(html), MAX_PAGES - 1) + 1))
    if pages:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=len(pages)) as pool:
            for status_n, html_n in pool.map(lambda page: _get(BROWSE_URL, {'search': imdb, 'page': page}, cookies),
                                             pages):
                if status_n == 200 and not logged_out(status_n, html_n):
                    rows.extend(parse_rows(html_n))
    seen, out = set(), []
    for row in rows:
        if row['id'] in seen or not wanted(row, kind):
            continue
        seen.add(row['id'])
        out.append(row)
    _clear_expired()
    control.log(u'bithumen: %d torrent (%s, %s)' % (len(out), imdb, kind))
    _learn_passkey(out or rows)
    return out


def _mark_expired():
    data = load()
    if not data.get('expired'):
        data['expired'] = int(time.time())
        save(data)


def _clear_expired():
    data = load()
    if data.get('expired'):
        data.pop('expired', None)
        save(data)


def expired():
    return bool(load().get('expired'))


# --- Passkey: a tracker-cimbol ------------------------------------------------------

def passkey_of(torrent):
    match = re.search(PASSKEY_RE.encode('ascii'), torrent or b'')
    return match.group(1).decode('ascii') if match else ''


def passkey():
    '''A tarolt passkey (a jelenlegi uid-hoz), vagy ''.'''
    data = load()
    uid = credentials()[0]
    return (data.get('passkey') or '') if data.get('uid') == uid else ''


def _learn_passkey(rows):
    '''Ha meg nincs passkey, egy torrent letoltesebol (a sutivel) kiolvassa.'''
    if passkey() or not rows:
        return passkey()
    status, torrent = _get(COOKIE_DOWNLOAD_URL % (rows[0]['id'], rows[0]['id']), cookies=_cookies(), binary=True)
    key = passkey_of(torrent) if status == 200 and torrent[:1] == b'd' else ''
    if key:
        data = load()
        data.update({'uid': credentials()[0], 'passkey': key, 'at': int(time.time())})
        save(data)
        control.log(u'bithumen: a passkey megvan')
    return key


# --- Forrasok a netmozi formajaban (mint az nCore) ------------------------------------

def language(row):
    from resources.lib.modules import ncore
    if '/Hun/' in (row.get('category') or '') or re.search(r'(?i)\bhun\b(?![\s._-]?sub)', row.get('title') or ''):
        return 'Szinkron'
    if re.search(ncore.HUNSUB_RE, row.get('title') or ''):
        return 'Felirat'
    return u'Külföldi'


def source_url(torrent_id, season=None, episode=None):
    url = PREFIX + str(torrent_id)
    if season is not None and episode is not None:
        url += '?s=%d&e=%d' % (int(season), int(episode))
    return url


def is_source(url):
    return (url or '').startswith(PREFIX)


def parse_source_url(url):
    '''(torrent id, evad, resz) -- az evad/resz None, ha nem pakk.'''
    rest = (url or '')[len(PREFIX):]
    torrent_id, _sep, query = rest.partition('?')
    match = re.match(r's=(\d+)&e=(\d+)$', query or '')
    if match:
        return torrent_id, int(match.group(1)), int(match.group(2))
    return torrent_id, None, None


def sources_for(imdb, kind='film', season=None, episode=None, rows=None):
    '''
    Forras-szotarak, mint az nCore-nal (ncore.sources_for). A 'ncore': True
    a "torrent" jelzo (a lista, a lejatszas es az elozmeny ebbol tudja, hogy
    Elementum kell); a 'tracker' mondja meg, honnan jott.
    '''
    from resources.lib.modules import ncore
    rows = search(imdb, kind) if rows is None else rows
    if not rows:
        return []
    out = []
    for row in rows:
        if not wanted(row, kind):
            continue                                 # lemezkep, vagy a masik fajta
        title = row.get('title') or ''
        pack = False
        if kind == 'series' and season is not None:
            found = ncore.covers(title, season, episode)
            if found is not None:
                if not found:
                    continue
            else:
                seasons = ncore.seasons_of(title)
                if seasons != ncore.ALL_SEASONS and int(season) not in seasons:
                    continue
                pack = True
        quality = ncore.grade(title)
        category = row.get('category') or ''
        res = ncore.resolution(title) or ('SD' if category.endswith('/SD') else '')
        nyelv = language(row)
        detail = u' '.join(part for part in (res, ncore.size_label(row.get('size')),
                                             u'%d seed' % row.get('seeders', 0)) if part)
        if pack:
            detail += u' | évadcsomag: csak ez a rész töltődik le'
        out.append({
            'index': 0,
            'label': u'[B]%s[/B] | [COLOR limegreen]%s[/COLOR] | [COLOR blue]%s[/COLOR] | %s' % (
                SITE, nyelv, quality, detail),
            'url': source_url(row['id'], season, episode) if pack else source_url(row['id']),
            'subtitled': False,
            'language': nyelv,
            'site': SITE,
            'quality': quality,
            'valid': row.get('seeders', 0) > 0,
            'seeders': row.get('seeders', 0),
            'size': row.get('size', ''),
            'resolution': res,
            'title': title,
            'ncore': True,
            'tracker': SITE,
        })
    out.sort(key=lambda item: -item['seeders'])
    return out


def season_availability(imdb, season, numbers, rows=None):
    '''{reszszam: True/False} egy evadra, egy keresesbol; None, ha nem ment.'''
    from resources.lib.modules import ncore
    rows = search(imdb, 'series') if rows is None else rows
    if rows is None:
        return None
    return ncore.season_availability(imdb, season, numbers, rows=rows)


# --- Lejatszas: Elementum ---------------------------------------------------------

def torrent_files(torrent):
    '''A .torrent fajljainak utvonalai (bencode, csak a "files"/"name" resz).'''
    try:
        info = _bdecode(torrent).get(b'info') or {}
    except Exception as exc:
        control.log_exception(u'bithumen torrent bontása', exc)
        return []
    name = (info.get(b'name') or b'').decode('utf-8', 'replace')
    if b'files' not in info:
        return [name] if name else []
    out = []
    for entry in info.get(b'files') or []:
        parts = [part.decode('utf-8', 'replace') for part in entry.get(b'path') or []]
        if parts:
            out.append('/'.join([name] + parts) if name else '/'.join(parts))
    return out


def _bdecode(data):
    '''Minimalis bencode-olvaso (dict / list / int / bajtsor).'''
    def parse(index):
        char = data[index:index + 1]
        if char == b'd':
            index += 1
            out = {}
            while data[index:index + 1] != b'e':
                key, index = parse(index)
                value, index = parse(index)
                out[key] = value
            return out, index + 1
        if char == b'l':
            index += 1
            out = []
            while data[index:index + 1] != b'e':
                value, index = parse(index)
                out.append(value)
            return out, index + 1
        if char == b'i':
            end = data.index(b'e', index)
            return int(data[index + 1:end]), end + 1
        colon = data.index(b':', index)
        length = int(data[index:colon])
        return data[colon + 1:colon + 1 + length], colon + 1 + length
    value, _end = parse(0)
    return value


def play_url(torrent_id, key, file_name='', position=0):
    '''Az Elementum lejatszo-URL-je (a passkey-es letolto linkkel, suti nelkul).'''
    from resources.lib.modules import ncore
    uri = quote(DOWNLOAD_URL % (key, torrent_id), safe='')
    url = ncore.ELEMENTUM_PLAY % (uri, int(position or 0))
    if file_name:
        pattern = r'(?i)(?:^|[\\/])' + re.escape(file_name) + r'$'
    else:
        pattern = ncore.SAMPLE_FILTER
    return url + '&file_match=' + quote(pattern, safe='')


def resolve(url, position=0, ask=False):
    '''
    bithumen:// forras -> Elementum URL. None, ha nincs Elementum, nincs
    passkey, vagy evadcsomagnal nem talaljuk a reszt (ask: a nezo valaszt).
    '''
    from resources.lib.modules import ncore
    if not ncore.elementum_installed():
        control.log(u'bithumen: az Elementum nincs telepítve', control.LOGWARNING)
        return None
    ncore.ensure_elementum_setup()
    torrent_id, season, episode = parse_source_url(url)
    key = passkey() or _learn_passkey([{'id': torrent_id}])
    if not key:
        control.log(u'bithumen: nincs passkey (a süti lejárt?)', control.LOGWARNING)
        return None
    file_name = ''
    if season is not None:
        status, torrent = _get(DOWNLOAD_URL % (key, torrent_id), binary=True)
        paths = torrent_files(torrent) if status == 200 else []
        file_name = ncore.pick_episode_file(paths, season, episode)
        if not file_name and ask:
            file_name = ncore.choose_file(paths, season, episode)
        if not file_name:
            control.log(u'bithumen: az évadcsomagban nincs meg a rész (%s)' % torrent_id, control.LOGWARNING)
            return None
        control.log(u'bithumen: évadcsomagból csak ez a fájl: %s' % file_name)
    return play_url(torrent_id, key, file_name, position)


# --- Beallitasok: proba -------------------------------------------------------------

TEST_IMDB = 'tt0133093'          # Matrix: biztosan van rola torrent


def test():
    '''(sorok a parbeszedablakba) -- belepes (suti), kereses, passkey.'''
    imported = import_from_downloads()
    uid, secret = credentials()
    if not uid or not secret:
        return [u'Előbb add meg a bithumen sütit (uid és pass) a beállításokban, vagy tedd a',
                u'Letöltések mappába netmozi-bithumen.txt néven, vagy írd be telefonról',
                u'(Beállítások / Bejelentkezés / Bevitel telefonról).']
    forget()
    rows = search(TEST_IMDB, 'film')
    if rows is None:
        return [u'Belépés: nem sikerült -- %s' % EXPIRED_TEXT if expired() else
                u'Belépés / keresés: nem sikerült (lásd a naplót).']
    lines = ([u'Süti: beolvasva a Letöltésekből'] if imported else []) + [
        u'Belépés (süti): rendben', u'Keresés (%s): %d torrent' % (TEST_IMDB, len(rows))]
    for row in rows[:3]:
        lines.append(u'  %s  (%d seed)' % (row['title'][:50], row['seeders']))
    lines.append(u'Passkey (a lejátszáshoz): %s' % (u'megvan' if passkey() else u'NINCS -- nem jött le a torrent'))
    return lines
