# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from xbmcvfs import translatePath


# --- Kodi API rovidítések ---------------------------------------------------

addon = xbmcaddon.Addon
addonInfo = xbmcaddon.Addon().getAddonInfo
lang = xbmcaddon.Addon().getLocalizedString


# A SZEMELYES beallitasok (hang, automatikus inditas, elozetes, intro,
# hozzaszolas, figyeles) a nevvel letrehozott profiloknal a profil sajat
# fajljaban elnek (settings.json a profil mappajaban); amig ott nincs
# ertek, a Kozos (a Kodi altalanos) beallitasa ervenyes. Az eszkozhoz
# kotott dolgok (belepes, kulcsok, nCore, elrendezes, Vissza=szunet)
# mindig kozosek.
PERSONAL_SETTINGS = ('preferlanguage', 'listlanguage', 'listlanguagelabel', 'hometrailer',
                     'trailerdelay', 'homebackdrop', 'autoplay', 'autoplaytimeout',
                     'autoplaymaxsources', 'autoplaynext', 'skipdeadepisode', 'episodeskipmax',
                     'introskip', 'commentoverlay', 'commentdelay', 'minquality', 'watchseries')
PROFILE_SETTINGS_FILE = 'settings.json'
_profile_settings_cache = {'path': None, 'stamp': None, 'data': {}}


def profileSettingsPath():
    return os.path.join(profileDir(), PROFILE_SETTINGS_FILE)


def profileSettings():
    '''{kulcs: ertek}: az aktiv, nevvel letrehozott profil sajat beallitasai ({} a Kozosnel).'''
    if not activeProfile():
        return {}
    import json
    path = profileSettingsPath()
    try:
        stamp = os.stat(path).st_mtime
    except OSError:
        return {}
    cache = _profile_settings_cache
    if cache['path'] == path and cache['stamp'] == stamp:
        return cache['data']
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        data = data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        data = {}
    cache.update(path=path, stamp=stamp, data=data)
    return data


def _writeProfileSettings(data):
    import json
    path = profileSettingsPath()
    makeFile(os.path.dirname(path))
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=1)
    _profile_settings_cache['path'] = None


# Egy Addon-peldany legfeljebb ennyi masodpercig szolgal ki olvasast. Minden
# uj peldany a teljes beallitasfat felepiti es lebontja: lejatszas kozben (a
# 32 bites TV-s Kodiban, ahol az Elementum is a folyamatban fut) ez a
# folytonos memoria-ki-be ket osszeomlast okozott (scudo: map hiba az Addon
# felszabaditasakor). Par masodperc kesleses a beallitas-valtozasnal nem szamit.
ADDON_TTL = 5.0
_addon_cache = {'addon': None, 'at': 0.0}


def _addon():
    now = time.time()
    if _addon_cache['addon'] is None or not 0 <= now - _addon_cache['at'] < ADDON_TTL:
        _addon_cache['addon'] = xbmcaddon.Addon()
        _addon_cache['at'] = now
    return _addon_cache['addon']


def setting(key):
    '''
    FRISS Addon-peldanyon at (legfeljebb ADDON_TTL mp-es): a Kodi a mar
    letrehozott peldanyba nem tolti be a kesobb elmentett beallitasokat, es a
    hosszan futo kezdokepernyonel (es a szolgaltatasnal) a valtozas kulonben
    csak ujrainditas utan latszott. A szemelyes kulcsoknal elobb az aktiv
    profil sajat erteke.
    '''
    if key in PERSONAL_SETTINGS:
        own = profileSettings()
        if key in own:
            return own[key]
    try:
        return _addon().getSetting(key)
    except RuntimeError:
        _addon_cache['addon'] = None
        # Frissites kozben a Kodi egy pillanatra nem ismeri a bovitmenyt
        # ("Unknown addon id"): a futo kezdokepernyo ne haljon bele.
        return ''


def settingBool(key):
    return (setting(key) or '').strip().lower() == 'true'


def setSetting(key, value):
    '''Friss peldanyon at; a szemelyes kulcsok nevvel letrehozott profilnal a profil fajljaba.'''
    if key in PERSONAL_SETTINGS and activeProfile():
        data = dict(profileSettings())
        data[key] = value
        try:
            _writeProfileSettings(data)
            return True
        except (IOError, OSError, TypeError, ValueError) as exc:
            log_exception(u'profil beállítás írása', exc)
            return False
    try:
        return _addon().setSetting(key, value)
    except RuntimeError:
        _addon_cache['addon'] = None
        return False


# --- A csomagba sutott kulcsok (TMDB, Movie of the Night) -------------------
#
# A kulcsot taviranyitoval begepelni kin -- ezert a kiadott ZIP-be
# belekerulhet egy resources/keys.json (a build.py teszi bele a helyi,
# gitbe NEM kerulo tools/keys.json-bol). A sorrend: a Kodi beallitasa, majd
# a Letoltesek mappaban levo fajl, vegul ez. Igy aki maga ir be kulcsot,
# annak az ervenyes.

KEYS_FILE = 'keys.json'
# A csomagba tett kulcs ELFEDVE all a fajlban (XOR + base64). Ez nem
# titkositas -- aki keresi, megtalalja --, de a kulcsokra vadaszo
# automatak (amik sima 32 jegyu hexat keresnek) nem akadnak rajta.
KEYS_SALT = 'netmozi'
_bundled_keys = {'loaded': False, 'data': {}}


def _unmask(text):
    import base64
    try:
        raw = base64.b64decode((text or '').encode('ascii'))
    except Exception:
        return ''
    salt = KEYS_SALT.encode('ascii')
    return ''.join(chr(byte ^ salt[index % len(salt)]) for index, byte in enumerate(raw))


def maskKey(text):
    '''A build.py hasznalja: a kulcs elfedett alakja.'''
    import base64
    salt = KEYS_SALT.encode('ascii')
    raw = bytes((ord(ch) ^ salt[index % len(salt)]) for index, ch in enumerate(text or ''))
    return base64.b64encode(raw).decode('ascii')


def keyProxy():
    '''A kulcs-kozvetito Worker cime (rejtett beallitas; a settings.xml-ben az alapertek), vagy ''.'''
    try:
        return (setting('keyproxy') or '').strip().rstrip('/')
    except Exception:
        return ''


def keyAccess():
    '''
    Amivel a kulcs-kozvetito Workert hivhatjuk: a TV-n beirt titkos PIN (a
    Worker ellenorzi, a programban nincs benne a helyes ertek); atmenetileg a
    regi belepojel. '' ha nincs.
    '''
    try:
        pin = (setting('keypin') or '').strip()
    except Exception:
        pin = ''
    from resources.lib.modules import config
    return pin or config.KEY_PROXY_TOKEN


# Ha a Worker nem enged be (rossz PIN), nem ostromoljuk: minden hivas 1,5 mp
# kesleltetett 404 lenne, a hatterszalak percekig ezen porognenek. Ennyi
# ideig (vagy amig a PIN nem valtozik) nem is probaljuk -- a Window(10000)
# tulajdonsagon at a szolgaltatas es a bovitmeny is latja.
PROXY_DENIED_PROPERTY = 'netmozi.proxydenied'
PROXY_DENIED_PAUSE = 1800
PROXY_DENIED_TEXT = u'A titkos PIN nem jó -- Beállítások / Bejelentkezés / Titkos PIN'


def _accessMark(access):
    import hashlib
    return hashlib.sha1((access or '').encode('utf-8')).hexdigest()[:10]


def proxyRejected(status, text):
    '''A Worker valasza "nem engedlek be": 404 sima "Not found" szoveggel (a szolgaltato 404-e JSON).'''
    return str(status) == '404' and (text or '').strip() == 'Not found'


def proxyDenied(now=None):
    '''A Worker nemreg elutasitotta a mostani PIN-t (es azota nem irtak be masikat).'''
    try:
        until, mark = xbmcgui.Window(10000).getProperty(PROXY_DENIED_PROPERTY).split('|', 1)
        return float(until) > (now or time.time()) and mark == _accessMark(keyAccess())
    except (ValueError, TypeError, AttributeError):
        return False


def markProxyDenied(now=None):
    '''A Worker elutasitott: szunet, es egyszer szolunk (a naploba es a kepernyore).'''
    if proxyDenied(now):
        return
    try:
        xbmcgui.Window(10000).setProperty(PROXY_DENIED_PROPERTY, '%d|%s' % (
            (now or time.time()) + PROXY_DENIED_PAUSE, _accessMark(keyAccess())))
    except Exception:
        pass
    log(u'Kulcs-közvetítő: a PIN nem jó, %d percig nem próbáljuk' % (PROXY_DENIED_PAUSE // 60), LOGWARNING)
    infoDialog(PROXY_DENIED_TEXT, time=8000)


def proxyUsable():
    '''Hivhato-e a kulcs-kozvetito: van cime, van mivel belepni, es nem utasitott el nemreg.'''
    return bool(keyProxy() and keyAccess()) and not proxyDenied()


def checkPin(pin=None):
    '''
    A beirt titkos PIN jo-e: a Worker (nem a program) donti el. (True/False,
    uzenet). A regi, atmeneti belepojelet itt NEM hasznaljuk -- csak a PIN-t.
    '''
    from resources.lib.modules import client
    if pin is None:
        pin = (setting('keypin') or '').strip()
    if not keyProxy():
        return False, u'Nincs beállítva a közvetítő.'
    if not pin:
        return False, u'Még nincs beírva PIN (Beállítások / Bejelentkezés / Titkos PIN).'
    response = client.request(keyProxy() + '/tmdb/3/configuration', headers={'X-NM': pin},
                              output='response', timeout=20)
    if not response:
        return False, u'A közvetítő most nem érhető el (van internet?). Próbáld újra később.'
    status = str(response[0])
    if status == '200':
        try:
            xbmcgui.Window(10000).clearProperty(PROXY_DENIED_PROPERTY)     # nem varunk a szunet vegere
        except Exception:
            pass
        return True, u'A PIN jó: a TMDB-adatok, a feliratok és a streaming-listák ezzel működnek.'
    if status == '404':
        return False, u'A PIN nem jó. Figyelj a kis- és nagybetűkre, és írd be újra.'
    return False, u'Váratlan válasz (%s). Próbáld újra később.' % status


def bundledKeys():
    if _bundled_keys['loaded']:
        return _bundled_keys['data']
    import json
    data = {}
    try:
        path = os.path.join(addonPath, 'resources', KEYS_FILE)
        with open(path, encoding='utf-8') as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            # Elfedett alak ({"k": {...}}) vagy sima {kulcs: ertek}.
            masked = loaded.get('k') if isinstance(loaded.get('k'), dict) else None
            data = dict((name, _unmask(value)) for name, value in masked.items()) if masked else loaded
    except (IOError, OSError, ValueError):
        data = {}
    _bundled_keys.update(loaded=True, data=data)
    return data


def bundledKey(name):
    return (bundledKeys().get(name) or '').strip()


def addonKnown():
    '''Ismeri-e a Kodi most a bovitmenyt (frissites kozben egy pillanatra nem).'''
    try:
        xbmcaddon.Addon()
        return True
    except RuntimeError:
        return False

def addonInstalled(addon_id):
    '''Telepitve (es engedelyezve) van-e egy masik bovitmeny (pl. az adaptiv lejatszo)?'''
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except RuntimeError:
        return False


addItem = xbmcplugin.addDirectoryItem
directory = xbmcplugin.endOfDirectory
content = xbmcplugin.setContent
resolve = xbmcplugin.setResolvedUrl
item = xbmcgui.ListItem

keyboard = xbmc.Keyboard
condVisibility = xbmc.getCondVisibility
jsonrpc = xbmc.executeJSONRPC
execute = xbmc.executebuiltin
sleep = xbmc.sleep

openFile = xbmcvfs.File
# mkdirs: a profilok mappaja beagyazott (profiles/<nev>/), a mkdir csak egy szintet hozna letre.
makeFile = xbmcvfs.mkdirs
deleteFile = xbmcvfs.delete
listDir = xbmcvfs.listdir
transPath = translatePath


# --- Utvonalak --------------------------------------------------------------

addonPath = translatePath(addonInfo('path'))
dataPath = translatePath(addonInfo('profile'))

# --- Profilok ("Ki nez?") -----------------------------------------------------
#
# A SZEMELYES adatok (elozmeny, folytatas, figyelt lista, tanult introk)
# profilonkent kulon mappaban elnek. A nevtelen "Kozos" profil a gyoker:
# ami eddig volt, az marad ott. Az aktiv profil neve egy kis fajlban van;
# minden olvasas ezt nezi, hogy a plugin es a szolgaltatas (kulon
# folyamatok) ugyanazt lassak.

PROFILE_FILE = 'profile.json'
PROFILES_DIR = 'profiles'


def _profile_state():
    import json
    try:
        with open(os.path.join(dataPath, PROFILE_FILE), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def profileSlug(name):
    """Mappanev egy profilnevbol: csak betu/szam/kotojel."""
    import re as _re
    import unicodedata
    text = unicodedata.normalize('NFKD', name or '')
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    return _re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')[:40]


def activeProfile():
    """Az aktiv profil neve, vagy '' (Kozos)."""
    return (_profile_state().get('active') or '').strip()


def profileDir():
    """Ahova a szemelyes adatok kerulnek."""
    name = activeProfile()
    if not name:
        return dataPath
    return os.path.join(dataPath, PROFILES_DIR, profileSlug(name) or 'profil')
cacheFile = os.path.join(dataPath, 'cache.db')


# --- Naplozas ---------------------------------------------------------------

LOGDEBUG = xbmc.LOGDEBUG
LOGINFO = xbmc.LOGINFO
LOGWARNING = xbmc.LOGWARNING
LOGERROR = xbmc.LOGERROR

ADDON_NAME = 'NetMozi'


def log(message, level=LOGINFO):
    '''Egysegesen prefixelt Kodi-log, hogy a naploban kereshetok legyunk. API-kulcs nem kerul bele.'''
    try:
        import re
        text = re.sub(r'(?i)(api_key=)[^&\s]+', r'\1***', u'%s' % message)
        xbmc.log('%s: %s' % (ADDON_NAME, text), level)
    except Exception:
        pass


def log_error(message):
    log(message, LOGERROR)


class timed(object):
    '''
    Egy lépés időtartamának naplózása.

    Lassú indulásnál ebből derül ki, MELYIK szakasz viszi az időt -- a
    bővítményé vagy a Kodié.

        with control.timed(u'felirat letöltés'):
            ...
    '''

    def __init__(self, label):
        self.label = label
        self.started = 0.0

    def __enter__(self):
        self.started = time.time()
        return self

    def __exit__(self, *exc_info):
        log(u'[idő] %s: %.1f mp' % (self.label, time.time() - self.started))
        return False


def log_exception(context, exc):
    '''Kivetel naplozasa a hivas kontextusaval egyutt.'''
    log('%s -- %s: %s' % (context, type(exc).__name__, exc), LOGERROR)


# --- Dialogusok -------------------------------------------------------------

def addonIcon():
    try:
        return os.path.join(addonInfo('path'), 'icon.png')
    except Exception:
        return ''


def infoDialog(message, heading=ADDON_NAME, icon='', time=3000):
    if icon == '':
        icon = addonIcon()
    try:
        xbmcgui.Dialog().notification(heading, message, icon, time, sound=False)
    except Exception:
        execute('Notification(%s,%s, %s, %s)' % (heading, message, time, icon))


def errorDialog(message, heading=ADDON_NAME):
    '''Hibajelzes a felhasznalonak + naplobejegyzes.'''
    log_error(message)
    try:
        xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception:
        pass


def okDialog(message, heading=ADDON_NAME):
    return xbmcgui.Dialog().ok(heading, message)


def yesnoDialog(heading=ADDON_NAME, message='', nolabel='', yeslabel=''):
    return xbmcgui.Dialog().yesno(heading, message, nolabel, yeslabel)


def selectDialog(items, heading=ADDON_NAME):
    return xbmcgui.Dialog().select(heading, items)


def idle():
    return execute('Dialog.Close(busydialog)')


def busy():
    return execute('ActivateWindow(busydialog)')


def refresh():
    return execute('Container.Refresh')


def openSettings(id=None):
    try:
        idle()
        execute('Addon.OpenSettings(%s)' % (id or addonInfo('id')))
    except Exception:
        return


# --- Hibakeresesi naplo kimasolasa ------------------------------------------
#
# Android 11 ota a Kodi mappajaba az ADB nem lat bele. A bovitmeny viszont
# el tudja erni a sajat naplojat (special://logpath), es ki tudja masolni egy
# nyilvanos mappaba (Letoltesek), ahonnan hibakereseskor kiolvashato.

DEBUG_LOG_TARGETS = (
    '/storage/emulated/0/Download/netmozi-kodi.log',
    '/sdcard/Download/netmozi-kodi.log',
)


def exportLog():
    """A kodi.log masolata a Letoltesek mappaba. A celt adja vissza, vagy ''."""
    source = translatePath('special://logpath/kodi.log')
    previous = translatePath('special://logpath/kodi.old.log')
    for target in DEBUG_LOG_TARGETS:
        try:
            folder = os.path.dirname(target)
            if not os.path.isdir(folder):
                continue
            if xbmcvfs.copy(source, target):
                # Melle az elozo futas naploja is (-old): egy kifagyas utan az mondja meg, mi tortent.
                try:
                    if os.path.exists(previous):
                        xbmcvfs.copy(previous, target.replace('.log', '-old.log'))
                except Exception as exc:
                    log_exception(u'előző napló kimásolása', exc)
                return target
        except Exception as exc:
            log_exception(u'napló kimásolása (%s)' % target, exc)
    return ''


# Hibakereseshez: a sajat lista, az elozmenyek es a TMDB-adatok EGY zipben a
# Letoltesek mappaba (az ADB a Kodi mappajaba nem lat bele). CSAK ezek a
# fajlok: beallitas (jelszo), kulcs soha nem kerul bele.
DATA_EXPORT_FILES = ('watchlist.json', 'watched.json', 'watching.json', 'progress.json',
                     'tmdb.json', 'covers.json', 'profile.json', 'marked.json', 'taste.json')
DATA_EXPORT_NAME = 'netmozi-adatok.zip'     # a valodi nev idobelyeges: netmozi-adatok-20260925-2107.zip
DATA_EXPORT_KEEP = 5


def exportData(folders=None):
    '''A hibakeresesi adatok zipje a Letoltesek mappaba. A celt adja vissza, vagy ''.'''
    import zipfile
    folders = folders or [os.path.dirname(target) for target in DEBUG_LOG_TARGETS]
    sources = []
    for root, _dirs, files in os.walk(dataPath):
        for name in files:
            if name in DATA_EXPORT_FILES:
                full = os.path.join(root, name)
                sources.append((full, os.path.relpath(full, dataPath)))
    for folder in folders:
        try:
            if not os.path.isdir(folder):
                continue
            # idobelyeges nev: a korabbi mentes nem irodik felul; az utolso DATA_EXPORT_KEEP marad
            target = os.path.join(folder, DATA_EXPORT_NAME.replace('.zip', time.strftime('-%Y%m%d-%H%M%S.zip')))
            old = sorted(name for name in os.listdir(folder)
                         if name.startswith(DATA_EXPORT_NAME[:-4]) and name.endswith('.zip'))
            for name in old[:max(0, len(old) - (DATA_EXPORT_KEEP - 1))]:
                try:
                    os.remove(os.path.join(folder, name))
                except OSError:
                    pass
            with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
                archive.writestr('info.txt', u'%s %s\n%s\n' % (
                    addonInfo('id'), addonInfo('version'), time.strftime('%Y-%m-%d %H:%M:%S')))
                for full, rel in sources:
                    archive.write(full, rel)
            return target
        except Exception as exc:
            log_exception(u'adatok kimásolása (%s)' % folder, exc)
    return ''