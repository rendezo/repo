# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Megtekintési előzmények: mit néztünk, és MELYIK forrás vált be.
#
# A NETMOZI adatlap útvonalát tároljuk, nem a feloldott stream URL-jét: az
# előbbi állandó, az utóbbi tokenes és néhány óra múlva lejár. Emellett
# megjegyezzük, melyik forrás (host) működött -- újranézéskor a bővítmény
# azzal kezdi a próbálkozást, így elsőre elindul.
#
# A lejátszás két lépésben történik (adatlap megnyitása, majd forrás
# indítása), és ezek külön plugin-hívások -- külön folyamatban. Ezért az
# adatlap adatait előbb "kontextusként" lerakjuk, és sikeres indításkor
# abból áll össze az előzmény-bejegyzés.

import json
import os
import time

from resources.lib.modules import control, pageurl

HISTORY_FILE = 'watched.json'
CONTEXT_FILE = 'watching.json'

# Ennél több bejegyzést nem tartunk; a lista tetején a legfrissebb.
MAX_ENTRIES = 200


def _path(name):
    return os.path.join(control.profileDir(), name)


def _read(name, default):
    try:
        with open(_path(name), encoding='utf-8') as handle:
            return json.load(handle)
    except (IOError, OSError, ValueError):
        return default


def _write(name, data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(name), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'előzmény írása (%s)' % name, exc)
        return False


# --- Kontextus: melyik adatlapról indul a lejátszás ------------------------

def set_context(page, details, episode_label=''):
    '''Az éppen megnyitott adatlap adatai, sikeres indítás esetére.'''
    details = details or {}
    _write(CONTEXT_FILE, {
        'page': pageurl.canonical(page),
        'title': details.get('title', ''),
        'thumb': details.get('thumb', ''),
        'plot': details.get('plot', ''),
        'duration': details.get('duration', 0),
        'episode_label': episode_label,
        # Mikor allitottuk be: a hatterszolgaltatas ebbol tudja, hogy egy
        # eppen indulo lejatszas ehhez az adatlaphoz tartozik-e.
        'set': int(time.time()),
    })
    # A sajat lejatszasvezerlo (osd.py) ebbol tudja, hogy a kovetkezo video
    # a mienk. A szolgaltatas a lejatszas vegen torli.
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty('netmozi.playing', '1')
        # Film indul: ami most jatszik / jatszani fog, az NEM elozetes. (Ha a
        # kezdokepernyo elozetese epp elindult, a film azt valtja -- a jelzoje
        # nem maradhat bent, kulonben nincs folytatas-koveto.)
        from resources.lib.modules import config
        xbmcgui.Window(10000).clearProperty(config.TRAILER_PROPERTY)
    except Exception:
        pass


def get_context():
    context = _read(CONTEXT_FILE, {})
    if isinstance(context, dict) and context.get('page'):
        context['page'] = pageurl.canonical(context['page'])
    return context


def clear_context():
    '''Olyan lejatszas elott, ami NEM netmozi adatlaphoz tartozik.'''
    _write(CONTEXT_FILE, {})


# --- Előzmények -------------------------------------------------------------

def load():
    '''Bejegyzések, legfrissebb elöl.'''
    entries = _read(HISTORY_FILE, [])
    if not isinstance(entries, list):
        return []
    # A regi (valtozo cimu) utvonalak az allando alakra; ugyanabbol a
    # tetelbol a legfrissebb (elol levo) marad.
    out, seen = [], set()
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        entry = dict(entry)
        for field in ('key', 'page'):
            if entry.get(field):
                entry[field] = pageurl.canonical(entry[field])
        if entry.get('key') in seen:
            continue
        seen.add(entry.get('key'))
        out.append(entry)
    return out


def find(key):
    key = pageurl.canonical(key)
    for entry in load():
        if entry.get('key') == key:
            return entry
    return None


def add(site='', quality='', language='', torrent=''):
    '''
    Sikeres lejátszás rögzítése az utoljára megnyitott adatlap alapján.

    Ugyanaz a tétel nem duplikálódik: felkerül a lista tetejére, és a
    bevált forrás neve a legutóbbira frissül.
    '''
    context = get_context()
    page = context.get('page')
    if not page:
        control.log(u'Előzmény kihagyva: nincs adatlap kontextus', control.LOGDEBUG)
        return False

    entry = {
        'key': page,
        'title': context.get('title', ''),
        'episode_label': context.get('episode_label', ''),
        # A netmozi adatlap útvonala -- ez nem jár le.
        'page': page,
        # Ez a forrás vált be legutóbb; újranézéskor ezzel kezdünk.
        'site': site,
        # ...és milyen volt: a lista ebből mutatja a minőséget.
        'quality': quality or '',
        'language': language or '',
        # nCore-rol nezve: melyik torrent (ujranezeskor azzal kezdunk).
        'torrent': torrent or '',
        'thumb': context.get('thumb', ''),
        'plot': context.get('plot', ''),
        'duration': context.get('duration', 0),
        'time': int(time.time()),
    }
    entries = [item for item in load() if item.get('key') != page]
    entries.insert(0, entry)
    del entries[MAX_ENTRIES:]
    control.log(u'Előzményhez adva: %s (%s)' % (entry['title'], site))
    return _write(HISTORY_FILE, entries)


def remove(key):
    key = pageurl.canonical(key)
    entries = load()
    remaining = [item for item in entries if item.get('key') != key]
    if len(remaining) == len(entries):
        return False
    return _write(HISTORY_FILE, remaining)


def clear():
    return _write(HISTORY_FILE, [])


def remembered(page):
    '''
    (forras, torrent): ami ennel a filmnel -- sorozatnal a sorozat barmelyik
    reszenel -- legutobb bevalt. ('', '') ha nincs. A torrent az nCore-
    torrent azonositoja; evadpakknal a tobbi reszhez is ugyanaz.
    '''
    from resources.lib.modules import progress
    page = pageurl.canonical(page or '')
    parts = progress.split_page(page)
    base = parts[0] + '/' if parts else None
    for entry in load():
        other = entry.get('page') or ''
        if other == page or (base and other.startswith(base)):
            return entry.get('site') or '', entry.get('torrent') or ''
    return '', ''


def site_for_series(base):
    """
    A sorozathoz legutóbb bevált forrás neve.

    A következő rész feloldásakor ezzel kezdünk: ugyanannál a sorozatnál
    jó eséllyel ugyanaz a host működik, így elsőre elindul -- és a Kodi
    nem vár feleslegesen.
    """
    if not base:
        return ''
    base = pageurl.canonical(base)
    for entry in load():
        page = entry.get('page') or ''
        if page.startswith(base) and entry.get('site'):
            return entry['site']
    return ''
