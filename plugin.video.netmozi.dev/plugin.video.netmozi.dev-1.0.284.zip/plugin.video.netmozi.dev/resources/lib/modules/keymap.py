# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A bovitmeny sajat billentyu-kiosztasa (special://profile/keymaps/netmozi.xml),
# a lejatszas alatti (FullscreenVideo) gombokra. Ket dolog kerulhet bele:
#
#   - a hozzaszolas-gomb (sarga / Y, vagy betanitott kod) -> RunPlugin(comments);
#   - a Vissza gomb lejatszas kozben: a Kodi alapbol a menube lep, a film a
#     hatterben megy tovabb ("Fullscreen" muvelet) -- ez egy idos nezonek
#     csapda (a menu ott all, a film szol, nem tudja, mit nyomjon). Ezert
#     alapbol SZUNET, hosszan nyomva leallitas; a beallitassal (backstop)
#     rovid nyomasra is leallitas. Az Android
#     TV taviranyito Vissza gombja a Kodiban "backspace" (es "browser_back"),
#     az Esc es a remote "back" is le van fedve.
#
#   - "sajat vezerlo": lejatszas kozben az OK gomb a bovitmeny sajat
#     lejatszasvezerlojet nyitja (osd.py) a Kodi vezerlosavja helyett; ha
#     a video nem a mienk, az osd.py a Kodi sajatjat hivja (Action(OSD)).
#
# A fajlt mindig egyben irjuk ujra, a masik kotes megtartasaval; a
# szolgaltatas percenkent osszeveti a beallitassal (sync).

import os
import re

from resources.lib.modules import control


FILE = 'netmozi.xml'
BACK_MARKER = 'netmozi-backpause'
BACK_STOP_MARKER = 'netmozi-backstop'
OSD_MARKER = 'netmozi-osd'
# A kezdokepernyon (a sajat ablak: a Kodi a Python-ablakoknak 13000-tol ad
# azonositot) a Vissza roviden NEM lep ki a bovitmenybol -- csak hosszan
# nyomva. A hosszu nyomas a PreviousMenu muveletet adja (a rovid a Back),
# a homewindow ebbol tudja, melyik volt. A telefonos elrendezes ezt nem
# hasznalja (ott a rovid Vissza kilep, mint eddig).
HOME_MARKER = 'netmozi-home-longpress'
HOME_WINDOW_IDS = (13000, 13001, 13002, 13003)
COMMENT_RE = r'RunPlugin\([^)]*action=comments\)'
CODE_RE = r'<key id="(\d+)">[^<]*action=comments'


def folder():
    return control.transPath('special://profile/keymaps/')


def path():
    return os.path.join(folder(), FILE)


def read():
    try:
        with open(path(), encoding='utf-8') as handle:
            return handle.read()
    except (IOError, OSError):
        return ''


def comment_code(text):
    '''A hozzaszolas-gomb a fajlban: None (nincs), '' (sarga/Y), vagy a kod.'''
    if not re.search(COMMENT_RE, text or ''):
        return None
    match = re.search(CODE_RE, text)
    return match.group(1) if match else ''


def has_back_pause(text):
    return BACK_MARKER in (text or '')


def has_own_osd(text):
    return OSD_MARKER in (text or '')


def own_osd_wanted():
    '''Alapbol be (a beallitas "false"-ra kapcsolhato ki).'''
    try:
        return control.setting('ownosd') != 'false'
    except Exception:
        return True


def has_home_longpress(text):
    return HOME_MARKER in (text or '')


def home_sections():
    '''A kezdokepernyo ablakainak szakaszai: hosszu Vissza = PreviousMenu (kilepes).'''
    lines = [u'  <!-- %s: a kezdokepernyon a Vissza csak hosszan nyomva lep ki -->' % HOME_MARKER]
    for window_id in HOME_WINDOW_IDS:
        lines += [u'  <window%d>' % window_id,
                  u'    <remote>', u'      <back mod="longpress">PreviousMenu</back>', u'    </remote>',
                  u'    <keyboard>']
        for key in ('backspace', 'browser_back', 'escape'):
            lines.append(u'      <%s mod="longpress">PreviousMenu</%s>' % (key, key))
        lines += [u'    </keyboard>', u'  </window%d>' % window_id]
    return lines


def back_pause_wanted():
    '''Alapbol szunet (uj beallitas, "backstop": igy mindenhol ez az alap, a regi ertektol fuggetlenul).'''
    try:
        return control.setting('backstop') != 'true'
    except Exception:
        return True


def build(comment, back_pause, addon_url, own_osd=False):
    '''A keymap szovege (a kezdokepernyo hosszu-Vissza szakaszai mindig benne vannak).'''
    keyboard = []
    remote = []
    if own_osd:
        run = 'RunPlugin(%s?action=osd)' % addon_url
        keyboard.append(u'      <!-- %s: OK = a sajat lejatszasvezerlo -->' % OSD_MARKER)
        for key in ('return', 'enter', 'kp_enter'):
            keyboard.append(u'      <%s>%s</%s>' % (key, run, key))
        remote.append(u'      <select>%s</select>' % run)
        # jobbra / balra: a sajat tekeres (+/-1 perc, a gyors nyomasok osszeadodnak)
        for key, step in (('right', '1'), ('left', '-1')):
            seek_run = 'RunPlugin(%s?action=osdseek&amp;step=%s)' % (addon_url, step)
            keyboard.append(u'      <%s>%s</%s>' % (key, seek_run, key))
            remote.append(u'      <%s>%s</%s>' % (key, seek_run, key))
    if comment is not None:
        run = 'RunPlugin(%s?action=comments)' % addon_url
        if comment:
            keyboard.append(u'      <key id="%s">%s</key>' % (comment, run))
        else:
            keyboard.append(u'      <y>%s</y>' % run)
            remote.append(u'      <yellow>%s</yellow>' % run)
    if back_pause:
        keyboard.append(u'      <!-- %s: Vissza = szunet, hosszan = leallitas -->' % BACK_MARKER)
        for key in ('backspace', 'browser_back', 'escape'):
            keyboard.append(u'      <%s>Pause</%s>' % (key, key))
            keyboard.append(u'      <%s mod="longpress">Stop</%s>' % (key, key))
        remote.append(u'      <back>Pause</back>')
        remote.append(u'      <back mod="longpress">Stop</back>')
    else:
        keyboard.append(u'      <!-- %s: Vissza = leallitas (nem a menu, mogotte a filmmel) -->' % BACK_STOP_MARKER)
        for key in ('backspace', 'browser_back', 'escape'):
            keyboard.append(u'      <%s>Stop</%s>' % (key, key))
        remote.append(u'      <back>Stop</back>')
    lines = [u'<?xml version="1.0" encoding="UTF-8"?>',
             u'<!-- A netmozi bővítmény írta. Törölhető, ha nem kell. -->',
             u'<keymap>']
    if keyboard or remote:
        lines.append(u'  <FullscreenVideo>')
        if remote:
            lines += [u'    <remote>'] + remote + [u'    </remote>']
        lines += [u'    <keyboard>'] + keyboard + [u'    </keyboard>', u'  </FullscreenVideo>']
    lines += home_sections() + [u'</keymap>', u'']
    return u'\n'.join(lines)


def write(comment, back_pause, addon_url=None, own_osd=None):
    '''Kiirja (vagy torli, ha ures) es ujratolteti. True, ha sikerult.'''
    if addon_url is None:
        addon_url = 'plugin://%s/' % control.addonInfo('id')
    if own_osd is None:
        own_osd = own_osd_wanted()
    text = build(comment, back_pause, addon_url, own_osd)
    target = path()
    try:
        if not text:
            if os.path.exists(target):
                os.remove(target)
        else:
            control.makeFile(folder())
            with open(target, 'w', encoding='utf-8') as handle:
                handle.write(text)
    except (IOError, OSError) as exc:
        control.log_exception(u'billentyű-hozzárendelés írása', exc)
        return False
    try:
        control.execute('Action(reloadkeymaps)')
    except Exception:
        pass
    control.log(u'Billentyű-kiosztás: hozzászólás=%s, vissza lejátszás közben: %s'
                % ('nincs' if comment is None else (comment or u'sárga/Y'), u'szünet' if back_pause else u'leállítás'))
    return True


def sync():
    '''A fajl kovesse a beallitast (a szolgaltatas hivja). True, ha irt.'''
    wanted = back_pause_wanted()
    osd_wanted = own_osd_wanted()
    text = read()
    # A TELJES elvart tartalommal vetjuk ossze (nem csak a jelzokkel): igy egy
    # uj kotes (pl. a nyilak tekerese) a regi fajlba is bekerul frissiteskor.
    comment = comment_code(text)
    expected = build(comment, wanted, 'plugin://%s/' % control.addonInfo('id'), osd_wanted)
    if text == expected:
        return False
    return write(comment, wanted, own_osd=osd_wanted)
