# -*- coding: utf-8 -*-
'''
A netmozi adatlapjainak EGYSEGES alakja.

A netmozi az utvonal harmadik tagjaba kodolt cimet tesz
("/sorozatok/39941/OQ88JB4w..."), ami a sorozat legfrissebb reszevel
egyutt VALTOZIK -- a szerver viszont csak az azonositot nezi, a harmadik
tag barmi lehet. Ha a teljes utvonal lenne a kulcs, egy sorozat az uj resz
utan "masik sorozat" lenne: a kedvencet, a figyelest, a folytatast nem
ismerne fel, es ujra felveve duplazodna. Ezert MINDEN adatlap egy allando
alakra kerul, mielott kulcs vagy osszehasonlitas lenne belole:

    /sorozatok/39941/OQ88JB4w.../s2/e5  ->  /sorozatok/39941/x/s2/e5
    /filmek/42028/OQ88JB4w...           ->  /filmek/42028/x
'''

import re

SLUG = 'x'

# A netmozi cime elol elmarad: a tarolt utvonalak relativak (BASE_URL + utvonal).
_PAGE_RE = re.compile(r'^(?:https?://(?:www\.)?netmozi\.[a-z]+)?/(?P<kind>filmek|sorozatok)/(?P<id>\d+)'
                      r'(?:/(?!s\d+/e\d+/?$)[^/?#&]*)?(?P<episode>/s\d+/e\d+)?/?$')


def canonical(page):
    '''Az adatlap allando alakja; ami nem netmozi adatlap (pl. "imdb:tt1"), az valtozatlan.'''
    if not page or not isinstance(page, str):
        return page
    match = _PAGE_RE.match(page.strip())
    if not match:
        return page
    return '/%s/%s/%s%s' % (match.group('kind'), match.group('id'), SLUG, match.group('episode') or '')


def canonical_keys(data, better=None):
    '''
    Egy {adatlap: bejegyzes} szotar allando kulcsokkal. Ha ket regi kulcs
    ugyanarra az adatlapra mutat, a better(a, b) donti el, melyik marad
    (None: az elso). A "__meta__"-szeru kulcsok valtozatlanok.
    '''
    out = {}
    for page, entry in (data or {}).items():
        key = canonical(page)
        if key in out and better is not None:
            out[key] = better(out[key], entry)
        elif key not in out:
            out[key] = entry
    return out


def unique(pages):
    '''Utvonalak listaja allando alakban, ismetles nelkul, a sorrendet tartva.'''
    out, seen = [], set()
    for page in pages or []:
        key = canonical(page)
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out
