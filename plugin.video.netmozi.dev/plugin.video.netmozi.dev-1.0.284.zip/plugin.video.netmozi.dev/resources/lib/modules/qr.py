# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# QR-kod es nagy szamjegyek PNG-kepben, kulso csomag nelkul (a TV-s Kodiban
# nincs Pillow / qrcode). A bevitel-ablak ezekkel mutatja a cimet es a kodot
# ugy, hogy par meterrol is leolvashato legyen -- a skin betuitol fuggetlenul.
#
# A QR: bajt-mod, M hibajavitas, 1-10. verzio (213 bajtig), a szabvany szerinti
# maszk-valasztassal (Project Nayuki QR-kodolojanak menete szerint).

import re
import struct
import zlib


# M szint: hibajavito bajt / blokk, es a blokkok szama (1-10. verzio)
ECC_PER_BLOCK = (None, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26)
BLOCKS = (None, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5)
FORMAT_M = 0
MAX_VERSION = 10

MASKS = (
    lambda x, y: (x + y) % 2,
    lambda x, y: y % 2,
    lambda x, y: x % 3,
    lambda x, y: (x + y) % 3,
    lambda x, y: (x // 3 + y // 2) % 2,
    lambda x, y: x * y % 2 + x * y % 3,
    lambda x, y: (x * y % 2 + x * y % 3) % 2,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2,
)


def _raw_modules(version):
    '''Az adatnak jut modulok szama (a funkcio-mintak nelkul).'''
    result = (16 * version + 128) * version + 64
    if version >= 2:
        count = version // 7 + 2
        result -= (25 * count - 10) * count - 55
        if version >= 7:
            result -= 36
    return result


def _data_bytes(version):
    return _raw_modules(version) // 8 - ECC_PER_BLOCK[version] * BLOCKS[version]


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for byte in data:
        factor = byte ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _codewords(data, version):
    '''A bajtok bitfolyamma (mod, hossz, adat, kitoltes), majd hibajavitassal, osszefesulve.'''
    bits = [0, 1, 0, 0]
    count_bits = 8 if version < 10 else 16
    bits += [(len(data) >> i) & 1 for i in reversed(range(count_bits))]
    for byte in data:
        bits += [(byte >> i) & 1 for i in reversed(range(8))]
    capacity = _data_bytes(version) * 8
    bits += [0] * min(4, capacity - len(bits))
    bits += [0] * (-len(bits) % 8)
    words = [int(''.join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(words) < capacity // 8:
        words.append(pad)
        pad ^= 0xEC ^ 0x11

    blocks_n, ecc_len = BLOCKS[version], ECC_PER_BLOCK[version]
    raw = _raw_modules(version) // 8
    short_n = blocks_n - raw % blocks_n
    short_len = raw // blocks_n
    divisor = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(blocks_n):
        part = words[k:k + short_len - ecc_len + (0 if i < short_n else 1)]
        k += len(part)
        ecc = _rs_remainder(part, divisor)
        if i < short_n:
            part.append(0)
        blocks.append(part + ecc)
    out = []
    for i in range(len(blocks[0])):
        for j, block in enumerate(blocks):
            if i != short_len - ecc_len or j >= short_n:
                out.append(block[i])
    return out


class _Matrix(object):
    def __init__(self, version):
        self.version = version
        self.size = version * 4 + 17
        self.dark = [[False] * self.size for _ in range(self.size)]
        self.fixed = [[False] * self.size for _ in range(self.size)]

    def put(self, x, y, dark):
        self.dark[y][x] = bool(dark)
        self.fixed[y][x] = True

    def alignment_positions(self):
        if self.version == 1:
            return []
        count = self.version // 7 + 2
        step = (self.version * 8 + count * 3 + 5) // (count * 4 - 4) * 2
        return sorted([self.size - 7 - i * step for i in range(count - 1)] + [6])

    def draw_patterns(self):
        size = self.size
        for i in range(size):
            self.put(6, i, i % 2 == 0)
            self.put(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < size and 0 <= y < size:
                        self.put(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        positions = self.alignment_positions()
        last = len(positions) - 1
        for i, cx in enumerate(positions):
            for j, cy in enumerate(positions):
                if (i, j) in ((0, 0), (0, last), (last, 0)):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.put(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)
        self.draw_format(0)
        if self.version >= 7:
            rem = self.version
            for _ in range(12):
                rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
            bits = self.version << 12 | rem
            for i in range(18):
                bit = (bits >> i) & 1
                a, b = size - 11 + i % 3, i // 3
                self.put(a, b, bit)
                self.put(b, a, bit)

    def draw_format(self, mask):
        data = FORMAT_M << 3 | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412
        bit = lambda i: (bits >> i) & 1
        size = self.size
        for i in range(6):
            self.put(8, i, bit(i))
        self.put(8, 7, bit(6))
        self.put(8, 8, bit(7))
        self.put(7, 8, bit(8))
        for i in range(9, 15):
            self.put(14 - i, 8, bit(i))
        for i in range(8):
            self.put(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.put(8, size - 15 + i, bit(i))
        self.put(8, size - 8, True)

    def draw_data(self, words):
        size, i, total = self.size, 0, len(words) * 8
        right = size - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(size):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = size - 1 - vert if upward else vert
                    if not self.fixed[y][x] and i < total:
                        self.dark[y][x] = bool((words[i >> 3] >> (7 - (i & 7))) & 1)
                        i += 1
            right -= 2

    def apply_mask(self, mask):
        rule = MASKS[mask]
        for y in range(self.size):
            row, fixed = self.dark[y], self.fixed[y]
            for x in range(self.size):
                if not fixed[x] and rule(x, y) == 0:
                    row[x] = not row[x]

    def penalty(self):
        size, score = self.size, 0
        rows = [''.join('1' if v else '0' for v in row) for row in self.dark]
        cols = [''.join(row[x] for row in rows) for x in range(size)]
        for line in rows + cols:
            score += sum(len(run) - 2 for run in re.findall(r'0{5,}|1{5,}', line))
            score += 40 * len(re.findall(r'(?=10111010000|00001011101)', '0000' + line + '0000'))
        for y in range(size - 1):
            for x in range(size - 1):
                if rows[y][x] == rows[y][x + 1] == rows[y + 1][x] == rows[y + 1][x + 1]:
                    score += 3
        dark, total = sum(row.count('1') for row in rows), size * size
        score += ((abs(dark * 20 - total * 10) + total - 1) // total - 1) * 10
        return score


def encode(text):
    '''A szoveg QR-kodja: modul-matrix (sorok listaja, True = sotet).'''
    data = text.encode('utf-8') if not isinstance(text, bytes) else text
    for version in range(1, MAX_VERSION + 1):
        header = 4 + (8 if version < 10 else 16)
        if header + len(data) * 8 <= _data_bytes(version) * 8:
            break
    else:
        raise ValueError(u'túl hosszú a QR-kódhoz')
    matrix = _Matrix(version)
    matrix.draw_patterns()
    matrix.draw_data(_codewords(list(data), version))
    best = None
    for mask in range(8):
        matrix.apply_mask(mask)
        matrix.draw_format(mask)
        score = matrix.penalty()
        if best is None or score < best[0]:
            best = (score, mask)
        matrix.apply_mask(mask)
    matrix.apply_mask(best[1])
    matrix.draw_format(best[1])
    return matrix.dark


def png(width, height, rows, alpha=False):
    '''PNG 8 bites szurke (alpha=True: szurke + atlatszosag) kepsorokbol (bytes).'''
    def chunk(tag, body):
        return struct.pack('>I', len(body)) + tag + body + struct.pack('>I', zlib.crc32(tag + body) & 0xFFFFFFFF)
    header = struct.pack('>IIBBBBB', width, height, 8, 4 if alpha else 0, 0, 0, 0)
    raw = b''.join(b'\x00' + row for row in rows)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b'')


def qr_png(text, pixels=600, quiet=4):
    '''
    A QR-kod pixels x pixels meretu fekete-feher PNG-ben, egesz pixeles
    modulokkal (eles a TV-n is), korulotte legalabb `quiet` modulnyi feher.
    '''
    modules = encode(text)
    count = len(modules)
    scale = max(1, pixels // (count + 2 * quiet))
    offset = (pixels - count * scale) // 2
    white, black = b'\xff', b'\x00'
    blank = white * pixels
    rows = [blank] * offset
    for line in modules:
        row = white * offset + b''.join((black if dark else white) * scale for dark in line)
        row += white * (pixels - len(row))
        rows += [row] * scale
    rows += [blank] * (pixels - len(rows))
    return png(pixels, pixels, rows)


# Szamjegyek szogletes, vastag vonalakkal (mint egy kijelzon): hét szakasz
# (a felso, b jobb felso, c jobb also, d also, e bal also, f bal felso,
# g kozepso), a sarkok kitoltve, ha barmelyik odaero szakasz eg.
SEGMENTS = {
    '0': 'abcdef', '1': 'bc', '2': 'abged', '3': 'abgcd', '4': 'fgbc',
    '5': 'afgcd', '6': 'afgedc', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg',
}
CORNERS = (('a', 'f'), ('a', 'b'), ('f', 'e', 'g'), ('b', 'c', 'g'), ('e', 'd'), ('c', 'd'))


def digits_png(text, height=184, width=104, stroke=24, gap=40):
    '''A szamjegyek feher, atlatszo hatteru PNG-ben: (szelesseg, magassag, png).'''
    text = ''.join(ch for ch in text if ch in SEGMENTS)
    total = max(1, len(text) * width + max(0, len(text) - 1) * gap)
    mid = (height - stroke) // 2
    xs = (0, width - stroke)
    ys = (0, mid, height - stroke)
    canvas = [bytearray(total * 2) for _ in range(height)]

    def fill(x, y, w, h):
        for yy in range(y, y + h):
            canvas[yy][2 * x:2 * (x + w)] = b'\xff\xff' * w

    for n, ch in enumerate(text):
        left, on = n * (width + gap), SEGMENTS[ch]
        if ch == '1':
            left -= (width - stroke) // 2              # az egyes a helye kozepen all, ne a jobb szelen
        bars = {
            'a': (stroke, 0, width - 2 * stroke, stroke),
            'g': (stroke, mid, width - 2 * stroke, stroke),
            'd': (stroke, height - stroke, width - 2 * stroke, stroke),
            'f': (0, stroke, stroke, mid - stroke),
            'b': (width - stroke, stroke, stroke, mid - stroke),
            'e': (0, mid + stroke, stroke, height - stroke - mid - stroke),
            'c': (width - stroke, mid + stroke, stroke, height - stroke - mid - stroke),
        }
        for name in on:
            x, y, w, h = bars[name]
            fill(left + x, y, w, h)
        corners = ((xs[0], ys[0]), (xs[1], ys[0]), (xs[0], ys[1]), (xs[1], ys[1]), (xs[0], ys[2]), (xs[1], ys[2]))
        for (x, y), touching in zip(corners, CORNERS):
            if any(name in on for name in touching):
                fill(left + x, y, stroke, stroke)
    return total, height, png(total, height, [bytes(row) for row in canvas], alpha=True)
