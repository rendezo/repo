# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A torrent-forrasok egy helyen: nCore es bithumen. A forraslista, a
# lejatszas, az automatikus inditas es az elerhetoseg ezen at kerdez -- igy
# mindket oldal ugyanugy viselkedik (a forras-szotarban 'ncore': True a
# "torrent" jelzo, a 'tracker' mondja meg, melyik oldalrol jott).

import re

from resources.lib.modules import bithumen, control, ncore


TRACKERS = (('ncore', ncore), ('bithumen', bithumen))
LABELS = {'ncore': u'nCore', 'bithumen': u'bithumen'}


def active():
    '''A beallitott oldalak: [(nev, modul)].'''
    out = []
    for name, module in TRACKERS:
        try:
            if module.enabled():
                out.append((name, module))
        except Exception as exc:
            control.log_exception(u'torrent-oldal (%s)' % name, exc)
    return out


def enabled():
    return bool(active())


def label():
    '''A gomb / uzenet neve: "nCore", "bithumen", vagy ha mindketto: "Torrent".'''
    names = [name for name, _module in active()]
    return LABELS[names[0]] if len(names) == 1 else u'Torrent'


def sources_for(imdb, kind='film', season=None, episode=None):
    '''Az osszes beallitott oldal torrentjei egy cimhez (parhuzamosan), a tobb seederes elol.'''
    trackers = active()
    if not imdb or not trackers:
        return []

    def one(item):
        name, module = item
        try:
            return module.sources_for(imdb, kind, season=season, episode=episode)
        except Exception as exc:
            control.log_exception(u'%s források' % LABELS[name], exc)
            return []
    if len(trackers) == 1:
        results = [one(trackers[0])]
    else:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=len(trackers)) as pool:
            results = list(pool.map(one, trackers))
    out = [source for part in results for source in part or []]
    out.sort(key=lambda item: -(item.get('seeders') or 0))
    return out


def tracker_of(source_or_url):
    ''''ncore' / 'bithumen' / '' egy forrashoz (vagy forras-URL-hez).'''
    url = source_or_url if isinstance(source_or_url, str) else (source_or_url or {}).get('url') or ''
    for name, module in TRACKERS:
        if module.is_source(url):
            return name
    return ''


def is_source(url):
    return bool(tracker_of(url))


def torrent_of(source):
    '''
    A torrent azonositoja az elozmenyhez ("ezzel ment legutobb"): nCore-nal
    a puszta szam (a regi bejegyzesek is igy vannak), bithumennel "bh:<szam>".
    '' ha nem torrent.
    '''
    if not (source or {}).get('ncore'):
        return ''
    name = tracker_of(source)
    if name == 'bithumen':
        return 'bh:' + bithumen.parse_source_url(source.get('url') or '')[0]
    return ncore.torrent_of(source)


def resolve(url, position=0, ask=False):
    '''Torrent-forras -> Elementum URL (az oldal szerint), vagy None.'''
    if bithumen.is_source(url):
        return bithumen.resolve(url, position, ask)
    if ncore.is_source(url):
        return ncore.resolve(url, position, ask)
    return None


def season_availability(name, imdb, season, numbers):
    '''{reszszam: True/False} egy oldalrol, vagy None.'''
    module = dict(TRACKERS).get(name)
    return module.season_availability(imdb, season, numbers) if module else None


def safe(url):
    '''Naploba: a letolto linkben levo kulcs nelkul.'''
    return re.sub(r'(?i)(%2F|/)[0-9a-f]{32}(%2F|/)', r'\1<kulcs>\2', re.sub(r'(?i)(key%3D|key=)[0-9a-z]+', r'\1<kulcs>', url or ''))
