# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Bevitel telefonrol / geprol: egy IDEIGLENES weboldal a TV-n, hogy a
# hosszu szovegeket (jelszo, PIN, kulcs, bithumen-suti) ne a taviranyitoval
# kelljen begepelni.
#
#   - csak amig a TV-n nyitva van az ablak (legfeljebb TIMEOUT mp), es az
#     elso sikeres mentes utan leall;
#   - csak a TV-n kiirt negyjegyu koddal fogad el adatot (a halozaton mas
#     nem irhatja at a beallitasokat); MAX_TRIES rossz kod utan leall;
#   - a meglevo ertekeket SOHA nem mutatja (csak azt, hogy be van-e allitva);
#     az uresen hagyott mezo valtozatlan marad.

import html
import random
import re
import socket
import threading
import time
from urllib.parse import parse_qs

import xbmc
import xbmcgui

from resources.lib.modules import control


PORT = 8765
TIMEOUT = 600
MAX_TRIES = 5
RUNNING_PROPERTY = 'netmozi.webinput'      # a Kodi fo ablakan: fut-e mar egy bevitel (ido)

# A teljes bithumen-suti egy mezoben (a bongeszobol bemasolva): ebbol jon a uid es a pass.
COOKIE_FIELD = ('bhcookie', u'vagy a teljes bithumen süti egyben', True)
COOKIE_HINT = (u'Firefoxban / Chrome-ban a Cookie-Editor bővítménnyel: a bithumen.be oldalán Export, '
               u'bármelyik formátum (JSON, Header String, Netscape), és ide bemásolva.')

# A titkos PIN az urlap tetejen, a kod alatt: ez kell a kulcsok nelkuli hasznalathoz.
PIN_FIELD = 'keypin'
PIN_HINT = (u'A titkos PIN a kulcsok nélküli használathoz kell: saját API-kulcs nélkül ezzel jönnek a '
            u'TMDB-adatok (háttérkép, magyar leírás), a feliratok és a streaming-listák a közös '
            u'kulcs-közvetítőn át. Ha lent saját kulcsot adsz meg, ott a PIN helyett azt használja.')


def fields(model=None):
    '''
    Az urlap mezoi a beallitasokbol: MINDEN szoveges beallitas (az uj is
    magatol), szakaszonkent -- [(beallitas, felirat, rejtett, csoport)].
    '''
    if model is None:
        model = _settings_model()
    out = []
    for section in model:
        for item in section.get('items') or []:
            if item.get('type') != 'text':
                continue
            out.append((item['id'], item['label'], bool(item.get('hidden')), section['title']))
            if item['id'] == 'bhpass':
                out.append(COOKIE_FIELD + (section['title'],))
    return out


def _settings_model():
    import os
    from resources.lib.modules import prefs
    try:
        with open(os.path.join(control.addonPath, 'resources', 'settings.xml'), encoding='utf-8') as handle:
            return prefs.parse(handle.read())
    except (IOError, OSError, ValueError) as exc:
        control.log_exception(u'bevitel: a beállítások listája', exc)
        return []


def local_ip():
    '''A TV cime a helyi halozaton (a Kodi tudja; tartaleknak a kimeno UDP-socket cime).'''
    try:
        import xbmc
        address = xbmc.getInfoLabel('Network.IPAddress') or ''
        if address and not address.startswith(('127.', '0.')) and address.count('.') == 3:
            return address
    except Exception:
        pass
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(('192.0.2.1', 9))           # nem megy ki csomag: csak a kimeno cim kell
        return probe.getsockname()[0]
    except OSError:
        return '127.0.0.1'
    finally:
        probe.close()


def is_set(setting_id):
    if setting_id == 'bhcookie':
        from resources.lib.modules import bithumen
        return all(bithumen.credentials())
    try:
        return bool((control.setting(setting_id) or '').strip())
    except Exception:
        return False


def _row(setting_id, label, hidden, hint=u''):
    state = u'be van állítva' if is_set(setting_id) else u'nincs megadva'
    attrs = u'name="%s" autocomplete="off" autocapitalize="none" spellcheck="false"' % setting_id
    if setting_id == COOKIE_FIELD[0]:
        field = u'<textarea %s rows="3" class="secret" placeholder="uid=…; pass=…"></textarea>' % attrs
    else:
        field = u'<input %s type="%s">' % (attrs, 'password' if hidden else 'text')
    return u'<label>%s <small>(%s)</small>%s%s</label>' % (
        html.escape(label), state, field, u'<span class="hint">%s</span>' % html.escape(hint) if hint else u'')


def page(message=u'', ok=False, code=u''):
    '''Az urlap (a meglevo ertekek nelkul). code: a QR-kodbol jott kod, elore kitoltve.'''
    groups, rows, pin = [], {}, u''
    for setting_id, label, hidden, group in fields():
        if setting_id == PIN_FIELD:
            pin = _row(setting_id, label, hidden, PIN_HINT)
            continue
        if group not in rows:
            groups.append(group)
            rows[group] = []
        rows[group].append(_row(setting_id, label, hidden, COOKIE_HINT if setting_id == COOKIE_FIELD[0] else u''))
    body = u''.join(u'<fieldset><legend>%s</legend>%s</fieldset>' % (html.escape(group), u''.join(rows[group]))
                    for group in groups)
    note = (u'<p class="%s">%s</p>' % ('ok' if ok else 'err', html.escape(message).replace(u'\n', u'<br>'))
            if message else u'')
    code = re.sub(r'\D', u'', code or u'')[:4]
    return (u'<!doctype html><html lang="hu"><head><meta charset="utf-8">'
            u'<meta name="viewport" content="width=device-width, initial-scale=1">'
            u'<title>netmozi -- bevitel</title><style>'
            u'body{font-family:system-ui,sans-serif;background:#141418;color:#eee;margin:0}'
            u'main{max-width:560px;margin:0 auto;padding:20px 16px 32px}'
            u'h1{font-size:22px;text-align:center;margin:8px 0 4px}.lead{text-align:center;color:#aaa;margin:0 0 18px}'
            u'fieldset{border:1px solid #333;border-radius:10px;margin:0 0 14px;padding:10px 12px}'
            u'legend{color:#e53935;font-weight:600}label{display:block;margin:8px 0;font-size:14px}'
            u'small{color:#888}.hint{display:block;color:#999;font-size:13px;margin-top:6px;line-height:1.4}'
            u'input,textarea{display:block;width:100%%;box-sizing:border-box;margin-top:4px;padding:10px;'
            u'font-size:16px;border-radius:8px;border:1px solid #444;background:#1e1e24;color:#fff;font-family:inherit}'
            u'textarea{resize:vertical}.secret{-webkit-text-security:disc}'
            u'.code{font-size:28px;letter-spacing:10px;text-align:center}'
            u'button{width:100%%;padding:14px;font-size:17px;border:0;border-radius:10px;background:#e53935;color:#fff}'
            u'.ok{color:#4cd964}.err{color:#ff8a80}.ok,.err{text-align:center}</style></head><body><main>'
            u'<h1>netmozi -- bevitel a TV-re</h1>'
            u'<p class="lead">Csak amit kitöltesz, az változik; az üres mező marad, ami volt.</p>%s'
            u'<form method="post"><fieldset><legend>A TV-n látható kód</legend>'
            u'<label>Kód<input name="code" class="code" inputmode="numeric" maxlength="4" autocomplete="off" '
            u'required value="%s"></label></fieldset>'
            u'<fieldset><legend>Titkos PIN</legend>%s</fieldset>'
            u'%s<button type="submit">Mentés a TV-re</button></form></main></body></html>') % (note, code, pin, body)


def apply(form):
    '''A kitoltott mezok a beallitasokba. Visszaad: a beallitott mezok feliratai.'''
    from resources.lib.modules import bithumen
    done = []
    known = fields()
    labels = dict((setting_id, label) for setting_id, label, _hidden, _group in known)
    cookie = (form.get('bhcookie') or u'').strip()
    if cookie or (form.get('bhuid') or u'').strip() or (form.get('bhpass') or u'').strip():
        # bithumen: a teljes suti, vagy a ket ertek (a mar beallitottal kiegeszitve)
        if cookie:
            uid, secret = bithumen.parse_cookie('', cookie)
        else:
            old_uid, old_secret = bithumen.credentials()
            uid, secret = bithumen.parse_cookie((form.get('bhuid') or u'').strip() or old_uid,
                                                (form.get('bhpass') or u'').strip() or old_secret)
        if (cookie or (form.get('bhpass') or u'').strip()) and len(secret) != 32:
            raise ValueError(u'A bithumen pass 32 karakter (0-9, a-f) -- ez nem az.')
        if uid:
            control.setSetting('bhuid', uid)
        if secret:
            control.setSetting('bhpass', secret)
        if uid and secret:
            control.setSetting('bithumen', 'true')
        bithumen.forget()
        done.append(u'bithumen süti')
    for setting_id, _label, _hidden, _group in known:
        if setting_id in ('bhuid', 'bhpass', 'bhcookie'):
            continue
        value = (form.get(setting_id) or u'').strip()
        if not value:
            continue
        control.setSetting(setting_id, value)
        if setting_id in ('ncoreuser', 'ncorepass'):
            control.setSetting('ncore', 'true')
        done.append(labels[setting_id])
    return done


def verify(done):
    '''
    Mentes utan rogton kiprobaljuk, ami kiprobalhato (az uj kodok mukodnek-e):
    a titkos PIN, az nCore-belepes, a bithumen-suti. [(rendben?, sor)].
    '''
    from resources.lib.modules import bithumen, ncore
    labels = dict((setting_id, label) for setting_id, label, _hidden, _group in fields())
    out = []
    if labels.get('keypin') in done:
        try:
            ok, message = control.checkPin()
        except Exception as exc:
            control.log_exception(u'bevitel: PIN-próba', exc)
            ok, message = False, u'nem sikerült ellenőrizni'
        out.append((ok, u'Titkos PIN: %s' % message))
    if labels.get('ncoreuser') in done or labels.get('ncorepass') in done:
        user, password = ncore.credentials()
        ncore.forget()
        ok, message = ncore.login(user, password) if user and password else (False, u'hiányzik a név vagy a jelszó')
        out.append((ok, u'nCore belépés: %s' % (u'rendben' if ok else message)))
    if u'bithumen süti' in done:
        rows = bithumen.search(bithumen.TEST_IMDB, 'film')
        ok = rows is not None
        out.append((ok, u'bithumen: %s' % ((u'rendben (%d torrent a próbakeresésre, passkey %s)'
                                             % (len(rows), u'megvan' if bithumen.passkey() else u'NINCS')) if ok
                                            else bithumen.EXPIRED_TEXT)))
    return out


class Session(object):
    '''Egy bevitel: a szerver, a kod, es az eredmeny (a hivo ebbol latja, mikor kesz).'''

    def __init__(self, port=PORT, host='0.0.0.0', code=None):
        self.code = code or '%04d' % random.SystemRandom().randint(0, 9999)
        self.tries = 0
        self.saved = None          # a beallitott mezok feliratai, ha mentett
        self.checks = []           # [(rendben?, sor)] -- a mentes utani probak
        self.failed = False        # tul sok rossz kod
        self.server = self._bind(host, port)
        self.port = self.server.server_address[1]

    def _bind(self, host, port):
        import socketserver
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        session = self

        class Server(ThreadingHTTPServer):
            daemon_threads = True

            def server_bind(self):
                # A HTTPServer itt socket.getfqdn()-t hivna: a TV-n a nevfeloldas sokaig is tarthat.
                socketserver.TCPServer.server_bind(self)
                self.server_name, self.server_port = self.server_address[:2]

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass                                     # a kodi.log-ba ne irjon (a formban jelszo van)

            def _send(self, text, status=200):
                data = text.encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if session.saved is not None or session.failed:
                    return self._send(page(u'Ez a bevitel már lezárult.', ok=session.saved is not None), 410)
                query = parse_qs(self.path.partition('?')[2])
                self._send(page(code=(query.get('k') or [u''])[0]))

            def do_POST(self):
                if session.saved is not None or session.failed:
                    return self._send(page(u'Ez a bevitel már lezárult.'), 410)
                length = min(int(self.headers.get('Content-Length') or 0), 16384)
                raw = self.rfile.read(length).decode('utf-8', 'replace')
                form = dict((key, values[0]) for key, values in parse_qs(raw).items())
                if (form.get('code') or '').strip() != session.code:
                    session.tries += 1
                    if session.tries >= MAX_TRIES:
                        session.failed = True
                        return self._send(page(u'Túl sok rossz kód: a bevitel leállt.'), 403)
                    return self._send(page(u'Rossz kód -- a TV-n látható négy számjegyet írd be.'), 403)
                try:
                    done = apply(form)
                except ValueError as exc:
                    return self._send(page(str(exc), code=session.code), 400)
                if not done:
                    return self._send(page(u'Nem töltöttél ki semmit.', code=session.code), 400)
                try:
                    checks = verify(done)
                except Exception as exc:
                    control.log_exception(u'bevitel: ellenőrzés', exc)
                    checks = []
                session.checks = checks
                lines = [u'Elmentve a TV-re: %s.' % u', '.join(done)] + [
                    (u'✓ ' if ok else u'✗ ') + text for ok, text in checks]
                self._send(page(u'\n'.join(lines), ok=all(ok for ok, _text in checks)))
                session.saved = done                     # a valasz mar kiment: a TV most zarhat

        for candidate in (port, 0):
            try:
                return Server((host, candidate), Handler)
            except OSError:
                continue
        raise OSError(u'nem sikerült portot nyitni')

    def start(self):
        thread = threading.Thread(target=self.server.serve_forever)
        thread.daemon = True
        thread.start()
        return self

    def stop(self):
        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception:
            pass


# A TV-n sajat ablak (nem a Kodi parbeszedablaka): QR-kod a cimmel (benne a
# koddal, igy a telefon elore kitolti), alatta a kod nagy szamjegyekkel -- a
# kepek a skin betuitol fuggetlenul par meterrol is olvashatok.
WINDOW_XML = 'NetmoziInput.xml'
QR_ID, CAPTION_ID, CODE_ID, ADDRESS_ID, STATUS_ID, RESULT_ID = 201, 202, 203, 204, 205, 301
QR_PIXELS = 560
RESULT_WAIT = 120                                    # az eredmeny ennyi ideig marad kint, ha nem zarja be
CLOSE_ACTIONS = (9, 10, 13, 92, 7, 100)              # vissza, menu, stop, OK, kattintas


class InputWindow(xbmcgui.WindowXMLDialog):
    '''A bevitel ablaka: amig var, a QR es a kod; mentes utan az eredmeny.'''

    closed = False
    images = (u'', u'')
    address = u''
    code = u''
    status = u''

    def onInit(self):
        try:
            qr_path, code_path = self.images
            if qr_path:
                self.getControl(QR_ID).setImage(qr_path, False)
            if code_path:
                self.getControl(CODE_ID).setImage(code_path, False)
            else:
                self.getControl(CAPTION_ID).setLabel(u'KÓD: [B]%s[/B]' % self.code)
            self.getControl(ADDRESS_ID).setLabel(u'Vagy írd be a böngészőbe:  [B]%s[/B]' % self.address)
            self.show_status(self.status)
        except Exception as exc:
            control.log_exception(u'bevitel: az ablak feltöltése', exc)

    def show_status(self, text):
        self.status = text
        try:
            self.getControl(STATUS_ID).setLabel(text)
        except Exception:
            pass

    def show_result(self, text):
        try:
            self.getControl(RESULT_ID).setText(text)
        except Exception as exc:
            control.log_exception(u'bevitel: az eredmény', exc)
        self.setProperty('state', 'done')

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 10
        if action_id in CLOSE_ACTIONS[:4] or (action_id in CLOSE_ACTIONS and self.getProperty('state') == 'done'):
            self.closed = True
            self.close()


def make_images(link, code, folder=None):
    '''(QR-kep, kod-kep) utvonala a profil mappaban, egyedi nevvel (a Kodi kepgyorsitotara miatt).'''
    import binascii
    import os
    from resources.lib.modules import qr
    folder = folder or control.dataPath
    token = binascii.hexlify(os.urandom(4)).decode('ascii')
    paths = []
    try:
        if not os.path.isdir(folder):
            os.makedirs(folder)
        for name, data in (('qr', qr.qr_png(link, QR_PIXELS)), ('code', qr.digits_png(code, 150, 84, 20, 32)[2])):
            path = os.path.join(folder, 'webinput-%s-%s.png' % (name, token))
            with open(path, 'wb') as handle:
                handle.write(data)
            paths.append(path)
    except Exception as exc:
        control.log_exception(u'bevitel: QR-kép', exc)
        remove_images(paths)
        return u'', u''
    return tuple(paths)


def remove_images(paths):
    import os
    for path in paths or ():
        try:
            if path:
                os.remove(path)
        except OSError:
            pass


def result_lines(session):
    if session.saved:
        return [u'[B]Elmentve:[/B] %s.' % u', '.join(session.saved), u''] + [
            (u'[COLOR limegreen]✓[/COLOR] ' if ok else u'[COLOR red]✗[/COLOR] ') + text for ok, text in session.checks]
    return [u'[COLOR red]Túl sok rossz kód: a bevitel leállt.[/COLOR]']


def run():
    '''
    A Beallitasok gombja: a weboldal elindul, a TV sajat ablakban kiirja a
    QR-kodot, a cimet es a kodot, es var, amig mentes, Vissza, vagy lejar az
    ido. Mentes utan ugyanitt az eredmeny (mi ment at, a probak).
    '''
    home = xbmcgui.Window(10000)
    try:
        since = float(home.getProperty(RUNNING_PROPERTY) or 0)
    except ValueError:
        since = 0
    if since and time.time() - since < TIMEOUT + RESULT_WAIT + 60:
        # a gombot tobbszor is megnyomtak, mig az elso elindult: egy ablak eleg
        control.log(u'Bevitel telefonról: már fut egy, ez kimarad')
        return False
    home.setProperty(RUNNING_PROPERTY, '%d' % time.time())
    try:
        return _run()
    finally:
        home.clearProperty(RUNNING_PROPERTY)


def _run():
    try:
        session = Session().start()
    except OSError as exc:
        control.log_exception(u'bevitel telefonról', exc)
        return control.okDialog(u'A bevitelhez nem sikerült a weboldalt elindítani.')
    address = u'http://%s:%d' % (local_ip(), session.port)
    control.log(u'Bevitel telefonról: elindult (%s)' % address)
    images = make_images(u'%s/?k=%s' % (address, session.code), session.code)
    try:
        window = InputWindow(WINDOW_XML, control.addonPath, 'Default', '1080i')
    except Exception as exc:
        control.log_exception(u'bevitel: az ablak', exc)
        remove_images(images)
        session.stop()
        return control.okDialog(u'A bevitel ablakát nem sikerült megnyitni.\nCím: %s   Kód: %s' % (address, session.code))
    window.images, window.address, window.code = images, address, session.code
    monitor = xbmc.Monitor()
    started = time.time()
    try:
        window.show()
        while not window.closed and not monitor.abortRequested():
            left = TIMEOUT - (time.time() - started)
            if session.saved is not None or session.failed or left <= 0:
                break
            window.show_status(u'Még %d perc  ·  Kilépés: Vissza' % (int(left // 60) + 1))
            monitor.waitForAbort(0.5)
        session.stop()
        if not window.closed and (session.saved is not None or session.failed):
            window.show_result(u'\n'.join(result_lines(session)))
            shown = time.time()
            while not window.closed and time.time() - shown < RESULT_WAIT and not monitor.abortRequested():
                monitor.waitForAbort(0.5)
    finally:
        session.stop()
        window.close()
        remove_images(images)
        del window
    if session.saved:
        control.log(u'Bevitel telefonról: elmentve (%s)' % u', '.join(session.saved))
        return True
    control.log(u'Bevitel telefonról: lezárva mentés nélkül')
    return False
