# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A bemasolt bithumen-suti felismerese, Kodi nelkul (a bovitmeny es a
# tools/deploy_keyproxy.py is ezt hasznalja): a "Cookie:" sor / "uid=...;
# pass=..." (Header String), a Cookie-Editor es az EditThisCookie
# JSON-exportja, vagy a Netscape cookies.txt.

import re


def cookie_values(text):
    '''
    {nev: ertek} a bemasolt sutibol, barmelyik szokasos alakban: a "Cookie:"
    sor / "uid=...; pass=..." (Header String), a Cookie-Editor es az
    EditThisCookie JSON-exportja, vagy a Netscape cookies.txt. Ha mas oldal
    sutije is benne van, csak a bithumenet nezzuk.
    '''
    found = {}
    ours = lambda chunk: 'bithumen' in chunk or 'bithumen' not in text
    for block in re.findall(r'\{[^{}]*\}', text):
        name = re.search(r'"name"\s*:\s*"([^"]*)"', block)
        value = re.search(r'"value"\s*:\s*"([^"]*)"', block)
        if name and value and ours(block):
            found.setdefault(name.group(1), value.group(1))
    for line in text.splitlines():
        cells = line.strip().split('\t')
        if len(cells) >= 7 and ours(cells[0]):
            found.setdefault(cells[5].strip(), cells[6].strip())
    for name, value in re.findall(r'(?:^|[;\s,])([A-Za-z_]\w*)=([^;\s,]*)', text):
        found.setdefault(name, value)
    return found


def parse_cookie(uid, secret):
    text = u'%s; %s' % (uid or u'', secret or u'')
    structured = lambda value: bool(re.search(r'[=\t"]', value or u''))
    if structured(text):
        found = cookie_values(text)
        uid = found.get('uid') or (uid if not structured(uid) else '')
        secret = found.get('pass') or (secret if not structured(secret) else '')
    uid = re.sub(r'\D', '', uid or '')
    secret = re.sub(r'[^0-9a-fA-F]', '', secret or '').lower()
    return uid, secret
