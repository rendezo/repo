# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Valogatott filmlistak a kezdokepernyon, harom sorban (a TMDB-bol):
#
#   Mert tetszett: <cim>   egy friss kedvenc (vagy a legutobb latott cim) alapjan a
#                          TMDB ajanlasai
#   (Ajanlo sor eleje)     a legutobb latott filmek "univerzuma" (TMDB-gyujtemeny, pl.
#                          Mission: Impossible): gyujtemenyenkent a KOVETKEZO resz -- nem
#                          kulon sor, az Ajanlo elejere kerul (home.with_next_parts)
#   Valogatas: <tema>      egy tema (TMDB-kulcsszo, pl. idoutazas) legjobbra ertekelt
#                          filmjei -- hetente masik, az izles (kedvelt mufajok) szerint
#
# Csak az kerul a sorba, ami fent van a netmozin, es meg nem lattad (elozmeny,
# elkezdett, kedvenc, nem tetszett). A TMDB -> IMDb parositas orokre, a netmozi
# talalat hetente ujra. Naponta fut (a kezdokepernyo hatterszalabol), a
# profil sajat adataival (profilonkent kulon fajl).
#
# Fajl (a profil mappajaban): curated.json
#   {'__meta__': {'last_run'}, 'ids': {'movie:123': 'tt...'}, 'coll': {'tt...': {'id', 'name'}},
#    'found': {...}, 'missing': {...}, 'theme': {'key', 'week'}, 'shown': ['heist', ...],
#    'rows': {'liked': {'title', 'imdbs'}, 'universe': {...}, 'theme': {...}}}

import json
import os
import time

from resources.lib.modules import control, pageurl


FILE = 'curated.json'
ROWS = (('liked', u'Mert tetszett'), ('theme', u'Válogatás'))    # a sajat soruk van
ROW_KEYS = tuple(key for key, _title in ROWS)
UNIVERSE_MAX = 3              # ennyi gyujtemeny kovetkezo resze kerul a Folytatas sorba
INTERVAL = 24 * 3600          # naponta ujra (a hetente valtozo tema is ebbol jon)
RECHECK = 7 * 24 * 3600       # a netmozi-talalat (es a "nincs") hetente ujra
WEEK = 7 * 24 * 3600
ROW_TARGET = 15               # ennyi netmozis cimig gyujt egy sorba
CANDIDATES_MAX = 40           # egy sorhoz legfeljebb ennyi TMDB-jeloltet nez meg
SEARCH_MAX = 90               # egy futasban legfeljebb ennyi netmozi-kereses
HISTORY_SCAN = 15             # a legutobb latott filmek kozul ennyinek nezzuk a gyujtemenyet
SEEDS_MAX = 3                 # a "Mert tetszett" ennyi kedvenccel probalkozik, ha az elso nem ad sort
THEME_MEMORY = 8              # egy tema ennyi hetig nem jon ujra

# (kulcs, TMDB-kulcsszo, nev, a netmozi kategoriai, amikhez illik)
THEMES = (
    ('timetravel', 4379, u'Időutazás', (u'Sci-Fi', u'Kaland')),
    ('heist', 10051, u'Nagy rablások', (u'Akció', u'Bűnügyi')),
    ('truestory', 9672, u'Igaz történet alapján', (u'Dráma', u'Életrajz', u'Történelmi')),
    ('survival', 10349, u'Túlélők', (u'Kaland', u'Thriller')),
    ('dystopia', 4565, u'Disztópia', (u'Sci-Fi', u'Dráma')),
    ('space', 3801, u'Űrutazás', (u'Sci-Fi', u'Kaland')),
    ('zombie', 12377, u'Zombik', (u'Horror', u'Akció')),
    ('serialkiller', 10714, u'Sorozatgyilkosok nyomában', (u'Thriller', u'Bűnügyi', u'Misztikus')),
    ('ai', 310, u'Mesterséges intelligencia', (u'Sci-Fi', u'Thriller')),
    ('postapocalypse', 4458, u'A világvége után', (u'Sci-Fi', u'Akció')),
    ('prisonescape', 9777, u'Szökés a börtönből', (u'Dráma', u'Bűnügyi')),
    ('conartist', 10453, u'Szélhámosok', (u'Bűnügyi', u'Vígjáték')),
    ('spy', 470, u'Kémek', (u'Akció', u'Thriller')),
    ('courtroom', 33519, u'Tárgyalótermi drámák', (u'Dráma', u'Bűnügyi')),
    ('roadtrip', 7312, u'Úton', (u'Kaland', u'Vígjáték')),
    ('treasure', 6956, u'Kincsvadászat', (u'Kaland', u'Családi')),
    ('haunted', 3358, u'Kísértetházak', (u'Horror', u'Misztikus')),
    ('alien', 14909, u'Földönkívüli invázió', (u'Sci-Fi', u'Akció')),
    ('revenge', 9748, u'Bosszú', (u'Akció', u'Thriller')),
    ('martialarts', 779, u'Harcművészet', (u'Akció',)),
    ('boxing', 209476, u'A ringben', (u'Sport', u'Dráma')),
    ('submarine', 339, u'Tengeralattjárók', (u'Háborús', u'Thriller')),
)


def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'válogatott listák írása', exc)
        return False


def due(now=None):
    from resources.lib.modules import tmdb
    now = now or time.time()
    data = load()
    meta = data.get('__meta__') or {}
    universe = (data.get('rows') or {}).get('universe')
    old_format = isinstance(universe, dict) and universe.get('imdbs') and 'names' not in universe   # 1.0.288-bol
    return bool(tmdb.api_key()) and (old_format or not 0 <= now - (meta.get('last_run') or 0) < INTERVAL)


# --- Amit mar lattal, es amit szeretsz -------------------------------------------------

def seen_pages():
    '''Amit nem ajanlunk: elozmeny, elkezdett / vegignezett, kedvenc, nem tetszett.'''
    from resources.lib.modules import history, progress, taste
    out = set()
    sources = (lambda: [entry.get('page') or entry.get('key') for entry in history.load()],
               lambda: progress.load(), lambda: taste.favorite_pages(), lambda: taste.disliked())
    for source in sources:
        try:
            out |= set(pageurl.canonical(page) for page in source() or [] if page)
        except Exception as exc:
            control.log_exception(u'válogatott listák: látott címek', exc)
    return out


def seen_imdbs():
    '''Ugyanez IMDb-vel (a boritokbol): igy akkor is kimarad, ha a netmozin mas oldalon van.'''
    from resources.lib.modules import history, progress, taste, tmdb
    out = set()
    try:
        out |= set(tmdb.imdb_id(entry.get('thumb') or '') for entry in history.load())
        out |= set(tmdb.imdb_id(entry.get('thumb') or '') for entry in progress.load().values())
        out |= set(entry.get('imdb') or tmdb.imdb_id(entry.get('thumb') or '') for entry in taste.favorites())
    except Exception as exc:
        control.log_exception(u'válogatott listák: látott címek', exc)
    out.discard('')
    return out


def top_genres():
    '''A kedvelt mufajok (kedvencek, tetszett cimek), a gyakoribb elol.'''
    from resources.lib.modules import taste
    counts = {}
    try:
        data = taste.load()
        entries = list(data['favorites'].values()) + [e for e in data['ratings'].values() if (e.get('vote') or 0) > 0]
    except Exception:
        entries = []
    for entry in entries:
        for genre in entry.get('genres') or []:
            counts[genre] = counts.get(genre, 0) + 1
    return [genre for genre, _count in sorted(counts.items(), key=lambda item: -item[1])]


def watched_films():
    '''A legutobb latott filmek: [(oldal, cim, borito)], a legfrissebb elol (elozmeny, aztan a haladas).'''
    from resources.lib.modules import history, progress
    out, seen = [], set()
    entries = [(e.get('page') or e.get('key'), e.get('title'), e.get('thumb'), e.get('time') or 0) for e in history.load()]
    try:
        entries += [(page, e.get('title'), e.get('thumb'), e.get('updated') or 0)
                    for page, e in progress.load().items() if progress.film_key(page) and progress.finished(e)]
    except Exception:
        pass
    for page, title, thumb, _when in sorted(entries, key=lambda item: -(item[3] or 0)):
        page = pageurl.canonical(page or '')
        if page and page.startswith('/filmek/') and page not in seen:
            seen.add(page)
            out.append((page, title or u'', thumb or ''))
    return out


def seeds():
    '''A "Mert tetszett" kiindulasai: a kedvencek (a legfrissebb elol), aztan a legutobb latott film.'''
    from resources.lib.modules import taste
    out = []
    try:
        for entry in taste.favorites():
            out.append((entry['page'], entry.get('title') or u'', entry.get('imdb') or '', entry.get('thumb') or ''))
    except Exception as exc:
        control.log_exception(u'válogatott listák: kedvencek', exc)
    out += [(page, title, '', thumb) for page, title, thumb in watched_films()[:1]]
    return out


def week_of(now):
    '''A naptari het (hetfotol), pl. 202640.'''
    from datetime import date
    year, week, _day = date.fromtimestamp(now).isocalendar()
    return year * 100 + week


def pick_theme(data, now=None, force=False):
    '''
    A heti tema (hetfonkent mas): ami illik az izleshez, es az utobbi
    THEME_MEMORY hetben nem volt. force: masikat most (a "Masik tema" csempe).
    '''
    now = now or time.time()
    week = week_of(now)
    current = data.get('theme') or {}
    known = dict((theme[0], theme) for theme in THEMES)
    if not force and current.get('key') in known and (current.get('week') == week
                                                      or (current.get('week') or 0) < 100000):
        data['theme'] = {'key': current['key'], 'week': week}     # a regi (nem hetfoi) hetszamot atvesszuk
        return known[current['key']]
    shown = list(data.get('shown') or [])
    fresh = [theme for theme in THEMES if theme[0] not in shown[-THEME_MEMORY:] and theme[0] != current.get('key')] \
        or [theme for theme in THEMES if theme[0] != current.get('key')]
    start = week % len(fresh)
    ordered = fresh[start:] + fresh[:start]               # egyenlo pontnal hetente mas
    liked = top_genres()
    weight = dict((genre, len(liked) - index) for index, genre in enumerate(liked))
    theme = max(ordered, key=lambda theme: sum(weight.get(genre, 0) for genre in theme[3]))
    data['theme'] = {'key': theme[0], 'week': week}
    data['shown'] = (shown + [theme[0]])[-THEME_MEMORY:]
    return theme


# --- TMDB -> IMDb -> netmozi --------------------------------------------------------

class Finder(object):
    '''A jeloltek netmozis cimei (a talalatok a fajlban, a keresesek szama korlatos).'''

    def __init__(self, data, search, exclude, now, sleep, exclude_imdbs=()):
        self.data, self.search, self.exclude, self.now, self.sleep = data, search, exclude, now, sleep
        self.exclude_imdbs = set(exclude_imdbs)
        self.ids = data.setdefault('ids', {})
        self.found = data.setdefault('found', {})
        self.missing = data.setdefault('missing', {})
        self.searched = 0
        self.offline = False                      # a netmozi / a TMDB nem valaszolt: a regi sor marad

    def imdb(self, kind, tmdb_id):
        from resources.lib.modules import tmdb
        key = '%s:%s' % (kind, tmdb_id)
        if key not in self.ids:
            got = tmdb.external_imdb(kind, tmdb_id)
            if got is None:
                self.offline = True
                return ''
            self.ids[key] = got
        return self.ids[key]

    def on_netmozi(self, imdb):
        '''A netmozi sora (elmentve), vagy None.'''
        from resources.lib.modules import client, config, providers
        entry = self.found.get(imdb)
        checked = (entry or {}).get('checked', self.missing.get(imdb, 0))
        if (entry or imdb in self.missing) and 0 <= self.now - checked < RECHECK:
            return entry
        if self.offline or self.searched >= SEARCH_MAX or client.blocked_recently():
            return entry
        hits = self.search(imdb)
        self.searched += 1
        if hits is None:
            self.offline = True
            return entry
        row = providers.match(hits, imdb)
        if row is None:
            self.found.pop(imdb, None)
            self.missing[imdb] = int(self.now)
        else:
            slim = providers._slim(row)
            slim['checked'] = int(self.now)
            self.found[imdb] = slim
            self.missing.pop(imdb, None)
        self.sleep(config.PROVIDER_SEARCH_PAUSE)
        return self.found.get(imdb)

    def collect(self, candidates, extra_exclude=(), limit=ROW_TARGET):
        '''[(fajta, TMDB id)] -> a netmozin meglevo, meg nem latott cimek IMDb-je, sorrendben.'''
        out = []
        skip = self.exclude | set(extra_exclude)
        for kind, tmdb_id in candidates[:CANDIDATES_MAX]:
            if len(out) >= limit or self.offline:
                break
            imdb = self.imdb(kind, tmdb_id)
            if not imdb or imdb in out or imdb in self.exclude_imdbs:
                continue
            row = self.on_netmozi(imdb)
            if row and row.get('url') and pageurl.canonical(row['url']) not in skip:
                out.append(imdb)
        return out


def liked_row(finder):
    '''Mert tetszett: egy friss kedvenc (vagy a legutobb latott film) TMDB-ajanlasai.'''
    from resources.lib.modules import tmdb
    for page, title, imdb, thumb in seeds()[:SEEDS_MAX]:
        imdb = imdb or tmdb.imdb_id(thumb)
        if not imdb:
            continue
        record = tmdb.cached(imdb) or tmdb.fetch(imdb) or {}
        if not record.get('id'):
            continue
        ids = tmdb.recommendations(record.get('kind') or tmdb.MOVIE, record['id'])
        if ids is None:
            finder.offline = True
            return None
        imdbs = finder.collect([(record.get('kind') or tmdb.MOVIE, tmdb_id) for tmdb_id in ids], [page])
        if imdbs:
            return {'title': u'Mert tetszett: %s' % title, 'imdbs': imdbs}
    return {}


def collection_name(name):
    for suffix in (u' gyűjtemény', u' Collection', u' - gyűjtemény'):
        if name.endswith(suffix):
            name = name[:-len(suffix)]
    return name.strip()


def universe_row(finder):
    '''
    A legutobb latott filmek gyujtemenyeibol (legfeljebb UNIVERSE_MAX) a
    kovetkezo resz: a legutobb latott resz utani elso, ami megvan a netmozin
    es meg nem lattad; ha a vegere ertel, az elso kimaradt korabbi.
    '''
    from resources.lib.modules import tmdb
    colls = finder.data.setdefault('coll', {})
    tried, picks, names = set(), [], {}
    for _page, _title, thumb in watched_films()[:HISTORY_SCAN]:
        if len(picks) >= UNIVERSE_MAX:
            break
        imdb = tmdb.imdb_id(thumb)
        if not imdb:
            continue
        if imdb not in colls:
            got = tmdb.collection_of(imdb)
            if got is None:
                finder.offline = True
                return None
            colls[imdb] = got
        coll = colls[imdb]
        if not coll or coll['id'] in tried:
            continue
        tried.add(coll['id'])
        parts = tmdb.collection_parts(coll['id'])
        if parts is None:
            finder.offline = True
            return None
        part_imdbs = [finder.imdb(tmdb.MOVIE, tmdb_id) for tmdb_id in parts]
        seen = [index for index, part in enumerate(part_imdbs) if part and part in finder.exclude_imdbs]
        last = seen[-1] if seen else -1
        order = parts[last + 1:] + parts[:last + 1]
        got = finder.collect([(tmdb.MOVIE, tmdb_id) for tmdb_id in order], limit=1)
        if got:
            picks.append(got[0])
            names[got[0]] = collection_name(coll['name'])
    return {'title': u'Folytasd', 'imdbs': picks, 'names': names}


def theme_row(finder, force=False):
    '''Valogatas: a heti tema legjobbra ertekelt filmjei. force: masik tema most.'''
    from resources.lib.modules import tmdb
    theme = pick_theme(finder.data, finder.now, force)
    ids = []
    for page in (1, 2):
        got = tmdb.discover_keyword(theme[1], page)
        if got is None:
            finder.offline = True
            return None
        ids += got
        if len(got) < 20:
            break
    imdbs = finder.collect([(tmdb.MOVIE, tmdb_id) for tmdb_id in ids])
    return {'title': u'Válogatás: %s' % theme[2], 'imdbs': imdbs} if imdbs else {}


def run(search, now=None, sleep=time.sleep):
    '''A harom sor ujraszamolasa. Visszaad: hany netmozi-keresest vegzett.'''
    from resources.lib.modules import tmdb
    if not tmdb.api_key():
        return 0
    now = now or time.time()
    data = load()
    finder = Finder(data, search, seen_pages(), now, sleep, seen_imdbs())
    rows = data.setdefault('rows', {})
    for key, builder in (('liked', liked_row), ('universe', universe_row), ('theme', theme_row)):  # a universe a Folytatasba
        try:
            row = builder(finder)
        except Exception as exc:
            control.log_exception(u'válogatott lista (%s)' % key, exc)
            row = None
        if row is not None and not finder.offline:
            rows[key] = row
        finder.offline = False                     # a kovetkezo sor ujra probalkozik
    used = set(imdb for row in rows.values() for imdb in (row or {}).get('imdbs') or [])
    for store in (finder.found, finder.missing):
        for imdb in list(store):
            if imdb not in used and 0 <= now - ((store[imdb] or {}).get('checked', 0) if isinstance(store[imdb], dict)
                                                 else store[imdb]) >= RECHECK:
                del store[imdb]
    data['__meta__'] = {'last_run': int(now)}
    save(data)
    control.log(u'Válogatott listák: %s | Folytatás: %s (%d netmozi-keresés)' % (
        u' | '.join((rows.get(key) or {}).get('title') or u'-' for key in ROW_KEYS),
        u', '.join(((rows.get('universe') or {}).get('names') or {}).values()) or u'-', finder.searched))
    return finder.searched


def switch_theme(search, now=None, sleep=time.sleep, tries=3):
    '''
    A "Masik tema" csempe: a kovetkezo legjobban illo tema most (ez lesz a
    heti). Ha egy temabol nincs mit mutatni, a kovetkezot probalja. Visszaad:
    az uj sor cime, vagy None (nem sikerult).
    '''
    now = now or time.time()
    data = load()
    finder = Finder(data, search, seen_pages(), now, sleep, seen_imdbs())
    row = None
    for _attempt in range(tries):
        row = theme_row(finder, force=True)
        if row is None or finder.offline or row:
            break
    if row is None or finder.offline or not row:
        save(data)                                 # a TMDB-parositasok ne vesszenek el
        return None
    data.setdefault('rows', {})['theme'] = row
    save(data)
    control.log(u'Válogatás: másik téma -- %s (%d cím)' % (row['title'], len(row['imdbs'])))
    return row['title']


def rows(data=None):
    '''{sor kulcsa: [netmozi sor]} -- ami kozben latottnak szamit, kimarad.'''
    data = load() if data is None else data
    found = data.get('found') or {}
    seen, seen_ids = seen_pages(), seen_imdbs()
    out = {}
    for key in ROW_KEYS:
        items = []
        for imdb in ((data.get('rows') or {}).get(key) or {}).get('imdbs') or []:
            entry = found.get(imdb)
            if entry and entry.get('url') and pageurl.canonical(entry['url']) not in seen and imdb not in seen_ids:
                items.append(entry)
        out[key] = items
    return out


def next_parts(data=None):
    '''Az Ajanlo sor elejere: [(netmozi sor, gyujtemeny neve)] -- ami kozben latottnak szamit, kimarad.'''
    data = load() if data is None else data
    found = data.get('found') or {}
    universe = (data.get('rows') or {}).get('universe') or {}
    if 'names' not in universe:
        return []                                  # a regi (1.0.288-as) alak: az ujraszamolasig semmi
    names = universe.get('names') or {}
    seen, seen_ids = seen_pages(), seen_imdbs()
    out = []
    for imdb in universe.get('imdbs') or []:
        entry = found.get(imdb)
        if entry and entry.get('url') and pageurl.canonical(entry['url']) not in seen and imdb not in seen_ids:
            out.append((entry, names.get(imdb) or u''))
    return out


def titles(data=None):
    '''{sor kulcsa: cim} -- a sor sajat cime ("Mert tetszett: X"), ha van.'''
    data = load() if data is None else data
    return dict((key, ((data.get('rows') or {}).get(key) or {}).get('title') or title) for key, title in ROWS)
