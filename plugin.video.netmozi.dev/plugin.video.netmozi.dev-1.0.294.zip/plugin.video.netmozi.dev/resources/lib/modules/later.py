# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# "Kesobb megnezem": egy film felirasa a Sajat listara -- ertesites es izles
# nelkul (a kedvenc szive az ajanlot is alakitja, ez nem). Profilonkent kulon.
# Ha a filmet vegignezted, magatol lekerul.
#
# Fajl (a profil mappajaban): later.json  {oldal: {'title', 'thumb', 'imdb', 'added'}}

import json
import os
import time

from resources.lib.modules import control, pageurl


FILE = 'later.json'


def _path():
    return os.path.join(control.profileDir(), FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
    except (IOError, OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return dict((pageurl.canonical(page), entry) for page, entry in data.items() if isinstance(entry, dict))


def save(data):
    try:
        control.makeFile(control.profileDir())
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'később megnézem írása', exc)
        return False


def is_later(page, data=None):
    return bool(page) and pageurl.canonical(page) in (load() if data is None else data)


def pages():
    return set(load())


def toggle(page, title=u'', thumb=u'', imdb=u''):
    '''Fel / le a listarol. Visszaad: most rajta van-e.'''
    page = pageurl.canonical(page)
    data = load()
    if page in data:
        del data[page]
        save(data)
        return False
    data[page] = {'title': title or u'', 'thumb': thumb or '', 'imdb': imdb or '', 'added': int(time.time())}
    save(data)
    return True


def remove(page):
    page = pageurl.canonical(page)
    data = load()
    if page not in data:
        return False
    del data[page]
    return save(data)


def entries():
    '''A lista, a legutobb felirt elol; a mar vegignezett filmek lekerulnek (a fajlbol is).'''
    from resources.lib.modules import progress
    data = load()
    done = [page for page in data if progress.finished(progress.get(page) or {})]
    if done:
        for page in done:
            del data[page]
        save(data)
    items = [dict(entry, page=page) for page, entry in data.items()]
    return sorted(items, key=lambda entry: -(entry.get('added') or 0))
