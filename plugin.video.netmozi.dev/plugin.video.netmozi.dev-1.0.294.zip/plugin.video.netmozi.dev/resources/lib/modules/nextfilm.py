# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Kovetkezo film: ha egy film vegigment, a kezdokepernyo egy hasonlot ajanl
# -- szigoruan ugyanabbol a kategoriabol --, a reszletezojet betoltve, a
# lejatszas gombon fogyo korrel; ha a nezo nem nyul semmihez, indul. A
# Vissza a befejezett film adatlapjara visz. Egymas utan legfeljebb
# CHAIN_MAX-szor (igy osszesen harom film), utana megall.
#
# A jelolt a befejezett film fo kategoriajanak legnezettebb filmjei kozul
# jon (netmozi lista). Elol, aminek MINDEN kategoriaja egyezik; legalabb
# ketto (egykategorias filmnel az az egy) kozos kell. Nem ajanljuk, ami a
# kedvencek, a sajat lista (figyelt), a megnezett / elkezdett / nem
# tetszett cimek kozt van, se a lancban mar ajanlottat.

from resources.lib.modules import control, pageurl


COUNTDOWN = 12              # mp a magatol indulasig
CHAIN_MAX = 2               # ennyi ajanlott film egymas utan (+ az elso = 3)
PAGES = 3                   # a kategoria legnezettebb filmjei ennyi oldalrol (24/oldal)
PAGE_SIZE = 24
RING_FRAMES = 24            # a fogyo kor kepkockai: nm-ring-00.png .. nm-ring-24.png
END_SETTLE = 2.0            # mp a film vege utan (a haladast a szolgaltatas meg kiirja)


def enabled():
    try:
        return (control.setting('nextfilm') or 'true').lower() != 'false'
    except Exception:
        return True


def ring_texture(left, total=COUNTDOWN):
    '''A fogyo kor kepkockaja a hatralevo idohoz.'''
    import math
    frame = max(0, min(RING_FRAMES, int(math.ceil(RING_FRAMES * max(0.0, left) / float(total or 1)))))
    return 'nm-ring-%02d.png' % frame


def excluded_pages():
    '''Amit nem ajanlunk: kedvenc, sajat lista (figyelt, kesobb megnezem), megnezett, elkezdett / vegignezett, nem tetszett.'''
    from resources.lib.modules import history, marks, progress, taste, watchlist
    out = set()
    from resources.lib.modules import later
    sources = (lambda: watchlist.load(), lambda: later.pages(), lambda: taste.favorite_pages(), lambda: taste.disliked(),
               lambda: marks.pages(), lambda: progress.load(),
               lambda: [entry.get('page') or entry.get('key') for entry in history.load()])
    for source in sources:
        try:
            out |= set(pageurl.canonical(page) for page in source() or [] if page)
        except Exception as exc:
            control.log_exception(u'következő film: kizárások', exc)
    return out


def categories_for(thumb, search):
    '''A film kategoriai a netmozi keresojebol (az IMDb-vel pontosan azt az egy cimet adja).'''
    from resources.lib.modules import providers, tmdb
    imdb = tmdb.imdb_id(thumb or '')
    if not imdb:
        return []
    hits = search(imdb)
    row = providers.match(hits or [], imdb)
    return list((row or {}).get('categories') or [])


def rank(candidates, categories, exclude):
    '''
    A jeloltek (netmozi sorok) a legjobb elol: film, nincs kizarva, megvan a
    fo kategoria es legalabb ketto (egykategorias filmnel az az egy) kozos;
    elol, aminek minden kategoriaja egyezik, aztan a tobb kozos, aztan a
    lista sorrendje (nezettseg).
    '''
    cats = [c for c in categories or [] if c]
    if not cats:
        return []
    want = set(cats)
    need = min(len(want), 2)
    scored, seen = [], set()
    for index, row in enumerate(candidates or []):
        page = pageurl.canonical(row.get('url') or '')
        if not page or page in seen or row.get('isSeries') or page in exclude:
            continue
        seen.add(page)
        have = set(row.get('categories') or [])
        shared = len(want & have)
        if cats[0] not in have or shared < need:
            continue
        scored.append((0 if want <= have else 1, -shared, index, row))
    scored.sort(key=lambda item: item[:3])
    return [item[3] for item in scored]


def pick(categories, exclude, fetch_page, options):
    '''
    A legjobb jelolt (netmozi sor), vagy None. fetch_page(mufaj erteke, oldal)
    -> sorok (None halozati hibanal); options: [(ertek, felirat)] a netmozi
    mufajai. A fo kategoria az elso, amelyik a netmozi mufajai kozt van.
    '''
    values = dict((label, value) for value, label in options or [])
    primary = next((c for c in categories or [] if c in values), None)
    if primary is None:
        return None
    ordered = [primary] + [c for c in categories if c != primary]
    pool = []
    for page in range(1, PAGES + 1):
        rows = fetch_page(values[primary], page)
        if rows is None:
            break
        pool += rows
        ranked = rank(pool, ordered, exclude)
        if ranked and set(ranked[0].get('categories') or []) >= set(ordered):
            return ranked[0]                     # teljes egyezes: nem kell tovabb lapozni
        if len(rows) < PAGE_SIZE:
            break
    ranked = rank(pool, ordered, exclude)
    return ranked[0] if ranked else None


def find(watched, chain_seen, search):
    '''
    A kovetkezo film egy befejezetthez ({'page', 'thumb', 'genres'}): netmozi
    sor vagy None. A hatterszalbol (halozat).
    '''
    from resources.lib.modules import cache, home
    categories = list(watched.get('genres') or []) or categories_for(watched.get('thumb'), search)
    if not categories:
        control.log(u'Következő film: a kategória nem derült ki')
        return None
    exclude = excluded_pages() | set(chain_seen or ()) | {pageurl.canonical(watched.get('page') or '')}

    def fetch_page(value, page):
        url = home.genre_url(value, page, order=home.ORDER_MOST_VIEWED, tipus='1')
        return cache.get(home.fetch_listing, home.CACHE_HOURS, url, '1')
    row = pick(categories, exclude, fetch_page, home.genre_options())
    control.log(u'Következő film (%s): %s' % (u', '.join(categories), (row or {}).get('title') or u'nincs'))
    return row
