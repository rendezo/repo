# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Kozos torrent-fiok: az nCore es a bithumen belepoje a kulcs-kozvetito
# Workeren, a titkos PIN mogott (GET /creds, csak a PIN nyitja). Akinek a
# TV-jen be van irva a PIN, es a sajat nCore / bithumen mezoi uresek, az ezt
# hasznalja; a sajat mezo mindig elsobbseget elvez.
#
# A Worker valaszat a profil mappaba is elmentjuk (CACHE_HOURS-ig friss),
# hogy ne kelljen minden inditasnal kerdezni, es ha a Worker epp nem erheto
# el, a lejatszas akkor is menjen. Mas PIN-nel a mentett nem ervenyes (a
# PIN lenyomata van mellette, nem a PIN). Ha az oldal elutasitja (a jelszo
# kozben valtozott), a hivo refresh=True-val ujrakeri.

import hashlib
import json
import os
import time

from resources.lib.modules import control


CACHE_FILE = 'shared-accounts.json'
CACHE_HOURS = 6
RETRY_AFTER = 600            # mp: ha a Worker nem valaszolt, ennyi ideig nem kerdezzuk ujra
NAMES = ('ncore', 'bithumen')
OWN_FIELDS = {'ncore': ('ncoreuser', 'ncorepass'), 'bithumen': ('bhuid', 'bhpass')}
_memory = {}


def _path():
    return os.path.join(control.dataPath, CACHE_FILE)


def fingerprint(pin):
    return hashlib.sha256(('netmozi-kozos|' + (pin or '')).encode('utf-8')).hexdigest()[:16]


def _pin():
    try:
        return (control.setting('keypin') or '').strip()
    except Exception:
        return ''


def _load():
    if 'data' not in _memory:
        try:
            with open(_path(), encoding='utf-8') as handle:
                data = json.load(handle)
        except (IOError, OSError, ValueError):
            data = {}
        _memory['data'] = data if isinstance(data, dict) else {}
    return _memory['data']


def _save(data):
    _memory['data'] = data
    try:
        if not os.path.isdir(control.dataPath):
            os.makedirs(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except (IOError, OSError) as exc:
        control.log_exception(u'közös fiók mentése', exc)


def forget():
    _memory.pop('data', None)
    try:
        os.remove(_path())
    except OSError:
        pass


def _clean(raw):
    '''A Worker valaszabol csak a vart mezok, szovegkent.'''
    out = {}
    if not isinstance(raw, dict):
        return out
    for name, keys in (('ncore', ('user', 'pass')), ('bithumen', ('uid', 'pass'))):
        item = raw.get(name)
        if isinstance(item, dict) and all(isinstance(item.get(k), str) and item.get(k).strip() for k in keys):
            out[name] = dict((k, item[k].strip()) for k in keys)
    return out


def fetch():
    '''
    A Workertol: ('ok', {nev: {...}}) -- ures szotar, ha semmi nincs
    megosztva --, ('denied', None) ha a PIN nem nyitja, ('offline', None) ha
    nincs PIN / kozvetito, vagy a Worker nem erheto el.
    '''
    from resources.lib.modules import client
    pin, proxy = _pin(), control.keyProxy()
    if not pin or not proxy:
        return 'offline', None
    response = client.request(proxy + '/creds', headers={'X-NM': pin}, output='response', timeout=10)
    if not response:
        return 'offline', None
    status, text = response
    if status == '404':
        control.log(u'Közös fiók: a PIN nem nyitja', control.LOGWARNING)
        return 'denied', None
    if status != '200':
        return 'offline', None
    try:
        return 'ok', _clean(json.loads(text))
    except ValueError:
        return 'offline', None


def own_set(name):
    '''A TV-n be van-e irva a sajat belepes ehhez az oldalhoz.'''
    try:
        return any((control.setting(field) or '').strip() for field in OWN_FIELDS[name])
    except Exception:
        return False


def refresh(now=None):
    '''
    Ujrakeri a Workertol, elmenti, es jelzi, mi valtozott. Egy oldalt egyszer
    (a legelso alkalommal) magatol bekapcsol, ha a TV-n nincs hozza sajat
    belepes -- igy a csak PIN-nel beallitott TV-n rogton megy. Ha a nezo
    kesobb kikapcsolja, nem kapcsoljuk vissza. Visszaad: a megosztott oldalak
    neve, vagy None (nem sikerult).
    '''
    now = now or time.time()
    _memory['tried'] = now
    state, creds = fetch()
    data = dict(_load())
    if state == 'denied' or (data.get('pin') and data.get('pin') != fingerprint(_pin())):
        forget()                                 # a PIN mar nem nyitja / masik PIN: a mentett nem jo
    if state != 'ok':
        return None
    old = data.get('creds') or {}
    applied = list(data.get('applied') or [])
    for name in creds:
        if name not in applied:
            applied.append(name)
            if not own_set(name):
                control.setSetting(name, 'true')
                control.log(u'Közös fiók: %s bekapcsolva' % name)
    for name in NAMES:
        if old.get(name) != creds.get(name):
            _forget_session(name)
    _save({'pin': fingerprint(_pin()), 'at': now, 'creds': creds, 'applied': applied})
    return sorted(creds)


def _forget_session(name):
    '''Mas lett a belepes: az oldal mentett munkamenete (nCore) / passkeye (bithumen) nem jo.'''
    try:
        if name == 'ncore':
            from resources.lib.modules import ncore
            ncore.forget()
        elif name == 'bithumen':
            from resources.lib.modules import bithumen
            bithumen.forget()
    except Exception as exc:
        control.log_exception(u'közös fiók: munkamenet törlése', exc)


def get(name, refresh_now=False, now=None):
    '''
    A kozos belepes egy oldalhoz ({'user','pass'} / {'uid','pass'}), vagy {}.
    A mentettet adja, ha friss es ehhez a PIN-hez tartozik; kulonben ujrakeri
    (ha az nem sikerul, a mentett marad, amig a PIN ugyanaz).
    '''
    now = now or time.time()
    pin = _pin()
    if not pin:
        return {}
    data = _load()
    mine = data.get('pin') == fingerprint(pin)
    fresh = mine and 0 <= now - (data.get('at') or 0) < CACHE_HOURS * 3600
    since = now - (_memory.get('tried') or 0)
    if (refresh_now and not 0 <= since < 60) or (not fresh and not 0 <= since < RETRY_AFTER):
        refresh(now)
        data = _load()
        mine = data.get('pin') == fingerprint(pin)
    return dict((data.get('creds') or {}).get(name) or {}) if mine else {}


def source(name):
    '''Honnan jon a belepes: 'own' (a TV-n beirt), 'shared' (kozos fiok), vagy ''.'''
    if own_set(name):
        return 'own'
    return 'shared' if get(name) else ''
