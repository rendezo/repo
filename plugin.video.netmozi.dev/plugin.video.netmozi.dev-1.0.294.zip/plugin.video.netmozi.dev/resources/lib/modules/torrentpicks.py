# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Torrent-ajanlok a kezdokepernyon, ket uj sorban:
#   nCore      recommended.php: a Film es a Sorozat doboz "Staff altal jelolt" resze
#   bithumen   community.php?cat=all: "Masok altal ajanlott torrentek" (csak film / sorozat)
#
# A listakban nincs IMDb-azonosito: a torrent adatlapjarol jon (egyszer, utana
# megjegyezve). Az IMDb-vel a netmozi keresoje dont (megvan-e ott: akkor a
# netmozi teteleként latszik), a netmozin nem levo cimek a TMDB magyar cimevel
# es poszterevel latszanak, es torrentrol indulnak. Csak a bekapcsolt
# torrent-oldal sora latszik. A kezdokepernyo hatterszalabol fut, PICKS_INTERVAL-onkent.
#
# Fajl: torrentpicks.json
#   {'__meta__': {'last_run'},
#    'imdb':    {'nc:4235921': 'tt...', 'bh:1305703': ''}      torrent -> IMDb ('' ha nincs rajta)
#    'info':    {'tt...': {'title', 'thumb', 'year', 'kind', 'tmdb'}}
#    'found':   {'tt...': {netmozi sor, 'checked'}}, 'missing': {'tt...': checked}
#    'rows':    {'ncorepicks': ['tt...', ...], 'bhpicks': [...]}}

import json
import os
import re
import time

from resources.lib.modules import control


FILE = 'torrentpicks.json'
ROWS = (('ncorepicks', 'ncore', 'nc'), ('bhpicks', 'bithumen', 'bh'))
ROW_KEYS = tuple(key for key, _tracker, _prefix in ROWS)
PICKS_INTERVAL = 12 * 3600       # ennyi idonkent olvassuk ujra az ajanlokat
RECHECK = 2 * 24 * 3600          # a netmozi-talalat (es a "nincs") ennyi ido utan ujra: friss cimek
DETAILS_MAX = 50                 # egy futasban legfeljebb ennyi torrent-adatlap (az elso futas kb. 45)
SEARCH_MAX = 60                  # es ennyi netmozi-kereses
PAUSE = 0.4                      # mp a torrent-adatlapok kozt


def _path():
    return os.path.join(control.dataPath, FILE)


def load():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def save(data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'torrent-ajánlók írása', exc)
        return False


def _module(tracker):
    from resources.lib.modules import bithumen, ncore
    return ncore if tracker == 'ncore' else bithumen


def _enabled(tracker):
    try:
        return _module(tracker).enabled()
    except Exception:
        return False


def any_enabled():
    return any(_enabled(tracker) for _key, tracker, _prefix in ROWS)


def due(now=None):
    now = now or time.time()
    meta = load().get('__meta__') or {}
    return any_enabled() and not 0 <= now - (meta.get('last_run') or 0) < PICKS_INTERVAL


def clean_title(title):
    """
    A torrent nevebol olvashato cim (ha a TMDB nem ismeri): "Runner.2026.1080p..." ->
    "Runner", "Alice.in.Borderland.S01.1080p" -> "Alice in Borderland", "1945 BD25" -> "1945".
    """
    text = (title or u'').replace(u'.', u' ').replace(u'_', u' ')
    padded = u' ' + text
    cuts = [m.start() for m in re.finditer(
        r'(?i)\s(?:(?:19|20)\d{2}|S\d{1,2}(?:E\d+)?|BD\d\d|\d{3,4}p|complete|retail|hun|web|bluray)\b', padded) if m.start() > 0]
    if cuts:
        text = padded[:cuts[0]]
    return re.sub(r'\s+', u' ', text).strip(u' -') or (title or u'')


def run(search, now=None, sleep=time.sleep, force=False):
    '''
    Az ajanlok ujraolvasasa. A `search(szoveg)` a netmozi keresese
    (navigator.searchMovies). Visszaad: hany uj torrent-adatlapot nyitottunk meg.
    '''
    from resources.lib.modules import client, providers, tmdb
    now = now or time.time()
    data = load()
    imdbs = data.setdefault('imdb', {})
    info = data.setdefault('info', {})
    found = data.setdefault('found', {})
    missing = data.setdefault('missing', {})
    rows = data.setdefault('rows', {})
    opened = 0
    for row_key, tracker, prefix in ROWS:
        if not _enabled(tracker):
            continue
        module = _module(tracker)
        picks = module.recommended()
        if picks is None:
            control.log(u'%s ajánló: most nem érhető el (marad a régi sor)' % tracker, control.LOGWARNING)
            continue
        order = []
        for pick in picks:
            key = '%s:%s' % (prefix, pick['id'])
            if key not in imdbs:
                if opened >= DETAILS_MAX:
                    continue
                got = module.imdb_of(pick['id'])
                opened += 1
                sleep(PAUSE)
                if got is None:
                    continue                          # halozati hiba: legkozelebb
                imdbs[key] = got
            imdb = imdbs[key]
            if not imdb or imdb in order:
                continue
            order.append(imdb)
            if imdb not in info:
                info[imdb] = {'title': pick.get('title') if tracker == 'bithumen' else clean_title(pick.get('title')),
                              'thumb': pick.get('thumb') or '', 'year': pick.get('year') or '',
                              'kind': 'tv' if pick.get('kind') == 'series' else 'movie'}
        rows[row_key] = order

    listed = []
    for row_key in ROW_KEYS:
        for imdb in rows.get(row_key) or []:
            if imdb not in listed:
                listed.append(imdb)
    # Magyar cim, poszter: a TMDB-tol (egyszer). Kulon kor, hogy a netmozi kiesese ne akassza meg.
    for imdb in listed:
        meta = info.setdefault(imdb, {})
        if 'tmdb' not in meta:
            got = tmdb.find_basic(imdb)
            if got is not None:
                meta['tmdb'] = 1 if got else 0
                if got:
                    meta.update(title=got['title'] or meta.get('title', u''), year=got['year'] or meta.get('year', ''),
                                kind=got['kind'], thumb=got['poster'] or meta.get('thumb', ''))
    searched = 0
    for imdb in listed:
        entry = found.get(imdb)
        checked = (entry or {}).get('checked', missing.get(imdb, 0))
        if (entry or imdb in missing) and 0 <= now - checked < RECHECK and not force:
            continue
        if searched >= SEARCH_MAX or client.blocked_recently():
            continue
        hits = search(imdb)
        searched += 1
        if hits is None:
            control.log(u'torrent-ajánlók: a netmozi keresés nem érhető el', control.LOGWARNING)
            break
        row = providers.match(hits, imdb)
        if row is None:
            found.pop(imdb, None)
            missing[imdb] = int(now)
        else:
            slim = providers._slim(row)
            slim['checked'] = int(now)
            found[imdb] = slim
            missing.pop(imdb, None)
        sleep(providers.config.PROVIDER_SEARCH_PAUSE)
    # Ami mar egyik sorban sincs: takaritas (az adatlap -> IMDb parositas marad, kicsi).
    for store in (info, found, missing):
        for imdb in list(store):
            if imdb not in listed:
                del store[imdb]
    data['__meta__'] = {'last_run': int(now)}
    save(data)
    control.log(u'torrent-ajánlók: %s (%d új adatlap, %d netmozi-keresés)' % (
        u', '.join('%s %d' % (key, len(rows.get(key) or [])) for key in ROW_KEYS), opened, searched))
    return opened


def rows(data=None):
    '''
    {sor kulcsa: [netmozi sor, vagy a jelolt {'imdb', 'title', 'thumb', 'year', 'kind'}]}
    -- csak a bekapcsolt torrent-oldal sora (a tobbi ures).
    '''
    data = load() if data is None else data
    found = data.get('found') or {}
    info = data.get('info') or {}
    out = {}
    for row_key, tracker, _prefix in ROWS:
        items = []
        if _enabled(tracker):
            for imdb in (data.get('rows') or {}).get(row_key) or []:
                entry = found.get(imdb)
                if entry and entry.get('url'):
                    items.append(entry)
                else:
                    meta = info.get(imdb) or {}
                    items.append({'imdb': imdb, 'title': meta.get('title') or imdb, 'thumb': meta.get('thumb') or '',
                                  'year': meta.get('year') or '', 'kind': meta.get('kind') or 'movie'})
        out[row_key] = items
    return out
