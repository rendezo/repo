# NetMozi (dev)

Kodi videó-bővítmény, ami a netmozi.com kínálatát teszi elérhetővé.

Ez a [vargalex/plugin.video.netmozi](https://github.com/vargalex/plugin.video.netmozi)
**módosított változata**, saját bővítmény-azonosítóval (`plugin.video.netmozi.dev`),
hogy a hivatalos repó frissítései ne írják felül a helyi változtatásokat.

Kodi 19 (Matrix) vagy újabb szükséges.

## Telepítés

```bash
python3 build.py
```

Az elkészült `dist/plugin.video.netmozi.dev-<verzió>.zip` telepíthető:
**Beállítások → Kiegészítők → Telepítés zip-fájlból**.

A build szándékosan kihagyja a fejlesztői fájlokat (`tests/`, `tools/`, `_deps/`),
és a zipen belüli mappát mindig az `addon.xml`-ben szereplő azonosítóra nevezi.

> A régi `NetMozi` bővítményt érdemes eltávolítani telepítés előtt — külön
> azonosító miatt a kettő egymás mellett is megélne.

## Mi változott az eredetihez képest

### Új funkciók

**Év szerinti szűrés.** A Filmek és Sorozatok menü tetején „Év szűrő" sor;
bármelyik rendezés szűkíthető egy évre. Szerveroldali szűrés, tehát a lapozás
és az elemszám is helyes marad.

**Stream Top 10.** A főmenü tetején a Netflix, Apple TV (filmek és sorozatok)
és a Prime Video aktuális magyarországi top listája, magyar címekkel és
borítóval — plusz egy „Mind egyben" nézet. Egy címre lépve rákeres a netmozi
kínálatában.

**Automatikus indítás.** Ha egy top listás címre pontosan egy találat jön,
a bővítmény magától elindítja az első működő forrást. Sorban próbálja őket
(érvényesek elöl), és továbblép, ha egy forrás nem oldható fel vagy a
lejátszás nem indul el időben. Végig látszik, hol tart. Kikapcsolható.

**Sorozat-folytatás.** Sorozatnál az évadok listája jön, és a rész
megnyitása indít. A rész végén magától jön a következő: ha telepítve van az
[Up Next](https://kodi.wiki/view/Add-on:UpNext), az mutatja a visszaszámlálós
ablakot, különben lejátszási listával oldja meg. A kettő szándékosan kizárja
egymást.

**Amit már láttam.** A főmenüben, a Stream Top 10 alatt: minden elindított
film és rész felkerül ide. A lista a **film címét** mutatja, és a netmozi
adatlapra mutat — az nem jár le, ellentétben a feloldott stream URL-lel.
A bővítmény megjegyzi, melyik forrás vált be, és újranézéskor azzal kezdi,
így jellemzően elsőre elindul. Helyi menüvel egy tétel törölhető.

**Karbantartás fül a beállításokban.**
- *Diagnosztika futtatása* — végigjárja az élő oldalt, és megnevezi, melyik
  szelektor romlott el
- *Eredeti bővítmény változásai* — megmutatja, adott-e ki javítást az
  eredeti szerző

### Átalakítások

- **HTTP réteg `requests`-re.** A régi `urllib2`-s kód minden kivételt némán
  elnyelt, ezért a hiba egy szinttel feljebb, értelmezhetetlen `IndexError`-ként
  bukkant fel. Most minden hibaág konkrét okot naplóz.
- **Szelektorok egy helyen.** Minden HTML-osztálynév, regex és szöveges marker
  a `config.py`-ba került; a `navigator.py`-ban nem maradt egy sem. Oldal-változáskor
  egy fájlban kell javítani.
- **Beszédes hibák.** Hiányzó elemnél a bővítmény megnevezi, mi hiányzik
  (`cím (.col_name)`), a felhasználó pedig értelmes üzenetet kap.
- **Gyorsítótár.** `eval()` helyett JSON, string-fűzött SQL helyett paraméteres.
- **Python 2 kigyomlálva.** Nincs több verzió-elágazás.

### Javított hibák

- A lista játékideje percben ment át a Kodinak másodperc helyett
- A `Külfüldi` elírás
- A gyorsítótár argumentum-kulcsa `TypeError`-t dobott, így a kulcs egy
  memóriacím lett
- A Prime Video fekvő borítói megnyúltak poszter-nézetben
- Egy átmeneti hiba a Netflix magyar listájánál 24 órára beragasztotta az
  angol tartaléklistát

## Felépítés

```
default.py                      útválasztó
resources/lib/indexers/
  navigator.py                  minden menü és a lejátszási lánc
resources/lib/modules/
  config.py                     MINDEN oldal-specifikus szelektor
  client.py                     HTTP (requests) + HTML feldolgozás
  cache.py                      sqlite gyorsítótár
  streams.py                    Stream Top 10 szolgáltatók
  netflix.py                    Netflix magyar lista + globális tartalék
  upnext.py                     Up Next integráció
  diagnostics.py                beépített önellenőrzés
  upstream.py                   az eredeti bővítmény figyelése
  control.py                    Kodi API + naplózás
  utils.py                      segédfüggvények
```

## Fejlesztés

```bash
python3 tests/fetch_fixtures.py     # egyszer: friss HTML letöltése
python3 tests/run_all.py            # minden teszt, végigvezetve
```

286 ellenőrzés 9 készletben, Kodi nélkül fut. Részletek:
[tests/README.md](tests/README.md).

Ha az oldal változik, a tesztek megnevezik a hibás szelektort, ami a
`config.py`-ban javítható. Hátha az eredeti szerző már megoldotta:

```bash
python3 tools/check_upstream.py --diff
```

## Külső függőségek

`script.module.requests`, `script.module.resolveurl`,
`script.module.inputstreamhelper`. Fejlesztéshez letölthetők a `_deps/`
mappába (nincs verziókövetve) — lásd `_deps/README.md`.

## Licenc

GPL-3.0, ahogy az eredeti bővítmény. Az eredeti szerző: vargalex.
