# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
from urllib.parse import parse_qsl

# A hozzászólás-kérés fájlneve. Ugyanaz, mint comments.REQUEST_FILE -- azt
# NEM importáljuk, mert a modul a nehéz importláncot húzná be; a tesztsor
# ellenőrzi, hogy a kettő egyezik.
COMMENT_REQUEST_FILE = 'comments.request'


def quick_comment_request():
    """
    Jelzés a háttérszolgáltatásnak, hogy hozza vissza a hozzászólásokat.

    SZÁNDÉKOSAN a nehéz importok ELŐTT fut le, és csak azt tölti be, amire
    tényleg szükség van. A Kodi minden gombnyomásra új folyamatot indít, és
    a navigator importja (resolveurl, requests, tíz belső modul) több
    másodpercet vinne el egyetlen fájl írásához.
    """
    import os

    import xbmcaddon
    import xbmcvfs

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    try:
        if not os.path.exists(profile):
            os.makedirs(profile)
        with open(os.path.join(profile, COMMENT_REQUEST_FILE), 'w') as handle:
            handle.write('1')
    except OSError:
        pass


def route(params):
    '''A plugin:// URL query-jét a megfelelő navigator metódusra képezi.'''
    from resources.lib.indexers import navigator
    from resources.lib.modules import control

    action = params.get('action')
    nav = navigator.navigator()

    if action is None:
        return nav.root()
    if action == 'base':
        return nav.getOrderTypes(params.get('type'), params.get('year'))
    # A 'netflix*' nevek régebbi kedvencekben/widgetekben még élhetnek.
    if action in ('streams', 'netflix'):
        return nav.getStreams()
    if action == 'streamtop':
        return nav.getStreamTop(params.get('provider'))
    if action in ('playtitle', 'netflixplay'):
        return nav.playTitle(params.get('search'))
    if action == 'netflixtop':
        return nav.getNetflixTop10(params.get('category'))
    if action == 'years':
        return nav.getYears(params.get('type'))
    if action == 'movies':
        return nav.getMovies(params.get('type'), params.get('page'),
                             params.get('order'), params.get('search'),
                             params.get('year'))
    if action == 'movie':
        return nav.getMovie(params.get('url'))
    if action == 'playmovie':
        return nav.playmovie(params.get('url'), params.get('subtitled') == 'true')
    if action == 'search':
        return nav.getSearches()
    if action == 'series':
        return nav.getSeries(params.get('url'), params.get('auto') == '1')
    if action == 'episodes':
        return nav.getEpisodes(params.get('url'), params.get('serie'),
                               params.get('auto') == '1')
    if action == 'sources':
        return nav.showSources(params.get('url'))
    if action == 'playdirect':
        return nav.playDirect(params.get('url'))
    if action == 'playepisode':
        return nav.playEpisode(params.get('url'))
    if action == 'resolveepisode':
        return nav.resolveEpisode(params.get('url'), params.get('skip') == '1')
    if action == 'searchbuilder':
        return nav.getSearchBuilder(params)
    if action == 'searchpick':
        return nav.pickSearchField(params.get('field'), params)
    if action == 'searchrun':
        return nav.runSearch(params)
    if action == 'adultlist':
        return nav.adultList()
    if action == 'adultsearch':
        return nav.adultSearch()
    if action == 'adultresults':
        return nav.adultResults(params.get('query'), params.get('page'))
    if action == 'adultplay':
        return nav.adultPlay(params.get('url'))
    if action == 'newsearch':
        return nav.doSearch()
    if action == 'deletesearchhistory':
        return nav.deleteSearchHistory()
    if action == 'clearcache':
        return nav.clearCache()
    if action == 'recommended':
        return nav.getRecommended()
    if action == 'recommendedlist':
        return nav.getRecommendedList(params.get('type'))
    if action == 'history':
        return nav.getHistory()
    if action == 'historyplay':
        return nav.playHistory(params.get('url'))
    if action == 'historyremove':
        return nav.removeHistory(params.get('url'))
    if action == 'historyclear':
        return nav.clearHistory()
    if action == 'comments':
        return nav.requestComments()
    if action == 'commentkey':
        return nav.installCommentKey()
    if action == 'commentlearn':
        return nav.learnCommentKey()
    if action == 'diagnostics':
        return nav.runDiagnostics()
    if action == 'updatecheck':
        return nav.forceUpdate()
    if action == 'upstreamcheck':
        return nav.checkUpstream()

    control.log_error('Ismeretlen action: %s' % action)
    return nav.root()


if __name__ == '__main__':
    _params = dict(parse_qsl(sys.argv[2].replace('?', '', 1)))
    if _params.get('action') == 'comments':
        # Gyors ág: nincs mögötte menü, csak egy jelzés.
        quick_comment_request()
    else:
        from resources.lib.indexers import navigator
        from resources.lib.modules import control
        route(_params)
