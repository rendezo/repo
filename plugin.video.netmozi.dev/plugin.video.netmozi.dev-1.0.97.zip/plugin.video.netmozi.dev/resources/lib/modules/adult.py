# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Rejtett, felnottkorhoz kotott lista.
#
# Nincs hozza menupont sehol: kizarolag ugy erheto el, hogy a keresobe a
# config.ADULT_KEYWORD szot irjuk be. A kulcsszo NEM kerul be sem a keresesi
# elozmenybe, sem a "Mar lattam" listaba -- kulonben a rejtes ertelmetlen lenne.
#
# A netmozi szelektorai a config.py-ban vannak; ez viszont egy masik forras,
# ezert a sajat mintai -- a streams.py es a netflix.py mintajara -- itt, egy
# helyen allnak.

import re

try:
    from urllib.parse import quote_plus
except ImportError:                                   # pragma: no cover
    from urllib import quote_plus

from resources.lib.modules import client


BASE = 'https://www.xvideos.com'

# A lapozas nullatol indul: az elso oldal p=0, a masodik p=1.
SEARCH_URL = BASE + '/?k=%s&p=%s'

# Egy talalati sor a "<div id=video_..." jelolessel kezdodik. A befoglalo
# osztaly "frame-block thumb-block", de a sorhatarhoz az id a megbizhatobb.
ROW_SPLIT = r'<div id="video_'

LINK_RE = r'<a href="(/video[^"]+)"'
# A borito lusta toltessel jon: a src csak egy ures gif, a valodi kep data-src.
THUMB_RE = r'data-src="(https://[^"]+\.jpg)"'
DURATION_RE = r'<span class="duration">([^<]+)</span>'
TITLE_RE = r'<a href="/video[^"]+" title="([^"]*)"'
QUALITY_RE = r'<span class="video-hd-mark">([^<]*)</span>'

# Perc -> masodperc. Az oldal magyarul is kiirja ("33 perc"), de biztos, ami
# biztos: barmilyen szoveg elso szamat elfogadjuk.
MINUTES_RE = r'(\d+)'

# A videooldal a lejatszhato cimeket egy JS-hivasban adja meg.
STREAM_PATTERNS = (
    ('mp4_high', r"setVideoUrlHigh\('([^']+)'\)"),
    ('mp4_low', r"setVideoUrlLow\('([^']+)'\)"),
    ('hls', r"setVideoHLS\('([^']+)'\)"),
)
PAGE_TITLE_RE = r"setVideoTitle\('([^']*)'\)"
PAGE_THUMB_RE = r"setThumbUrl\('([^']+)'\)"

# Ennel tobb sort nem dolgozunk fel egy oldalrol -- az oldal ennyit ad.
MAX_ROWS = 40


def _unescape(text):
    '''A cimekben HTML-entitasok es JS-eskapolas is elofordul.'''
    if not text:
        return ''
    try:
        from html import unescape
        text = unescape(text)
    except ImportError:                               # pragma: no cover
        pass
    return text.replace('\\/', '/').replace("\\'", "'").strip()


def parse(html):
    '''A talalati oldal sorai: [{title, url, thumb, duration, quality}].'''
    rows = []
    for chunk in re.split(ROW_SPLIT, html or '')[1:MAX_ROWS + 1]:
        link = re.search(LINK_RE, chunk)
        if not link:
            continue
        title = re.search(TITLE_RE, chunk)
        thumb = re.search(THUMB_RE, chunk)
        duration = re.search(DURATION_RE, chunk)
        quality = re.search(QUALITY_RE, chunk)

        minutes = 0
        if duration:
            found = re.search(MINUTES_RE, duration.group(1))
            minutes = int(found.group(1)) if found else 0

        rows.append({
            'title': _unescape(title.group(1)) if title else link.group(1),
            'url': BASE + link.group(1),
            'thumb': thumb.group(1) if thumb else '',
            # A Kodi masodpercet var; az oldal percet ir ki.
            'duration': minutes * 60,
            'quality': (quality.group(1) or '').strip() if quality else '',
        })
    return rows


def homepage():
    """
    A cimlap listaja. Halozati hibanal None.

    Csak EGY oldal van: a "?p=1" ugyanazt a 40 tetelt adja vissza, ezert itt
    nincs lapozo -- ellentetben a keresessel, ami rendesen lapozhato.
    """
    html = client.request(BASE + '/')
    if html is None:
        return None
    return parse(html)


def search(query, page=1):
    '''
    Kereses talalatai.

    Halozati hibanal None, hogy meg lehessen kulonboztetni az "ures talalat"
    esettol -- ugyanaz az elv, mint a navigator.searchMovies-nal.
    '''
    page = max(1, int(page or 1))
    html = client.request(SEARCH_URL % (quote_plus(query or ''), page - 1))
    if html is None:
        return None
    return parse(html)


def stream(url):
    '''
    Egy video lejatszhato cime: {'url', 'title', 'thumb'}. Hibanal None.

    Az MP4 az elsodleges: az adaptiv stream (HLS) plusz kiegeszitot igenyel,
    az MP4 viszont mindenhol megy. A HLS csak tartalek.
    '''
    html = client.request(url)
    if html is None:
        return None
    for _name, pattern in STREAM_PATTERNS:
        found = re.search(pattern, html)
        if found and found.group(1):
            title = re.search(PAGE_TITLE_RE, html)
            thumb = re.search(PAGE_THUMB_RE, html)
            return {'url': _unescape(found.group(1)),
                    'title': _unescape(title.group(1)) if title else '',
                    'thumb': _unescape(thumb.group(1)) if thumb else ''}
    return None
