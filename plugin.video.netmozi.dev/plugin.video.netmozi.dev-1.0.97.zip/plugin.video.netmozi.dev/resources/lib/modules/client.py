# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import html as html_lib
import random
import re
import time
from urllib.parse import unquote_plus, urljoin, urlparse

import requests
import urllib3

from resources.lib.modules import cache, config, control

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_TIMEOUT = 30
DEFAULT_HEADERS = {
    'Accept-Language': 'hu-HU,hu;q=0.8,en-US;q=0.6,en;q=0.4,de;q=0.2',
}
FORM_CONTENT_TYPE = 'application/x-www-form-urlencoded'

# Egy plugin-hivason belul eleg egyszer sqlite-bol kiolvasni a User-Agentet.
_user_agent = None


def user_agent():
    global _user_agent
    if _user_agent is None:
        _user_agent = cache.get(randomagent, config.CACHE_HOURS_USER_AGENT) or randomagent()
    return _user_agent


def _build_headers(url, headers, cookie, referer, post):
    result = dict(DEFAULT_HEADERS)
    result['User-Agent'] = user_agent()
    if referer:
        result['Referer'] = referer
    else:
        parsed = urlparse(url)
        result['Referer'] = '%s://%s/' % (parsed.scheme, parsed.netloc)
    if cookie:
        result['Cookie'] = cookie
    if isinstance(post, str):
        # requests nem allitja be maganak, ha a body mar kesz string.
        result['Content-Type'] = FORM_CONTENT_TYPE
    if headers:
        result.update(headers)
    return result


def _send(session, url, post, headers, timeout, verify, allow_redirects):
    kwargs = {'headers': headers, 'timeout': timeout, 'verify': verify,
              'allow_redirects': allow_redirects}
    if post is not None:
        return session.post(url, data=post, **kwargs)
    return session.get(url, **kwargs)


def request(url, post=None, headers=None, cookie=None, referer=None,
            output='', timeout=DEFAULT_TIMEOUT, allow_redirects=True):
    '''
    HTTP kérés a megadott URL-re.

    output:
        ''         -> a válasz szövege (str)
        'cookie'   -> a kapott sütik "k=v; k=v" formában
        'geturl'   -> az átirányítások utáni végleges URL
        'response' -> (státuszkód, szöveg)
        'headers'  -> a válasz fejlécei

    Hiba esetén None-t ad vissza, és a KONKRÉT okot naplózza -- a régi
    változat minden kivételt szó nélkül elnyelt, ezért a hiba csak egy
    szinttel feljebb, értelmezhetetlen IndexError-ként jelent meg.
    '''
    request_headers = _build_headers(url, headers, cookie, referer, post)
    session = requests.Session()
    session.max_redirects = 10
    try:
        try:
            response = _send(session, url, post, request_headers, timeout, True, allow_redirects)
        except requests.exceptions.SSLError as exc:
            # Az oldal tanúsítványa gyakran hibás; a régi kód eleve kikapcsolta
            # az ellenőrzést. Itt legalább csak szükség esetén, naplózva tesszük.
            control.log('SSL ellenőrzés kikapcsolva (%s): %s' % (url, exc), control.LOGWARNING)
            response = _send(session, url, post, request_headers, timeout, False, allow_redirects)
    except requests.exceptions.Timeout:
        control.log_error('Időtúllépés (%ss) -- %s' % (timeout, url))
        return None
    except requests.exceptions.TooManyRedirects:
        control.log_error('Túl sok átirányítás -- %s' % url)
        return None
    except requests.exceptions.ConnectionError as exc:
        control.log_error('Nem sikerült csatlakozni -- %s (%s)' % (url, exc))
        return None
    except requests.exceptions.RequestException as exc:
        control.log_exception('HTTP kérés (%s)' % url, exc)
        return None

    if response.status_code >= 400:
        # 4xx/5xx nem feltétlenül végzetes (pl. törölt tartalomnál a végleges
        # URL még kell), ezért csak naplózunk, és a hívóra bízzuk a döntést.
        control.log('HTTP %s -- %s' % (response.status_code, url), control.LOGWARNING)

    try:
        if output == 'cookie':
            return '; '.join('%s=%s' % (c.name, c.value) for c in session.cookies)
        if output == 'geturl':
            return response.url
        if output == 'headers':
            return response.headers
        text = response.content.decode('utf-8', errors='replace')
        if output == 'response':
            return (str(response.status_code), text)
        return text
    finally:
        response.close()
        session.close()


def source(url, **kwargs):
    '''Visszafelé kompatibilis alias a request()-re.'''
    return request(url, **kwargs)


def parseDOM(content, name=u'', attrs=None, ret=False):
    # Copyright (C) 2010-2011 Tobias Ussing And Henrik Mosgaard Jensen
    attrs = attrs or {}

    if isinstance(content, str):
        content = [content]
    elif not isinstance(content, list):
        return u''

    if not name.strip():
        return u''

    ret_lst = []
    for item in content:
        temp_item = re.compile('(<[^>]*?\n[^>]*?>)').findall(item)
        for match in temp_item:
            item = item.replace(match, match.replace('\n', ' '))

        lst = []
        for key in attrs:
            lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=[\'"]' + attrs[key] + '[\'"].*?>))', re.M | re.S).findall(item)
            if len(lst2) == 0 and attrs[key].find(' ') == -1:  # Try matching without quotation marks
                lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=' + attrs[key] + '.*?>))', re.M | re.S).findall(item)

            if len(lst) == 0:
                lst = lst2
                lst2 = []
            else:
                test = list(range(len(lst)))
                test.reverse()
                for i in test:  # Delete anything missing from the next list.
                    if not lst[i] in lst2:
                        del(lst[i])

        if len(lst) == 0 and attrs == {}:
            lst = re.compile('(<' + name + '>)', re.M | re.S).findall(item)
            if len(lst) == 0:
                lst = re.compile('(<' + name + ' .*?>)', re.M | re.S).findall(item)

        if isinstance(ret, str):
            lst2 = []
            for match in lst:
                attr_lst = re.compile('<' + name + '.*?' + ret + '=([\'"].[^>]*?[\'"])>', re.M | re.S).findall(match)
                if len(attr_lst) == 0:
                    attr_lst = re.compile('<' + name + '.*?' + ret + '=(.[^>]*?)>', re.M | re.S).findall(match)
                for tmp in attr_lst:
                    cont_char = tmp[0]
                    if cont_char in "'\"":
                        # Limit down to next variable.
                        if tmp.find('=' + cont_char, tmp.find(cont_char, 1)) > -1:
                            tmp = tmp[:tmp.find('=' + cont_char, tmp.find(cont_char, 1))]

                        # Limit to the last quotation mark
                        if tmp.rfind(cont_char, 1) > -1:
                            tmp = tmp[1:tmp.rfind(cont_char)]
                    else:
                        if tmp.find(' ') > 0:
                            tmp = tmp[:tmp.find(' ')]
                        elif tmp.find('/') > 0:
                            tmp = tmp[:tmp.find('/')]
                        elif tmp.find('>') > 0:
                            tmp = tmp[:tmp.find('>')]

                    lst2.append(tmp.strip())
            lst = lst2
        else:
            lst2 = []
            for match in lst:
                endstr = u'</' + name

                start = item.find(match)
                end = item.find(endstr, start)
                pos = item.find('<' + name, start + 1)

                while pos < end and pos != -1:
                    tend = item.find(endstr, end + len(endstr))
                    if tend != -1:
                        end = tend
                    pos = item.find('<' + name, pos + 1)

                if start == -1 and end == -1:
                    temp = u''
                elif start > -1 and end > -1:
                    temp = item[start + len(match):end]
                elif end > -1:
                    temp = item[:end]
                elif start > -1:
                    temp = item[start + len(match):]

                if ret:
                    endstr = item[end:item.find('>', item.find(endstr)) + 1]
                    temp = match + temp + endstr

                item = item[item.find(temp, item.find(match)) + len(temp):]
                lst2.append(temp)
            lst = lst2
        ret_lst += lst

    return ret_lst


def replaceHTMLCodes(txt):
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = html_lib.unescape(txt)
    txt = txt.replace('&quot;', '"')
    txt = txt.replace('&amp;', '&')
    return txt


def randomagent():
    '''Véletlen, mai böngésző-verziójú User-Agent.'''
    chrome = ['%s.0.0.0' % v for v in range(118, 133)]
    firefox = ['%s.0' % v for v in range(115, 134)]
    windows = ['Windows NT 10.0; Win64; x64']
    mac = ['Macintosh; Intel Mac OS X 10_15_7']
    templates = [
        ('Mozilla/5.0 (%s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s Safari/537.36', windows + mac, chrome),
        ('Mozilla/5.0 (%s; rv:%s) Gecko/20100101 Firefox/%s', windows + mac, firefox),
    ]
    template, platforms, versions = random.choice(templates)
    version = random.choice(versions)
    platform = random.choice(platforms)
    if template.count('%s') == 3:
        return template % (platform, version, version)
    return template % (platform, version)


# A measure_speed visszatérési értékei:
#   None  -> a forrás NEM érhető el (kapcsolódási hiba vagy HTTP 4xx/5xx)
#   -1    -> elérhető, de a sebesség nem mérhető (túl kevés adat)
#   > 0   -> mért sebesség kB/s-ban
SPEED_UNMEASURABLE = -1

# Ennyi adat kell egy értelmes méréshez.
MIN_SAMPLE = 32 * 1024

# HLS lejátszólista felismerése: ez maga nem videó, csak hivatkozásokat
# tartalmaz, ezért a benne megadott első darabot mérjük helyette.
M3U8_MARKER = '#EXTM3U'

# A HLS gyakran KETSZINTU: a fo lejatszolista valtozatokra mutat, azok pedig a
# valodi darabokra. Egy szint kovetese ezert meg mindig csak egy par kilobajtos
# listat talalna -- ketto kell, hogy elerjunk a videohoz es merni tudjunk.
M3U8_MAX_DEPTH = 2

# Ha ezt kapjuk vissza, a "forras" valojaban egy WEBOLDAL, nem video: tipikusan
# Cloudflare-ellenorzes ("Just a moment..."), hibaoldal vagy letoltogomb.
# Ilyenkor a meres egy nagy HTML-t toltene le villamgyorsan, es a forras
# "nagyon gyorsnak" latszana -- kozben el sem indul. Ezert tartalmat is nezunk.
HTML_CONTENT_TYPE = 'text/html'
HTML_MARKERS = (b'<!doctype html', b'<html', b'<head', b'<script')


def _stream_headers(url):
    """A "url|fejlécek" alakot bontja szét, mert egyes hostok csak úgy adják."""
    headers = dict(DEFAULT_HEADERS)
    headers['User-Agent'] = user_agent()
    if '|' in url:
        url, extra = url.split('|', 1)
        for pair in extra.split('&'):
            if '=' in pair:
                key, value = pair.split('=', 1)
                headers[key.strip()] = unquote_plus(value.strip())
    return url, headers


def _first_segment(manifest, base_url):
    """A HLS lejátszólista első valódi hivatkozása (darab vagy alváltozat)."""
    for line in manifest.splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            return urljoin(base_url, line)
    return None


def looks_playable(url, timeout=5):
    """
    False, ha a feloldott cim biztosan NEM video (weboldal vagy hibaoldal).

    A ResolveURL nehany hostnal "sikerrel" ter vissza, de az eredeti
    oldalcimet adja vissza video helyett -- pl. Cloudflare-vedett letoltooldal.
    A lejatszas ilyenkor csak a mp-es idotullepes utan bukik el, ami hosszu
    var akozas a semmiert.

    BIZONYTALANSAG ESETEN True: halozati hiba vagy idotullepes eseten NEM
    zarunk ki egy forrast, mert a Kodi lejatszoja mas fejleccekkel akar sikerrel
    is jarhat. Csak akkor mondunk nemet, ha tenyleg latjuk, hogy weboldal.
    """
    target, headers = _stream_headers(url)
    try:
        response = requests.get(target, headers=headers, timeout=timeout,
                                stream=True, verify=False)
    except requests.exceptions.RequestException:
        return True
    try:
        if response.status_code >= 400:
            control.log('Előellenőrzés: HTTP %s -- %s'
                        % (response.status_code, target), control.LOGWARNING)
            return False
        if HTML_CONTENT_TYPE in (response.headers.get('content-type') or '').lower():
            control.log('Előellenőrzés: weboldal, nem videó -- %s' % target,
                        control.LOGWARNING)
            return False
        head = next(response.iter_content(chunk_size=512), b'').lstrip().lower()
        if any(marker in head for marker in HTML_MARKERS):
            control.log('Előellenőrzés: HTML törzs videó helyett -- %s' % target,
                        control.LOGWARNING)
            return False
    except requests.exceptions.RequestException:
        return True
    finally:
        try:
            response.close()
        except Exception:
            pass
    return True


def measure_speed(url, sample_bytes=512 * 1024, timeout=10, _depth=0):
    """
    Egy stream valós sebessége kB/s-ban, kis minta alapján.

    A feloldás sikere csak azt mondja meg, hogy a forrás ÉL -- az akadozást
    a sebesség okozza. Ezért letöltünk egy darabkát, és mérjük.

    Az "elérhető, de nem mérhető" eset KÜLÖN van kezelve: egy m3u8
    lejátszólista pár kilobájt, mert csak hivatkozásokat tartalmaz. Ilyet
    halottnak jelölni súlyos félrevezetés lenne, ezért követjük a benne
    megadott első darabot, és ha az sem megy, SPEED_UNMEASURABLE jön vissza.
    """
    target, headers = _stream_headers(url)
    session = requests.Session()
    started = time.time()
    read = 0
    body = b''
    try:
        response = session.get(target, headers=headers, timeout=timeout,
                               stream=True, verify=False)
        if response.status_code >= 400:
            control.log('Sebességmérés: HTTP %s -- %s' % (response.status_code, target),
                        control.LOGWARNING)
            return None
        if HTML_CONTENT_TYPE in (response.headers.get('content-type') or '').lower():
            control.log('Sebességmérés: weboldal jött vissza, nem videó -- %s'
                        % target, control.LOGWARNING)
            return None
        for chunk in response.iter_content(chunk_size=32 * 1024):
            read += len(chunk)
            if len(body) < 8192:
                body += chunk[:8192]
            if read >= sample_bytes or (time.time() - started) > timeout:
                break
    except requests.exceptions.RequestException as exc:
        control.log('Sebességmérés sikertelen (%s): %s' % (target, exc), control.LOGWARNING)
        return None
    finally:
        try:
            response.close()
        except Exception:
            pass
        session.close()

    # Nem minden szerver kuld helyes content-type-ot, ezert belenezunk.
    head = body[:512].lstrip().lower()
    if any(marker in head for marker in HTML_MARKERS):
        control.log('Sebességmérés: HTML törzs videó helyett -- %s' % target,
                    control.LOGWARNING)
        return None

    elapsed = max(0.001, time.time() - started)
    if read >= MIN_SAMPLE:
        return int((read / 1024.0) / elapsed)

    # Kevés adat: lejátszólista? Akkor a benne megadott első darabot mérjük.
    text = body.decode('utf-8', 'replace')
    if _depth < M3U8_MAX_DEPTH and M3U8_MARKER in text:
        segment = _first_segment(text, target)
        if segment:
            control.log('Sebességmérés: lejátszólista, a darabot mérjük', control.LOGDEBUG)
            nested = measure_speed(segment, sample_bytes, timeout, _depth=1)
            if nested is not None:
                return nested

    # Elérhető volt, csak mérni nem tudtuk -- ez NEM halott forrás.
    control.log('Sebességmérés: elérhető, de nem mérhető (%d byte) -- %s'
                % (read, target), control.LOGDEBUG)
    return SPEED_UNMEASURABLE
