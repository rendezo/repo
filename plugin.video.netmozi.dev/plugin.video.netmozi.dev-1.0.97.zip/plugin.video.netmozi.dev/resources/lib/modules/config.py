# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Minden oldal-specifikus szelektor, regex és szöveges marker EGY helyen.
# Ha a netmozi.com átdesignol, először ITT kell javítani -- a navigator.py-ban
# nem maradhat HTML-osztálynév vagy regex.

BASE_URL = 'https://netmozi.com/'
LOGIN_PATH = 'login/do'

# A bejelentkezés akkor sikeres, ha a válasz cookie-i közt ez szerepel.
LOGIN_OK_COOKIE = 'ca='

# Lista-oldal URL sablonja: page, type, order, search sorrendben.
LIST_URL = '%s?page=%s&type=%s&order=%s&search=%s'

# Ajánló oldalak. Egyoldalasak, nincs lapozó, de a listaelemek szerkezete
# ugyanaz, mint a rendes listáé.
RECOMMENDED_URL = '%s?recommended&recommended_type=%s'
RECOMMENDED_TYPES = (
    ('1', u'Premier'),
    ('2', u'DVD'),
    ('3', u'Sorozatok'),
)

# Év szerinti szűrés. Az oldal szerveroldalon támogatja, ezért a lapozás és
# az elemszám is helyes marad -- nem utólag szórjuk ki a találatokat.
YEAR_FILTER = '&year_from=%s&year_to=%s'

# A részletes keresés űrlapja tartalmazza a legnagyobb választható évet.
YEAR_MAX_RE = r'name="year_from"[^>]*?max="([0-9]{4})"'
YEAR_MIN = 1920

# A "nincs év szűrés" jelölése a plugin URL-ekben.
YEAR_ALL = ''


# --- Rendezési lehetőségek (getOrderTypes) ----------------------------------

ORDER_SELECT_ID = 'order_by_select'
ORDER_OPTION_RE = r'<option value="([0-9])"(.*)>(.*)</option>'

# Ezek a rendezések nem jelennek meg a menüben.
# Szándékosan a FELIRAT részlete alapján szűrünk, nem az érték alapján: ha az
# oldal átírja a szöveget, a menüpont legfeljebb visszajelenik (látható, könnyen
# javítható), míg egy átszámozásnál az érték szerinti szűrés némán rossz sort
# tüntetne el.
HIDDEN_ORDERS = (u'Név alapján',)


# --- Lista-oldal (getMovies) ------------------------------------------------

LIST_ITEM_CLASS = 'col-12.*?'
LIST_TITLE_CLASS = 'col_name'
LIST_LINK_CLASS = 'col_a'
LIST_COL_CLASS = 'col-sm-6'          # [0] = borító, [1] = adatblokk
LIST_ROW_CLASS = 'row'

# A title attribútumot ki kell vágni, mert elrontja a col_name keresését.
LIST_TITLE_ATTR_RE = r'(.*?)(title="[^"]*?")(.*)'

SERIES_MARKER = '(sorozat)'
SERIES_MARKER_HTML = '<small>(sorozat)</small>'

# Adatsor-címkék: PONTOSAN úgy, ahogy az oldal HTML-jében szerepelnek.
LABEL_YEAR = 'Év:'
LABEL_DURATION = 'Játékidő:'
LABEL_LINKCOUNT = 'Megtekintő linkek:'
LABEL_PLOT = 'Leírás'
LABEL_CATEGORY = 'Kategória:'

# A kategóriák vesszővel elválasztva érkeznek ("Horror , Misztikus").
CATEGORY_SPLIT_RE = r'\s*,\s*'
# Ennél többet nem írunk ki a listában, hogy a cím ne szoruljon ki.
CATEGORY_BADGE_MAX = 3

YEAR_RE = r'([0-9]{4})'
DURATION_RE = r'([0-9]+) perc'
LINKCOUNT_RE = r'([0-9]+)db'
DURATION_SUFFIX = ' perc'

PAGER_SELECT_NAME = 'page'


# --- Adatlap (getMovie / getSeries / getEpisodes) ---------------------------

DETAIL_CONTAINER_CLASS = 'container'
DETAIL_TITLE_TAG = 'h3'
DETAIL_SUBTITLE_TAG = 'h4'
DETAIL_INFO_CLASS = 'col-sm-8'
DETAIL_THUMB_CLASS = 'col-sm-4'

# A rész URL-je "<sorozat>/s<évad>/e<rész>" alakú; ebből tudjuk kiszedni,
# hol tartunk, amikor a hátralévő részeket sorba állítjuk.
EPISODE_URL_RE = r'^(?P<base>.*)/s(?P<season>\d+)/e(?P<episode>\d+)$'

SEASON_LIST_ID = 'seasonUl'          # évadok; a részekhez: SEASON_LIST_ID + évadszám

# Regisztrációhoz kötött tartalom jelzése az adatlapon.
REGISTRATION_MARKER = 'regeljbe.png'

# --- Hozzászólások az adatlapon ---------------------------------------------
# Szerveroldalon renderelve érkeznek, abban a HTML-ben, amit az adatlaphoz
# amúgy is letöltünk -- nincs szükség külön kérésre.
COMMENT_CARD_CLASS = 'card'
COMMENT_CARD_MARKER = 'Hozzászólások'
COMMENT_ENTRY_TAG = 'fieldset'
COMMENT_HEAD_TAG = 'legend'
COMMENT_DATE_RE = r'([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2})'

# A "megtekintő linkek" gomb, ami a külső forrástáblára mutat.
LINKS_BUTTON_CLASS = 'details_links_btn'


# --- Forrástábla a külső link-oldalon (getMovie második kérés) --------------

SOURCE_CARD_CLASS = 'card .+?'
SOURCE_TABLE_WRAP_CLASS = 'table-responsive'
SOURCE_TABLE_CLASS = 'table'
SOURCE_PLAY_BTN_CLASS = 'btn btn-outline-primary btn-sm action-btn'

# A forrás-URL tokenes és néhány óránként változik, a benne lévő azonosító
# viszont állandó. Bármit, amit forráshoz KÖTVE jegyzünk meg (pl. mért
# sebesség), erre kell kulcsolni -- különben a token lejártával elveszik.
SOURCE_ID_RE = r'/links/open/([0-9]+)'

# Oszlopindexek a forrástábla sorain belül.
COL_LANGUAGE = 0
COL_VALID = 1
COL_PLAY = 3
COL_QUALITY = 4
COL_SITE = 5

# Nyelv-zászlók -> megjelenítendő címke. A sorrend számít: az első találat nyer.
LANGUAGE_FLAGS = (
    ('hungary.gif', 'Szinkron'),
    ('usa.gif', 'Külföldi'),
    ('uk-hu.png', 'Felirat'),
)
LANGUAGE_UNKNOWN = 'Ismeretlen'

# A beállításban felkínált hangsávok. A "Mindegy" jelenti, hogy nem
# rendezünk át semmit -- marad az oldal saját sorrendje.
LANGUAGE_ANY = u'Mindegy'
LANGUAGE_SUBTITLED = 'Felirat'       # ennél töltünk le feliratot

# Érvénytelen forrás jelzése.
INVALID_SOURCE_MARKER = 'red_mark.png'


# --- Lejátszási lánc (playmovie) -------------------------------------------

# Közvetítő oldal, ami base64-ben vagy iframe-ben rejti a valódi forrást.
REDIRECT_HOST_MARKER = 'mindjart.megnezed'
REDIRECT_B64_RE = r'^(.*)function counter(.*)var link([^=]*)=([^"]*)"([^"]*)";(.*)$'
REDIRECT_IFRAME_RE = r'<iframe[^>]*src=[\'"]([^\'"]+)[\'"]'

# Ezeket a hostokat a ResolveURL előtt JS-deobfuszkálással kell bontani.
JSUNHUNT_HOSTS = ('streamplay', 'sbot')
JSUNHUNT_SRC_RE = r'.*setAttribute\("src","([^"]*)".*'


# --- Cache élettartamok (óra) ----------------------------------------------

CACHE_HOURS_USER_AGENT = 1
CACHE_HOURS_LOGIN_COOKIE = 24
CACHE_HOURS_ANON_COOKIE = 24 * 365
CACHE_HOURS_VISITOR_ID = 24

# A Netflix Top 10 hetente frissül, napi egy letöltés bőven elég (~900 kB).
CACHE_HOURS_NETFLIX = 24


# --- Automatikus lejátszás (Netflix Top 10) --------------------------------

# Ennyi forrásnál tovább nem próbálkozunk: a Kodi megszakítja a túl sokáig
# futó bővítmény-hívást, és a felhasználó sem vár a végtelenségig.
AUTOPLAY_MAX_SOURCES = 6

# Ennyi másodpercig várjuk, hogy a lejátszás TÉNYLEGESEN elinduljon.
# Ha nem indul el, jön a következő forrás.
AUTOPLAY_START_TIMEOUT = 15

# A lejátszási listából / Up Next-ből hívott feloldásnál a Kodi VÁR ránk, és
# ha sokáig tart, feladja ("Can't find item to play"). Ezért itt jóval
# kevesebb forrást próbálunk, mint az interaktív, folyamatjelzős ágon.
RESOLVE_MAX_SOURCES = 3

# Ha egy résznek egyetlen forrása sem oldható fel, ennyi KÖVETKEZŐ részt
# próbálunk még az évadon belül, mielőtt feladjuk. Beállításból jön; ez
# csak a tartalék, ha nem olvasható.
#
# Minden átugrott rész két oldalletöltés plusz forrásfeloldás, tehát a
# magas érték hosszú várakozást is jelenthet.
EPISODE_SKIP_MAX = 5

# A feliratok a lejátszás ELŐTT töltődnek le, tehát minden másodpercük
# késlelteti az indulást. Ezért CSAK EGYET töltünk le -- de a jót: a magyart.
# Így nem kell lejátszás közben nyelvet váltani, és gyorsabb is.
SUBTITLE_TIMEOUT = 8


# --- Források előzetes ellenőrzése -----------------------------------------
#
# Minden forrás feloldása MÁSODPERCEKBE telik, plusz a sebességminta, ezért
# korlátozzuk. A feloldás sikere csak azt mondja meg, hogy a forrás ÉL --
# az akadozást a sebesség okozza, azt külön mérjük.

CHECK_MAX_SOURCES = 8
CHECK_SAMPLE_BYTES = 384 * 1024
CHECK_TIMEOUT = 8

# Ez alatt a sebesség alatt akadozás várható (kB/s).
CHECK_SLOW_LIMIT = 400

# A lejatszas elotti gyors ellenorzes idokorlatja. Roviden tartjuk: csak azt
# nezi meg, hogy videot kapunk-e vagy weboldalt. Igy egy jatszhatatlan forras
# fel masodperc alatt kiesik ahelyett, hogy AUTOPLAY_START_TIMEOUT masodpercig
# varnank egy lejatszasra, ami sosem indul el.
PLAYABLE_CHECK_TIMEOUT = 5

# Nyelvjelölések, amikre a magyar feliratot felismerjük. Kisbetűsítve,
# részlet-egyezéssel keresünk, mert a források eltérően nevezik el
# ("hu", "hun", "Hungarian", "magyar", "HU_forced" ...).
SUBTITLE_PREFERRED = ('magyar', 'hungarian', 'hun', 'hu')

# --- Saját frissítés ---------------------------------------------------------
#
# A Kodi magától NAPONTA EGYSZER nézi meg a repókat, ezért egy frissen kiadott
# verzió akár egy napig sem jelenik meg. Ez a cím teszi lehetővé, hogy azonnal
# megkérdezzük: van-e újabb, mint ami telepítve van.
UPDATE_ADDONS_XML = 'https://rendezo.github.io/repo/addons.xml'
UPDATE_VERSION_RE = r'id="%s"[^>]*?version="([0-9][0-9.]*)"'


# --- Rejtett, felnottkorhoz kotott lista ------------------------------------
#
# Nincs hozza menupont sehol. Csak ugy jon elo, ha a keresobe PONTOSAN ezt a
# szot irjuk (kis/nagybetu es a szelek szokoze nem szamit). A szo nem kerul be
# a keresesi elozmenybe, es az innen inditott lejatszas nem kerul be a "Mar
# lattam" listaba sem -- kulonben a rejtes ertelmetlen lenne.
#
# Ha meg akarod valtoztatni, itt az egyetlen hely.
ADULT_KEYWORD = 'makpf'

# Egy talalati oldal utan felkinaljuk a kovetkezot.
ADULT_PAGE_SIZE = 27
