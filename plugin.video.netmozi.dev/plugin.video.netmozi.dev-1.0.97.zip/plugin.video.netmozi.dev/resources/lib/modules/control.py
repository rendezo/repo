# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from xbmcvfs import translatePath


# --- Kodi API rovidítések ---------------------------------------------------

addon = xbmcaddon.Addon
addonInfo = xbmcaddon.Addon().getAddonInfo
setting = xbmcaddon.Addon().getSetting
setSetting = xbmcaddon.Addon().setSetting
lang = xbmcaddon.Addon().getLocalizedString

addItem = xbmcplugin.addDirectoryItem
directory = xbmcplugin.endOfDirectory
content = xbmcplugin.setContent
resolve = xbmcplugin.setResolvedUrl
item = xbmcgui.ListItem

keyboard = xbmc.Keyboard
condVisibility = xbmc.getCondVisibility
jsonrpc = xbmc.executeJSONRPC
execute = xbmc.executebuiltin
sleep = xbmc.sleep

openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdir
deleteFile = xbmcvfs.delete
listDir = xbmcvfs.listdir
transPath = translatePath


# --- Utvonalak --------------------------------------------------------------

addonPath = translatePath(addonInfo('path'))
dataPath = translatePath(addonInfo('profile'))
cacheFile = os.path.join(dataPath, 'cache.db')


# --- Naplozas ---------------------------------------------------------------

LOGDEBUG = xbmc.LOGDEBUG
LOGINFO = xbmc.LOGINFO
LOGWARNING = xbmc.LOGWARNING
LOGERROR = xbmc.LOGERROR

ADDON_NAME = 'NetMozi'


def log(message, level=LOGINFO):
    '''Egysegesen prefixelt Kodi-log, hogy a naploban kereshetok legyunk.'''
    try:
        xbmc.log('%s: %s' % (ADDON_NAME, message), level)
    except Exception:
        pass


def log_error(message):
    log(message, LOGERROR)


class timed(object):
    '''
    Egy lépés időtartamának naplózása.

    Lassú indulásnál ebből derül ki, MELYIK szakasz viszi az időt -- a
    bővítményé vagy a Kodié.

        with control.timed(u'felirat letöltés'):
            ...
    '''

    def __init__(self, label):
        self.label = label
        self.started = 0.0

    def __enter__(self):
        self.started = time.time()
        return self

    def __exit__(self, *exc_info):
        log(u'[idő] %s: %.1f mp' % (self.label, time.time() - self.started))
        return False


def log_exception(context, exc):
    '''Kivetel naplozasa a hivas kontextusaval egyutt.'''
    log('%s -- %s: %s' % (context, type(exc).__name__, exc), LOGERROR)


# --- Dialogusok -------------------------------------------------------------

def addonIcon():
    try:
        return os.path.join(addonInfo('path'), 'icon.png')
    except Exception:
        return ''


def infoDialog(message, heading=ADDON_NAME, icon='', time=3000):
    if icon == '':
        icon = addonIcon()
    try:
        xbmcgui.Dialog().notification(heading, message, icon, time, sound=False)
    except Exception:
        execute('Notification(%s,%s, %s, %s)' % (heading, message, time, icon))


def errorDialog(message, heading=ADDON_NAME):
    '''Hibajelzes a felhasznalonak + naplobejegyzes.'''
    log_error(message)
    try:
        xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception:
        pass


def okDialog(message, heading=ADDON_NAME):
    return xbmcgui.Dialog().ok(heading, message)


def yesnoDialog(heading=ADDON_NAME, message='', nolabel='', yeslabel=''):
    return xbmcgui.Dialog().yesno(heading, message, nolabel, yeslabel)


def selectDialog(items, heading=ADDON_NAME):
    return xbmcgui.Dialog().select(heading, items)


def idle():
    return execute('Dialog.Close(busydialog)')


def busy():
    return execute('ActivateWindow(busydialog)')


def refresh():
    return execute('Container.Refresh')


def openSettings(id=None):
    try:
        idle()
        execute('Addon.OpenSettings(%s)' % (id or addonInfo('id')))
    except Exception:
        return
