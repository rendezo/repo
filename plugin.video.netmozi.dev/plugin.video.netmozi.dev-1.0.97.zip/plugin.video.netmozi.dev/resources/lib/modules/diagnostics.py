# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Önellenőrzés: végigjárja az élő oldalt, és megmondja, melyik szelektor
# bukott el. A netmozi rendszeresen átírja a HTML-jét, és a hibából magától
# nem derül ki, MI változott -- ez a jelentés megnevezi a javítandó
# konstanst a config.py-ban.

import json
import re

from resources.lib.modules import client, config, streams

OK, FAIL, WARN = 'OK', 'HIBA', 'FIGY'


class Report(object):
    '''Ellenőrzések eredménye, szakaszokra bontva.'''

    def __init__(self):
        self.lines = []
        self.failures = 0

    def section(self, title):
        self.lines.append('')
        self.lines.append('[B]%s[/B]' % title)

    def add(self, status, name, detail=''):
        if status == FAIL:
            self.failures += 1
            colour = 'red'
        elif status == WARN:
            colour = 'orange'
        else:
            colour = 'lightgreen'
        self.lines.append('  [COLOR %s]%-4s[/COLOR]  %s%s'
                          % (colour, status, name, '  -- %s' % detail if detail else ''))

    def check(self, condition, name, fix='', detail=''):
        '''Egy ellenőrzés; hibánál kiírja, melyik konstanst kell javítani.'''
        if condition:
            self.add(OK, name, detail)
            return True
        self.add(FAIL, name, u'javítandó: config.%s' % fix if fix else detail)
        return False

    def text(self):
        return '\n'.join(self.lines).strip('\n')


def _first(items):
    return items[0] if items else None


def check_site(report, cookie):
    '''Lista-oldal, rendezés választó, lapozó.'''
    report.section(u'Lista-oldal')
    url = config.LIST_URL % (config.BASE_URL, 1, '', 1, '')
    content = client.request(url, cookie=cookie)
    if not report.check(content, u'oldal letöltése', detail=config.BASE_URL):
        return None

    items = client.parseDOM(content, 'div', attrs={'class': config.LIST_ITEM_CLASS})
    report.check(items, u'listaelemek', 'LIST_ITEM_CLASS', u'%d elem' % len(items))
    if not items:
        return None

    item = items[0]
    match = re.search(config.LIST_TITLE_ATTR_RE, item, re.S)
    if match:
        item = '%s%s' % (match.group(1), match.group(3))
    title = _first(client.parseDOM(item, 'div', attrs={'class': config.LIST_TITLE_CLASS}))
    report.check(title, u'cím', 'LIST_TITLE_CLASS')
    link = _first(client.parseDOM(item, 'a', attrs={'class': config.LIST_LINK_CLASS}, ret='href'))
    report.check(link, u'hivatkozás', 'LIST_LINK_CLASS')

    columns = client.parseDOM(item, 'div', attrs={'class': config.LIST_COL_CLASS})
    report.check(len(columns) >= 2, u'borító + adatblokk', 'LIST_COL_CLASS',
                 u'%d oszlop' % len(columns))
    rows = client.parseDOM(columns[1] if len(columns) > 1 else '', 'div',
                           attrs={'class': config.LIST_ROW_CLASS})
    report.check(rows, u'adatsorok', 'LIST_ROW_CLASS')

    # A címkéket az ÖSSZES elemen keressük: egy-egy bejegyzésből jogosan
    # hiányozhat a játékidő vagy az évszám (pl. sorozatnál), a szelektor
    # akkor romlott el, ha SEHOL nem fordul elő.
    all_rows = []
    for entry in items:
        entry_columns = client.parseDOM(entry, 'div', attrs={'class': config.LIST_COL_CLASS})
        if len(entry_columns) > 1:
            all_rows.extend(client.parseDOM(entry_columns[1], 'div',
                                            attrs={'class': config.LIST_ROW_CLASS}))
    for label, name, constant in ((config.LABEL_YEAR, u'"Év" címke', 'LABEL_YEAR'),
                                  (config.LABEL_DURATION, u'"Játékidő" címke', 'LABEL_DURATION'),
                                  (config.LABEL_LINKCOUNT, u'"Megtekintő linkek" címke',
                                   'LABEL_LINKCOUNT')):
        hits = sum(1 for row in all_rows if label in row)
        report.check(hits, name, constant, u'%d elemnél' % hits)

    pager = _first(client.parseDOM(content, 'select', attrs={'name': config.PAGER_SELECT_NAME}))
    report.check(pager, u'lapozó', 'PAGER_SELECT_NAME')
    order = _first(client.parseDOM(content, 'select', attrs={'id': config.ORDER_SELECT_ID}))
    if report.check(order, u'rendezés választó', 'ORDER_SELECT_ID'):
        options = re.findall(config.ORDER_OPTION_RE, order)
        report.check(options, u'rendezés opciók', 'ORDER_OPTION_RE',
                     u'%d db' % len(options))

    # Év szerinti szűrés: a szerver tényleg szűr-e még
    year_url = url + config.YEAR_FILTER % (2026, 2026)
    year_content = client.request(year_url, cookie=cookie)
    year_items = client.parseDOM(year_content or '', 'div',
                                 attrs={'class': config.LIST_ITEM_CLASS})
    report.check(year_items, u'év szerinti szűrés', 'YEAR_FILTER',
                 u'%d találat 2026-ra' % len(year_items))
    return link


def check_detail(report, cookie, path):
    '''Adatlap és forrástábla.'''
    report.section(u'Adatlap')
    content = client.request('%s%s' % (config.BASE_URL, path), cookie=cookie)
    if not report.check(content, u'adatlap letöltése', detail=path[:40]):
        return
    if config.REGISTRATION_MARKER in content:
        report.add(WARN, u'regisztrációhoz kötött tartalom', config.REGISTRATION_MARKER)
        return

    container = _first(client.parseDOM(content, 'div',
                                       attrs={'class': config.DETAIL_CONTAINER_CLASS}))
    report.check(container, u'tartalom keret', 'DETAIL_CONTAINER_CLASS')
    report.check(client.parseDOM(container or '', config.DETAIL_TITLE_TAG),
                 u'cím', 'DETAIL_TITLE_TAG')
    report.check(client.parseDOM(container or '', 'div',
                                 attrs={'class': config.DETAIL_INFO_CLASS}),
                 u'adatblokk', 'DETAIL_INFO_CLASS')
    report.check(client.parseDOM(container or '', 'div',
                                 attrs={'class': config.DETAIL_THUMB_CLASS}),
                 u'borító', 'DETAIL_THUMB_CLASS')

    links_url = _first(client.parseDOM(content, 'a',
                                       attrs={'class': config.LINKS_BUTTON_CLASS}, ret='href'))
    if not report.check(links_url, u'linkek gomb', 'LINKS_BUTTON_CLASS'):
        return

    report.section(u'Forrástábla')
    if links_url.startswith('//'):
        links_url = 'https:%s' % links_url
    links = client.request(links_url)
    if not report.check(links, u'forráslista letöltése'):
        return
    card = _first(client.parseDOM(links, 'div', attrs={'class': config.SOURCE_CARD_CLASS}))
    report.check(card, u'kártya', 'SOURCE_CARD_CLASS')
    wrap = _first(client.parseDOM(card or '', 'div',
                                  attrs={'class': config.SOURCE_TABLE_WRAP_CLASS}))
    report.check(wrap, u'tábla keret', 'SOURCE_TABLE_WRAP_CLASS')
    table = client.parseDOM(wrap or '', 'table', attrs={'class': config.SOURCE_TABLE_CLASS})
    report.check(table, u'tábla', 'SOURCE_TABLE_CLASS')
    rows = client.parseDOM(table, 'tr')
    report.check(rows, u'forrássorok', detail=u'%d sor' % len(rows))
    if not rows:
        return
    cols = client.parseDOM(rows[0], 'td')
    report.check(len(cols) > config.COL_SITE, u'oszlopok száma',
                 'COL_* indexek', u'%d oszlop' % len(cols))
    play = client.parseDOM(cols[config.COL_PLAY] if len(cols) > config.COL_PLAY else '',
                           'a', attrs={'class': config.SOURCE_PLAY_BTN_CLASS}, ret='href')
    report.check(play, u'lejátszás gomb', 'SOURCE_PLAY_BTN_CLASS')
    flags = cols[config.COL_LANGUAGE] if cols else ''
    report.check(any(marker in flags for marker, _ in config.LANGUAGE_FLAGS),
                 u'nyelv jelölés', 'LANGUAGE_FLAGS')


def check_streams(report):
    '''Stream Top 10 szolgáltatók.'''
    report.section(u'Stream Top 10')
    for provider in streams.PROVIDERS:
        data = streams.fetch(provider['key'])
        count = len(data['rows']) if data else 0
        report.check(count >= 5, provider['label'],
                     detail=u'%d cím' % count if data else u'nem elérhető')


def run(cookie):
    '''Teljes önellenőrzés. Riportot ad vissza.'''
    report = Report()
    report.lines.append(u'[B]NetMozi diagnosztika[/B]')
    path = check_site(report, cookie)
    if path:
        check_detail(report, cookie, path)
    check_streams(report)
    report.section(u'Összegzés')
    failures = report.failures
    if failures:
        report.add(FAIL, u'%d ellenőrzés bukott el' % failures,
                   u'a jelölt konstansokat kell javítani a config.py-ban')
        # Az összegzés maga nem újabb hiba.
        report.failures = failures
    else:
        report.add(OK, u'minden rendben')
    return report
