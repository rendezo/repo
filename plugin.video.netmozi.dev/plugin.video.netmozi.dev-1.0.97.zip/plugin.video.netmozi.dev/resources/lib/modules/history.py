# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Megtekintési előzmények: mit néztünk, és MELYIK forrás vált be.
#
# A NETMOZI adatlap útvonalát tároljuk, nem a feloldott stream URL-jét: az
# előbbi állandó, az utóbbi tokenes és néhány óra múlva lejár. Emellett
# megjegyezzük, melyik forrás (host) működött -- újranézéskor a bővítmény
# azzal kezdi a próbálkozást, így elsőre elindul.
#
# A lejátszás két lépésben történik (adatlap megnyitása, majd forrás
# indítása), és ezek külön plugin-hívások -- külön folyamatban. Ezért az
# adatlap adatait előbb "kontextusként" lerakjuk, és sikeres indításkor
# abból áll össze az előzmény-bejegyzés.

import json
import os
import time

from resources.lib.modules import control

HISTORY_FILE = 'watched.json'
CONTEXT_FILE = 'watching.json'

# Ennél több bejegyzést nem tartunk; a lista tetején a legfrissebb.
MAX_ENTRIES = 200


def _path(name):
    return os.path.join(control.dataPath, name)


def _read(name, default):
    try:
        with open(_path(name), encoding='utf-8') as handle:
            return json.load(handle)
    except (IOError, OSError, ValueError):
        return default


def _write(name, data):
    try:
        control.makeFile(control.dataPath)
        with open(_path(name), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=1)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'előzmény írása (%s)' % name, exc)
        return False


# --- Kontextus: melyik adatlapról indul a lejátszás ------------------------

def set_context(page, details, episode_label=''):
    '''Az éppen megnyitott adatlap adatai, sikeres indítás esetére.'''
    details = details or {}
    _write(CONTEXT_FILE, {
        'page': page,
        'title': details.get('title', ''),
        'thumb': details.get('thumb', ''),
        'plot': details.get('plot', ''),
        'duration': details.get('duration', 0),
        'episode_label': episode_label,
    })


def get_context():
    return _read(CONTEXT_FILE, {})


# --- Előzmények -------------------------------------------------------------

def load():
    '''Bejegyzések, legfrissebb elöl.'''
    entries = _read(HISTORY_FILE, [])
    return entries if isinstance(entries, list) else []


def find(key):
    for entry in load():
        if entry.get('key') == key:
            return entry
    return None


def add(site=''):
    '''
    Sikeres lejátszás rögzítése az utoljára megnyitott adatlap alapján.

    Ugyanaz a tétel nem duplikálódik: felkerül a lista tetejére, és a
    bevált forrás neve a legutóbbira frissül.
    '''
    context = get_context()
    page = context.get('page')
    if not page:
        control.log(u'Előzmény kihagyva: nincs adatlap kontextus', control.LOGDEBUG)
        return False

    entry = {
        'key': page,
        'title': context.get('title', ''),
        'episode_label': context.get('episode_label', ''),
        # A netmozi adatlap útvonala -- ez nem jár le.
        'page': page,
        # Ez a forrás vált be legutóbb; újranézéskor ezzel kezdünk.
        'site': site,
        'thumb': context.get('thumb', ''),
        'plot': context.get('plot', ''),
        'duration': context.get('duration', 0),
        'time': int(time.time()),
    }
    entries = [item for item in load() if item.get('key') != page]
    entries.insert(0, entry)
    del entries[MAX_ENTRIES:]
    control.log(u'Előzményhez adva: %s (%s)' % (entry['title'], site))
    return _write(HISTORY_FILE, entries)


def remove(key):
    entries = load()
    remaining = [item for item in entries if item.get('key') != key]
    if len(remaining) == len(entries):
        return False
    return _write(HISTORY_FILE, remaining)


def clear():
    return _write(HISTORY_FILE, [])


def site_for_series(base):
    """
    A sorozathoz legutóbb bevált forrás neve.

    A következő rész feloldásakor ezzel kezdünk: ugyanannál a sorozatnál
    jó eséllyel ugyanaz a host működik, így elsőre elindul -- és a Kodi
    nem vár feleslegesen.
    """
    if not base:
        return ''
    for entry in load():
        page = entry.get('page') or ''
        if page.startswith(base) and entry.get('site'):
            return entry['site']
    return ''
