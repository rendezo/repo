# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from resources.lib.modules import client, control


# === Elsődleges forrás: a magyar Netflix kezdőlap ==========================
#
# A "Jelenleg a legnépszerűbb" rovat MAGYAR címeket ad, ezért a netmozi
# keresője sokkal pontosabban talál, mint az angol nyelvű globális listával.

HU_URL = 'https://www.netflix.com/hu/'
HU_HEADERS = {'Accept-Language': 'hu-HU,hu;q=0.9,en;q=0.5'}

# A data-uia az oldal UI-teszt attribútuma. Azért erre építünk, mert a CSS
# osztálynevek (default-ltr-iqcdef-cache-...) minden Netflix-buildnél mások.
HU_ITEM_RE = r'data-uia="top-10-element-(\d+)"(.*?)</button>'
HU_TITLE_RE = r'</span>\s*([^<>]{1,150}?)\s*</div>'
HU_IMAGE_RE = r'background-image:\s*url\(([^)]+)\)'


# === Tartalék forrás: a hivatalos globális heti adatfájl ===================
#
# Gépi feldolgozásra szánt TSV, ezért stabil -- viszont ANGOL címeket ad.
# Csak akkor jön elő, ha a magyar oldal feldolgozása nem sikerül.

TOP10_URL = 'https://top10.netflix.com/data/all-weeks-global.tsv'
TIMEOUT = 60

CATEGORIES = (
    ('Films (English)', u'Filmek (angol)'),
    ('Films (Non-English)', u'Filmek (nem angol)'),
    ('TV (English)', u'Sorozatok (angol)'),
    ('TV (Non-English)', u'Sorozatok (nem angol)'),
)

REQUIRED = ('week', 'category', 'weekly_rank', 'show_title')
EMPTY = 'N/A'


def parse_hu(content):
    '''
    A magyar kezdőlap "Jelenleg a legnépszerűbb" rovata.

    {'source': 'hu', 'week': '', 'rows': [{'rank', 'title', 'thumb', 'category'}]}
    Hibás vagy üres bemenetnél None.
    '''
    if not content:
        return None
    rows = []
    for rank, block in re.findall(HU_ITEM_RE, content, re.S):
        title = ''
        # A blokkban több </span>...</div> is akad; a cím az első olyan,
        # ami nem üres és nem a sorszám.
        for candidate in re.findall(HU_TITLE_RE, block, re.S):
            candidate = client.replaceHTMLCodes(candidate).strip()
            if candidate and not candidate.isdigit():
                title = candidate
                break
        if not title:
            continue
        image = re.search(HU_IMAGE_RE, block)
        rows.append({
            'rank': rank,
            'title': title,
            'thumb': image.group(1).strip() if image else '',
            'category': '',
        })
    if not rows:
        control.log_error(u'Netflix HU: nem találtam top-10 elemet (változott az oldal?)')
        return None
    rows.sort(key=lambda row: int(row['rank']) if row['rank'].isdigit() else 99)
    control.log(u'Netflix HU: %d cím' % len(rows))
    return {'source': 'hu', 'week': '', 'rows': rows}


def parse_global(content):
    '''A globális TSV legfrissebb hetének sorai. Hibánál None.'''
    if not content:
        return None
    # Kizárólag \n mentén hasítunk: a splitlines() a U+0085 / U+2028 / U+2029
    # karaktereken is törne, azok viszont egy címben simán előfordulhatnak.
    lines = [line.rstrip('\r') for line in content.split('\n') if line.strip()]
    if len(lines) < 2:
        control.log_error(u'Netflix Top 10: üres adatfájl')
        return None

    header = lines[0].split('\t')
    try:
        index = {name: header.index(name) for name in REQUIRED}
    except ValueError:
        control.log_error(u'Netflix Top 10: váratlan oszlopok -- %s' % header[:9])
        return None
    season_at = header.index('season_title') if 'season_title' in header else None

    rows = []
    week = ''
    for line in lines[1:]:
        cols = line.split('\t')
        if len(cols) <= max(index.values()):
            continue
        current = cols[index['week']]
        if current > week:
            # Új, frissebb hét: a korábban gyűjtött sorok elavultak.
            week, rows = current, []
        elif current < week:
            continue
        season = cols[season_at].strip() if season_at is not None and len(cols) > season_at else ''
        rows.append({
            'category': cols[index['category']].strip(),
            'rank': cols[index['weekly_rank']].strip(),
            'title': cols[index['show_title']].strip(),
            'season': '' if season in (EMPTY, '') else season,
            'thumb': '',
        })

    if not rows:
        control.log_error(u'Netflix Top 10: nem találtam feldolgozható sort')
        return None
    control.log(u'Netflix Top 10 (globális): %s hét, %d sor' % (week, len(rows)))
    return {'source': 'global', 'week': week, 'rows': rows}


def fetch_hu():
    '''
    Elsődleges forrás: a magyar kezdőlap.

    KÜLÖN cache-bejegyzés, szándékosan. A cache.get() nem ír ki None-t, ezért
    egy átmeneti hiba nem ragad be 24 órára -- a következő megnyitáskor újra
    próbálkozik. (Korábban a tartalék eredménye került a cache-be, és onnantól
    hiába jött vissza a magyar oldal, egy napig az angol lista maradt.)
    '''
    return parse_hu(client.request(HU_URL, headers=HU_HEADERS, timeout=TIMEOUT))


def fetch_global():
    '''Tartalék forrás: a hivatalos globális heti adatfájl (angol címek).'''
    return parse_global(client.request(TOP10_URL, timeout=TIMEOUT))


def by_category(data, category):
    '''Egy kategória sorai helyes sorrendben (a globális tartalékhoz).'''
    if not data:
        return []
    rows = [row for row in data.get('rows', []) if row.get('category') == category]
    return sorted(rows, key=lambda row: int(row['rank']) if row['rank'].isdigit() else 99)
