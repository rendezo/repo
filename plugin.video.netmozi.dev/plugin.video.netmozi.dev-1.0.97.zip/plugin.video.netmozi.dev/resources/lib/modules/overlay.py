# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Hozzászólás-átfedés lejátszás közben.
#
# show()-val jelenítjük meg, nem doModal()-lal: így NEM kap fókuszt, és a
# távirányító végig a lejátszót vezérli. Cserébe a lista magától görget
# (a skin XML autoscroll beállítása), mint egy élő chat.

import os
import re

import xbmc
import xbmcgui

from resources.lib.modules import comments, control

XML_FILE = 'CommentOverlay.xml'
CAPTURE_XML = 'KeyCapture.xml'
CAPTURE_LABEL_ID = 201
CAPTURE_TEXT_ID = 202

# Ezekkel lehet kilépni a tanításból, ezért nem tanuljuk meg őket.
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
CANCEL_ACTIONS = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK)
TITLE_ID = 101
TEXT_ID = 102


class CommentOverlay(xbmcgui.WindowXMLDialog):
    """
    SZÁNDÉKOSAN nincs saját __init__.

    A Kodi a konstruktor argumentumait a __new__-nak is átadja, ezért egyedi
    kulcsszavas paraméter (heading=, body=) TypeError-t okoz -- és mivel a
    hívás try/except-ben volt, ez némán elnyelődött. Az értékeket a
    példányosítás UTÁN állítjuk be.
    """

    heading = u'Hozzászólások'
    body = ''

    def onInit(self):
        try:
            self.getControl(TITLE_ID).setLabel(self.heading)
            self.getControl(TEXT_ID).setText(self.body)
        except Exception as exc:
            control.log_exception(u'hozzászólás-átfedés feltöltése', exc)


def build_body(entries):
    '''A hozzászólások egyetlen, görgethető szöveggé fűzve.'''
    blocks = []
    for entry in entries:
        blocks.append(u'%s\n%s' % (comments.format_line(entry), entry.get('text', '')))
    return u'\n\n'.join(blocks)


def create(title, entries):
    '''Átfedés példányosítása; None, ha nincs mit mutatni.'''
    if not entries:
        return None
    heading = u'Hozzászólások (%d)' % len(entries)
    if title:
        heading = u'%s  --  %s' % (title, heading)
    try:
        window = CommentOverlay(XML_FILE, control.addonPath, 'Default', '1080i')
    except Exception as exc:
        control.log_exception(u'hozzászólás-átfedés létrehozása', exc)
        return None
    window.heading = heading
    window.body = build_body(entries)
    return window


class KeyCapture(xbmcgui.WindowXMLDialog):
    """
    Megvárja, míg a néző megnyom egy gombot, és elkapja a kódját.

    Így nem kell naplót olvasni ahhoz, hogy kiderüljön, milyen kódot küld a
    távirányító egy-egy gombja -- TV-n ez amúgy is kivitelezhetetlen.
    """

    prompt = u'Nyomd meg a kívánt gombot'
    hint = u''
    captured = None

    def onInit(self):
        try:
            self.getControl(CAPTURE_LABEL_ID).setLabel(self.prompt)
            self.getControl(CAPTURE_TEXT_ID).setText(self.hint)
        except Exception as exc:
            control.log_exception(u'gombtanító feltöltése', exc)

    def onAction(self, action):
        try:
            action_id = action.getId()
            code = action.getButtonCode()
        except Exception as exc:
            control.log_exception(u'gomb kiolvasása', exc)
            return self.close()
        if action_id in CANCEL_ACTIONS:
            self.captured = None
            return self.close()
        if code:
            self.captured = code
            control.log(u'Betanított gombkód: %s (0x%X)' % (code, code))
            return self.close()


# A Kodi a HOZZÁRENDELETLEN gombokat is naplózza. Az onAction ezeket nem
# mindig látja, a napló viszont igen -- ezért van szükség erre a tartalékra.
ONKEY_RE = r'OnKey:\s*(\d+)\s*\('


def _log_path():
    return os.path.join(xbmc.translatePath('special://logpath/')
                        if hasattr(xbmc, 'translatePath')
                        else control.transPath('special://logpath/'), 'kodi.log')


def log_size():
    """A napló jelenlegi mérete, hogy csak az azutáni részt nézzük."""
    try:
        return os.path.getsize(_log_path())
    except OSError:
        return None


def key_from_log(since):
    """A `since` bájt óta naplózott UTOLSÓ gombkód, vagy None."""
    if since is None:
        return None
    try:
        with open(_log_path(), 'rb') as handle:
            handle.seek(since)
            chunk = handle.read(400000).decode('utf-8', 'replace')
    except (IOError, OSError) as exc:
        control.log_exception(u'napló olvasása', exc)
        return None
    codes = re.findall(ONKEY_RE, chunk)
    if not codes:
        return None
    try:
        return int(codes[-1])
    except ValueError:
        return None


def capture_key():
    """
    (kód, sikerult) pár.

    A kód None, ha a néző megszakította VAGY ha a gomb el sem jut a Kodiig
    -- ez utóbbi is hasznos információ, mert akkor más gombot kell választani.
    """
    try:
        window = KeyCapture(CAPTURE_XML, control.addonPath, 'Default', '1080i')
    except Exception as exc:
        control.log_exception(u'gombtanító létrehozása', exc)
        return None
    window.prompt = u'Nyomd meg a gombot, amit használni szeretnél'
    window.hint = (u'A bővítmény ezt fogja hozzárendelni a hozzászólásokhoz.\n\n'
                   u'Kilépés: Vissza gomb.')
    # A napló mérete a tanítás ELŐTT: ha az onAction nem látja a gombot,
    # a napló azóta írt részéből még kinyerhetjük a kódját.
    before = log_size()
    try:
        window.doModal()
    except Exception as exc:
        control.log_exception(u'gombtanító megjelenítése', exc)
        return None
    captured = window.captured
    del window
    if captured:
        control.log(u'Gomb elkapva közvetlenül: %s' % captured)
        return captured
    from_log = key_from_log(before)
    if from_log:
        control.log(u'Gomb a naplóból: %s' % from_log)
    return from_log
