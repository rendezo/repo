# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Részletes keresés: a feltételeket a néző összeállítja, és csak akkor
# indul a keresés, amikor rányom.
#
# A választható értékeket (műfaj, típus, nyelv, minőség, kezdőbetű) az
# oldal saját űrlapjából olvassuk ki, nem égetjük be -- így ha a netmozi
# bővíti a listát, magától követjük.

import re
from datetime import date
from urllib.parse import quote_plus

from resources.lib.modules import client, config, control

# A kereső űrlap select-jei: mezőkulcs -> (HTML id, URL paraméter, felirat)
SELECTS = (
    ('genre', 'exGenre', 'genre', u'Műfaj'),
    ('type', 'exType', 'type', u'Típus'),
    ('language', 'exLanguage', 'language', u'Nyelv'),
    ('quality', 'exQuality', 'quality', u'Minőség'),
    ('letter', 'exFirstLetter', 'first_letter', u'Kezdőbetű'),
)

# Szabadon beírható mezők: mezőkulcs -> (URL paraméter, felirat)
FREE_FIELDS = (
    ('title', 'search', u'Cím'),
    ('actor', 'actor', u'Színész / készítő'),
)

# Az évszámot is választani lehet, nem beírni: távirányítóval kényelmesebb.
# Ennyi évet kínálunk visszafelé a legfrissebbtől.
YEAR_SPAN = 26
YEAR_FIELDS = (
    ('yearfrom', 'year_from', u'Évszám ettől'),
    ('yearto', 'year_to', u'Évszám eddig'),
)

# Rövid, rögzített értékkészletű mezők: TV-n a választó kényelmesebb, mint
# a beírás. mezőkulcs -> (URL paraméter, felirat, értékek)
RATING_VALUES = tuple(str(value) for value in range(0, 11))
CHOICE_FIELDS = (
    ('ratingfrom', 'rating_from', u'IMDb értékelés ettől', RATING_VALUES),
    ('ratingto', 'rating_to', u'IMDb értékelés eddig', RATING_VALUES),
)


def year_values():
    '''A választható évszámok, a legfrissebbtől visszafelé.'''
    top = date.today().year
    return tuple(str(year) for year in range(top, top - YEAR_SPAN, -1))

# Az űrlap alapértéke; ha csak az egyik oldalt adja meg a néző, a másik ez.
RATING_MIN = '0'
RATING_MAX = '10'

# Megjelenítési sorrend, a netmozi űrlapját követve.
FIELD_ORDER = ('title', 'genre', 'type', 'yearfrom', 'yearto', 'language',
               'quality', 'ratingfrom', 'ratingto', 'letter', 'actor')

# A billentyűzetes mezők -- minden más választható.
TYPED_FIELDS = tuple(key for key, _param, _label in FREE_FIELDS)

ALL_FIELDS = FIELD_ORDER

OPTION_RE = r'<option[^>]*value="([^"]*)"[^>]*>(.*?)</option>'
SELECT_RE = r'<select[^>]*id="%s"[^>]*>(.*?)</select>'

# Ezek a "válassz" jellegű sorok nem valódi értékek.
PLACEHOLDERS = (u'válassz', u'--')

# A rendezés a részletes keresésnél is kell; ez az oldal alapértelmezettje.
DEFAULT_ORDER = '5'


def _clean(text):
    return client.replaceHTMLCodes(re.sub(r'<[^>]+>', '', text)).strip()


def parse_options(html):
    '''Mezőkulcs -> [(érték, felirat)] a keresőűrlap select-jeiből.'''
    result = {}
    if not html:
        return result
    for key, element_id, _param, _label in SELECTS:
        block = re.search(SELECT_RE % re.escape(element_id), html, re.S)
        if not block:
            control.log(u'Kereső: nincs ilyen választó: %s' % element_id,
                        control.LOGWARNING)
            continue
        options = []
        for value, text in re.findall(OPTION_RE, block.group(1), re.S):
            label = _clean(text)
            if not value or not label:
                continue
            if any(mark in label.lower() for mark in PLACEHOLDERS):
                continue
            options.append((value, label))
        if options:
            result[key] = options
    control.log(u'Kereső: %d választó, összesen %d opció'
                % (len(result), sum(len(v) for v in result.values())))
    return result


def fetch_options():
    '''cache.get() hívja; None = hiba, olyankor a régi érték marad.'''
    options = parse_options(client.request(config.BASE_URL))
    return options or None


def field_label(key):
    '''Egy mező felirata.'''
    for stored, _param, label in YEAR_FIELDS:
        if stored == key:
            return label
    for stored, _element_id, _param, label in SELECTS:
        if stored == key:
            return label
    for stored, _param, label in FREE_FIELDS:
        if stored == key:
            return label
    for stored, _param, label, _values in CHOICE_FIELDS:
        if stored == key:
            return label
    return key


def choice_values(key):
    '''A választható értékkészletű mezők lehetőségei, vagy None.'''
    for stored, _param, _label, values in CHOICE_FIELDS:
        if stored == key:
            return values
    if key in [stored for stored, _param, _label in YEAR_FIELDS]:
        return year_values()
    return None


def label_for(options, key, value):
    '''Egy beállított érték olvasható neve.'''
    for stored, label in options.get(key, ()):
        if stored == value:
            return label
    return value


def build_url(state, page=1, order=DEFAULT_ORDER):
    '''A netmozi lista-URL a megadott feltételekkel.'''
    parts = ['page=%s' % page, 'order=%s' % (order or DEFAULT_ORDER)]
    for key, _element_id, param, _label in SELECTS:
        parts.append('%s=%s' % (param, state.get(key, '') or ''))
    for key, param, _label in FREE_FIELDS:
        parts.append('%s=%s' % (param, quote_plus(state.get(key, '') or '')))

    # Az évszámnál MINDKÉT határt meg kell adni: ha csak az alsót küldjük,
    # az oldal nulla találatot ad vissza. (Élőben ellenőrizve.)
    low, high = state.get('yearfrom', ''), state.get('yearto', '')
    if low or high:
        years = year_values()
        parts.append('year_from=%s' % (low or years[-1]))
        parts.append('year_to=%s' % (high or years[0]))
    else:
        parts.append('year_from=')
        parts.append('year_to=')

    # Az értékelés csak akkor kerül be, ha a néző tényleg szűkített: a
    # 0-10 tartomány küldése felesleges zaj lenne.
    low, high = state.get('ratingfrom', ''), state.get('ratingto', '')
    if low or high:
        parts.append('rating_from=%s' % (low or RATING_MIN))
        parts.append('rating_to=%s' % (high or RATING_MAX))
    return '%s?%s' % (config.BASE_URL, '&'.join(parts))


def describe(state, options):
    '''Rövid összefoglaló a beállított feltételekről.'''
    parts = []
    for key in FIELD_ORDER:
        value = state.get(key)
        if not value:
            continue
        parts.append(u'%s: %s' % (field_label(key), label_for(options, key, value)))
    return u', '.join(parts) if parts else u'nincs feltétel'
