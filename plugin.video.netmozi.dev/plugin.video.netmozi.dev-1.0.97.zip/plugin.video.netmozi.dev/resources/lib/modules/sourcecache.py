# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# A forrás-ellenőrzés eredményének megjegyzése filmenként.
#
# Az ellenőrzés forrásonként másodpercekbe telik, ezért kár kétszer
# lefuttatni. Az eredményt a film netmozi-útvonalához kötve tároljuk.

import json
import os
import time

from resources.lib.modules import control

STORE_FILE = 'sourcescan.json'

# Ennél több film mérését nem tartjuk meg.
MAX_ENTRIES = 60


def _path():
    return os.path.join(control.dataPath, STORE_FILE)


def _read():
    try:
        with open(_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def load(page):
    '''
    Egy filmhez mért sebességek: {forrás URL: kB/s}, plusz a mérés ideje.

    Üres szótár, ha még nem mértük.
    '''
    entry = _read().get(page or '')
    if not isinstance(entry, dict):
        return {}, 0
    speeds = entry.get('speeds')
    return (speeds if isinstance(speeds, dict) else {}), entry.get('time', 0)


def save(page, speeds):
    '''Mérés eltárolása. A legrégebbi bejegyzések kiesnek.'''
    if not page:
        return False
    data = _read()
    data[page] = {'speeds': speeds, 'time': int(time.time())}
    if len(data) > MAX_ENTRIES:
        # A legrégebbi mérések esnek ki.
        for key in sorted(data, key=lambda k: data[k].get('time', 0))[:-MAX_ENTRIES]:
            data.pop(key, None)
    try:
        control.makeFile(control.dataPath)
        with open(_path(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        return True
    except (IOError, OSError, TypeError, ValueError) as exc:
        control.log_exception(u'forrásmérés mentése', exc)
        return False


def clear():
    try:
        os.remove(_path())
    except OSError:
        pass
