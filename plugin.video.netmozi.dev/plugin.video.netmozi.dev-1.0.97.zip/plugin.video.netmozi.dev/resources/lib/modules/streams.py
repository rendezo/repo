# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Streaming szolgáltatók "legnépszerűbb" listái.
#
# Mindegyik feldolgozó UGYANAZT az alakot adja vissza, hogy a menü ne tudja,
# melyik szolgáltatóval dolgozik:
#     {'source': <kulcs>, 'rows': [{'rank', 'title', 'thumb'}, ...]}
# Hibánál None -- a cache.get() ilyenkor nem ír ki semmit, tehát a következő
# megnyitás újra próbálkozik.
#
# A magyar oldalakat használjuk, mert MAGYAR címeket adnak: a netmozi keresője
# azokra jóval pontosabban talál, mint az eredeti angol címekre.
#
# HBO Max szándékosan hiányzik: a hbomax.com/hu/hu/shows oldal csak SEO-adatot
# ad vissza, a katalógust bejelentkezés után, kliensoldali API-ból tölti be,
# ezért szerveroldalról nem nyerhető ki. Lásd a README-t.

import json
import re

from resources.lib.modules import client, control, netflix

TIMEOUT = 60
HU_HEADERS = {'Accept-Language': 'hu-HU,hu;q=0.9,en;q=0.5'}


# --- Apple TV --------------------------------------------------------------
#
# Szerveroldalon renderelt oldal. A data-testid horgonyokra építünk, mert a
# CSS osztálynevek (svelte-1fla0gl) buildenként változnak.

APPLE_MOVIES_URL = ('https://tv.apple.com/hu/collection/alegnepszerubb-most/'
                    'uts.col.ChartsMovies.tvs.sbd.4000?l=hu')
APPLE_SHOWS_URL = ('https://tv.apple.com/hu/collection/alegnepszerubb-most/'
                   'uts.col.ChartsShows.tvs.sbd.4000?l=hu')

APPLE_ITEM_RE = r'data-testid="grid-item"(.*?)</li>'
APPLE_RANK_RE = r'data-testid="ordinal"[^>]*>\s*([0-9]{1,3})'
APPLE_ALT_RE = r'alt="([^"]{1,150})"'
APPLE_IMAGE_RE = r'srcset="(https://[^\s",]+)'


def parse_apple(content, key):
    if not content:
        return None
    rows = []
    for position, block in enumerate(re.findall(APPLE_ITEM_RE, content, re.S), start=1):
        # A cím a műsor logójának alt szövege; a korábbi alt-ok üresek vagy
        # dekoratív képekhez tartoznak, ezért az UTOLSÓ nem üres kell.
        alts = [alt.strip() for alt in re.findall(APPLE_ALT_RE, block) if alt.strip()]
        if not alts:
            continue
        rank = re.search(APPLE_RANK_RE, block)
        image = re.search(APPLE_IMAGE_RE, block)
        rows.append({
            'rank': rank.group(1) if rank else str(position),
            'title': client.replaceHTMLCodes(alts[-1]),
            'thumb': image.group(1) if image else '',
        })
    if not rows:
        control.log_error(u'%s: nem találtam listaelemet (változott az oldal?)' % key)
        return None
    control.log(u'%s: %d cím' % (key, len(rows)))
    return {'source': key, 'rows': rows}


# --- Prime Video -----------------------------------------------------------
#
# A tartalom egy beágyazott JSON blobban van; a Top 10 a "Charts" típusú
# konténer. Típus szerint keressük, nem pozíció szerint, mert a sorrend változhat.

PRIME_URL = ('https://www.primevideo.com/region/eu/storefront/'
             'ref=atv_nb_lcl_hu_HU?merchId=SVODTop10&language=hu_HU&ie=UTF8')
PRIME_BLOB_RE = r'<script[^>]*type="application/json"[^>]*>(.*?)</script>'
PRIME_CHART_TYPE = 'Charts'

# A Prime csak FEKVŐ borítót ad (1920x1080), a többi szolgáltató állót. Ha a
# fekvő képet tesszük a poszter helyére, a poszter-nézet megnyújtja. Az Amazon
# képszolgáltatója viszont tud szerveroldali 2:3 vágást, így egységes marad.
PRIME_TRANSFORM_RE = r'\._[A-Z0-9,_]+_\.'
PRIME_PORTRAIT = '._UR400,600_.'


def prime_poster(url):
    '''Álló, 2:3 arányú változat a fekvő borítóból (középre vágva).'''
    if not url:
        return ''
    return re.sub(PRIME_TRANSFORM_RE, PRIME_PORTRAIT, url)


def parse_prime(content, key='prime'):
    if not content:
        return None
    container = None
    for blob in re.findall(PRIME_BLOB_RE, content, re.S):
        try:
            data = json.loads(blob)
        except ValueError:
            continue
        containers = (data.get('init', {}).get('preparations', {})
                      .get('body', {}).get('containers'))
        if not isinstance(containers, list):
            continue
        for candidate in containers:
            if isinstance(candidate, dict) and candidate.get('containerType') == PRIME_CHART_TYPE:
                container = candidate
                break
        if container:
            break
    if not container:
        control.log_error(u'Prime Video: nem találtam "%s" konténert' % PRIME_CHART_TYPE)
        return None

    rows = []
    for position, entity in enumerate(container.get('entities', []), start=1):
        if not isinstance(entity, dict):
            continue
        title = entity.get('displayTitle') or entity.get('title')
        if not title:
            continue
        images = entity.get('images')
        thumb = ''
        if isinstance(images, dict):
            cover = images.get('cover')
            if isinstance(cover, dict):
                thumb = cover.get('url') or ''
            elif isinstance(cover, str):
                thumb = cover
        rows.append({'rank': str(position),
                     'title': client.replaceHTMLCodes(title.strip()),
                     'thumb': thumb,
                     'poster': prime_poster(thumb)})
    if not rows:
        control.log_error(u'Prime Video: a Top 10 konténer üres')
        return None
    control.log(u'Prime Video: %d cím' % len(rows))
    return {'source': key, 'rows': rows}


# --- Netflix ---------------------------------------------------------------
#
# A magyar kezdőlap feldolgozása a netflix modulban van, mert ahhoz tartozik
# a globális tartaléklista is.

def parse_netflix(content, key='netflix'):
    data = netflix.parse_hu(content)
    if data:
        data['source'] = key
    return data


# --- Regiszter -------------------------------------------------------------

# A 'short' a kombinált listában jelenik meg minden sor elején.
PROVIDERS = (
    {'key': 'netflix', 'label': u'Netflix', 'short': u'Netflix',
     'url': netflix.HU_URL, 'parse': parse_netflix},
    {'key': 'applemovies', 'label': u'Apple TV — Filmek', 'short': u'Apple film',
     'url': APPLE_MOVIES_URL, 'parse': parse_apple},
    {'key': 'appleshows', 'label': u'Apple TV — Sorozatok', 'short': u'Apple sorozat',
     'url': APPLE_SHOWS_URL, 'parse': parse_apple},
    {'key': 'prime', 'label': u'Prime Video', 'short': u'Prime',
     'url': PRIME_URL, 'parse': parse_prime},
)

# A "mind egyben" nézet kulcsa -- nem valódi szolgáltató.
ALL_KEY = 'all'

PROVIDER_BY_KEY = {provider['key']: provider for provider in PROVIDERS}


def fetch(key):
    '''Egy szolgáltató listája. cache.get() hívja, ezért None = hiba.'''
    provider = PROVIDER_BY_KEY.get(key)
    if not provider:
        control.log_error(u'Ismeretlen szolgáltató: %s' % key)
        return None
    content = client.request(provider['url'], headers=HU_HEADERS, timeout=TIMEOUT)
    return provider['parse'](content, key)
