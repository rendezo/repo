# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Integráció az Up Next kiegészítővel (service.upnext).
#
# Az Up Next egy háttérszolgáltatás, ami a rész vége felé felugró ablakot mutat
# visszaszámlálóval, és utána elindítja a következő részt. A bővítmény egy
# JSON-RPC "NotifyAll" üzenettel jelzi neki, mi megy most és mi jön utána; a
# következő rész elindítása onnantól az Up Next dolga.
#
# Az üzenet formátuma az AddonSignals konvencióját követi (a küldő azonosítója
# ".SIGNAL" végződést kap, az adat base64-elt JSON egy egyelemű listában),
# ezért nincs szükség a script.module.addon.signals függőségre.

import json
from base64 import b64encode

from resources.lib.modules import control

ADDON_ID = 'plugin.video.netmozi.dev'
UPNEXT_ADDON = 'service.upnext'
SIGNAL = 'upnext_data'


def available():
    '''Telepítve és engedélyezve van-e az Up Next.'''
    try:
        return bool(control.condVisibility('System.HasAddon(%s)' % UPNEXT_ADDON))
    except Exception as exc:
        control.log_exception(u'Up Next észlelése', exc)
        return False


def episode_info(title, showtitle, season, episode, art='', plot='', duration=0):
    '''Egy rész leírása az Up Next által várt mezőkkel.'''
    return {
        # Könyvtáron kívüli tartalomnál nincs valódi azonosító; az Up Next
        # csak megkülönböztetésre használja, ezért elég egy stabil string.
        'episodeid': '%s_s%s_e%s' % (showtitle, season, episode),
        'tvshowid': showtitle,
        'title': title,
        'art': {
            'thumb': art,
            'tvshow.poster': art,
            'tvshow.fanart': art,
            'tvshow.landscape': '',
            'tvshow.clearart': '',
            'tvshow.clearlogo': '',
        },
        'season': season,
        'episode': episode,
        'showtitle': showtitle,
        'plot': plot,
        'playcount': 0,
        'rating': None,
        'firstaired': '',
        'runtime': duration,
    }


def build_payload(current, following, play_url):
    '''Az Up Next-nek küldendő adatszerkezet.'''
    return {
        'current_episode': current,
        'next_episode': following,
        'play_url': play_url,
    }


def encode(payload):
    '''base64-elt JSON, ahogy az AddonSignals is küldi.'''
    return b64encode(json.dumps(payload).encode('utf-8')).decode('ascii')


def notify(current, following, play_url):
    '''
    Szólunk az Up Next-nek, mi megy most és mi jön utána.

    Csak akkor hívd, amikor a lejátszás MÁR fut -- az Up Next ekkor tudja
    a jelenlegi részhez kötni az adatot.
    '''
    if not following:
        return False
    payload = build_payload(current, following, play_url)
    request = json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'JSONRPC.NotifyAll',
        'params': {
            'sender': '%s.SIGNAL' % ADDON_ID,
            'message': SIGNAL,
            'data': [encode(payload)],
        },
    })
    try:
        control.jsonrpc(request)
        control.log(u'Up Next értesítve, következő: %s' % following.get('title'))
        return True
    except Exception as exc:
        control.log_exception(u'Up Next értesítés', exc)
        return False
