# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Az eredeti bővítmény változásainak figyelése.
#
# A saját águnk külön addon id-vel fut, ezért a Kodi soha nem frissíti felül --
# cserébe az eredeti javításait kézzel kell átemelni. Ez a modul megmutatja,
# hogy egyáltalán van-e mit átemelni.

import json
import os

from resources.lib.modules import client, control

REPO = 'vargalex/plugin.video.netmozi'
BRANCH = 'master'
API = 'https://api.github.com/repos/%s' % REPO
HEADERS = {'Accept': 'application/vnd.github+json'}

# Ezekben él a scraper és a lejátszási lánc; a többi változás minket nem érint.
WATCHED = ('resources/lib/indexers/navigator.py',
           'resources/lib/modules/client.py',
           'resources/lib/modules/cache.py',
           'addon.xml')

STATE_FILE = 'upstream.json'

# A szövegablak véges; ennél hosszabb kódrészletet nem írunk ki egy fájlhoz.
MAX_PATCH_LINES = 60


def _state_path():
    return os.path.join(control.dataPath, STATE_FILE)


def load_state():
    try:
        with open(_state_path(), encoding='utf-8') as handle:
            return json.load(handle)
    except (IOError, OSError, ValueError):
        return {}


def save_state(state):
    try:
        control.makeFile(control.dataPath)
        with open(_state_path(), 'w', encoding='utf-8') as handle:
            json.dump(state, handle, indent=2, ensure_ascii=False, sort_keys=True)
        return True
    except (IOError, OSError) as exc:
        control.log_exception(u'upstream állapot mentése', exc)
        return False


def _api(path):
    raw = client.request('%s%s' % (API, path), headers=HEADERS)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError as exc:
        control.log_exception(u'GitHub válasz feldolgozása', exc)
        return None


def check():
    '''
    (szöveges jelentés, fej-commit azonosítója) pár.

    A commit azonosító None, ha nem sikerült lekérni -- olyankor nem is
    szabad új alapállapotot rögzíteni.
    '''
    head = _api('/commits/%s' % BRANCH)
    if not head:
        return (u'Nem sikerült elérni a GitHubot.\n'
                u'Ellenőrizd a hálózatot, majd próbáld újra.'), None

    head_sha = head['sha']
    lines = [u'[B]Eredeti bővítmény: %s[/B]' % REPO,
             u'legutóbbi változás: %s -- %s'
             % (head['commit']['author']['date'][:10],
                head['commit']['message'].splitlines()[0])]

    baseline = load_state().get('commit')
    if not baseline:
        lines.append('')
        lines.append(u'Még nincs rögzített alapállapot. Ha a mostani állapotot')
        lines.append(u'már átnézted, a következő futtatás ezt veszi alapul.')
        return '\n'.join(lines), head_sha

    if baseline == head_sha:
        lines.append('')
        lines.append(u'[COLOR lightgreen]Nincs új változás az utolsó átnézés óta.[/COLOR]')
        return '\n'.join(lines), head_sha

    compare = _api('/compare/%s...%s' % (baseline, head_sha))
    if not compare:
        lines.append('')
        lines.append(u'Az összehasonlítás nem sikerült.')
        return '\n'.join(lines), None

    commits = compare.get('commits', [])
    files = compare.get('files', [])

    lines.append('')
    lines.append(u'[B]%d új commit az utolsó átnézés óta[/B]' % len(commits))
    for commit in commits:
        message = commit['commit']['message'].splitlines()
        lines.append('')
        lines.append(u'  [COLOR deepskyblue]%s[/COLOR]  %s'
                     % (commit['commit']['author']['date'][:10], message[0]))
        # A commit üzenet többi sora gyakran elmondja, MIT javítottak.
        for extra in message[1:]:
            if extra.strip():
                lines.append(u'      %s' % extra.strip())

    lines.append('')
    lines.append(u'[B]Érintett fájlok[/B]')
    important = []
    for entry in files:
        watched = entry['filename'] in WATCHED
        if watched:
            important.append(entry)
        lines.append(u'  %s%s[/COLOR]  +%s -%s'
                     % (u'[COLOR orange]' if watched else u'[COLOR gray]',
                        entry['filename'], entry['additions'], entry['deletions']))

    # A minket érintő fájloknál a KONKRÉT kódváltozás is érdekel.
    for entry in important:
        patch = entry.get('patch')
        if not patch:
            continue
        lines.append('')
        lines.append(u'[B]%s -- változások[/B]' % entry['filename'])
        patch_lines = patch.splitlines()
        for row in patch_lines[:MAX_PATCH_LINES]:
            if row.startswith('+') and not row.startswith('+++'):
                lines.append(u'  [COLOR lightgreen]%s[/COLOR]' % row)
            elif row.startswith('-') and not row.startswith('---'):
                lines.append(u'  [COLOR red]%s[/COLOR]' % row)
            elif row.startswith('@@'):
                lines.append(u'  [COLOR gray]%s[/COLOR]' % row)
            else:
                lines.append(u'  %s' % row)
        if len(patch_lines) > MAX_PATCH_LINES:
            lines.append(u'  [COLOR gray]... még %d sor. A teljes eltéréshez:[/COLOR]'
                         % (len(patch_lines) - MAX_PATCH_LINES))
            lines.append(u'  [COLOR gray]python3 tools/check_upstream.py --diff[/COLOR]')

    lines.append('')
    if important:
        lines.append(u'[COLOR orange]%d olyan fájl változott, ami minket is érint.[/COLOR]'
                     % len(important))
    else:
        lines.append(u'[COLOR lightgreen]A minket érintő fájlok nem változtak.[/COLOR]')
    return '\n'.join(lines), head_sha
