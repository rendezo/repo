# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import unicodedata


def safeopen(filepath, mode):
    '''UTF-8 kódolású fájlnyitás.'''
    return open(filepath, mode, encoding='utf-8')


def first(items, default=None):
    '''
    Lista első eleme, vagy `default`.

    A scraper mindenhol `parseDOM(...)[0]`-t hívott: ha az oldal szerkezete
    változott, ez IndexError-t dobott, aminek a szövegéből nem derült ki,
    MELYIK szelektor bukott el. Ezzel a hiba kezelhető helyre kerül.
    '''
    return items[0] if items else default


def at(items, index, default=None):
    '''Lista indexelése IndexError nélkül (negatív index is működik).'''
    try:
        return items[index]
    except (IndexError, TypeError):
        return default


def to_int(value, default=0):
    '''Az első egész szám kinyerése egy szövegből.'''
    if isinstance(value, int):
        return value
    try:
        match = re.search(r'-?\d+', str(value))
        return int(match.group(0)) if match else default
    except (TypeError, ValueError):
        return default


def absolute_url(url, scheme='https'):
    '''A protokoll nélküli ("//host/...") hivatkozások kiegészítése.'''
    if not url:
        return url
    if url.startswith('//'):
        return '%s:%s' % (scheme, url)
    return url


def normalize_title(text):
    """
    Összehasonlításra alkalmas alak: kisbetűs, ékezet és írásjel nélkül.

    A netmozi és a streaming szolgáltatók eltérően írják ugyanazt a címet
    (kötőjel, felkiáltójel, "A"/"Az" névelő, ékezetek), ezért a nyers
    összehasonlítás használhatatlan.
    """
    if not text:
        return ''
    text = unicodedata.normalize('NFKD', text)
    text = ''.join(char for char in text if not unicodedata.combining(char))
    return re.sub(r'[^0-9a-z]+', ' ', text.lower()).strip()
