# -*- coding: utf-8 -*-

'''
    NetMozi Add-on
    Copyright (C) 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

# Háttérszolgáltatás: a hozzászólás-átfedés megjelenítése lejátszás közben.
#
# Erre azért van szükség, mert a plugin rövid életű -- a lista felépítése
# vagy az URL feloldása után kilép, tehát nem tud ott lenni a film alatt.
# A szolgáltatás viszont végig fut, és figyeli a lejátszót.
#
# A hozzászólásokat NEM ez tölti le: a plugin nyeri ki őket az adatlapból,
# amit amúgy is letölt, és fájlba teszi. Így itt nincs hálózati munka.

import time

import xbmc
import xbmcaddon

from resources.lib.modules import comments, control, overlay

# Ennyit várunk a lejátszás indulása után, hogy a kép már fent legyen.
# Beállításból jön; ez csak a tartalék, ha nem olvasható.
DEFAULT_DELAY = 2


def show_delay():
    try:
        value = int(xbmcaddon.Addon().getSetting('commentdelay'))
    except (ValueError, TypeError, Exception):
        return DEFAULT_DELAY
    return max(0, value)


def enabled():
    try:
        return xbmcaddon.Addon().getSettingBool('commentoverlay')
    except Exception:
        return False


def show_overlay():
    """Átfedés megnyitása. None-t ad, ha nincs mit vagy nem sikerült."""
    title, entries = comments.load()
    if not entries:
        control.log(u'Átfedés kihagyva: nincs eltárolt hozzászólás')
        return None
    window = overlay.create(title, entries)
    if window is None:
        control.log_error(u'Az átfedés ablakot nem sikerült létrehozni')
        return None
    try:
        # show() és nem doModal(): nem visszük el a fókuszt a lejátszótól.
        window.show()
    except Exception as exc:
        control.log_exception(u'átfedés megjelenítése', exc)
        return None
    control.log(u'Hozzászólás-átfedés megjelenítve: %d db' % len(entries))
    return window


def close_overlay(window):
    if window is None:
        return None
    try:
        window.close()
    except Exception as exc:
        control.log_exception(u'átfedés bezárása', exc)
    return None


def main():
    """
    Lejátszás figyelése LEKÉRDEZÉSSEL, nem visszahívásokkal.

    A lejátszó visszahívásainak gyorsan vissza kell térniük -- ott várakozni
    megbízhatatlan. Másodpercenként megnézzük, megy-e a lejátszás, és pár
    másodperc után nyitjuk az átfedést, hogy a kép már fent legyen.
    """
    control.log(u'Szolgáltatás indul')
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    window = None
    started = None
    delay = show_delay()
    shown_once = False
    # Fél másodperces ütem: a gombnyomásra adott válasz feleannyit várat.
    tick = 0.5

    while not monitor.abortRequested():
        if monitor.waitForAbort(tick):
            break
        try:
            playing = player.isPlaying()
        except Exception:
            playing = False

        if not playing:
            window = close_overlay(window)
            started = None
            shown_once = False
            # Új lejátszásnál a friss beállítás érvényesüljön.
            delay = show_delay()
            continue

        if started is None:
            started = time.time()

        # A néző visszakérte (távirányító gomb -> plugin -> kérés-fájl).
        if comments.take_request():
            window = close_overlay(window)
            window = show_overlay()
            continue

        if window is not None or (time.time() - started) < delay:
            continue
        if not enabled() or shown_once:
            continue
        window = show_overlay()
        # Sikertelen megjelenítést ne ismételgessünk másodpercenként.
        shown_once = True

    close_overlay(window)
    comments.clear()
    control.log(u'Szolgáltatás leáll')


if __name__ == '__main__':
    main()
